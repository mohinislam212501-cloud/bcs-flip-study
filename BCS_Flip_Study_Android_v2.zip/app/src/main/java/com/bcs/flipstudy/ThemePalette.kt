package com.bcs.flipstudy

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

data class AppPalette(
    val id: String,
    val label: String,
    val cardBg: Int,
    val cardBorder: Int,
    val ringStart: Int,
    val ringEnd: Int,
    val studyBg: Int,
    val studyBorder: Int,
    val studyText: Int,
    val wasteBg: Int,
    val wasteBorder: Int,
    val wasteText: Int,
    val statusBg: Int,
    val statusBorder: Int,
    val statusText: Int,
    val accent: Int,
    val pillActiveBg: Int,
    val pillActiveBorder: Int,
    val pillActiveText: Int
)

object ThemePalette {

    fun get(id: String, isNight: Boolean): AppPalette {
        if (!isNight) {
            return when (id) {
                "sage" -> AppPalette(
                    "sage", "সেজ ও অ্যাম্বার",
                    Color.parseColor("#FFFFFF"), Color.parseColor("#DDE8E3"),
                    Color.parseColor("#0D7C66"), Color.parseColor("#34D399"),
                    Color.parseColor("#0E7761"), Color.parseColor("#0E7761"), Color.WHITE,
                    Color.parseColor("#B84A4A"), Color.parseColor("#B84A4A"), Color.WHITE,
                    Color.parseColor("#0D5C54"), Color.parseColor("#0D5C54"), Color.WHITE,
                    Color.parseColor("#0E7761"),
                    Color.parseColor("#0D5C54"), Color.parseColor("#0D5C54"), Color.WHITE
                )
                "espresso" -> AppPalette(
                    "espresso", "এসপ্রেসো ও টিল",
                    Color.parseColor("#FFFDF9"), Color.parseColor("#E5DDD3"),
                    Color.parseColor("#0F766E"), Color.parseColor("#2DD4BF"),
                    Color.parseColor("#0F766E"), Color.parseColor("#0F766E"), Color.WHITE,
                    Color.parseColor("#BA5252"), Color.parseColor("#BA5252"), Color.WHITE,
                    Color.parseColor("#B47B0A"), Color.parseColor("#B47B0A"), Color.WHITE,
                    Color.parseColor("#0F766E"),
                    Color.parseColor("#0F766E"), Color.parseColor("#0F766E"), Color.WHITE
                )
                "nordic" -> AppPalette(
                    "nordic", "নর্ডিক ও অরোরা",
                    Color.parseColor("#FFFFFF"), Color.parseColor("#DCE6EE"),
                    Color.parseColor("#0284C7"), Color.parseColor("#2DD4BF"),
                    Color.parseColor("#0F6C8C"), Color.parseColor("#0F6C8C"), Color.WHITE,
                    Color.parseColor("#B85463"), Color.parseColor("#B85463"), Color.WHITE,
                    Color.parseColor("#C27838"), Color.parseColor("#C27838"), Color.WHITE,
                    Color.parseColor("#0284C7"),
                    Color.parseColor("#0F6C8C"), Color.parseColor("#0F6C8C"), Color.WHITE
                )
                else -> AppPalette( // "ocean" (Color 2 - DEFAULT)
                    "ocean", "ডিপ ওশান ও ইন্ডিগো",
                    Color.parseColor("#FFFFFF"), Color.parseColor("#DCE3F0"),
                    Color.parseColor("#3B82F6"), Color.parseColor("#6366F1"),
                    Color.parseColor("#3B5BDB"), Color.parseColor("#3B5BDB"), Color.WHITE,
                    Color.parseColor("#C44D4D"), Color.parseColor("#C44D4D"), Color.WHITE,
                    Color.parseColor("#3B5BDB"), Color.parseColor("#3B5BDB"), Color.WHITE,
                    Color.parseColor("#4F46E5"),
                    Color.parseColor("#3B5BDB"), Color.parseColor("#3B5BDB"), Color.WHITE
                )
            }
        }

        // Pure Black AMOLED Night Palettes (eye-friendly, low-glare!)
        return when (id) {
            "sage" -> AppPalette(
                "sage", "সেজ ও অ্যাম্বার",
                Color.parseColor("#121716"), Color.parseColor("#21302C"),
                Color.parseColor("#10B981"), Color.parseColor("#34D399"),
                Color.parseColor("#081C17"), Color.parseColor("#34D399"), Color.parseColor("#E6FAF3"),
                Color.parseColor("#1E1010"), Color.parseColor("#D97777"), Color.parseColor("#FDECEC"),
                Color.parseColor("#0B241D"), Color.parseColor("#34D399"), Color.parseColor("#A7F3D0"),
                Color.parseColor("#34D399"),
                Color.parseColor("#0C261F"), Color.parseColor("#34D399"), Color.parseColor("#6EE7B7")
            )
            "espresso" -> AppPalette(
                "espresso", "এসপ্রেসো ও টিল",
                Color.parseColor("#161412"), Color.parseColor("#2C2621"),
                Color.parseColor("#14B8A6"), Color.parseColor("#2DD4BF"),
                Color.parseColor("#0A1D1B"), Color.parseColor("#2DD4BF"), Color.parseColor("#E6FAF8"),
                Color.parseColor("#1F1111"), Color.parseColor("#D87070"), Color.parseColor("#FCEAEA"),
                Color.parseColor("#261D0B"), Color.parseColor("#EAB308"), Color.parseColor("#FDE68A"),
                Color.parseColor("#2DD4BF"),
                Color.parseColor("#0D2422"), Color.parseColor("#2DD4BF"), Color.parseColor("#5EEAD4")
            )
            "nordic" -> AppPalette(
                "nordic", "নর্ডিক ও অরোরা",
                Color.parseColor("#141920"), Color.parseColor("#25303D"),
                Color.parseColor("#5EEAD4"), Color.parseColor("#7DD3FC"),
                Color.parseColor("#0C1E24"), Color.parseColor("#5EEAD4"), Color.parseColor("#E6FAFC"),
                Color.parseColor("#211115"), Color.parseColor("#DE6E7B"), Color.parseColor("#FDECEF"),
                Color.parseColor("#261A10"), Color.parseColor("#FDBA74"), Color.parseColor("#FFEDD5"),
                Color.parseColor("#7DD3FC"),
                Color.parseColor("#132636"), Color.parseColor("#7DD3FC"), Color.parseColor("#BAE6FD")
            )
            else -> AppPalette( // "ocean" (Color 2 - DEFAULT!)
                "ocean", "ডিপ ওশান ও ইন্ডিগো",
                Color.parseColor("#10141D"), Color.parseColor("#222C42"),
                Color.parseColor("#60A5FA"), Color.parseColor("#818CF8"),
                Color.parseColor("#0F182E"), Color.parseColor("#60A5FA"), Color.parseColor("#EFF6FF"),
                Color.parseColor("#211112"), Color.parseColor("#E57373"), Color.parseColor("#FEECEC"),
                Color.parseColor("#151F3B"), Color.parseColor("#818CF8"), Color.parseColor("#DBEAFE"),
                Color.parseColor("#818CF8"),
                Color.parseColor("#162140"), Color.parseColor("#818CF8"), Color.parseColor("#C7D2FE")
            )
        }
    }

    fun makeBg(ctx: Context, fill: Int, stroke: Int, radiusDp: Float, strokeDp: Float = 1.2f): GradientDrawable {
        val d = ctx.resources.displayMetrics.density
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusDp * d
            setColor(fill)
            if (strokeDp > 0f) setStroke((strokeDp * d).toInt().coerceAtLeast(1), stroke)
        }
    }
}

object CategoryColors {
    const val WASTE_HEX = "#EF4444"
    const val EAT_HEX = "#F59E0B"
    const val AWAY_HEX = "#14B8A6"
    const val SLEEP_HEX = "#6366F1"

    val WASTE_INT: Int = Color.parseColor(WASTE_HEX)
    val EAT_INT: Int = Color.parseColor(EAT_HEX)
    val AWAY_INT: Int = Color.parseColor(AWAY_HEX)
    val SLEEP_INT: Int = Color.parseColor(SLEEP_HEX)
}

object ReasonCatalog {
    val DEFAULT_WASTE_REASONS = listOf(
        "সোশ্যাল মিডিয়া/ভিডিও",
        "গেম",
        "আড্ডা/গল্প",
        "ক্লান্তি/ঝিমুনি",
        "অন্যান্য কাজ"
    )
    val DEFAULT_AWAY_REASONS = listOf(
        "কোচিং/ক্লাস",
        "বাজার/কাজ",
        "আত্মীয়/সামাজিক",
        "ভ্রমণ",
        "অন্যান্য"
    )
    fun mapLegacyWasteReason(raw: String): String = when (raw.trim()) {
        "ফোন স্ক্রলিং" -> "সোশ্যাল মিডিয়া/ভিডিও"
        else -> raw
    }
}
