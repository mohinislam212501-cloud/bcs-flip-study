package com.bcs.flipstudy

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import java.util.Calendar
import java.util.Locale

object FlipAudioManager {

    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile
    private var tts: TextToSpeech? = null
    @Volatile
    private var ttsReady = false
    @Volatile
    private var pendingSpeech: String? = null
    private val autoReleaseRunnable = Runnable {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {}
        tts = null
        ttsReady = false
    }

    private fun scheduleTtsAutoSleep() {
        mainHandler.removeCallbacks(autoReleaseRunnable)
        mainHandler.postDelayed(autoReleaseRunnable, 30_000L)
    }

    private fun isInQuietHours(ctx: Context): Boolean {
        if (!DataStore.isFlipAudioQuietMute(ctx)) return false
        if (!DataStore.isSrQuietOn(ctx)) return false
        val start = DataStore.getSrQuietStartMin(ctx)
        val end = DataStore.getSrQuietEndMin(ctx)
        if (start == end) return false
        val cal = Calendar.getInstance()
        val nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        return if (start > end) (nowMin >= start || nowMin < end) else (nowMin in start until end)
    }

    fun onFlipStudyOn(ctx: Context) {
        if (isInQuietHours(ctx)) return
        playForMode(ctx, DataStore.getFlipAudioMode(ctx), isStart = true)
    }

    fun onFlipStudyOff(ctx: Context) {
        if (isInQuietHours(ctx)) return
        playForMode(ctx, DataStore.getFlipAudioMode(ctx), isStart = false)
    }

    fun playTest(ctx: Context) {
        val mode = DataStore.getFlipAudioMode(ctx)
        val effective = if (mode == "off") "tone" else mode
        playForMode(ctx, effective, isStart = true)
    }

    private fun playForMode(ctx: Context, mode: String, isStart: Boolean) {
        when (mode) {
            "tone" -> playSoftTone(isStart)
            "voice" -> speakBengali(ctx, if (isStart) "পড়া শুরু হয়েছে" else "পড়া বিরতিতে", fallbackTone = true, isStart = isStart)
            "both" -> {
                playSoftTone(isStart)
                mainHandler.postDelayed({
                    speakBengali(ctx, if (isStart) "পড়া শুরু হয়েছে" else "পড়া বিরতিতে", fallbackTone = false, isStart = isStart)
                }, 260L)
            }
        }
    }

    private fun playSoftTone(isStart: Boolean) {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
            val tone = if (isStart) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_BEEP
            val dur = if (isStart) 220 else 140
            tg.startTone(tone, dur)
            mainHandler.postDelayed({
                try { tg.release() } catch (_: Exception) {}
            }, dur + 120L)
        } catch (_: Exception) {}
    }

    private fun speakBengali(ctx: Context, text: String, fallbackTone: Boolean, isStart: Boolean) {
        val appCtx = ctx.applicationContext
        val engine = tts
        if (engine != null && ttsReady) {
            try {
                engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "flip_audio_${System.currentTimeMillis()}")
                scheduleTtsAutoSleep()
            } catch (_: Exception) {
                if (fallbackTone) playSoftTone(isStart)
            }
            return
        }
        pendingSpeech = text
        if (engine == null) {
            try {
                var created: TextToSpeech? = null
                created = TextToSpeech(appCtx) { status ->
                    if (status == TextToSpeech.SUCCESS) {
                        val t = created ?: return@TextToSpeech
                        val bdRes = t.setLanguage(Locale("bn", "BD"))
                        val okLang = bdRes != TextToSpeech.LANG_MISSING_DATA && bdRes != TextToSpeech.LANG_NOT_SUPPORTED
                        if (!okLang) {
                            val inRes = t.setLanguage(Locale("bn", "IN"))
                            if (inRes == TextToSpeech.LANG_MISSING_DATA || inRes == TextToSpeech.LANG_NOT_SUPPORTED) {
                                ttsReady = false
                                if (fallbackTone) playSoftTone(isStart)
                                return@TextToSpeech
                            }
                        }
                        try {
                            val bestVoice = t.voices
                                ?.filter { it.locale?.language.equals("bn", ignoreCase = true) }
                                ?.maxByOrNull { v ->
                                    var sc = v.quality
                                    val n = v.name.lowercase()
                                    if (n.contains("network") || n.contains("neural") || n.contains("wavenet")) sc += 300
                                    if (v.locale?.country.equals("BD", ignoreCase = true)) sc += 50
                                    sc
                                }
                            if (bestVoice != null) t.voice = bestVoice
                        } catch (_: Exception) {}
                        t.setSpeechRate(0.95f)
                        t.setPitch(0.97f)
                        ttsReady = true
                        val queued = pendingSpeech
                        pendingSpeech = null
                        if (!queued.isNullOrBlank()) {
                            try {
                                t.speak(queued, TextToSpeech.QUEUE_FLUSH, null, "flip_audio_init")
                                scheduleTtsAutoSleep()
                            } catch (_: Exception) {}
                        }
                    } else {
                        ttsReady = false
                        if (fallbackTone) playSoftTone(isStart)
                    }
                }
                tts = created
            } catch (_: Exception) {
                if (fallbackTone) playSoftTone(isStart)
            }
        }
    }
}
