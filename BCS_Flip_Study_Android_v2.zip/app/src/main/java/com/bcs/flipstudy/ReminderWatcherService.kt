package com.bcs.flipstudy

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * হালকা ফোরগ্রাউন্ড ওয়াচার সার্ভিস:
 * কোনো লুপ বা WakeLock নেই — শুধু ডাইনামিক SCREEN_ON / SCREEN_OFF রিসিভার ধরে রাখে।
 */
class ReminderWatcherService : Service() {

    companion object {
        const val ACTION_START_WATCHER = "com.bcs.flipstudy.START_WATCHER"
    }

    private var screenReceiverRegistered = false

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_ON -> SmartReminderManager.onScreenOn(context)
                Intent.ACTION_SCREEN_OFF -> SmartReminderManager.onScreenOff(context)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createWatcherChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Android 12+ ফোরগ্রাউন্ড সার্ভিস ক্র্যাশ এড়াতে আগে startForeground, তারপর বন্ধের সিদ্ধান্ত
        startForeground(SmartReminderManager.NOTIF_WATCHER_ID, buildWatcherNotification())
        if (!DataStore.isSrEnabled(this)) {
            stopSelf()
            return START_NOT_STICKY
        }

        registerScreenReceiverIfNeeded()
        return START_STICKY
    }

    private fun registerScreenReceiverIfNeeded() {
        if (screenReceiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        registerReceiver(screenReceiver, filter)
        screenReceiverRegistered = true
    }

    private fun buildWatcherNotification(): Notification {
        val openPi = PendingIntent.getActivity(
            this, 4005, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, SmartReminderManager.CHANNEL_WATCHER)
            .setSmallIcon(R.drawable.ic_notif_mascot)
            .setContentTitle("স্মার্ট রিমাইন্ডার চালু আছে")
            .setContentText("ফোন চালানো ও বিরতির স্মার্ট পপ-আপ সক্রিয়")
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(openPi)
            .build()
    }

    private fun createWatcherChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(SmartReminderManager.CHANNEL_WATCHER) == null) {
                val ch = NotificationChannel(
                    SmartReminderManager.CHANNEL_WATCHER,
                    "স্মার্ট রিমাইন্ডার সার্ভিস",
                    NotificationManager.IMPORTANCE_MIN
                ).apply {
                    setShowBadge(false)
                }
                nm.createNotificationChannel(ch)
            }
        }
    }

    override fun onDestroy() {
        if (screenReceiverRegistered) {
            try { unregisterReceiver(screenReceiver) } catch (_: Exception) {}
            screenReceiverRegistered = false
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
