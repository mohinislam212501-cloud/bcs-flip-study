package com.bcs.flipstudy

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

class DonutPieChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    data class Slice(
        val label: String,
        val valueSec: Long,
        val color: Int
    )

    private var slices: List<Slice> = emptyList()
    private var totalSec: Long = 0L
    private var selectedIndex: Int = -1
    private var animProgress: Float = 1f
    private var textMainColor: Int = 0xFF101828.toInt()
    private var textMutedColor: Int = 0xFF667085.toInt()
    private var bgHoleColor: Int = 0xFFFFFFFF.toInt()
    private var animator: ValueAnimator? = null

    var onSliceSelected: ((Int) -> Unit)? = null

    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.BUTT
    }
    private val centerValPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val centerSubPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
    }
    private val arcRect = RectF()
    private val popRect = RectF()

    fun setData(
        items: List<Slice>,
        mainTextColor: Int,
        mutedTextColor: Int,
        holeColor: Int
    ) {
        slices = items.filter { it.valueSec > 0L }
        totalSec = slices.sumOf { it.valueSec }.coerceAtLeast(1L)
        selectedIndex = -1
        textMainColor = mainTextColor
        textMutedColor = mutedTextColor
        bgHoleColor = holeColor

        animator?.cancel()
        animProgress = 0f
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 460L
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                animProgress = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun selectIndex(index: Int) {
        selectedIndex = if (index == selectedIndex) -1 else index
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (slices.isEmpty()) return

        val d = resources.displayMetrics.density
        val cx = width / 2f
        val cy = height / 2f
        val strokeW = 28f * d
        val popOffset = 6f * d
        val radius = (min(width, height) / 2f) - strokeW / 2f - popOffset - 4f * d
        if (radius <= 10f) return

        arcPaint.strokeWidth = strokeW
        arcRect.set(cx - radius, cy - radius, cx + radius, cy + radius)

        val gapDeg = if (slices.size > 1) 2.2f else 0f
        var startAngle = -90f
        val maxSweep = 360f * animProgress

        for (i in slices.indices) {
            val s = slices[i]
            val rawSweep = (s.valueSec.toFloat() / totalSec.toFloat()) * 360f
            val sweep = (rawSweep - gapDeg).coerceAtLeast(1.2f)
            val drawnStart = startAngle
            val remaining = (startAngle + 90f)
            if (remaining >= maxSweep) break
            val visibleSweep = min(sweep, maxSweep - remaining).coerceAtLeast(0.5f)

            arcPaint.color = s.color
            arcPaint.alpha = if (selectedIndex == -1 || selectedIndex == i) 255 else 95

            if (selectedIndex == i) {
                val midRad = Math.toRadians((drawnStart + rawSweep / 2f).toDouble())
                val dx = (cos(midRad) * popOffset).toFloat()
                val dy = (sin(midRad) * popOffset).toFloat()
                popRect.set(arcRect.left + dx, arcRect.top + dy, arcRect.right + dx, arcRect.bottom + dy)
                canvas.drawArc(popRect, drawnStart, visibleSweep, false, arcPaint)
            } else {
                canvas.drawArc(arcRect, drawnStart, visibleSweep, false, arcPaint)
            }
            startAngle += rawSweep
        }

        // Center Text
        centerValPaint.color = textMainColor
        centerValPaint.textSize = 18f * d
        centerSubPaint.color = textMutedColor
        centerSubPaint.textSize = 11.5f * d

        if (selectedIndex in slices.indices) {
            val sel = slices[selectedIndex]
            val pct = ((sel.valueSec * 100.0) / totalSec).toInt().coerceIn(1, 100)
            val title = if (sel.label.length > 14) sel.label.take(13) + "…" else sel.label
            canvas.drawText(DataStore.formatHoursMinBn(sel.valueSec), cx, cy - 2f * d, centerValPaint)
            canvas.drawText("$title · ${DataStore.toBnDigits(pct)}%", cx, cy + 16f * d, centerSubPaint)
        } else {
            canvas.drawText(DataStore.formatHoursMinBn(totalSec), cx, cy - 2f * d, centerValPaint)
            canvas.drawText("মোট সময়", cx, cy + 16f * d, centerSubPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP && slices.isNotEmpty()) {
            val cx = width / 2f
            val cy = height / 2f
            val dx = event.x - cx
            val dy = event.y - cy
            val dist = hypot(dx.toDouble(), dy.toDouble()).toFloat()
            val d = resources.displayMetrics.density
            val outerR = min(width, height) / 2f
            val innerR = outerR - 52f * d
            if (dist in innerR..outerR) {
                var angle = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat() + 90f
                if (angle < 0f) angle += 360f
                var acc = 0f
                for (i in slices.indices) {
                    val sweep = (slices[i].valueSec.toFloat() / totalSec.toFloat()) * 360f
                    if (angle in acc..(acc + sweep)) {
                        selectIndex(i)
                        onSliceSelected?.invoke(selectedIndex)
                        return true
                    }
                    acc += sweep
                }
            } else if (selectedIndex != -1) {
                selectIndex(-1)
                onSliceSelected?.invoke(-1)
                return true
            }
        }
        return true
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        super.onDetachedFromWindow()
    }
}
