package com.bcs.flipstudy

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * ব্যাটারি-সাশ্রয়ী ফ্লোটিং পপ-আপ ওভারলে:
 * - স্ক্রিন চালু ও ওভারলে চালু থাকলে শুধু এই ৬০fps পপ-আপ দেখায়।
 * - কোনো বাটন না চেপে কেটে দিলে বা ১৫ সেকেন্ড পর অটো সরে গেলে নির্ধারিত সেকেন্ড (ডিফল্ট ২০ সে.) পর
 *   সিস্টেম নোটিফিকেশন ফলো-আপ সিডিউল করে।
 * - [পড়ছি না] বাটন চেপে ধরলে (Long Press) "খাচ্ছি" মোড চালু হয়।
 */
object SmartReminderPopupOverlay {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var currentView: View? = null
    private var currentWebView: WebView? = null
    private var windowManager: WindowManager? = null
    private var pendingDismissRunnable: Runnable? = null

    fun canDrawOverlay(ctx: Context): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(ctx)
    }

    fun show(
        ctx: Context,
        kind: String,
        level: Int,
        elapsedMin: Int = 0,
        msgIndex: Int = 0,
        isPreview: Boolean = false
    ) {
        val appCtx = ctx.applicationContext
        if (!canDrawOverlay(appCtx)) return
        if (!DataStore.isSrPopupOverlayOn(appCtx) && !isPreview) return

        mainHandler.post {
            try {
                dismissInternal()
                val wm = appCtx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                windowManager = wm

                val dm = appCtx.resources.displayMetrics
                fun dp(v: Int): Int = (v * dm.density).toInt()

                val character = MascotContent.resolveCharacter(appCtx)
                val accent = MascotContent.accentColorFor(character, level)
                val title = MascotContent.titleFor(kind, level, elapsedMin)
                val msg = MascotContent.messageFor(appCtx, kind, level, elapsedMin, msgIndex)

                var actionTaken = false

                fun closeAndMaybeFallback() {
                    dismissInternal()
                    if (!actionTaken && !isPreview) {
                        SmartReminderManager.onPopupDismissedWithoutAction(appCtx, kind, level, elapsedMin, msgIndex)
                    }
                }

                val root = FrameLayout(appCtx).apply {
                    setPadding(dp(12), dp(10), dp(12), dp(6))
                }

                val cardBg = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(22).toFloat()
                    setColor(Color.parseColor("#F50D111C"))
                    setStroke(dp(2), accent)
                }

                val card = LinearLayout(appCtx).apply {
                    orientation = LinearLayout.VERTICAL
                    background = cardBg
                    setPadding(dp(12), dp(10), dp(12), dp(10))
                    elevation = dp(12).toFloat()
                }

                // Top Row: 60fps Mascot + Title/Msg + Close
                val topRow = LinearLayout(appCtx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }

                val animBox = FrameLayout(appCtx).apply {
                    layoutParams = LinearLayout.LayoutParams(dp(82), dp(82)).apply {
                        marginEnd = dp(10)
                    }
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = dp(14).toFloat()
                        setColor(Color.parseColor("#0B0F17"))
                    }
                    clipToOutline = true
                }

                val webView = createMascotWebView(appCtx, character, level)
                if (webView != null) {
                    currentWebView = webView
                    animBox.addView(webView, FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT
                    ))
                } else {
                    val iv = ImageView(appCtx).apply {
                        setImageResource(MascotContent.mascotResFor(character, level))
                        scaleType = ImageView.ScaleType.FIT_CENTER
                    }
                    animBox.addView(iv, FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT
                    ))
                }
                topRow.addView(animBox)

                val textCol = LinearLayout(appCtx).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }

                val headerRow = LinearLayout(appCtx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                val tvTitle = TextView(appCtx).apply {
                    text = title
                    setTextColor(accent)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
                    typeface = Typeface.DEFAULT_BOLD
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val btnClose = TextView(appCtx).apply {
                    text = "✕"
                    setTextColor(Color.parseColor("#94A3B8"))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                    setPadding(dp(8), dp(2), dp(4), dp(2))
                    setOnClickListener { closeAndMaybeFallback() }
                }
                headerRow.addView(tvTitle)
                headerRow.addView(btnClose)
                textCol.addView(headerRow)

                val tvMsg = TextView(appCtx).apply {
                    text = msg
                    setTextColor(Color.parseColor("#E2E8F0"))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.2f)
                    setPadding(0, dp(3), 0, 0)
                    setLineSpacing(dp(2).toFloat(), 1f)
                }
                textCol.addView(tvMsg)

                textCol.setOnClickListener {
                    actionTaken = true
                    dismissInternal()
                    if (!isPreview) {
                        try {
                            val open = Intent(appCtx, MainActivity::class.java).apply {
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                                putExtra(SmartReminderManager.EXTRA_LEVEL, level)
                                putExtra(SmartReminderManager.EXTRA_KIND, kind)
                                putExtra(SmartReminderManager.EXTRA_ELAPSED_MIN, elapsedMin)
                            }
                            appCtx.startActivity(open)
                        } catch (_: Exception) {}
                    }
                }

                topRow.addView(textCol)
                card.addView(topRow)

                // Action Buttons Row
                val btnRow = LinearLayout(appCtx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { topMargin = dp(8) }
                }

                val supportsLongPressEat = kind == MascotContent.KIND_ASK ||
                    kind == MascotContent.KIND_RECHECK ||
                    kind == MascotContent.KIND_ANGRY ||
                    kind == MascotContent.KIND_STRICT

                val (posLabel, posAction, negLabel, negAction) = when (kind) {
                    MascotContent.KIND_RECHECK -> Quad(
                        "হ্যাঁ, পড়ছি", SmartReminderActionReceiver.ACTION_SR_READING_YES,
                        "না, পড়ছি না\n(চেপে ধরলে খাচ্ছি)", SmartReminderActionReceiver.ACTION_SR_READING_NO
                    )
                    MascotContent.KIND_IDLE, MascotContent.KIND_AWAY_END -> Quad(
                        "পড়ছি", SmartReminderActionReceiver.ACTION_SR_START_STUDY,
                        "বাইরে আছি", SmartReminderActionReceiver.ACTION_SR_AWAY_PICKER
                    )
                    MascotContent.KIND_AWAY_PRE -> Quad(
                        "পড়া শুরু করি", SmartReminderActionReceiver.ACTION_SR_START_STUDY,
                        "ঠিক আছে", SmartReminderActionReceiver.ACTION_SR_SNOOZE
                    )
                    else -> Quad(
                        "পড়ছি", SmartReminderActionReceiver.ACTION_SR_READING_YES,
                        "পড়ছি না\n(চেপে ধরলে খাচ্ছি)", SmartReminderActionReceiver.ACTION_SR_READING_NO
                    )
                }

                val btnPos = makeActionButton(appCtx, posLabel, accent, Color.parseColor("#0B1111"), dp(10), 12.5f) {
                    actionTaken = true
                    dismissInternal()
                    if (!isPreview) {
                        appCtx.sendBroadcast(Intent(appCtx, SmartReminderActionReceiver::class.java).setAction(posAction))
                    }
                }
                val btnNeg = makeActionButton(
                    appCtx,
                    negLabel,
                    Color.parseColor("#1E293B"),
                    Color.parseColor("#E2E8F0"),
                    dp(10),
                    if (supportsLongPressEat) 10.5f else 12.5f
                ) {
                    actionTaken = true
                    dismissInternal()
                    if (!isPreview) {
                        appCtx.sendBroadcast(Intent(appCtx, SmartReminderActionReceiver::class.java).setAction(negAction))
                    }
                }

                if (supportsLongPressEat) {
                    btnNeg.setOnLongClickListener {
                        actionTaken = true
                        vibrateShort(appCtx)
                        val eatMin = DataStore.getSrEatMin(appCtx)
                        btnNeg.text = "খাচ্ছি (${DataStore.toBnDigits(eatMin)} মি.)"
                        btnNeg.setTextColor(Color.parseColor("#0B1111"))
                        btnNeg.background = GradientDrawable().apply {
                            shape = GradientDrawable.RECTANGLE
                            cornerRadius = dp(10).toFloat()
                            setColor(Color.parseColor("#FBBF24"))
                        }
                        mainHandler.postDelayed({
                            dismissInternal()
                            if (!isPreview) {
                                appCtx.sendBroadcast(
                                    Intent(appCtx, SmartReminderActionReceiver::class.java)
                                        .setAction(SmartReminderActionReceiver.ACTION_SR_EATING)
                                )
                            }
                        }, 420L)
                        true
                    }
                }

                val btnHeight = if (supportsLongPressEat) dp(42) else dp(38)
                btnRow.addView(btnPos, LinearLayout.LayoutParams(0, btnHeight, 1f).apply { marginEnd = dp(8) })
                btnRow.addView(btnNeg, LinearLayout.LayoutParams(0, btnHeight, 1f))
                card.addView(btnRow)

                root.addView(card, FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT
                ))

                val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                } else {
                    @Suppress("DEPRECATION")
                    WindowManager.LayoutParams.TYPE_PHONE
                }

                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                    y = dp(24)
                }

                card.translationY = -dp(160).toFloat()
                card.alpha = 0f
                wm.addView(root, lp)
                currentView = root

                card.animate()
                    .translationY(0f)
                    .alpha(1f)
                    .setDuration(360L)
                    .setInterpolator(DecelerateInterpolator(1.6f))
                    .start()

                val dismissTask = Runnable { closeAndMaybeFallback() }
                pendingDismissRunnable = dismissTask
                mainHandler.postDelayed(dismissTask, if (isPreview) 8000L else 15000L)
            } catch (_: Exception) {
                dismissInternal()
            }
        }
    }

    fun dismiss() {
        mainHandler.post { dismissInternal() }
    }

    private fun dismissInternal() {
        pendingDismissRunnable?.let { mainHandler.removeCallbacks(it) }
        pendingDismissRunnable = null
        try {
            currentWebView?.apply {
                stopLoading()
                loadUrl("about:blank")
                destroy()
            }
        } catch (_: Exception) {}
        currentWebView = null

        val v = currentView
        currentView = null
        if (v != null) {
            try {
                windowManager?.removeView(v)
            } catch (_: Exception) {}
        }
    }

    private fun vibrateShort(ctx: Context) {
        try {
            val vib = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vib.vibrate(VibrationEffect.createOneShot(70L, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(70L)
            }
        } catch (_: Exception) {}
    }

    @SuppressLint("SetJavaScriptEnabled")
    fun createMascotWebView(ctx: Context, character: String, level: Int): WebView? {
        return try {
            WebView(ctx).apply {
                setBackgroundColor(Color.TRANSPARENT)
                isVerticalScrollBarEnabled = false
                isHorizontalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
                settings.apply {
                    javaScriptEnabled = true
                    allowFileAccess = true
                    cacheMode = WebSettings.LOAD_NO_CACHE
                    domStorageEnabled = false
                }
                val safeChar = if (character == "ghost") "ghost" else "dragon"
                val safeStage = level.coerceIn(1, 5)
                loadUrl("file:///android_asset/mascot_anim.html?character=$safeChar&stage=$safeStage")
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun makeActionButton(
        ctx: Context,
        label: String,
        bgColor: Int,
        textColor: Int,
        radiusPx: Int,
        textSp: Float,
        onClick: () -> Unit
    ): TextView = TextView(ctx).apply {
        text = label
        setTextColor(textColor)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, textSp)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx.toFloat()
            setColor(bgColor)
        }
        setOnClickListener { onClick() }
    }

    private data class Quad(val a: String, val b: String, val c: String, val d: String)
}
