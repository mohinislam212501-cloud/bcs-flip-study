package com.bcs.flipstudy

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class SmartReminderActionReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_SR_READING_YES = "com.bcs.flipstudy.SR_READING_YES"
        const val ACTION_SR_READING_NO = "com.bcs.flipstudy.SR_READING_NO"
        const val ACTION_SR_EATING = "com.bcs.flipstudy.SR_EATING"
        const val ACTION_SR_START_STUDY = "com.bcs.flipstudy.SR_START_STUDY"
        const val ACTION_SR_AWAY_PICKER = "com.bcs.flipstudy.SR_AWAY_PICKER"
        const val ACTION_SR_SNOOZE = "com.bcs.flipstudy.SR_SNOOZE"
        const val ACTION_SR_AWAY_PLUS_30 = "com.bcs.flipstudy.SR_AWAY_PLUS_30"
        const val ACTION_SR_RETURN_AWAY = "com.bcs.flipstudy.SR_RETURN_AWAY"
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            ACTION_SR_READING_YES -> SmartReminderManager.onReadingYes(context)
            ACTION_SR_READING_NO -> SmartReminderManager.onReadingNo(context)
            ACTION_SR_EATING -> SmartReminderManager.onEatingMode(context)
            ACTION_SR_START_STUDY -> SmartReminderManager.onStartStudyFromIdle(context)
            ACTION_SR_AWAY_PICKER -> SmartReminderManager.openAwayPicker(context)
            ACTION_SR_SNOOZE -> SmartReminderManager.onSnoozeIdle(context)
            ACTION_SR_AWAY_PLUS_30 -> SmartReminderManager.onSetAwayMinutes(context, 30)
            ACTION_SR_RETURN_AWAY -> SmartReminderManager.returnFromAway(context)
        }
    }
}
