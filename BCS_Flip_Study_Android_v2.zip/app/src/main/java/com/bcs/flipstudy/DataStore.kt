package com.bcs.flipstudy

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class DayRecord(
    val date: String,
    var subject: String = "",
    var c45: Int = 0,
    var c25: Int = 0,
    var studySec: Long = 0L,
    var wasteSec: Long = 0L,
    var wasteReason: String = "",
    var sleepOtherSec: Long = 0L,
    var wordTarget: Boolean = false,
    var synced: Boolean = false,
    // ধাপ ২.৩: নতুন ফিল্ড (পুরোনো ডেটায় না থাকলে ডিফল্ট নেবে)
    var subjects: MutableMap<String, Long> = mutableMapOf(),
    var wasteReasons: MutableMap<String, Long> = mutableMapOf(),
    var mode: String = "flip",
    var estimated: Boolean = false,
    var eatSec: Long = 0L,
    var flipSec: Long = 0L,
    var manualSec: Long = 0L,
    var onlineSec: Long = 0L
) {
    fun totalStudyMinutes(): Int {
        if (studySec > 0L) return (studySec / 60L).toInt()
        return (c45 * 45) + (c25 * 25)
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("date", date)
        put("subject", subject)
        put("c45", c45)
        put("c25", c25)
        put("studySec", studySec)
        put("wasteSec", wasteSec)
        put("wasteReason", wasteReason)
        put("sleepOtherSec", sleepOtherSec)
        put("wordTarget", wordTarget)
        put("synced", synced)
        put("mode", mode)
        put("estimated", estimated)
        put("eatSec", eatSec)
        put("flipSec", flipSec)
        put("manualSec", manualSec)
        put("onlineSec", onlineSec)
        val subObj = JSONObject()
        for ((k, v) in subjects) subObj.put(k, v)
        put("subjects", subObj)
        val wrObj = JSONObject()
        for ((k, v) in wasteReasons) wrObj.put(k, v)
        put("wasteReasons", wrObj)
    }

    companion object {
        fun fromJson(o: JSONObject): DayRecord {
            val subMap = mutableMapOf<String, Long>()
            o.optJSONObject("subjects")?.let { so ->
                val it = so.keys()
                while (it.hasNext()) {
                    val k = it.next()
                    subMap[k] = so.optLong(k, 0L)
                }
            }
            val wrMap = mutableMapOf<String, Long>()
            o.optJSONObject("wasteReasons")?.let { wo ->
                val it = wo.keys()
                while (it.hasNext()) {
                    val k = it.next()
                    wrMap[k] = wo.optLong(k, 0L)
                }
            }
            return DayRecord(
                date = o.optString("date", DataStore.todayIso()),
                subject = o.optString("subject", ""),
                c45 = o.optInt("c45", 0),
                c25 = o.optInt("c25", 0),
                studySec = o.optLong("studySec", 0L),
                wasteSec = o.optLong("wasteSec", 0L),
                wasteReason = o.optString("wasteReason", ""),
                sleepOtherSec = o.optLong("sleepOtherSec", 0L),
                wordTarget = o.optBoolean("wordTarget", false),
                synced = o.optBoolean("synced", false),
                subjects = subMap,
                wasteReasons = wrMap,
                mode = o.optString("mode", "flip"),
                estimated = o.optBoolean("estimated", false),
                eatSec = o.optLong("eatSec", 0L),
                flipSec = o.optLong("flipSec", 0L),
                manualSec = o.optLong("manualSec", 0L),
                onlineSec = o.optLong("onlineSec", 0L)
            )
        }
    }
}

data class ChartBar(val label: String, val studyMin: Int, val wasteMin: Int, val sleepMin: Int)

data class ReportData(
    val period: String,
    val isYearly: Boolean,
    val totalStudyMin: Int,
    val totalWasteMin: Int,
    val totalSleepMin: Int,
    val avgDailyStudyMin: Int,
    val bestDay: String,
    val bestDayMin: Int,
    val currentStreak: Int,
    val longestStreak: Int,
    val productivityScore: Int,
    val subjects: Map<String, Long>,
    val wasteReasons: Map<String, Long>,
    val bars: List<ChartBar>,
    val isOffline: Boolean
)

data class RuntimeTrackerState(
    val running: Boolean,
    val mode: String, // IDLE, STUDY, BREAK, WASTE
    val stateStartMs: Long,
    val remainingSec: Int,
    val faceDown: Boolean
)

object DataStore {
    private const val PREF = "bcs_flip_study_prefs"
    private const val KEY_DAYS = "days_map_json"
    private const val KEY_GAS_URL = "gas_webapp_url"
    private const val KEY_SYNC_KEY = "gas_sync_secret_key"
    private const val KEY_PRESET_MIN = "preset_min"
    private const val KEY_ONLINE_STUDY = "online_study"
    private const val KEY_ALARM_ON = "alarm_on"
    private const val KEY_LAST_CLOSED = "last_closed_ms"
    private const val KEY_LAST_SYNC_TEXT = "last_sync_text"
    private const val KEY_SUBJECT = "current_subject"

    private const val KEY_GOAL_HOURS = "daily_goal_hours"
    private const val KEY_GOAL_NOTIF = "daily_goal_notif"
    private const val KEY_GOAL_NOTIFIED_DATE = "goal_notified_date"
    private const val KEY_EXAM_NAME = "exam_name"
    private const val KEY_EXAM_DATE = "exam_date_iso"
    private const val KEY_GRACE_SEC = "flip_grace_sec"
    private const val KEY_ALARM_MODE = "alarm_mode" // vibrate, sound, silent
    private const val KEY_THEME_MODE = "theme_mode" // day, night, auto
    private const val KEY_COLOR_PALETTE = "color_palette" // sage, ocean, espresso, nordic
    private const val KEY_FLIP_ENABLED = "flip_sensor_enabled"

    // ধাপ ১.৭: প্রসেস মারা গেলেও অবস্থা ধরে রাখার জন্য
    private const val KEY_RT_RUNNING = "rt_running"
    private const val KEY_RT_MODE = "rt_mode"
    private const val KEY_RT_START_MS = "rt_state_start_ms"
    private const val KEY_RT_REM_SEC = "rt_remaining_sec"
    private const val KEY_RT_FACE_DOWN = "rt_face_down"

    fun todayIso(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    fun currentMonthIso(): String = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
    fun currentYearIso(): String = SimpleDateFormat("yyyy", Locale.US).format(Date())

    fun toBnDigits(input: Any): String {
        val bn = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
        val s = input.toString()
        val sb = StringBuilder(s.length)
        for (ch in s) {
            if (ch in '0'..'9') sb.append(bn[ch - '0']) else sb.append(ch)
        }
        return sb.toString()
    }

    fun formatHoursMinBn(totalSec: Long): String {
        val mins = (totalSec / 60L).coerceAtLeast(0L)
        val h = mins / 60L
        val m = mins % 60L
        return if (h > 0) "${toBnDigits(h)}ঘ ${toBnDigits(m)}মি" else "${toBnDigits(m)}মি"
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun getGasUrl(ctx: Context): String = prefs(ctx).getString(KEY_GAS_URL, "") ?: ""
    fun setGasUrl(ctx: Context, url: String) = prefs(ctx).edit().putString(KEY_GAS_URL, url.trim()).apply()

    fun getSyncKey(ctx: Context): String = prefs(ctx).getString(KEY_SYNC_KEY, "") ?: ""
    fun setSyncKey(ctx: Context, k: String) = prefs(ctx).edit().putString(KEY_SYNC_KEY, k.trim()).apply()

    fun getPresetMin(ctx: Context): Int = prefs(ctx).getInt(KEY_PRESET_MIN, 45)
    fun setPresetMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_PRESET_MIN, min).apply()

    fun isOnlineStudy(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_ONLINE_STUDY, false)
    fun setOnlineStudy(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_ONLINE_STUDY, on).apply()

    fun isAlarmOn(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_ALARM_ON, true)
    fun setAlarmOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_ALARM_ON, on).apply()

    fun getCurrentSubject(ctx: Context): String = prefs(ctx).getString(KEY_SUBJECT, "BCS প্রস্তুতি") ?: "BCS প্রস্তুতি"
    fun setCurrentSubject(ctx: Context, sub: String) = prefs(ctx).edit().putString(KEY_SUBJECT, sub.trim().ifEmpty { "BCS প্রস্তুতি" }).apply()


    fun formatHmsBn(totalSec: Long): String {
        val s = totalSec.coerceAtLeast(0L)
        val h = s / 3600L
        val m = (s % 3600L) / 60L
        val sec = s % 60L
        return toBnDigits(String.format(Locale.US, "%02d:%02d:%02d", h, m, sec))
    }

    fun getDailyGoalHours(ctx: Context): Int = prefs(ctx).getInt(KEY_GOAL_HOURS, 4).coerceIn(1, 16)
    fun setDailyGoalHours(ctx: Context, h: Int) = prefs(ctx).edit().putInt(KEY_GOAL_HOURS, h.coerceIn(1, 16)).apply()

    fun isGoalNotifOn(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_GOAL_NOTIF, true)
    fun setGoalNotifOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_GOAL_NOTIF, on).apply()

    fun getGoalNotifiedDate(ctx: Context): String = prefs(ctx).getString(KEY_GOAL_NOTIFIED_DATE, "") ?: ""
    fun setGoalNotifiedDate(ctx: Context, d: String) = prefs(ctx).edit().putString(KEY_GOAL_NOTIFIED_DATE, d).apply()

    fun getExamName(ctx: Context): String = prefs(ctx).getString(KEY_EXAM_NAME, "BCS পরীক্ষা") ?: "BCS পরীক্ষা"
    fun setExamName(ctx: Context, name: String) = prefs(ctx).edit().putString(KEY_EXAM_NAME, name.trim().ifEmpty { "BCS পরীক্ষা" }).apply()

    fun getExamDateIso(ctx: Context): String = prefs(ctx).getString(KEY_EXAM_DATE, "2027-02-26") ?: "2027-02-26"
    fun setExamDateIso(ctx: Context, iso: String) = prefs(ctx).edit().putString(KEY_EXAM_DATE, iso.trim()).apply()

    fun isValidIsoDate(iso: String): Boolean = try {
        val f = SimpleDateFormat("yyyy-MM-dd", Locale.US); f.isLenient = false
        f.parse(iso.trim()) != null && iso.trim().length == 10
    } catch (_: Exception) { false }

    fun getDaysUntilExam(ctx: Context): Int {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val target = sdf.parse(getExamDateIso(ctx)) ?: return 0
            val today = sdf.parse(todayIso()) ?: return 0
            val diff = ((target.time - today.time) / 86_400_000L).toInt()
            diff.coerceAtLeast(0)
        } catch (_: Exception) { 0 }
    }

    fun getGraceSec(ctx: Context): Int = prefs(ctx).getInt(KEY_GRACE_SEC, 5)
    fun setGraceSec(ctx: Context, sec: Int) = prefs(ctx).edit().putInt(KEY_GRACE_SEC, sec).apply()

    fun getAlarmMode(ctx: Context): String = prefs(ctx).getString(KEY_ALARM_MODE, "vibrate") ?: "vibrate"
    fun setAlarmMode(ctx: Context, mode: String) = prefs(ctx).edit().putString(KEY_ALARM_MODE, mode).apply()

    fun getThemeMode(ctx: Context): String = prefs(ctx).getString(KEY_THEME_MODE, "auto") ?: "auto"
    fun setThemeMode(ctx: Context, mode: String) = prefs(ctx).edit().putString(KEY_THEME_MODE, mode).apply()

    fun getColorPalette(ctx: Context): String = prefs(ctx).getString(KEY_COLOR_PALETTE, "ocean") ?: "ocean"
    fun setColorPalette(ctx: Context, id: String) = prefs(ctx).edit().putString(KEY_COLOR_PALETTE, id).apply()

    fun wasNotifPermAsked(ctx: Context): Boolean = prefs(ctx).getBoolean("notif_perm_asked", false)
    fun setNotifPermAsked(ctx: Context) = prefs(ctx).edit().putBoolean("notif_perm_asked", true).apply()

    fun isFlipEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_FLIP_ENABLED, false)
    fun setFlipEnabled(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_FLIP_ENABLED, on).apply()

    @Volatile private var cachedStreak: Int = -1
    @Volatile private var cachedStreakDate: String = ""

    fun getCurrentStreak(ctx: Context): Int {
        val today = todayIso()
        if (cachedStreak >= 0 && cachedStreakDate == today) return cachedStreak
        val map = loadAllDays(ctx)
        val cal = Calendar.getInstance()
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        var streak = 0
        for (i in 0..365) {
            val c = cal.clone() as Calendar
            c.add(Calendar.DAY_OF_YEAR, -i)
            val rec = map[fmt.format(c.time)]
            if (rec != null && rec.totalStudyMinutes() > 0) streak++
            else if (i > 0) break
        }
        cachedStreak = streak
        cachedStreakDate = today
        return streak
    }

    fun getLast28DaysMinutes(ctx: Context): List<Int> {
        val map = loadAllDays(ctx)
        val cal = Calendar.getInstance()
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val out = mutableListOf<Int>()
        for (i in 27 downTo 0) {
            val c = cal.clone() as Calendar
            c.add(Calendar.DAY_OF_YEAR, -i)
            out.add(map[fmt.format(c.time)]?.totalStudyMinutes() ?: 0)
        }
        return out
    }

    fun getCurrentMonthDays(ctx: Context): List<DayRecord> {
        val map = loadAllDays(ctx)
        val cal = Calendar.getInstance()
        val maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val ym = SimpleDateFormat("yyyy-MM", Locale.US).format(cal.time)
        val list = mutableListOf<DayRecord>()
        for (d in 1..maxDay) {
            val iso = String.format(Locale.US, "%s-%02d", ym, d)
            list.add(map[iso] ?: DayRecord(date = iso))
        }
        return list
    }

    fun buildCsvExport(ctx: Context): String {
        val map = loadAllDays(ctx)
        val sb = StringBuilder("Date,Subject,StudyMin,45mCircles,25mCircles,WasteMin,SleepOtherMin,WordTarget\n")
        for (rec in map.values.sortedBy { it.date }) {
            val sub = rec.subject.replace(",", " ")
            sb.append("${rec.date},$sub,${rec.totalStudyMinutes()},${rec.c45},${rec.c25},${rec.wasteSec / 60L},${rec.sleepOtherSec / 60L},${rec.wordTarget}\n")
        }
        return sb.toString()
    }

    fun getLastSyncText(ctx: Context): String = prefs(ctx).getString(KEY_LAST_SYNC_TEXT, "এখনো সিঙ্ক হয়নি") ?: "এখনো সিঙ্ক হয়নি"
    fun setLastSyncText(ctx: Context, txt: String) = prefs(ctx).edit().putString(KEY_LAST_SYNC_TEXT, txt).apply()

    fun saveRuntimeState(ctx: Context, rt: RuntimeTrackerState) {
        prefs(ctx).edit()
            .putBoolean(KEY_RT_RUNNING, rt.running)
            .putString(KEY_RT_MODE, rt.mode)
            .putLong(KEY_RT_START_MS, rt.stateStartMs)
            .putInt(KEY_RT_REM_SEC, rt.remainingSec)
            .putBoolean(KEY_RT_FACE_DOWN, rt.faceDown)
            .apply()
    }

    fun loadRuntimeState(ctx: Context): RuntimeTrackerState {
        val p = prefs(ctx)
        return RuntimeTrackerState(
            running = p.getBoolean(KEY_RT_RUNNING, false),
            mode = p.getString(KEY_RT_MODE, "IDLE") ?: "IDLE",
            stateStartMs = p.getLong(KEY_RT_START_MS, 0L),
            remainingSec = p.getInt(KEY_RT_REM_SEC, getPresetMin(ctx) * 60),
            faceDown = p.getBoolean(KEY_RT_FACE_DOWN, false)
        )
    }

    fun markAppClosedNow(ctx: Context) {
        prefs(ctx).edit().putLong(KEY_LAST_CLOSED, System.currentTimeMillis()).apply()
    }

    fun absorbClosedTimeAsSleepOther(ctx: Context): Long {
        val lastClosed = prefs(ctx).getLong(KEY_LAST_CLOSED, 0L)
        if (lastClosed <= 0L) return 0L
        val now = System.currentTimeMillis()
        val gapSec = (now - lastClosed) / 1000L
        prefs(ctx).edit().putLong(KEY_LAST_CLOSED, 0L).apply()
        if (gapSec in 60L..86400L) {
            updateToday(ctx) { rec ->
                rec.sleepOtherSec += gapSec
                rec.synced = false
            }
            return gapSec
        }
        return 0L
    }

    @Synchronized
    fun loadAllDays(ctx: Context): MutableMap<String, DayRecord> {
        val raw = prefs(ctx).getString(KEY_DAYS, "{}") ?: "{}"
        val map = mutableMapOf<String, DayRecord>()
        try {
            val obj = JSONObject(raw)
            val it = obj.keys()
            while (it.hasNext()) {
                val k = it.next()
                val child = obj.optJSONObject(k)
                if (child != null) map[k] = DayRecord.fromJson(child)
            }
        } catch (_: Exception) {}
        return map
    }

    @Synchronized
    fun saveAllDays(ctx: Context, map: Map<String, DayRecord>) {
        val obj = JSONObject()
        for ((k, v) in map) obj.put(k, v.toJson())
        prefs(ctx).edit().putString(KEY_DAYS, obj.toString()).apply()
        cachedStreak = -1
    }


    @Synchronized
    fun addWaste(ctx: Context, startMs: Long, endMs: Long, reason: String = "অপচয় সময়") {
        val safeEnd = endMs
        val maxSpanMs = 4L * 3600L * 1000L
        val safeStart = if (startMs <= 0L || safeEnd <= startMs) safeEnd else maxOf(startMs, safeEnd - maxSpanMs)
        val segments = splitByDay(safeStart, safeEnd)
        if (segments.isEmpty()) return
        val map = loadAllDays(ctx)
        for ((iso, sec) in segments) {
            if (sec <= 0L) continue
            val rec = map[iso] ?: DayRecord(date = iso, subject = getCurrentSubject(ctx))
            rec.wasteSec += sec
            rec.wasteReasons[reason] = (rec.wasteReasons[reason] ?: 0L) + sec
            rec.synced = false
            map[iso] = rec
        }
        saveAllDays(ctx, map)
    }

    /** একক স্টাডি-লগিং পথ: মাঝরাত ভাগ, সোর্স (flip/manual/online) ও সর্বাধিক ৪ ঘণ্টা ক্যাপসহ। */
    @Synchronized
    fun addStudy(ctx: Context, startMs: Long, endMs: Long, source: String, circlePresetMin: Int = 0): DayRecord {
        val safeEnd = endMs
        val maxSpanMs = 4L * 3600L * 1000L
        val safeStart = if (startMs <= 0L || safeEnd <= startMs) safeEnd else maxOf(startMs, safeEnd - maxSpanMs)
        val sub = getCurrentSubject(ctx)
        val segments = splitByDay(safeStart, safeEnd)
        val today = todayIso()
        val map = loadAllDays(ctx)

        for ((iso, sec) in segments) {
            if (sec <= 0L) continue
            val rec = map[iso] ?: DayRecord(date = iso, subject = sub)
            rec.studySec += sec
            when (source) {
                "online" -> rec.onlineSec += sec
                "flip" -> rec.flipSec += sec
                else -> rec.manualSec += sec
            }
            rec.subject = sub
            rec.subjects[sub] = (rec.subjects[sub] ?: 0L) + sec
            rec.mode = source
            rec.synced = false
            map[iso] = rec
        }

        val todayRec = map[today] ?: DayRecord(date = today, subject = sub)
        if (circlePresetMin >= 40) {
            todayRec.c45 += 1
            todayRec.synced = false
            map[today] = todayRec
        } else if (circlePresetMin >= 20) {
            todayRec.c25 += 1
            todayRec.synced = false
            map[today] = todayRec
        }
        saveAllDays(ctx, map)
        return map[today] ?: todayRec
    }

    @Synchronized
    fun getToday(ctx: Context): DayRecord {
        val today = todayIso()
        val map = loadAllDays(ctx)
        return map[today] ?: DayRecord(date = today, subject = getCurrentSubject(ctx))
    }

    @Synchronized
    fun updateToday(ctx: Context, block: (DayRecord) -> Unit): DayRecord = updateDay(ctx, todayIso(), block)

    @Synchronized
    fun updateDay(ctx: Context, iso: String, block: (DayRecord) -> Unit): DayRecord {
        val map = loadAllDays(ctx)
        val rec = map[iso] ?: DayRecord(date = iso, subject = getCurrentSubject(ctx))
        block(rec)
        map[iso] = rec
        saveAllDays(ctx, map)
        return rec
    }

    fun startOfTodayMs(): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    /** একটি সময়-খণ্ড মাঝরাতে ভাগ করে (তারিখ, সেকেন্ড) তালিকা দেয়, যাতে রাত ১২টা পেরোনো সেশন দুই দিনে ঠিকভাবে বসে। */
    fun splitByDay(startMs: Long, endMs: Long): List<Pair<String, Long>> {
        val out = mutableListOf<Pair<String, Long>>()
        if (endMs <= startMs) return out
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        var cursor = startMs
        var guard = 0
        while (cursor < endMs && guard < 40) {
            val c = Calendar.getInstance().apply { timeInMillis = cursor }
            val iso = fmt.format(c.time)
            c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0)
            c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
            c.add(Calendar.DAY_OF_YEAR, 1)
            val segEnd = minOf(endMs, c.timeInMillis)
            val sec = (segEnd - cursor) / 1000L
            if (sec > 0L) out.add(Pair(iso, sec))
            cursor = segEnd
            guard++
        }
        return out
    }

    // সিঙ্কের সময় ডেটা বদলেছে কিনা বুঝতে কনটেন্ট-সিগনেচার (synced ফ্ল্যাগ বাদে)
    private fun contentSig(r: DayRecord): String =
        "${r.studySec}|${r.wasteSec}|${r.sleepOtherSec}|${r.eatSec}|${r.c45}|${r.c25}|${r.wordTarget}|${r.subject}|${r.wasteReason}|" +
            r.subjects.toSortedMap() + "|" + r.wasteReasons.toSortedMap()

    fun getLast7Days(ctx: Context): List<DayRecord> {
        val map = loadAllDays(ctx)
        val cal = Calendar.getInstance()
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val list = mutableListOf<DayRecord>()
        for (i in 6 downTo 0) {
            val c = cal.clone() as Calendar
            c.add(Calendar.DAY_OF_YEAR, -i)
            val d = fmt.format(c.time)
            list.add(map[d] ?: DayRecord(date = d))
        }
        return list
    }

    fun hasUnsyncedDays(ctx: Context): Boolean = loadAllDays(ctx).values.any { !it.synced }

    // ধাপ ২.১ ও ২.৪: শুধু synced=false দিন পাঠানো, {"ok":true} পেলেই synced=true, লোকাল ডেটা কখনো মুছবে না
    fun syncToGoogleDrive(ctx: Context): Pair<Boolean, String> {
        val urlStr = getGasUrl(ctx)
        if (urlStr.isBlank() || !urlStr.startsWith("http")) {
            return Pair(false, "সেটিংসে আগে Apps Script লিংক বসাও")
        }
        val map = loadAllDays(ctx)
        val unsynced = map.values.filter { !it.synced }.sortedBy { it.date }
        val sentSigs = unsynced.associate { it.date to contentSig(it) }
        if (unsynced.isEmpty()) {
            return Pair(true, "নতুন কোনো অসিঙ্কড ডেটা নেই (সব আপডেট আছে)")
        }
        return try {
            val arr = JSONArray()
            for (rec in unsynced) arr.put(rec.toJson())
            val payload = JSONObject().apply {
                put("appKey", "study_tracker")
                put("key", getSyncKey(ctx))
                put("updatedAt", System.currentTimeMillis())
                put("days", arr)
            }.toString()

            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                instanceFollowRedirects = true
                connectTimeout = 15000
                readTimeout = 15000
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            }
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val respText = if (stream != null) BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() } else ""
            conn.disconnect()

            val okJson = try { JSONObject(respText).optBoolean("ok", false) } catch (_: Exception) { false }
            if (code in 200..299 && okJson) {
                markSyncedIfUnchanged(ctx, sentSigs)
                val stamp = SimpleDateFormat("dd MMM, hh:mm a", Locale.US).format(Date())
                setLastSyncText(ctx, "সিঙ্কড: $stamp")
                Pair(true, "${toBnDigits(unsynced.size)}টি দিনের ডেটা ড্রাইভে সিঙ্ক হয়েছে!")
            } else {
                val errMsg = try { JSONObject(respText).optString("error", "") } catch (_: Exception) { "" }
                Pair(false, if (errMsg.isNotEmpty()) "সার্ভার ত্রুটি: $errMsg" else "সিঙ্ক ব্যর্থ (কোড: $code)")
            }
        } catch (e: Exception) {
            Pair(false, "নেটওয়ার্ক ত্রুটি: ${e.localizedMessage ?: "অজানা"}")
        }
    }

    // নেটওয়ার্ক কলের সময় সার্ভিস নতুন ডেটা লিখলে সেটি যেন মুছে না যায় এবং "synced" ভুলভাবে না বসে
    @Synchronized
    private fun markSyncedIfUnchanged(ctx: Context, sentSigs: Map<String, String>) {
        val fresh = loadAllDays(ctx)
        for ((date, sig) in sentSigs) {
            val rec = fresh[date] ?: continue
            if (contentSig(rec) == sig) rec.synced = true
        }
        saveAllDays(ctx, fresh)
    }

    // ধাপ ৪: মাসিক/বার্ষিক রিপোর্ট (লোকাল-ফার্স্ট, লোকাল খালি থাকলে সার্ভার ফলব্যাক)
    fun fetchOrComputeReport(ctx: Context, period: String, isYearly: Boolean): ReportData {
        val localAll = loadAllDays(ctx)
        val hasLocal = localAll.values.any {
            it.date.startsWith(period) && (it.totalStudyMinutes() > 0 || it.wasteSec > 0L || it.sleepOtherSec > 0L || it.eatSec > 0L)
        }
        if (hasLocal) {
            return computeLocalReport(ctx, period, isYearly).copy(isOffline = false)
        }
        val cacheKey = "report_cache_${if (isYearly) "y" else "m"}_$period"
        val cacheTsKey = "${cacheKey}_ts"
        val p = prefs(ctx)
        val isCurrent = if (isYearly) period == currentYearIso() else period == currentMonthIso()
        val cachedRaw = p.getString(cacheKey, null)
        val cachedTs = p.getLong(cacheTsKey, 0L)
        val now = System.currentTimeMillis()

        // আগের মাস/বছর একবার ক্যাশ হলে আর আনতে হবে না; চলতি মাস ১ ঘণ্টার মধ্যে ক্যাশ ব্যবহার
        if (cachedRaw != null && (!isCurrent || (now - cachedTs) < 3600_000L)) {
            parseServerReport(cachedRaw, period, isYearly, false)?.let { return it }
        }

        val urlStr = getGasUrl(ctx)
        if (urlStr.startsWith("http")) {
            try {
                val paramName = if (isYearly) "year" else "month"
                val keyEnc = URLEncoder.encode(getSyncKey(ctx), "UTF-8")
                val sep = if (urlStr.contains("?")) "&" else "?"
                val fullUrl = "$urlStr${sep}action=report&$paramName=${URLEncoder.encode(period, "UTF-8")}&key=$keyEnc"
                val conn = (URL(fullUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    instanceFollowRedirects = true
                    connectTimeout = 10000
                    readTimeout = 12000
                }
                val code = conn.responseCode
                val txt = if (code in 200..299) BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { it.readText() } else ""
                conn.disconnect()
                val parsed = parseServerReport(txt, period, isYearly, false)
                if (parsed != null) {
                    p.edit().putString(cacheKey, txt).putLong(cacheTsKey, now).apply()
                    return parsed
                }
            } catch (_: Exception) {}
        }

        // অফলাইন বা সার্ভার না পেলে ক্যাশ অথবা লোকাল ডেটা থেকে হিসাব
        if (cachedRaw != null) {
            parseServerReport(cachedRaw, period, isYearly, true)?.let { return it }
        }
        return computeLocalReport(ctx, period, isYearly)
    }

    private fun parseServerReport(raw: String, period: String, isYearly: Boolean, offline: Boolean): ReportData? {
        return try {
            val o = JSONObject(raw)
            if (!o.optBoolean("ok", false)) return null
            val subMap = mutableMapOf<String, Long>()
            o.optJSONObject("subjects")?.let { so ->
                val it = so.keys()
                while (it.hasNext()) { val k = it.next(); subMap[k] = so.optLong(k, 0L) }
            }
            val wrMap = mutableMapOf<String, Long>()
            o.optJSONObject("wasteReasons")?.let { wo ->
                val it = wo.keys()
                while (it.hasNext()) { val k = it.next(); wrMap[k] = wo.optLong(k, 0L) }
            }
            val bars = mutableListOf<ChartBar>()
            val arr = o.optJSONArray("bars") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val b = arr.getJSONObject(i)
                bars.add(ChartBar(b.optString("label"), b.optInt("studyMin"), b.optInt("wasteMin"), b.optInt("sleepMin")))
            }
            ReportData(
                period = period,
                isYearly = isYearly,
                totalStudyMin = o.optInt("totalStudyMin"),
                totalWasteMin = o.optInt("totalWasteMin"),
                totalSleepMin = o.optInt("totalSleepMin"),
                avgDailyStudyMin = o.optInt("avgDailyStudyMin"),
                bestDay = o.optString("bestDay", "—"),
                bestDayMin = o.optInt("bestDayMin"),
                currentStreak = o.optInt("currentStreak"),
                longestStreak = o.optInt("longestStreak"),
                productivityScore = o.optInt("productivityScore"),
                subjects = subMap,
                wasteReasons = wrMap,
                bars = bars,
                isOffline = offline
            )
        } catch (_: Exception) { null }
    }

    private fun computeLocalReport(ctx: Context, period: String, isYearly: Boolean): ReportData {
        val all = loadAllDays(ctx)
        val filtered = all.values.filter { it.date.startsWith(period) }.sortedBy { it.date }
        var totStudy = 0
        var totWaste = 0
        var totSleep = 0
        var bestDay = "—"
        var bestMin = 0
        val subMap = mutableMapOf<String, Long>()
        val wrMap = mutableMapOf<String, Long>()
        var curStreak = 0
        var maxStreak = 0

        for (d in filtered) {
            val sm = d.totalStudyMinutes()
            val wm = (d.wasteSec / 60L).toInt()
            val slm = (d.sleepOtherSec / 60L).toInt()
            totStudy += sm
            totWaste += wm
            totSleep += slm
            if (sm > bestMin) { bestMin = sm; bestDay = d.date.takeLast(2) }
            if (sm > 0) { curStreak++; if (curStreak > maxStreak) maxStreak = curStreak } else curStreak = 0
            for ((k, v) in d.subjects) subMap[k] = (subMap[k] ?: 0L) + v
            if (d.subjects.isEmpty() && d.subject.isNotEmpty() && sm > 0) {
                subMap[d.subject] = (subMap[d.subject] ?: 0L) + (sm * 60L)
            }
            for ((k, v) in d.wasteReasons) wrMap[k] = (wrMap[k] ?: 0L) + v
            if (d.wasteReasons.isEmpty() && d.wasteReason.isNotEmpty() && wm > 0) {
                wrMap[d.wasteReason] = (wrMap[d.wasteReason] ?: 0L) + (wm * 60L)
            }
        }

        val activeDays = filtered.count { it.totalStudyMinutes() > 0 }.coerceAtLeast(1)
        val avgDaily = totStudy / activeDays
        val denom = totStudy + totWaste
        val score = if (denom > 0) ((totStudy * 100) / denom) else 0

        val bars = mutableListOf<ChartBar>()
        if (isYearly) {
            val bnMonths = arrayOf("জানু", "ফেব্রু", "মার্চ", "এপ্রি", "মে", "জুন", "জুলা", "আগ", "সেপ্টে", "অক্টো", "নভে", "ডিসে")
            for (m in 1..12) {
                val ym = String.format(Locale.US, "%s-%02d", period, m)
                val mDays = filtered.filter { it.date.startsWith(ym) }
                bars.add(ChartBar(
                    bnMonths[m - 1],
                    mDays.sumOf { it.totalStudyMinutes() },
                    mDays.sumOf { (it.wasteSec / 60L).toInt() },
                    mDays.sumOf { (it.sleepOtherSec / 60L).toInt() }
                ))
            }
        } else {
            val parts = period.split("-")
            val cal = Calendar.getInstance().apply {
                set(Calendar.YEAR, parts.getOrNull(0)?.toIntOrNull() ?: 2026)
                set(Calendar.MONTH, (parts.getOrNull(1)?.toIntOrNull() ?: 1) - 1)
                set(Calendar.DAY_OF_MONTH, 1)
            }
            val maxD = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
            for (day in 1..maxD) {
                val iso = String.format(Locale.US, "%s-%02d", period, day)
                val rec = all[iso]
                bars.add(ChartBar(
                    toBnDigits(day),
                    rec?.totalStudyMinutes() ?: 0,
                    ((rec?.wasteSec ?: 0L) / 60L).toInt(),
                    ((rec?.sleepOtherSec ?: 0L) / 60L).toInt()
                ))
            }
        }

        return ReportData(period, isYearly, totStudy, totWaste, totSleep, avgDaily, bestDay, bestMin, curStreak, maxStreak, score, subMap, wrMap, bars, true)
    }

    // v7: স্মার্ট রিমাইন্ডার সেটিংস ও রানটাইম স্টেট (সব নতুন কী; পুরোনো কিছু বদলানো হয়নি)
    private const val KEY_SR_ENABLED = "sr_enabled"
    private const val KEY_SR_ASK_DELAY_MIN = "sr_ask_delay_min"
    private const val KEY_SR_REPEAT_MIN = "sr_repeat_min"
    private const val KEY_SR_READ_RECHECK_MIN = "sr_read_recheck_min"
    private const val KEY_SR_READ_RESET_MIN = "sr_read_reset_min"
    private const val KEY_SR_IDLE_MIN = "sr_idle_min"
    private const val KEY_SR_QUIET_ON = "sr_quiet_on"
    private const val KEY_SR_QUIET_START_MIN = "sr_quiet_start_min"
    private const val KEY_SR_QUIET_END_MIN = "sr_quiet_end_min"
    private const val KEY_SR_MASCOT_STYLE = "sr_mascot_style"
    private const val KEY_SR_POPUP_OVERLAY = "sr_popup_overlay"

    private const val KEY_SR_PHASE = "sr_phase"
    private const val KEY_SR_LEVEL = "sr_level"
    private const val KEY_SR_USE_ACCUM_MS = "sr_use_accum_ms"
    private const val KEY_SR_USE_SEGMENT_START_MS = "sr_use_segment_start_ms"
    private const val KEY_SR_SCREEN_OFF_SINCE_MS = "sr_screen_off_since_ms"
    private const val KEY_SR_PREV_ONLINE = "sr_prev_online"
    private const val KEY_SR_SESSION_STARTED_BY_REMINDER = "sr_session_started_by_reminder"
    private const val KEY_SR_LAST_STUDY_END_MS = "sr_last_study_end_ms"
    private const val KEY_SR_IDLE_FIRED_EPISODE = "sr_idle_fired_episode"
    private const val KEY_SR_APP_FG = "sr_app_fg"
    private const val KEY_SR_MIGRATED_V7 = "sr_migrated_v7"

    fun isSrEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_ENABLED, true)
    fun setSrEnabled(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_ENABLED, on).apply()

    fun getSrAskDelayMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_ASK_DELAY_MIN, 2).coerceIn(1, 60)
    fun setSrAskDelayMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_ASK_DELAY_MIN, min).apply()

    fun getSrRepeatMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_REPEAT_MIN, 5).coerceIn(1, 60)
    fun setSrRepeatMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_REPEAT_MIN, min).apply()

    fun getSrReadRecheckMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_READ_RECHECK_MIN, 15).coerceIn(1, 120)
    fun setSrReadRecheckMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_READ_RECHECK_MIN, min).apply()

    fun getSrReadResetMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_READ_RESET_MIN, 3).coerceIn(1, 30)
    fun setSrReadResetMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_READ_RESET_MIN, min).apply()

    fun getSrIdleMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_IDLE_MIN, 45).coerceAtLeast(0)
    fun setSrIdleMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_IDLE_MIN, min).apply()

    fun isSrQuietOn(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_QUIET_ON, true)
    fun setSrQuietOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_QUIET_ON, on).apply()

    fun getSrQuietStartMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_QUIET_START_MIN, 0).coerceIn(0, 1439)
    fun setSrQuietStartMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_QUIET_START_MIN, min.coerceIn(0, 1439)).apply()

    fun getSrQuietEndMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_QUIET_END_MIN, 360).coerceIn(0, 1439)
    fun setSrQuietEndMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_QUIET_END_MIN, min.coerceIn(0, 1439)).apply()

    fun getSrMascotStyle(ctx: Context): String = prefs(ctx).getString(KEY_SR_MASCOT_STYLE, "auto") ?: "auto"
    fun setSrMascotStyle(ctx: Context, style: String) = prefs(ctx).edit().putString(KEY_SR_MASCOT_STYLE, style).apply()

    fun isSrPopupOverlayOn(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_POPUP_OVERLAY, true)
    fun setSrPopupOverlayOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_POPUP_OVERLAY, on).apply()

    fun getSrPhase(ctx: Context): String = prefs(ctx).getString(KEY_SR_PHASE, SmartReminderManager.PHASE_NORMAL) ?: SmartReminderManager.PHASE_NORMAL
    fun setSrPhase(ctx: Context, phase: String) = prefs(ctx).edit().putString(KEY_SR_PHASE, phase).apply()

    fun getSrLevel(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_LEVEL, 0).coerceIn(0, 5)
    fun setSrLevel(ctx: Context, lvl: Int) = prefs(ctx).edit().putInt(KEY_SR_LEVEL, lvl.coerceIn(0, 5)).apply()

    fun getSrUseAccumMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_USE_ACCUM_MS, 0L).coerceAtLeast(0L)
    fun setSrUseAccumMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_USE_ACCUM_MS, ms.coerceAtLeast(0L)).apply()

    fun getSrUseSegmentStartMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_USE_SEGMENT_START_MS, 0L)
    fun setSrUseSegmentStartMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_USE_SEGMENT_START_MS, ms).apply()

    fun getSrScreenOffSinceMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_SCREEN_OFF_SINCE_MS, 0L)
    fun setSrScreenOffSinceMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_SCREEN_OFF_SINCE_MS, ms).apply()

    fun getSrPrevOnline(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_PREV_ONLINE, false)
    fun setSrPrevOnline(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_PREV_ONLINE, on).apply()

    fun isSrSessionStartedByReminder(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_SESSION_STARTED_BY_REMINDER, false)
    fun setSrSessionStartedByReminder(ctx: Context, started: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_SESSION_STARTED_BY_REMINDER, started).apply()

    fun getSrLastStudyEndMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_LAST_STUDY_END_MS, 0L)
    fun setSrLastStudyEndMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_LAST_STUDY_END_MS, ms).apply()

    fun isSrIdleFiredEpisode(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_IDLE_FIRED_EPISODE, false)
    fun setSrIdleFiredEpisode(ctx: Context, fired: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_IDLE_FIRED_EPISODE, fired).apply()

    fun isSrAppForeground(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_APP_FG, false)
    fun setSrAppForeground(ctx: Context, fg: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_APP_FG, fg).apply()

    fun isSrMigratedV7(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_MIGRATED_V7, false)
    fun setSrMigratedV7(ctx: Context, done: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_MIGRATED_V7, done).apply()

    fun formatTimeMinBn(totalMin: Int): String {
        val m = totalMin.coerceIn(0, 1439)
        return toBnDigits(String.format(Locale.US, "%02d:%02d", m / 60, m % 60))
    }

    // v7.1: ফলো-আপ দেরি, খাচ্ছি, বাইরে আছি ও স্ট্রিক্ট মোড কী
    private const val KEY_SR_FALLBACK_SEC = "sr_fallback_delay_sec"
    private const val KEY_SR_EAT_MIN = "sr_eat_min"
    private const val KEY_SR_STRICT_AFTER_MIN = "sr_strict_after_min"
    private const val KEY_SR_EAT_START_MS = "sr_eat_start_ms"
    private const val KEY_SR_EAT_UNTIL_MS = "sr_eat_until_ms"
    private const val KEY_SR_AWAY_UNTIL_MS = "sr_away_until_ms"
    private const val KEY_SR_AWAY_TOTAL_MIN = "sr_away_total_min"
    private const val KEY_SR_MSG_INDEX = "sr_msg_index"
    private const val KEY_SR_FB_KIND = "sr_pending_fb_kind"
    private const val KEY_SR_FB_LEVEL = "sr_pending_fb_level"
    private const val KEY_SR_FB_ELAPSED = "sr_pending_fb_elapsed"
    private const val KEY_SR_FB_MSG_IDX = "sr_pending_fb_msg_idx"

    fun getSrFallbackDelaySec(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_FALLBACK_SEC, 20).coerceIn(5, 120)
    fun setSrFallbackDelaySec(ctx: Context, sec: Int) = prefs(ctx).edit().putInt(KEY_SR_FALLBACK_SEC, sec.coerceIn(5, 120)).apply()

    fun getSrEatMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_EAT_MIN, 45).coerceIn(10, 180)
    fun setSrEatMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_EAT_MIN, min.coerceIn(10, 180)).apply()

    fun getSrStrictAfterMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_STRICT_AFTER_MIN, 30).coerceAtLeast(0)
    fun setSrStrictAfterMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_STRICT_AFTER_MIN, min.coerceAtLeast(0)).apply()

    fun getSrEatStartMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_EAT_START_MS, 0L)
    fun setSrEatStartMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_EAT_START_MS, ms).apply()

    fun getSrEatUntilMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_EAT_UNTIL_MS, 0L)
    fun setSrEatUntilMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_EAT_UNTIL_MS, ms).apply()

    fun getSrAwayUntilMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_AWAY_UNTIL_MS, 0L)
    fun setSrAwayUntilMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_AWAY_UNTIL_MS, ms).apply()

    fun getSrAwayTotalMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_AWAY_TOTAL_MIN, 0)
    fun setSrAwayTotalMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_AWAY_TOTAL_MIN, min).apply()

    fun getSrMsgIndex(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_MSG_INDEX, 0)
    fun setSrMsgIndex(ctx: Context, idx: Int) = prefs(ctx).edit().putInt(KEY_SR_MSG_INDEX, idx).apply()

    fun setSrPendingFallback(ctx: Context, kind: String, level: Int, elapsed: Int, msgIdx: Int) {
        prefs(ctx).edit()
            .putString(KEY_SR_FB_KIND, kind)
            .putInt(KEY_SR_FB_LEVEL, level)
            .putInt(KEY_SR_FB_ELAPSED, elapsed)
            .putInt(KEY_SR_FB_MSG_IDX, msgIdx)
            .apply()
    }
    fun clearSrPendingFallback(ctx: Context) {
        prefs(ctx).edit().putString(KEY_SR_FB_KIND, "").apply()
    }
    fun getSrPendingFbKind(ctx: Context): String = prefs(ctx).getString(KEY_SR_FB_KIND, "") ?: ""
    fun getSrPendingFbLevel(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_FB_LEVEL, 1)
    fun getSrPendingFbElapsed(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_FB_ELAPSED, 0)
    fun getSrPendingFbMsgIdx(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_FB_MSG_IDX, 0)

    // v7.2: কলে থাকলে কাস্টম সময় পরপর ৩বার ভাইব্রেট
    private const val KEY_SR_CALL_VIB_MIN = "sr_call_vib_min"
    fun getSrCallVibMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_CALL_VIB_MIN, 10).coerceAtLeast(0)
    fun setSrCallVibMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_CALL_VIB_MIN, min.coerceAtLeast(0)).apply()

    private const val KEY_SR_MAX_RAGE_NOTIF_SENT = "sr_max_rage_notif_sent"
    fun isSrMaxRageNotifSent(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_MAX_RAGE_NOTIF_SENT, false)
    fun setSrMaxRageNotifSent(ctx: Context, sent: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_MAX_RAGE_NOTIF_SENT, sent).apply()

    private const val KEY_SR_WASTE_COMMITTED_MS = "sr_waste_committed_ms"
    fun getSrWasteCommittedMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_WASTE_COMMITTED_MS, 0L).coerceAtLeast(0L)
    fun setSrWasteCommittedMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_WASTE_COMMITTED_MS, ms.coerceAtLeast(0L)).apply()
}
