package com.bcs.flipstudy

import android.content.Context
import android.provider.Settings
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class DayRecord(
    val date: String,
    var subject: String = "",
    var c45: Int = 0,
    var c25: Int = 0,
    var studySec: Long = 0L,
    var wasteSec: Long = 0L,
    var wasteReason: String = "",
    var sleepOtherSec: Long = 0L,
    var wordTarget: Boolean = false,
    var synced: Boolean = false,
    // ধাপ ২.৩: নতুন ফিল্ড (পুরোনো ডেটায় না থাকলে ডিফল্ট নেবে)
    var subjects: MutableMap<String, Long> = mutableMapOf(),
    var wasteReasons: MutableMap<String, Long> = mutableMapOf(),
    var mode: String = "flip",
    var estimated: Boolean = false,
    var eatSec: Long = 0L,
    var flipSec: Long = 0L,
    var manualSec: Long = 0L,
    var onlineSec: Long = 0L,
    var awaySec: Long = 0L,
    var awayReasons: MutableMap<String, Long> = mutableMapOf()
) {
    fun totalStudyMinutes(): Int {
        if (studySec > 0L) return (studySec / 60L).toInt()
        return (c45 * 45) + (c25 * 25)
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("date", date)
        put("subject", subject)
        put("c45", c45)
        put("c25", c25)
        put("studySec", studySec)
        put("wasteSec", wasteSec)
        put("wasteReason", wasteReason)
        put("sleepOtherSec", sleepOtherSec)
        put("wordTarget", wordTarget)
        put("synced", synced)
        put("mode", mode)
        put("estimated", estimated)
        put("eatSec", eatSec)
        put("flipSec", flipSec)
        put("manualSec", manualSec)
        put("onlineSec", onlineSec)
        put("awaySec", awaySec)
        val awObj = JSONObject()
        for ((k, v) in awayReasons) awObj.put(k, v)
        put("awayReasons", awObj)
        val subObj = JSONObject()
        for ((k, v) in subjects) subObj.put(k, v)
        put("subjects", subObj)
        val wrObj = JSONObject()
        for ((k, v) in wasteReasons) wrObj.put(k, v)
        put("wasteReasons", wrObj)
    }

    companion object {
        fun fromJson(o: JSONObject): DayRecord {
            val subMap = mutableMapOf<String, Long>()
            o.optJSONObject("subjects")?.let { so ->
                val it = so.keys()
                while (it.hasNext()) {
                    val k = it.next()
                    subMap[k] = so.optLong(k, 0L)
                }
            }
            val wrMap = mutableMapOf<String, Long>()
        val awMap = mutableMapOf<String, Long>()
            o.optJSONObject("wasteReasons")?.let { wo ->
                val it = wo.keys()
                while (it.hasNext()) {
                    val k = it.next()
                    wrMap[k] = wo.optLong(k, 0L)
                }
            }
            return DayRecord(
                date = o.optString("date", DataStore.todayIso()),
                subject = o.optString("subject", ""),
                c45 = o.optInt("c45", 0),
                c25 = o.optInt("c25", 0),
                studySec = o.optLong("studySec", 0L),
                wasteSec = o.optLong("wasteSec", 0L),
                wasteReason = o.optString("wasteReason", ""),
                sleepOtherSec = o.optLong("sleepOtherSec", 0L),
                wordTarget = o.optBoolean("wordTarget", false),
                synced = o.optBoolean("synced", false),
                subjects = subMap,
                wasteReasons = wrMap,
                mode = o.optString("mode", "flip"),
                estimated = o.optBoolean("estimated", false),
                eatSec = o.optLong("eatSec", 0L),
                flipSec = o.optLong("flipSec", 0L),
                manualSec = o.optLong("manualSec", 0L),
                onlineSec = o.optLong("onlineSec", 0L),
                awaySec = o.optLong("awaySec", 0L),
                awayReasons = mutableMapOf<String, Long>().apply {
                    o.optJSONObject("awayReasons")?.let { ao ->
                        val it = ao.keys()
                        while (it.hasNext()) { val k = it.next(); this[k] = ao.optLong(k, 0L) }
                    }
                }
            )
        }
    }
}

data class ChartBar(val label: String, val studyMin: Int, val wasteMin: Int, val sleepMin: Int)

data class ReportData(
    val period: String,
    val isYearly: Boolean,
    val totalStudyMin: Int,
    val totalWasteMin: Int,
    val totalSleepMin: Int,
    val avgDailyStudyMin: Int,
    val bestDay: String,
    val bestDayMin: Int,
    val currentStreak: Int,
    val longestStreak: Int,
    val productivityScore: Int,
    val subjects: Map<String, Long>,
    val wasteReasons: Map<String, Long>,
    val bars: List<ChartBar>,
    val isOffline: Boolean,
    val totalAwayMin: Int = 0,
    val awayReasons: Map<String, Long> = emptyMap()
)

enum class ReportPeriodType { DAY, WEEK, MONTH, YEAR }

data class UnifiedReportData(
    val type: ReportPeriodType,
    val anchorIso: String,
    val rangeStartIso: String,
    val rangeEndIso: String,
    val periodLabelBn: String,
    val isPartialCurrentPeriod: Boolean,
    val elapsedDaysCount: Int,
    val totalDaysCount: Int,
    val totalStudyMin: Int,
    val totalWasteMin: Int,
    val totalEatMin: Int,
    val totalSleepMin: Int,
    val totalAwayMin: Int,
    val flipMin: Int,
    val manualMin: Int,
    val onlineMin: Int,
    val avgDailyStudyMin: Int,
    val goalCompletionPct: Int,
    val wasteRatioScore: Int,
    val bestDayLabel: String,
    val bestDayMin: Int,
    val currentStreak: Int,
    val longestStreak: Int,
    val subjects: Map<String, Long>,
    val wasteReasons: Map<String, Long>,
    val awayReasons: Map<String, Long> = emptyMap(),
    val bars: List<ChartBar>,
    val hasAnyDataInPeriod: Boolean
)

data class RuntimeTrackerState(
    val running: Boolean,
    val mode: String, // IDLE, STUDY, BREAK, WASTE
    val stateStartMs: Long,
    val remainingSec: Int,
    val faceDown: Boolean
)

object DataStore {
    private const val PREF = "bcs_flip_study_prefs"
    private const val KEY_DAYS = "days_map_json"
    private const val KEY_GAS_URL = "gas_webapp_url"
    private const val KEY_SYNC_KEY = "gas_sync_secret_key"
    private const val KEY_PRESET_MIN = "preset_min"
    private const val KEY_ONLINE_STUDY = "online_study"
    private const val KEY_ALARM_ON = "alarm_on"
    private const val KEY_LAST_CLOSED = "last_closed_ms"
    private const val KEY_LAST_SYNC_TEXT = "last_sync_text"
    private const val KEY_SUBJECT = "current_subject"

    private const val KEY_GOAL_HOURS = "daily_goal_hours"
    private const val KEY_GOAL_NOTIF = "daily_goal_notif"
    private const val KEY_GOAL_NOTIFIED_DATE = "goal_notified_date"
    private const val KEY_EXAM_NAME = "exam_name"
    private const val KEY_EXAM_DATE = "exam_date_iso"
    private const val KEY_GRACE_SEC = "flip_grace_sec"
    private const val KEY_ALARM_MODE = "alarm_mode" // vibrate, sound, silent
    private const val KEY_THEME_MODE = "theme_mode" // day, night, auto
    private const val KEY_COLOR_PALETTE = "color_palette" // sage, ocean, espresso, nordic
    private const val KEY_FLIP_ENABLED = "flip_sensor_enabled"

    // ধাপ ১.৭: প্রসেস মারা গেলেও অবস্থা ধরে রাখার জন্য
    private const val KEY_RT_RUNNING = "rt_running"
    private const val KEY_RT_MODE = "rt_mode"
    private const val KEY_RT_START_MS = "rt_state_start_ms"
    private const val KEY_RT_REM_SEC = "rt_remaining_sec"
    private const val KEY_RT_FACE_DOWN = "rt_face_down"

    fun todayIso(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    fun currentMonthIso(): String = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
    fun currentYearIso(): String = SimpleDateFormat("yyyy", Locale.US).format(Date())

    fun toBnDigits(input: Any): String {
        val bn = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
        val s = input.toString()
        val sb = StringBuilder(s.length)
        for (ch in s) {
            if (ch in '0'..'9') sb.append(bn[ch - '0']) else sb.append(ch)
        }
        return sb.toString()
    }

    fun formatHoursMinBn(totalSec: Long): String {
        val mins = (totalSec / 60L).coerceAtLeast(0L)
        val h = mins / 60L
        val m = mins % 60L
        return if (h > 0) "${toBnDigits(h)}ঘ ${toBnDigits(m)}মি" else "${toBnDigits(m)}মি"
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun getGasUrl(ctx: Context): String = prefs(ctx).getString(KEY_GAS_URL, "") ?: ""
    fun setGasUrl(ctx: Context, url: String) = prefs(ctx).edit().putString(KEY_GAS_URL, url.trim()).apply()

    private const val KEY_SYNC_KEY_ENC = "gas_sync_secret_key_enc"
    private const val KEYSTORE_ALIAS_SYNC = "bcs_flip_sync_key_aes"

    private fun getOrCreateSyncAesKey(): SecretKey? {
        return try {
            val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            (ks.getKey(KEYSTORE_ALIAS_SYNC, null) as? SecretKey) ?: run {
                val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
                kg.init(
                    KeyGenParameterSpec.Builder(
                        KEYSTORE_ALIAS_SYNC,
                        KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                    )
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                        .setKeySize(256)
                        .build()
                )
                kg.generateKey()
            }
        } catch (_: Exception) { null }
    }

    fun getSyncKey(ctx: Context): String {
        val p = prefs(ctx)
        val enc = p.getString(KEY_SYNC_KEY_ENC, "") ?: ""
        if (enc.isNotEmpty()) {
            try {
                val raw = Base64.decode(enc, Base64.NO_WRAP)
                if (raw.size > 12) {
                    val iv = raw.copyOfRange(0, 12)
                    val ct = raw.copyOfRange(12, raw.size)
                    val key = getOrCreateSyncAesKey()
                    if (key != null) {
                        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
                        return String(cipher.doFinal(ct), Charsets.UTF_8)
                    }
                }
            } catch (_: Exception) {}
        }
        val legacy = p.getString(KEY_SYNC_KEY, "") ?: ""
        if (legacy.isNotEmpty()) {
            setSyncKey(ctx, legacy)
            return legacy
        }
        return ""
    }

    fun setSyncKey(ctx: Context, k: String) {
        val clean = k.trim()
        val p = prefs(ctx)
        if (clean.isEmpty()) {
            p.edit().remove(KEY_SYNC_KEY_ENC).remove(KEY_SYNC_KEY).apply()
            return
        }
        try {
            val key = getOrCreateSyncAesKey()
            if (key != null) {
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.ENCRYPT_MODE, key)
                val iv = cipher.iv
                val ct = cipher.doFinal(clean.toByteArray(Charsets.UTF_8))
                val combined = ByteArray(iv.size + ct.size)
                System.arraycopy(iv, 0, combined, 0, iv.size)
                System.arraycopy(ct, 0, combined, iv.size, ct.size)
                p.edit()
                    .putString(KEY_SYNC_KEY_ENC, Base64.encodeToString(combined, Base64.NO_WRAP))
                    .remove(KEY_SYNC_KEY)
                    .apply()
                return
            }
        } catch (_: Exception) {}
        p.edit().putString(KEY_SYNC_KEY, clean).apply()
    }

    fun getPresetMin(ctx: Context): Int = prefs(ctx).getInt(KEY_PRESET_MIN, 45)
    fun setPresetMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_PRESET_MIN, min).apply()

    fun isOnlineStudy(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_ONLINE_STUDY, false)
    fun setOnlineStudy(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_ONLINE_STUDY, on).apply()

    fun isAlarmOn(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_ALARM_ON, true)
    fun setAlarmOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_ALARM_ON, on).apply()

    fun getCurrentSubject(ctx: Context): String = prefs(ctx).getString(KEY_SUBJECT, "BCS প্রস্তুতি") ?: "BCS প্রস্তুতি"
    fun setCurrentSubject(ctx: Context, sub: String) = prefs(ctx).edit().putString(KEY_SUBJECT, sub.trim().ifEmpty { "BCS প্রস্তুতি" }).apply()


    fun formatHmsBn(totalSec: Long): String {
        val s = totalSec.coerceAtLeast(0L)
        val h = s / 3600L
        val m = (s % 3600L) / 60L
        val sec = s % 60L
        return toBnDigits(String.format(Locale.US, "%02d:%02d:%02d", h, m, sec))
    }

    fun getDailyGoalHours(ctx: Context): Int = prefs(ctx).getInt(KEY_GOAL_HOURS, 4).coerceIn(1, 16)
    fun setDailyGoalHours(ctx: Context, h: Int) = prefs(ctx).edit().putInt(KEY_GOAL_HOURS, h.coerceIn(1, 16)).apply()

    fun isGoalNotifOn(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_GOAL_NOTIF, true)
    fun setGoalNotifOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_GOAL_NOTIF, on).apply()

    fun getGoalNotifiedDate(ctx: Context): String = prefs(ctx).getString(KEY_GOAL_NOTIFIED_DATE, "") ?: ""
    fun setGoalNotifiedDate(ctx: Context, d: String) = prefs(ctx).edit().putString(KEY_GOAL_NOTIFIED_DATE, d).apply()

    fun getExamName(ctx: Context): String = prefs(ctx).getString(KEY_EXAM_NAME, "BCS পরীক্ষা") ?: "BCS পরীক্ষা"
    fun setExamName(ctx: Context, name: String) = prefs(ctx).edit().putString(KEY_EXAM_NAME, name.trim().ifEmpty { "BCS পরীক্ষা" }).apply()

    fun getExamDateIso(ctx: Context): String = prefs(ctx).getString(KEY_EXAM_DATE, "2027-02-26") ?: "2027-02-26"
    fun setExamDateIso(ctx: Context, iso: String) = prefs(ctx).edit().putString(KEY_EXAM_DATE, iso.trim()).apply()

    fun isValidIsoDate(iso: String): Boolean = try {
        val f = SimpleDateFormat("yyyy-MM-dd", Locale.US); f.isLenient = false
        f.parse(iso.trim()) != null && iso.trim().length == 10
    } catch (_: Exception) { false }

    fun getDaysUntilExam(ctx: Context): Int {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val target = sdf.parse(getExamDateIso(ctx)) ?: return 0
            val today = sdf.parse(todayIso()) ?: return 0
            val diff = ((target.time - today.time) / 86_400_000L).toInt()
            diff.coerceAtLeast(0)
        } catch (_: Exception) { 0 }
    }

    fun getGraceSec(ctx: Context): Int = prefs(ctx).getInt(KEY_GRACE_SEC, 5)
    fun setGraceSec(ctx: Context, sec: Int) = prefs(ctx).edit().putInt(KEY_GRACE_SEC, sec).apply()

    fun getAlarmMode(ctx: Context): String = prefs(ctx).getString(KEY_ALARM_MODE, "vibrate") ?: "vibrate"
    fun setAlarmMode(ctx: Context, mode: String) = prefs(ctx).edit().putString(KEY_ALARM_MODE, mode).apply()

    fun getThemeMode(ctx: Context): String = prefs(ctx).getString(KEY_THEME_MODE, "auto") ?: "auto"
    fun setThemeMode(ctx: Context, mode: String) = prefs(ctx).edit().putString(KEY_THEME_MODE, mode).apply()

    fun getColorPalette(ctx: Context): String = prefs(ctx).getString(KEY_COLOR_PALETTE, "ocean") ?: "ocean"
    fun setColorPalette(ctx: Context, id: String) = prefs(ctx).edit().putString(KEY_COLOR_PALETTE, id).apply()

    fun wasNotifPermAsked(ctx: Context): Boolean = prefs(ctx).getBoolean("notif_perm_asked", false)
    fun setNotifPermAsked(ctx: Context) = prefs(ctx).edit().putBoolean("notif_perm_asked", true).apply()

    fun isFlipEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_FLIP_ENABLED, false)
    fun setFlipEnabled(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_FLIP_ENABLED, on).apply()

    @Volatile private var cachedStreak: Int = -1
    @Volatile private var cachedStreakDate: String = ""

    fun getCurrentStreak(ctx: Context): Int {
        val today = todayIso()
        if (cachedStreak >= 0 && cachedStreakDate == today) return cachedStreak
        val map = getAllDaysMerged(ctx)
        val cal = Calendar.getInstance()
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        var streak = 0
        for (i in 0..365) {
            val c = cal.clone() as Calendar
            c.add(Calendar.DAY_OF_YEAR, -i)
            val rec = map[fmt.format(c.time)]
            if (rec != null && rec.totalStudyMinutes() > 0) streak++
            else if (i > 0) break
        }
        cachedStreak = streak
        cachedStreakDate = today
        val prevBest = prefs(ctx).getInt("saved_longest_streak", 0)
        prefs(ctx).edit()
            .putInt("saved_current_streak", streak)
            .putInt("saved_longest_streak", maxOf(prevBest, streak))
            .apply()
        return streak
    }

    fun getLast28DaysMinutes(ctx: Context): List<Int> {
        val map = getAllDaysMerged(ctx)
        val cal = Calendar.getInstance()
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val out = mutableListOf<Int>()
        for (i in 27 downTo 0) {
            val c = cal.clone() as Calendar
            c.add(Calendar.DAY_OF_YEAR, -i)
            out.add(map[fmt.format(c.time)]?.totalStudyMinutes() ?: 0)
        }
        return out
    }

    fun getCurrentMonthDays(ctx: Context): List<DayRecord> {
        val map = getAllDaysMerged(ctx)
        val cal = Calendar.getInstance()
        val maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val ym = SimpleDateFormat("yyyy-MM", Locale.US).format(cal.time)
        val list = mutableListOf<DayRecord>()
        for (d in 1..maxDay) {
            val iso = String.format(Locale.US, "%s-%02d", ym, d)
            list.add(map[iso] ?: DayRecord(date = iso))
        }
        return list
    }

    private fun csvEscape(raw: String): String {
        val clean = raw.replace("\r\n", " ").replace("\n", " ").replace("\r", " ")
        return if (clean.contains(",") || clean.contains("\"")) {
            val doubled = clean.replace("\"", "\"\"")
            "\"$doubled\""
        } else clean
    }

    fun buildCsvExport(ctx: Context, startIso: String? = null, endIso: String? = null): String {
        val map = getAllDaysMerged(ctx)
        val sb = StringBuilder("\uFEFFDate,Subject,StudyMin,FlipMin,ManualMin,OnlineMin,45mCircles,25mCircles,WasteMin,EatMin,SleepOtherMin,Mode,WordTarget,SubjectsJson,WasteReasonsJson,AwayMin,AwayReasonsJson\n")
        val rows = map.values.filter { r ->
            (startIso == null || r.date >= startIso) && (endIso == null || r.date <= endIso)
        }.sortedBy { it.date }
        for (rec in rows) {
            val flipM = rec.flipSec / 60L
            val manM = rec.manualSec / 60L
            val onM = rec.onlineSec / 60L
            val subJson = JSONObject().apply { rec.subjects.forEach { (k, v) -> put(k, v / 60L) } }.toString()
            val wrJson = JSONObject().apply { rec.wasteReasons.forEach { (k, v) -> put(k, v / 60L) } }.toString()
            sb.append(
                listOf(
                    csvEscape(rec.date),
                    csvEscape(rec.subject),
                    rec.totalStudyMinutes().toString(),
                    flipM.toString(),
                    manM.toString(),
                    onM.toString(),
                    rec.c45.toString(),
                    rec.c25.toString(),
                    (rec.wasteSec / 60L).toString(),
                    (rec.eatSec / 60L).toString(),
                    (rec.sleepOtherSec / 60L).toString(),
                    csvEscape(rec.mode),
                    rec.wordTarget.toString(),
                    csvEscape(subJson),
                    csvEscape(wrJson),
                    (rec.awaySec / 60L).toString(),
                    csvEscape(JSONObject().apply { rec.awayReasons.forEach { (k, v) -> put(k, v / 60L) } }.toString())
                ).joinToString(",")
            ).append("\n")
        }
        return sb.toString()
    }

    fun exportCsvToFile(ctx: Context, startIso: String? = null, endIso: String? = null, tag: String = "all"): File {
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val safeTag = tag.replace(Regex("[^a-zA-Z0-9_-]"), "_")
        val file = File(dir, "bcs_study_${safeTag}.csv")
        file.writeText(buildCsvExport(ctx, startIso, endIso), Charsets.UTF_8)
        return file
    }

    fun exportJsonToFile(ctx: Context): File {
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "bcs_study_backup_${todayIso()}.json")
        file.writeText(buildJsonExport(ctx), Charsets.UTF_8)
        return file
    }

    fun getLastSyncText(ctx: Context): String = prefs(ctx).getString(KEY_LAST_SYNC_TEXT, "এখনো সিঙ্ক হয়নি") ?: "এখনো সিঙ্ক হয়নি"
    fun setLastSyncText(ctx: Context, txt: String) = prefs(ctx).edit().putString(KEY_LAST_SYNC_TEXT, txt).apply()

    fun saveRuntimeState(ctx: Context, rt: RuntimeTrackerState) {
        prefs(ctx).edit()
            .putBoolean(KEY_RT_RUNNING, rt.running)
            .putString(KEY_RT_MODE, rt.mode)
            .putLong(KEY_RT_START_MS, rt.stateStartMs)
            .putInt(KEY_RT_REM_SEC, rt.remainingSec)
            .putBoolean(KEY_RT_FACE_DOWN, rt.faceDown)
            .apply()
    }

    fun loadRuntimeState(ctx: Context): RuntimeTrackerState {
        val p = prefs(ctx)
        return RuntimeTrackerState(
            running = p.getBoolean(KEY_RT_RUNNING, false),
            mode = p.getString(KEY_RT_MODE, "IDLE") ?: "IDLE",
            stateStartMs = p.getLong(KEY_RT_START_MS, 0L),
            remainingSec = p.getInt(KEY_RT_REM_SEC, getPresetMin(ctx) * 60),
            faceDown = p.getBoolean(KEY_RT_FACE_DOWN, false)
        )
    }

    fun markAppClosedNow(ctx: Context) {
        prefs(ctx).edit().putLong(KEY_LAST_CLOSED, System.currentTimeMillis()).apply()
    }

    fun absorbClosedTimeAsSleepOther(ctx: Context): Long {
        val lastClosed = prefs(ctx).getLong(KEY_LAST_CLOSED, 0L)
        if (lastClosed <= 0L) return 0L
        val now = System.currentTimeMillis()
        val gapSec = (now - lastClosed) / 1000L
        prefs(ctx).edit().putLong(KEY_LAST_CLOSED, 0L).apply()
        if (gapSec in 60L..86400L) {
            val excluded = getBreakLedger(ctx).map { it.first to it.second }.toMutableList()
            val phase = getSrPhase(ctx)
            if (phase == SmartReminderManager.PHASE_EATING) {
                val bs = getSrEatStartMs(ctx)
                val bu = getSrEatUntilMs(ctx)
                if (bs > 0L) excluded.add(bs to minOf(now, if (bu > 0L) bu else now))
            } else if (phase == SmartReminderManager.PHASE_AWAY) {
                val bs = getSrAwayStartMs(ctx)
                val bu = getSrAwayUntilMs(ctx)
                if (bs > 0L) excluded.add(bs to minOf(now, if (bu > 0L) bu else now))
            }
            val remainingRanges = subtractIntervals(lastClosed, now, excluded)
            var totalAbsorbed = 0L
            if (remainingRanges.isNotEmpty()) {
                val map = loadAllDays(ctx)
                for ((rs, re) in remainingRanges) {
                    for ((iso, sec) in splitByDay(rs, re)) {
                        if (sec <= 0L) continue
                        val rec = map[iso] ?: DayRecord(date = iso, subject = getCurrentSubject(ctx))
                        rec.sleepOtherSec += sec
                        rec.synced = false
                        map[iso] = rec
                        totalAbsorbed += sec
                    }
                }
                if (totalAbsorbed > 0L) saveAllDays(ctx, map)
            }
            return totalAbsorbed
        }
        return 0L
    }

    @Volatile private var daysCache: MutableMap<String, DayRecord>? = null

    @Synchronized
    fun loadAllDays(ctx: Context): MutableMap<String, DayRecord> {
        daysCache?.let { cached ->
            return cached.toMutableMap()
        }
        val raw = prefs(ctx).getString(KEY_DAYS, "{}") ?: "{}"
        val map = mutableMapOf<String, DayRecord>()
        try {
            val obj = JSONObject(raw)
            val it = obj.keys()
            while (it.hasNext()) {
                val k = it.next()
                val child = obj.optJSONObject(k)
                if (child != null) map[k] = DayRecord.fromJson(child)
            }
        } catch (_: Exception) {}
        daysCache = map.toMutableMap()
        return map
    }

    @Synchronized
    fun saveAllDays(ctx: Context, map: Map<String, DayRecord>) {
        val copy = map.toMutableMap()
        daysCache = copy
        val obj = JSONObject()
        for ((k, v) in copy) obj.put(k, v.toJson())
        prefs(ctx).edit().putString(KEY_DAYS, obj.toString()).apply()
        cachedStreak = -1
    }

    @Synchronized
    fun getAllDaysMerged(ctx: Context): Map<String, DayRecord> =
        mergeDays(loadAllDays(ctx), loadDriveCache(ctx))


    @Synchronized
    fun addWaste(ctx: Context, startMs: Long, endMs: Long, reason: String = "অপচয় সময়") {
        val safeEnd = endMs
        val maxSpanMs = 4L * 3600L * 1000L
        val safeStart = if (startMs <= 0L || safeEnd <= startMs) safeEnd else maxOf(startMs, safeEnd - maxSpanMs)
        val segments = splitByDay(safeStart, safeEnd)
        if (segments.isEmpty()) return
        val map = loadAllDays(ctx)
        for ((iso, rawSec) in segments) {
            if (rawSec <= 0L) continue
            val rec = map[iso] ?: DayRecord(date = iso, subject = getCurrentSubject(ctx))
            // এক দিনে পড়া + অপচয় ২৪ ঘণ্টার বেশি হতে পারে না (আজকের ক্ষেত্রে মাঝরাত থেকে এখন পর্যন্তই সর্বোচ্চ)
            val room = (maxTrackableSecForDay(iso) - rec.studySec - rec.wasteSec).coerceAtLeast(0L)
            val sec = minOf(rawSec, room)
            if (sec <= 0L) continue
            rec.wasteSec += sec
            rec.wasteReasons[reason] = (rec.wasteReasons[reason] ?: 0L) + sec
            rec.synced = false
            map[iso] = rec
        }
        saveAllDays(ctx, map)
    }

    /** একক স্টাডি-লগিং পথ: মাঝরাত ভাগ, সোর্স (flip/manual/online) ও সর্বাধিক ৪ ঘণ্টা ক্যাপসহ। */
    @Synchronized
    fun addStudy(ctx: Context, startMs: Long, endMs: Long, source: String, circlePresetMin: Int = 0): DayRecord {
        val safeEnd = endMs
        val maxSpanMs = 4L * 3600L * 1000L
        val safeStart = if (startMs <= 0L || safeEnd <= startMs) safeEnd else maxOf(startMs, safeEnd - maxSpanMs)
        val sub = getCurrentSubject(ctx)
        val segments = splitByDay(safeStart, safeEnd)
        val today = todayIso()
        val map = loadAllDays(ctx)

        for ((iso, sec) in segments) {
            if (sec <= 0L) continue
            val rec = map[iso] ?: DayRecord(date = iso, subject = sub)
            rec.studySec += sec
            when (source) {
                "online" -> rec.onlineSec += sec
                "flip" -> rec.flipSec += sec
                else -> rec.manualSec += sec
            }
            rec.subject = sub
            rec.subjects[sub] = (rec.subjects[sub] ?: 0L) + sec
            rec.mode = source
            rec.synced = false
            map[iso] = rec
        }

        val todayRec = map[today] ?: DayRecord(date = today, subject = sub)
        if (circlePresetMin >= 40) {
            todayRec.c45 += 1
            todayRec.synced = false
            map[today] = todayRec
        } else if (circlePresetMin >= 20) {
            todayRec.c25 += 1
            todayRec.synced = false
            map[today] = todayRec
        }
        saveAllDays(ctx, map)
        return map[today] ?: todayRec
    }

    @Synchronized
    fun getToday(ctx: Context): DayRecord {
        val today = todayIso()
        val map = loadAllDays(ctx)
        return map[today] ?: DayRecord(date = today, subject = getCurrentSubject(ctx))
    }

    @Synchronized
    fun updateToday(ctx: Context, block: (DayRecord) -> Unit): DayRecord = updateDay(ctx, todayIso(), block)

    @Synchronized
    fun updateDay(ctx: Context, iso: String, block: (DayRecord) -> Unit): DayRecord {
        val map = loadAllDays(ctx)
        val rec = map[iso] ?: DayRecord(date = iso, subject = getCurrentSubject(ctx))
        block(rec)
        map[iso] = rec
        saveAllDays(ctx, map)
        return rec
    }

    /** ওই তারিখে সর্বোচ্চ কত সেকেন্ড ট্র্যাক হওয়া সম্ভব: আজ হলে মাঝরাত থেকে এখন পর্যন্ত, অতীত হলে ২৪ ঘণ্টা। */
    fun maxTrackableSecForDay(iso: String): Long {
        if (iso != todayIso()) return 86_400L
        return ((System.currentTimeMillis() - startOfTodayMs()) / 1000L).coerceIn(0L, 86_400L)
    }

    /**
     * পুরোনো বাগে (একই ফোন-ব্যবহার বারবার অপচয়ে যোগ হওয়া) অসম্ভব অপচয় জমে থাকলে
     * (যেমন ২৫ ঘণ্টা/দিন) সেটি সম্ভাব্য সর্বোচ্চে নামিয়ে আনে। স্বাভাবিক ডেটা অক্ষত থাকে।
     */
    @Synchronized
    fun repairImpossibleWaste(ctx: Context): Int {
        val map = loadAllDays(ctx)
        var fixed = 0
        for ((iso, rec) in map) {
            val allowed = (maxTrackableSecForDay(iso) - rec.studySec).coerceAtLeast(0L)
            if (rec.wasteSec <= allowed) continue
            val ratio = allowed.toDouble() / rec.wasteSec.toDouble()
            val keys = rec.wasteReasons.keys.toList()
            var sum = 0L
            for (k in keys) {
                val v = ((rec.wasteReasons[k] ?: 0L) * ratio).toLong()
                if (v > 0L) { rec.wasteReasons[k] = v; sum += v } else rec.wasteReasons.remove(k)
            }
            rec.wasteSec = if (keys.isEmpty()) allowed else sum
            rec.synced = false
            fixed++
        }
        if (fixed > 0) saveAllDays(ctx, map)
        return fixed
    }

    fun startOfTodayMs(): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    /** একটি সময়-খণ্ড মাঝরাতে ভাগ করে (তারিখ, সেকেন্ড) তালিকা দেয়, যাতে রাত ১২টা পেরোনো সেশন দুই দিনে ঠিকভাবে বসে। */
    fun splitByDay(startMs: Long, endMs: Long): List<Pair<String, Long>> {
        val out = mutableListOf<Pair<String, Long>>()
        if (endMs <= startMs) return out
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        var cursor = startMs
        var guard = 0
        while (cursor < endMs && guard < 40) {
            val c = Calendar.getInstance().apply { timeInMillis = cursor }
            val iso = fmt.format(c.time)
            c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0)
            c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
            c.add(Calendar.DAY_OF_YEAR, 1)
            val segEnd = minOf(endMs, c.timeInMillis)
            val sec = (segEnd - cursor) / 1000L
            if (sec > 0L) out.add(Pair(iso, sec))
            cursor = segEnd
            guard++
        }
        return out
    }

    // সিঙ্কের সময় ডেটা বদলেছে কিনা বুঝতে কনটেন্ট-সিগনেচার (synced ফ্ল্যাগ বাদে)
    private fun contentSig(r: DayRecord): String =
        "${r.studySec}|${r.flipSec}|${r.manualSec}|${r.onlineSec}|${r.mode}|${r.wasteSec}|${r.sleepOtherSec}|${r.eatSec}|${r.c45}|${r.c25}|${r.wordTarget}|${r.subject}|${r.wasteReason}|" +
            r.subjects.toSortedMap() + "|" + r.wasteReasons.toSortedMap() + "|${r.awaySec}|" + r.awayReasons.toSortedMap()

    fun getLast7Days(ctx: Context): List<DayRecord> {
        val map = getAllDaysMerged(ctx)
        val cal = Calendar.getInstance()
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val list = mutableListOf<DayRecord>()
        for (i in 6 downTo 0) {
            val c = cal.clone() as Calendar
            c.add(Calendar.DAY_OF_YEAR, -i)
            val d = fmt.format(c.time)
            list.add(map[d] ?: DayRecord(date = d))
        }
        return list
    }

    fun hasUnsyncedDays(ctx: Context): Boolean = loadAllDays(ctx).values.any { !it.synced }

    // ধাপ ২.১ ও ২.৪: শুধু synced=false দিন পাঠানো, {"ok":true} পেলেই synced=true, লোকাল ডেটা কখনো মুছবে না
    fun syncToGoogleDrive(ctx: Context): Pair<Boolean, String> {
        val urlStr = getGasUrl(ctx)
        if (urlStr.isBlank() || !urlStr.startsWith("http")) {
            return Pair(false, "সেটিংসে আগে Apps Script লিংক বসাও")
        }
        val map = loadAllDays(ctx)
        val unsynced = map.values.filter { !it.synced }.sortedBy { it.date }
        val sentSigs = unsynced.associate { it.date to contentSig(it) }
        if (unsynced.isEmpty()) {
            return Pair(true, "নতুন কোনো অসিঙ্কড ডেটা নেই (সব আপডেট আছে)")
        }
        return try {
            val arr = JSONArray()
            for (rec in unsynced) arr.put(rec.toJson())
            val payload = JSONObject().apply {
                put("appKey", "study_tracker")
                put("key", getSyncKey(ctx))
                put("updatedAt", System.currentTimeMillis())
                put("days", arr)
            }.toString()

            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                instanceFollowRedirects = true
                connectTimeout = 15000
                readTimeout = 15000
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            }
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val respText = if (stream != null) BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() } else ""
            conn.disconnect()

            val okJson = try { JSONObject(respText).optBoolean("ok", false) } catch (_: Exception) { false }
            if (code in 200..299 && okJson) {
                markSyncedIfUnchanged(ctx, sentSigs)
                pruneSyncedOldDays(ctx)
                val stamp = SimpleDateFormat("dd MMM, hh:mm a", Locale.US).format(Date())
                setLastSyncText(ctx, "সিঙ্কড: $stamp")
                Pair(true, "${toBnDigits(unsynced.size)}টি দিনের ডেটা ড্রাইভে সিঙ্ক হয়েছে!")
            } else {
                val errMsg = try { JSONObject(respText).optString("error", "") } catch (_: Exception) { "" }
                Pair(false, if (errMsg.isNotEmpty()) "সার্ভার ত্রুটি: $errMsg" else "সিঙ্ক ব্যর্থ (কোড: $code)")
            }
        } catch (e: Exception) {
            Pair(false, "নেটওয়ার্ক ত্রুটি: ${e.localizedMessage ?: "অজানা"}")
        }
    }

    // নেটওয়ার্ক কলের সময় সার্ভিস নতুন ডেটা লিখলে সেটি যেন মুছে না যায় এবং "synced" ভুলভাবে না বসে
    @Synchronized
    private fun markSyncedIfUnchanged(ctx: Context, sentSigs: Map<String, String>) {
        val fresh = loadAllDays(ctx)
        for ((date, sig) in sentSigs) {
            val rec = fresh[date] ?: continue
            if (contentSig(rec) == sig) rec.synced = true
        }
        saveAllDays(ctx, fresh)
    }

    // ধাপ ৪: মাসিক/বার্ষিক রিপোর্ট (লোকাল + ড্রাইভ ক্যাশ মার্জ, খালি থাকলে সার্ভার ফলব্যাক)
    fun fetchOrComputeReport(ctx: Context, period: String, isYearly: Boolean): ReportData {
        val merged = mergeDays(loadAllDays(ctx), loadDriveCache(ctx))
        val hasMerged = merged.values.any {
            it.date.startsWith(period) && (it.totalStudyMinutes() > 0 || it.wasteSec > 0L || it.sleepOtherSec > 0L || it.eatSec > 0L)
        }
        if (hasMerged) {
            return computeReportFromMap(merged, period, isYearly, false)
        }
        val cacheKey = "report_cache_${if (isYearly) "y" else "m"}_$period"
        val cacheTsKey = "${cacheKey}_ts"
        val p = prefs(ctx)
        val isCurrent = if (isYearly) period == currentYearIso() else period == currentMonthIso()
        val cachedRaw = p.getString(cacheKey, null)
        val cachedTs = p.getLong(cacheTsKey, 0L)
        val now = System.currentTimeMillis()

        // আগের মাস/বছর একবার ক্যাশ হলে আর আনতে হবে না; চলতি মাস ১ ঘণ্টার মধ্যে ক্যাশ ব্যবহার
        if (cachedRaw != null && (!isCurrent || (now - cachedTs) < 3600_000L)) {
            parseServerReport(cachedRaw, period, isYearly, false)?.let { return it }
        }

        val urlStr = getGasUrl(ctx)
        if (urlStr.startsWith("http")) {
            try {
                val paramName = if (isYearly) "year" else "month"
                val keyEnc = URLEncoder.encode(getSyncKey(ctx), "UTF-8")
                val sep = if (urlStr.contains("?")) "&" else "?"
                val fullUrl = "$urlStr${sep}action=report&$paramName=${URLEncoder.encode(period, "UTF-8")}&key=$keyEnc"
                val conn = (URL(fullUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    instanceFollowRedirects = true
                    connectTimeout = 10000
                    readTimeout = 12000
                }
                val code = conn.responseCode
                val txt = if (code in 200..299) BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { it.readText() } else ""
                conn.disconnect()
                val parsed = parseServerReport(txt, period, isYearly, false)
                if (parsed != null) {
                    p.edit().putString(cacheKey, txt).putLong(cacheTsKey, now).apply()
                    return parsed
                }
            } catch (_: Exception) {}
        }

        // অফলাইন বা সার্ভার না পেলে ক্যাশ অথবা লোকাল ডেটা থেকে হিসাব
        if (cachedRaw != null) {
            parseServerReport(cachedRaw, period, isYearly, true)?.let { return it }
        }
        return computeLocalReport(ctx, period, isYearly)
    }

    private fun parseServerReport(raw: String, period: String, isYearly: Boolean, offline: Boolean): ReportData? {
        return try {
            val o = JSONObject(raw)
            if (!o.optBoolean("ok", false)) return null
            val subMap = mutableMapOf<String, Long>()
            o.optJSONObject("subjects")?.let { so ->
                val it = so.keys()
                while (it.hasNext()) { val k = it.next(); subMap[k] = so.optLong(k, 0L) }
            }
            val wrMap = mutableMapOf<String, Long>()
            o.optJSONObject("wasteReasons")?.let { wo ->
                val it = wo.keys()
                while (it.hasNext()) { val k = it.next(); wrMap[k] = wo.optLong(k, 0L) }
            }
            val bars = mutableListOf<ChartBar>()
            val arr = o.optJSONArray("bars") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val b = arr.getJSONObject(i)
                bars.add(ChartBar(b.optString("label"), b.optInt("studyMin"), b.optInt("wasteMin"), b.optInt("sleepMin")))
            }
            ReportData(
                period = period,
                isYearly = isYearly,
                totalStudyMin = o.optInt("totalStudyMin"),
                totalWasteMin = o.optInt("totalWasteMin"),
                totalSleepMin = o.optInt("totalSleepMin"),
                avgDailyStudyMin = o.optInt("avgDailyStudyMin"),
                bestDay = o.optString("bestDay", "—"),
                bestDayMin = o.optInt("bestDayMin"),
                currentStreak = o.optInt("currentStreak"),
                longestStreak = o.optInt("longestStreak"),
                productivityScore = o.optInt("productivityScore"),
                subjects = subMap,
                wasteReasons = wrMap,
                bars = bars,
                isOffline = offline
            )
        } catch (_: Exception) { null }
    }

    private fun computeLocalReport(ctx: Context, period: String, isYearly: Boolean): ReportData =
        computeReportFromMap(mergeDays(loadAllDays(ctx), loadDriveCache(ctx)), period, isYearly, true)

    private fun computeReportFromMap(all: Map<String, DayRecord>, period: String, isYearly: Boolean, offline: Boolean): ReportData {
        val filtered = all.values.filter { it.date.startsWith(period) }.sortedBy { it.date }
        var totStudy = 0
        var totWaste = 0
        var totSleep = 0
        var bestDay = "—"
        var bestMin = 0
        val subMap = mutableMapOf<String, Long>()
        val wrMap = mutableMapOf<String, Long>()
        var curStreak = 0
        var maxStreak = 0

        for (d in filtered) {
            val sm = d.totalStudyMinutes()
            val wm = (d.wasteSec / 60L).toInt()
            val slm = (d.sleepOtherSec / 60L).toInt()
            totStudy += sm
            totWaste += wm
            totSleep += slm
            if (sm > bestMin) { bestMin = sm; bestDay = d.date.takeLast(2) }
            if (sm > 0) { curStreak++; if (curStreak > maxStreak) maxStreak = curStreak } else curStreak = 0
            for ((k, v) in d.subjects) subMap[k] = (subMap[k] ?: 0L) + v
            if (d.subjects.isEmpty() && d.subject.isNotEmpty() && sm > 0) {
                subMap[d.subject] = (subMap[d.subject] ?: 0L) + (sm * 60L)
            }
            for ((k, v) in d.wasteReasons) wrMap[ReasonCatalog.mapLegacyWasteReason(k)] = (wrMap[ReasonCatalog.mapLegacyWasteReason(k)] ?: 0L) + v
            if (d.wasteReasons.isEmpty() && d.wasteReason.isNotEmpty() && wm > 0) {
                wrMap[d.wasteReason] = (wrMap[d.wasteReason] ?: 0L) + (wm * 60L)
            }
        }

        val activeDays = filtered.count { it.totalStudyMinutes() > 0 }.coerceAtLeast(1)
        val avgDaily = totStudy / activeDays
        val denom = totStudy + totWaste
        val score = if (denom > 0) ((totStudy * 100) / denom) else 0

        val bars = mutableListOf<ChartBar>()
        if (isYearly) {
            val bnMonths = arrayOf("জানু", "ফেব্রু", "মার্চ", "এপ্রি", "মে", "জুন", "জুলা", "আগ", "সেপ্টে", "অক্টো", "নভে", "ডিসে")
            for (m in 1..12) {
                val ym = String.format(Locale.US, "%s-%02d", period, m)
                val mDays = filtered.filter { it.date.startsWith(ym) }
                bars.add(ChartBar(
                    bnMonths[m - 1],
                    mDays.sumOf { it.totalStudyMinutes() },
                    mDays.sumOf { (it.wasteSec / 60L).toInt() },
                    mDays.sumOf { (it.sleepOtherSec / 60L).toInt() }
                ))
            }
        } else {
            val parts = period.split("-")
            val cal = Calendar.getInstance().apply {
                set(Calendar.YEAR, parts.getOrNull(0)?.toIntOrNull() ?: 2026)
                set(Calendar.MONTH, (parts.getOrNull(1)?.toIntOrNull() ?: 1) - 1)
                set(Calendar.DAY_OF_MONTH, 1)
            }
            val maxD = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
            for (day in 1..maxD) {
                val iso = String.format(Locale.US, "%s-%02d", period, day)
                val rec = all[iso]
                bars.add(ChartBar(
                    toBnDigits(day),
                    rec?.totalStudyMinutes() ?: 0,
                    ((rec?.wasteSec ?: 0L) / 60L).toInt(),
                    ((rec?.sleepOtherSec ?: 0L) / 60L).toInt()
                ))
            }
        }

        return ReportData(period, isYearly, totStudy, totWaste, totSleep, avgDaily, bestDay, bestMin, curStreak, maxStreak, score, subMap, wrMap, bars, offline)
    }

    // v7: স্মার্ট রিমাইন্ডার সেটিংস ও রানটাইম স্টেট (সব নতুন কী; পুরোনো কিছু বদলানো হয়নি)
    private const val KEY_SR_ENABLED = "sr_enabled"
    private const val KEY_SR_ASK_DELAY_MIN = "sr_ask_delay_min"
    private const val KEY_SR_REPEAT_MIN = "sr_repeat_min"
    private const val KEY_SR_READ_RECHECK_MIN = "sr_read_recheck_min"
    private const val KEY_SR_READ_RESET_MIN = "sr_read_reset_min"
    private const val KEY_SR_IDLE_MIN = "sr_idle_min"
    private const val KEY_SR_QUIET_ON = "sr_quiet_on"
    private const val KEY_SR_QUIET_START_MIN = "sr_quiet_start_min"
    private const val KEY_SR_QUIET_END_MIN = "sr_quiet_end_min"
    private const val KEY_SR_MASCOT_STYLE = "sr_mascot_style"
    private const val KEY_SR_POPUP_OVERLAY = "sr_popup_overlay"

    private const val KEY_SR_PHASE = "sr_phase"
    private const val KEY_SR_LEVEL = "sr_level"
    private const val KEY_SR_USE_ACCUM_MS = "sr_use_accum_ms"
    private const val KEY_SR_USE_SEGMENT_START_MS = "sr_use_segment_start_ms"
    private const val KEY_SR_SCREEN_OFF_SINCE_MS = "sr_screen_off_since_ms"
    private const val KEY_SR_PREV_ONLINE = "sr_prev_online"
    private const val KEY_SR_SESSION_STARTED_BY_REMINDER = "sr_session_started_by_reminder"
    private const val KEY_SR_LAST_STUDY_END_MS = "sr_last_study_end_ms"
    private const val KEY_SR_IDLE_FIRED_EPISODE = "sr_idle_fired_episode"
    private const val KEY_SR_APP_FG = "sr_app_fg"
    private const val KEY_SR_MIGRATED_V7 = "sr_migrated_v7"

    fun isSrEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_ENABLED, true)
    fun setSrEnabled(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_ENABLED, on).apply()

    fun getSrAskDelayMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_ASK_DELAY_MIN, 2).coerceIn(1, 60)
    fun setSrAskDelayMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_ASK_DELAY_MIN, min).apply()

    fun getSrRepeatMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_REPEAT_MIN, 5).coerceIn(1, 60)
    fun setSrRepeatMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_REPEAT_MIN, min).apply()

    fun getSrReadRecheckMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_READ_RECHECK_MIN, 15).coerceIn(1, 120)
    fun setSrReadRecheckMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_READ_RECHECK_MIN, min).apply()

    fun getSrReadResetMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_READ_RESET_MIN, 3).coerceIn(1, 30)
    fun setSrReadResetMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_READ_RESET_MIN, min).apply()

    fun getSrIdleMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_IDLE_MIN, 45).coerceAtLeast(0)
    fun setSrIdleMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_IDLE_MIN, min).apply()

    fun isSrQuietOn(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_QUIET_ON, true)
    fun setSrQuietOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_QUIET_ON, on).apply()

    fun getSrQuietStartMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_QUIET_START_MIN, 0).coerceIn(0, 1439)
    fun setSrQuietStartMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_QUIET_START_MIN, min.coerceIn(0, 1439)).apply()

    fun getSrQuietEndMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_QUIET_END_MIN, 360).coerceIn(0, 1439)
    fun setSrQuietEndMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_QUIET_END_MIN, min.coerceIn(0, 1439)).apply()

    fun getSrMascotStyle(ctx: Context): String = prefs(ctx).getString(KEY_SR_MASCOT_STYLE, "auto") ?: "auto"
    fun setSrMascotStyle(ctx: Context, style: String) = prefs(ctx).edit().putString(KEY_SR_MASCOT_STYLE, style).apply()

    fun isSrPopupOverlayOn(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_POPUP_OVERLAY, true)
    fun setSrPopupOverlayOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_POPUP_OVERLAY, on).apply()

    fun getSrPhase(ctx: Context): String = prefs(ctx).getString(KEY_SR_PHASE, SmartReminderManager.PHASE_NORMAL) ?: SmartReminderManager.PHASE_NORMAL
    fun setSrPhase(ctx: Context, phase: String) = prefs(ctx).edit().putString(KEY_SR_PHASE, phase).apply()

    fun getSrLevel(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_LEVEL, 0).coerceIn(0, 5)
    fun setSrLevel(ctx: Context, lvl: Int) = prefs(ctx).edit().putInt(KEY_SR_LEVEL, lvl.coerceIn(0, 5)).apply()

    fun getSrUseAccumMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_USE_ACCUM_MS, 0L).coerceAtLeast(0L)
    fun setSrUseAccumMs(ctx: Context, ms: Long) {
        val e = prefs(ctx).edit().putLong(KEY_SR_USE_ACCUM_MS, ms.coerceAtLeast(0L))
        // জমা হওয়া ফোন-ব্যবহার শূন্য হলে "ইতিমধ্যে অপচয়ে যোগ হয়েছে" কাউন্টারও শূন্য হবে (নইলে একই সময় বারবার যোগ হয়)
        if (ms <= 0L) e.putLong(KEY_SR_WASTE_COMMITTED_MS, 0L)
        e.apply()
    }

    fun getSrUseSegmentStartMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_USE_SEGMENT_START_MS, 0L)
    fun setSrUseSegmentStartMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_USE_SEGMENT_START_MS, ms).apply()

    fun getSrScreenOffSinceMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_SCREEN_OFF_SINCE_MS, 0L)
    fun setSrScreenOffSinceMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_SCREEN_OFF_SINCE_MS, ms).apply()

    fun getSrPrevOnline(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_PREV_ONLINE, false)
    fun setSrPrevOnline(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_PREV_ONLINE, on).apply()

    fun isSrSessionStartedByReminder(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_SESSION_STARTED_BY_REMINDER, false)
    fun setSrSessionStartedByReminder(ctx: Context, started: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_SESSION_STARTED_BY_REMINDER, started).apply()

    fun getSrLastStudyEndMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_LAST_STUDY_END_MS, 0L)
    fun setSrLastStudyEndMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_LAST_STUDY_END_MS, ms).apply()

    fun isSrIdleFiredEpisode(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_IDLE_FIRED_EPISODE, false)
    fun setSrIdleFiredEpisode(ctx: Context, fired: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_IDLE_FIRED_EPISODE, fired).apply()

    fun isSrAppForeground(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_APP_FG, false)
    fun setSrAppForeground(ctx: Context, fg: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_APP_FG, fg).apply()

    fun isSrMigratedV7(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_MIGRATED_V7, false)
    fun setSrMigratedV7(ctx: Context, done: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_MIGRATED_V7, done).apply()

    fun formatTimeMinBn(totalMin: Int): String {
        val m = totalMin.coerceIn(0, 1439)
        return toBnDigits(String.format(Locale.US, "%02d:%02d", m / 60, m % 60))
    }

    // v7.1: ফলো-আপ দেরি, খাচ্ছি, বাইরে আছি ও স্ট্রিক্ট মোড কী
    private const val KEY_SR_FALLBACK_SEC = "sr_fallback_delay_sec"
    private const val KEY_SR_EAT_MIN = "sr_eat_min"
    private const val KEY_SR_STRICT_AFTER_MIN = "sr_strict_after_min"
    private const val KEY_SR_EAT_START_MS = "sr_eat_start_ms"
    private const val KEY_SR_EAT_UNTIL_MS = "sr_eat_until_ms"
    private const val KEY_SR_AWAY_UNTIL_MS = "sr_away_until_ms"
    private const val KEY_SR_AWAY_TOTAL_MIN = "sr_away_total_min"
    private const val KEY_SR_MSG_INDEX = "sr_msg_index"
    private const val KEY_SR_FB_KIND = "sr_pending_fb_kind"
    private const val KEY_SR_FB_LEVEL = "sr_pending_fb_level"
    private const val KEY_SR_FB_ELAPSED = "sr_pending_fb_elapsed"
    private const val KEY_SR_FB_MSG_IDX = "sr_pending_fb_msg_idx"

    fun getSrFallbackDelaySec(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_FALLBACK_SEC, 20).coerceIn(5, 120)
    fun setSrFallbackDelaySec(ctx: Context, sec: Int) = prefs(ctx).edit().putInt(KEY_SR_FALLBACK_SEC, sec.coerceIn(5, 120)).apply()

    fun getSrEatMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_EAT_MIN, 45).coerceIn(10, 180)
    fun setSrEatMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_EAT_MIN, min.coerceIn(10, 180)).apply()

    fun getSrStrictAfterMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_STRICT_AFTER_MIN, 30).coerceAtLeast(0)
    fun setSrStrictAfterMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_STRICT_AFTER_MIN, min.coerceAtLeast(0)).apply()

    fun getSrEatStartMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_EAT_START_MS, 0L)
    fun setSrEatStartMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_EAT_START_MS, ms).apply()

    fun getSrEatUntilMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_EAT_UNTIL_MS, 0L)
    fun setSrEatUntilMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_EAT_UNTIL_MS, ms).apply()

    fun getSrAwayUntilMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_AWAY_UNTIL_MS, 0L)
    fun setSrAwayUntilMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_AWAY_UNTIL_MS, ms).apply()

    fun getSrAwayTotalMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_AWAY_TOTAL_MIN, 0)
    fun setSrAwayTotalMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_AWAY_TOTAL_MIN, min).apply()

    fun getSrMsgIndex(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_MSG_INDEX, 0)
    fun setSrMsgIndex(ctx: Context, idx: Int) = prefs(ctx).edit().putInt(KEY_SR_MSG_INDEX, idx).apply()

    fun setSrPendingFallback(ctx: Context, kind: String, level: Int, elapsed: Int, msgIdx: Int) {
        prefs(ctx).edit()
            .putString(KEY_SR_FB_KIND, kind)
            .putInt(KEY_SR_FB_LEVEL, level)
            .putInt(KEY_SR_FB_ELAPSED, elapsed)
            .putInt(KEY_SR_FB_MSG_IDX, msgIdx)
            .apply()
    }
    fun clearSrPendingFallback(ctx: Context) {
        prefs(ctx).edit().putString(KEY_SR_FB_KIND, "").apply()
    }
    fun getSrPendingFbKind(ctx: Context): String = prefs(ctx).getString(KEY_SR_FB_KIND, "") ?: ""
    fun getSrPendingFbLevel(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_FB_LEVEL, 1)
    fun getSrPendingFbElapsed(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_FB_ELAPSED, 0)
    fun getSrPendingFbMsgIdx(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_FB_MSG_IDX, 0)

    // v7.2: কলে থাকলে কাস্টম সময় পরপর ৩বার ভাইব্রেট
    private const val KEY_SR_CALL_VIB_MIN = "sr_call_vib_min"
    fun getSrCallVibMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_CALL_VIB_MIN, 10).coerceAtLeast(0)
    fun setSrCallVibMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_CALL_VIB_MIN, min.coerceAtLeast(0)).apply()

    private const val KEY_SR_MAX_RAGE_NOTIF_SENT = "sr_max_rage_notif_sent"
    fun isSrMaxRageNotifSent(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_MAX_RAGE_NOTIF_SENT, false)
    fun setSrMaxRageNotifSent(ctx: Context, sent: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_MAX_RAGE_NOTIF_SENT, sent).apply()

    private const val KEY_SR_WASTE_COMMITTED_MS = "sr_waste_committed_ms"
    fun getSrWasteCommittedMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_WASTE_COMMITTED_MS, 0L).coerceAtLeast(0L)
    fun setSrWasteCommittedMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_WASTE_COMMITTED_MS, ms.coerceAtLeast(0L)).apply()

    // v8.7: শর্তসাপেক্ষ নিরাপদ প্রুনিং (JSON >= ১ MB এবং ৪ মাসের পুরোনো synced=true দিন, দিনে সর্বোচ্চ ১ বার)
    @Synchronized
    fun pruneSyncedOldDays(ctx: Context) {
        val today = todayIso()
        if (prefs(ctx).getString("sr_last_prune_date", "") == today) return
        val raw = prefs(ctx).getString(KEY_DAYS, "{}") ?: "{}"
        if (raw.length < 1_000_000) return

        val cal = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            add(Calendar.MONTH, -3) // চলতি মাস + আগের ৩টি পূর্ণ মাস রাখা হবে
        }
        val cutoffYm = SimpleDateFormat("yyyy-MM", Locale.US).format(cal.time)
        val map = loadAllDays(ctx)
        val driveCache = loadDriveCache(ctx).toMutableMap()
        val toPrune = mutableListOf<String>()
        for ((k, v) in map) {
            if (k.take(7) < cutoffYm && v.synced) {
                driveCache[k] = v
                toPrune.add(k)
            }
        }
        if (toPrune.isEmpty()) {
            prefs(ctx).edit().putString("sr_last_prune_date", today).apply()
            return
        }
        // আগে অ্যাটমিকভাবে drive_days.json সেভ নিশ্চিত করো, ব্যর্থ হলে প্রুনিং বাতিল
        if (!saveDriveCache(ctx, driveCache)) return
        for (k in toPrune) map.remove(k)
        saveAllDays(ctx, map)
        prefs(ctx).edit().putString("sr_last_prune_date", today).apply()
    }

    private fun driveCacheFile(ctx: Context): File = File(ctx.filesDir, "drive_days.json")

    @Synchronized
    fun loadDriveCache(ctx: Context): Map<String, DayRecord> {
        val f = driveCacheFile(ctx)
        if (!f.exists()) return emptyMap()
        val out = mutableMapOf<String, DayRecord>()
        try {
            val obj = JSONObject(f.readText(Charsets.UTF_8))
            val it = obj.keys()
            while (it.hasNext()) {
                val k = it.next()
                obj.optJSONObject(k)?.let { out[k] = DayRecord.fromJson(it) }
            }
        } catch (_: Exception) {}
        return out
    }

    @Synchronized
    fun saveDriveCache(ctx: Context, map: Map<String, DayRecord>): Boolean {
        return try {
            val obj = JSONObject()
            for ((k, v) in map) obj.put(k, v.toJson())
            val target = driveCacheFile(ctx)
            val tmp = File(ctx.filesDir, "drive_days.json.tmp")
            tmp.writeText(obj.toString(), Charsets.UTF_8)
            if (target.exists()) target.delete()
            tmp.renameTo(target)
        } catch (_: Exception) {
            false
        }
    }

    /** তারিখ ধরে মার্জ: লোকালে যে তারিখ আছে সেখানে লোকাল সবসময় জেতে, ড্রাইভ শুধু লোকালে-না-থাকা দিন ভরে। */
    fun mergeDays(local: Map<String, DayRecord>, drive: Map<String, DayRecord>): Map<String, DayRecord> {
        val merged = linkedMapOf<String, DayRecord>()
        for ((k, v) in drive) merged[k] = v
        for ((k, v) in local) merged[k] = v
        return merged
    }

    fun buildJsonExport(ctx: Context): String {
        val map = getAllDaysMerged(ctx)
        val obj = JSONObject()
        for ((k, v) in map.toSortedMap()) obj.put(k, v.toJson())
        return obj.toString(2)
    }

    /** ড্রাইভ (Apps Script action=all_days) থেকে ইনক্রিমেন্টাল (since=) ডেটা এনে ক্যাশ ও মার্জ করে। */
    fun fetchAllDaysFromDrive(ctx: Context, timeoutMs: Int = 10000): Pair<Boolean, Map<String, DayRecord>> {
        val cached = loadDriveCache(ctx).toMutableMap()
        val urlStr = getGasUrl(ctx)
        if (!urlStr.startsWith("http")) {
            return Pair(false, mergeDays(loadAllDays(ctx), cached))
        }
        return try {
            val lastDate = cached.keys.maxOrNull()?.let { iso ->
                try {
                    val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                    val c = Calendar.getInstance().apply { time = fmt.parse(iso)!!; add(Calendar.DAY_OF_YEAR, -2) }
                    fmt.format(c.time)
                } catch (_: Exception) { iso }
            } ?: ""
            val payload = JSONObject().apply {
                put("appKey", "study_tracker")
                put("action", "all_days")
                put("key", getSyncKey(ctx))
                if (lastDate.isNotEmpty()) put("since", lastDate)
            }.toString()
            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                instanceFollowRedirects = true
                connectTimeout = timeoutMs
                readTimeout = timeoutMs
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            }
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload) }
            var code = conn.responseCode
            var txt = if (code in 200..299) BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { it.readText() } else ""
            conn.disconnect()
            var o = try { JSONObject(txt) } catch (_: Exception) { JSONObject() }
            if (!(code in 200..299 && o.optBoolean("ok", false) && o.has("days"))) {
                val keyEnc = URLEncoder.encode(getSyncKey(ctx), "UTF-8")
                val sep = if (urlStr.contains("?")) "&" else "?"
                val sincePart = if (lastDate.isNotEmpty()) "&since=${URLEncoder.encode(lastDate, "UTF-8")}" else ""
                val fullUrl = "$urlStr${sep}action=all_days&key=$keyEnc$sincePart"
                val gConn = (URL(fullUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    instanceFollowRedirects = true
                    connectTimeout = timeoutMs
                    readTimeout = timeoutMs
                }
                code = gConn.responseCode
                txt = if (code in 200..299) BufferedReader(InputStreamReader(gConn.inputStream, Charsets.UTF_8)).use { it.readText() } else ""
                gConn.disconnect()
                o = JSONObject(txt)
            }
            if (code in 200..299 && o.optBoolean("ok", false)) {
                val arr = o.optJSONArray("days") ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val rec = DayRecord.fromJson(arr.getJSONObject(i)).apply { synced = true }
                    cached[rec.date] = rec
                }
                saveDriveCache(ctx, cached)
                Pair(true, mergeDays(loadAllDays(ctx), cached))
            } else {
                Pair(false, mergeDays(loadAllDays(ctx), cached))
            }
        } catch (_: Exception) {
            Pair(false, mergeDays(loadAllDays(ctx), cached))
        }
    }

    // v8.5: শেষ ৮টি মেসেজের ইতিহাস ও সিম ডেটা ড্যাশবোর্ড পছন্দ
    private const val KEY_SR_RECENT_MSGS = "sr_recent_msgs"
    private const val KEY_SR_DASH_CELL_ALWAYS = "sr_dash_cell_always"

    fun getSrRecentMsgs(ctx: Context): List<String> {
        val raw = prefs(ctx).getString(KEY_SR_RECENT_MSGS, "") ?: ""
        return if (raw.isEmpty()) emptyList() else raw.split("|").filter { it.isNotEmpty() }
    }

    fun recordSrRecentMsg(ctx: Context, key: String) {
        val list = getSrRecentMsgs(ctx).toMutableList()
        list.remove(key)
        list.add(key)
        while (list.size > 8) list.removeAt(0)
        prefs(ctx).edit().putString(KEY_SR_RECENT_MSGS, list.joinToString("|")).apply()
    }

    fun isSrDashCellAlways(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_DASH_CELL_ALWAYS, false)
    fun setSrDashCellAlways(ctx: Context, always: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_DASH_CELL_ALWAYS, always).apply()

    // v8.6: অফলাইন ডিভাইস-লক (পাসওয়ার্ডের SHA-256 হ্যাশ + ডিভাইস ANDROID_ID)
    private const val KEY_DEVICE_UNLOCK_TOKEN = "app_device_unlock_token"
    private const val APP_LOCK_PW_HASH = "91a50fccf53f1fcb5ef38d1c8d2b5ee91d5ea2ecdbb2ce419d432fbb416bee6e"

    fun sha256Hex(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun expectedDeviceToken(ctx: Context): String {
        val androidId = try {
            Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "bcs_dev"
        } catch (_: Exception) { "bcs_dev" }
        return sha256Hex("$APP_LOCK_PW_HASH|$androidId")
    }

    fun isDeviceUnlocked(ctx: Context): Boolean {
        val saved = prefs(ctx).getString(KEY_DEVICE_UNLOCK_TOKEN, "") ?: ""
        return saved.isNotEmpty() && saved == expectedDeviceToken(ctx)
    }

    fun verifyAndUnlockDevice(ctx: Context, rawPassword: String): Boolean {
        if (sha256Hex(rawPassword.trim()) == APP_LOCK_PW_HASH) {
            prefs(ctx).edit().putString(KEY_DEVICE_UNLOCK_TOKEN, expectedDeviceToken(ctx)).apply()
            return true
        }
        return false
    }

    // v9.0: একক রিপোর্ট গণনা, ক্যালেন্ডার পিরিয়ড, সিঙ্ক টেস্ট/রিসেট ও মাস্টার পাসওয়ার্ড রিকভারি
    private const val KEY_REPORT_PERIOD_TYPE = "report_period_type"
    private const val KEY_REPORT_ANCHOR_ISO = "report_anchor_iso"
    private const val KEY_WEEK_START_DAY = "report_week_start_day"
    private const val KEY_SYNC_LOCK_FAILS = "sync_lock_fails"
    private const val KEY_SYNC_LOCK_UNTIL = "sync_lock_until_ms"

    fun getReportPeriodType(ctx: Context): ReportPeriodType {
        val raw = prefs(ctx).getString(KEY_REPORT_PERIOD_TYPE, "MONTH") ?: "MONTH"
        return try { ReportPeriodType.valueOf(raw) } catch (_: Exception) { ReportPeriodType.MONTH }
    }

    fun setReportPeriodType(ctx: Context, type: ReportPeriodType) {
        prefs(ctx).edit().putString(KEY_REPORT_PERIOD_TYPE, type.name).apply()
    }

    fun getReportAnchorIso(ctx: Context): String {
        val saved = prefs(ctx).getString(KEY_REPORT_ANCHOR_ISO, "") ?: ""
        return if (isValidIsoDate(saved)) saved else todayIso()
    }

    fun setReportAnchorIso(ctx: Context, iso: String) {
        if (isValidIsoDate(iso)) prefs(ctx).edit().putString(KEY_REPORT_ANCHOR_ISO, iso).apply()
    }

    fun getWeekStartDay(ctx: Context): Int {
        val v = prefs(ctx).getInt(KEY_WEEK_START_DAY, Calendar.SUNDAY)
        return if (v == Calendar.SATURDAY) Calendar.SATURDAY else Calendar.SUNDAY
    }

    fun setWeekStartDay(ctx: Context, day: Int) {
        val safe = if (day == Calendar.SATURDAY) Calendar.SATURDAY else Calendar.SUNDAY
        prefs(ctx).edit().putInt(KEY_WEEK_START_DAY, safe).apply()
    }

    fun isSyncUrlValid(urlStr: String): Boolean {
        val u = urlStr.trim()
        return u.startsWith("https://") && u.contains("script.google.com") && u.endsWith("/exec")
    }

    fun testSyncConnection(ctx: Context, urlStr: String, syncKey: String): Pair<Boolean, String> {
        val cleanUrl = urlStr.trim()
        if (!isSyncUrlValid(cleanUrl)) {
            return Pair(false, "সঠিক Apps Script লিংক দাও (https://... এবং /exec দিয়ে শেষ)")
        }
        return try {
            val payload = JSONObject().apply {
                put("appKey", "study_tracker")
                put("action", "ping")
                put("key", syncKey.trim())
                put("days", JSONArray())
            }.toString()
            val conn = (URL(cleanUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                instanceFollowRedirects = true
                connectTimeout = 12000
                readTimeout = 12000
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            }
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val txt = if (stream != null) BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() } else ""
            conn.disconnect()
            val o = try { JSONObject(txt) } catch (_: Exception) { JSONObject() }
            if (code in 200..299 && o.optBoolean("ok", false)) {
                Pair(true, "সংযোগ সফল! সার্ভারে পাসওয়ার্ড মিলেছে।")
            } else {
                val err = o.optString("error", "")
                Pair(false, if (err.isNotEmpty()) "সার্ভার ত্রুটি: $err" else "সংযোগ ব্যর্থ (কোড: $code)")
            }
        } catch (e: Exception) {
            Pair(false, "নেটওয়ার্ক ত্রুটি: ${e.localizedMessage ?: "অজানা"}")
        }
    }

    @Synchronized
    fun resetSyncStateForNewUrl(ctx: Context, resendAllDays: Boolean, clearDriveCache: Boolean) {
        if (resendAllDays) {
            val local = loadAllDays(ctx)
            for (rec in local.values) rec.synced = false
            saveAllDays(ctx, local)
        }
        if (clearDriveCache) {
            try { driveCacheFile(ctx).delete() } catch (_: Exception) {}
        }
        cachedStreak = -1
    }

    fun verifyAppMasterPassword(rawPassword: String): Boolean {
        return sha256Hex(rawPassword.trim()) == APP_LOCK_PW_HASH
    }

    fun getSyncLockFailCount(ctx: Context): Int = prefs(ctx).getInt(KEY_SYNC_LOCK_FAILS, 0)
    fun getSyncLockUntilMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SYNC_LOCK_UNTIL, 0L)
    fun recordSyncLockFailure(ctx: Context): Long {
        val next = getSyncLockFailCount(ctx) + 1
        val until = if (next >= 5) System.currentTimeMillis() + 60_000L else 0L
        prefs(ctx).edit().putInt(KEY_SYNC_LOCK_FAILS, next).putLong(KEY_SYNC_LOCK_UNTIL, until).apply()
        return until
    }
    fun resetSyncLockFailures(ctx: Context) {
        prefs(ctx).edit().putInt(KEY_SYNC_LOCK_FAILS, 0).putLong(KEY_SYNC_LOCK_UNTIL, 0L).apply()
    }

    fun computeUnifiedReport(ctx: Context, type: ReportPeriodType, anchorIso: String): UnifiedReportData {
        val all = getAllDaysMerged(ctx)
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val today = todayIso()
        val anchorCal = Calendar.getInstance().apply {
            time = try { fmt.parse(anchorIso) ?: Date() } catch (_: Exception) { Date() }
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val bnMonthsFull = arrayOf("জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর")
        val bnMonthsShort = arrayOf("জানু", "ফেব্রু", "মার্চ", "এপ্রি", "মে", "জুন", "জুলা", "আগ", "সেপ্টে", "অক্টো", "নভে", "ডিসে")
        val bnWeekDaysShort = arrayOf("রবি", "সোম", "মঙ্গল", "বুধ", "বৃহ", "শুক্র", "শনি")

        val startIso: String
        val endIso: String
        val totalDaysCount: Int
        val elapsedDaysCount: Int
        val isPartialCurrent: Boolean
        val baseLabel: String

        when (type) {
            ReportPeriodType.DAY -> {
                startIso = fmt.format(anchorCal.time)
                endIso = startIso
                totalDaysCount = 1
                elapsedDaysCount = 1
                isPartialCurrent = false
                val mName = bnMonthsFull[anchorCal.get(Calendar.MONTH)]
                baseLabel = "${toBnDigits(anchorCal.get(Calendar.DAY_OF_MONTH))} $mName ${toBnDigits(anchorCal.get(Calendar.YEAR))}"
            }
            ReportPeriodType.WEEK -> {
                val weekStart = getWeekStartDay(ctx)
                val startCal = anchorCal.clone() as Calendar
                while (startCal.get(Calendar.DAY_OF_WEEK) != weekStart) {
                    startCal.add(Calendar.DAY_OF_YEAR, -1)
                }
                val endCal = startCal.clone() as Calendar
                endCal.add(Calendar.DAY_OF_YEAR, 6)
                startIso = fmt.format(startCal.time)
                endIso = fmt.format(endCal.time)
                totalDaysCount = 7
                isPartialCurrent = today in startIso..endIso && today < endIso
                elapsedDaysCount = if (today in startIso..endIso) {
                    var cnt = 0
                    val tmp = startCal.clone() as Calendar
                    while (fmt.format(tmp.time) <= today) { cnt++; tmp.add(Calendar.DAY_OF_YEAR, 1) }
                    cnt.coerceIn(1, 7)
                } else 7
                val sDay = toBnDigits(startCal.get(Calendar.DAY_OF_MONTH))
                val eDay = toBnDigits(endCal.get(Calendar.DAY_OF_MONTH))
                val sMon = bnMonthsShort[startCal.get(Calendar.MONTH)]
                val eMon = bnMonthsShort[endCal.get(Calendar.MONTH)]
                baseLabel = if (sMon == eMon) "$sDay–$eDay $eMon" else "$sDay $sMon – $eDay $eMon"
            }
            ReportPeriodType.MONTH -> {
                val ym = SimpleDateFormat("yyyy-MM", Locale.US).format(anchorCal.time)
                val maxD = anchorCal.getActualMaximum(Calendar.DAY_OF_MONTH)
                startIso = "$ym-01"
                endIso = String.format(Locale.US, "%s-%02d", ym, maxD)
                totalDaysCount = maxD
                isPartialCurrent = today.startsWith(ym) && today < endIso
                elapsedDaysCount = if (today.startsWith(ym)) {
                    (today.takeLast(2).toIntOrNull() ?: maxD).coerceIn(1, maxD)
                } else maxD
                baseLabel = "${bnMonthsFull[anchorCal.get(Calendar.MONTH)]} ${toBnDigits(anchorCal.get(Calendar.YEAR))}"
            }
            ReportPeriodType.YEAR -> {
                val yr = anchorCal.get(Calendar.YEAR)
                startIso = "$yr-01-01"
                endIso = "$yr-12-31"
                totalDaysCount = anchorCal.getActualMaximum(Calendar.DAY_OF_YEAR)
                isPartialCurrent = today.startsWith("$yr-") && today < endIso
                elapsedDaysCount = if (today.startsWith("$yr-")) {
                    Calendar.getInstance().get(Calendar.DAY_OF_YEAR).coerceIn(1, totalDaysCount)
                } else totalDaysCount
                baseLabel = "সাল ${toBnDigits(yr)}"
            }
        }

        val periodLabelBn = if (isPartialCurrent && type != ReportPeriodType.DAY) {
            val prefix = when (type) {
                ReportPeriodType.WEEK -> "চলতি সপ্তাহ"
                ReportPeriodType.MONTH -> "চলতি মাস"
                else -> "চলতি বছর"
            }
            "$prefix (${toBnDigits(elapsedDaysCount)}/${toBnDigits(totalDaysCount)} দিন)"
        } else baseLabel

        val filtered = all.values.filter { it.date in startIso..endIso }.sortedBy { it.date }
        var totStudy = 0
        var totWaste = 0
        var totEat = 0
        var totSleep = 0
        var totAway = 0
        var flipM = 0
        var manM = 0
        var onM = 0
        var bestDayLabel = "—"
        var bestMin = 0
        val subMap = mutableMapOf<String, Long>()
        val wrMap = mutableMapOf<String, Long>()
        val awMap = mutableMapOf<String, Long>()
        var periodMaxStreak = 0
        var runningStreak = 0

        for (d in filtered) {
            val sm = d.totalStudyMinutes()
            val wm = (d.wasteSec / 60L).toInt()
            val em = (d.eatSec / 60L).toInt()
            val slm = (d.sleepOtherSec / 60L).toInt()
            val awm = (d.awaySec / 60L).toInt()
            totStudy += sm
            totWaste += wm
            totEat += em
            totSleep += slm
            totAway += awm
            val fMin = (d.flipSec / 60L).toInt()
            val mMin = (d.manualSec / 60L).toInt()
            val oMin = (d.onlineSec / 60L).toInt()
            if (fMin + mMin + oMin > 0) {
                flipM += fMin; manM += mMin; onM += oMin
            } else if (sm > 0) {
                if (d.mode == "online") onM += sm else flipM += sm
            }
            if (sm > bestMin) {
                bestMin = sm
                bestDayLabel = "${toBnDigits(d.date.takeLast(2))} ${bnMonthsShort[(d.date.substring(5, 7).toIntOrNull() ?: 1) - 1]}"
            }
            if (sm > 0) { runningStreak++; if (runningStreak > periodMaxStreak) periodMaxStreak = runningStreak } else runningStreak = 0
            for ((k, v) in d.subjects) subMap[k] = (subMap[k] ?: 0L) + v
            if (d.subjects.isEmpty() && d.subject.isNotEmpty() && sm > 0) {
                subMap[d.subject] = (subMap[d.subject] ?: 0L) + (sm * 60L)
            }
            for ((k, v) in d.wasteReasons) wrMap[ReasonCatalog.mapLegacyWasteReason(k)] = (wrMap[ReasonCatalog.mapLegacyWasteReason(k)] ?: 0L) + v
            for ((k, v) in d.awayReasons) awMap[k] = (awMap[k] ?: 0L) + v
            if (d.wasteReasons.isEmpty() && d.wasteReason.isNotEmpty() && wm > 0) {
                wrMap[d.wasteReason] = (wrMap[d.wasteReason] ?: 0L) + (wm * 60L)
            }
        }

        val hasAnyData = filtered.any { it.totalStudyMinutes() > 0 || it.wasteSec > 0L || it.eatSec > 0L || it.sleepOtherSec > 0L || it.awaySec > 0L }
        val avgDaily = totStudy / elapsedDaysCount.coerceAtLeast(1)
        val targetTotalMin = (getDailyGoalHours(ctx) * 60) * elapsedDaysCount.coerceAtLeast(1)
        val goalPct = if (targetTotalMin > 0) ((totStudy * 100) / targetTotalMin).coerceAtMost(999) else 0
        val denom = totStudy + totWaste
        val wasteScore = if (denom > 0) ((totStudy * 100) / denom) else 0

        val bars = mutableListOf<ChartBar>()
        when (type) {
            ReportPeriodType.DAY -> { /* দিনে বার চার্ট দেখানো হয় না */ }
            ReportPeriodType.WEEK -> {
                val c = Calendar.getInstance().apply { time = fmt.parse(startIso) ?: Date() }
                for (i in 0..6) {
                    val iso = fmt.format(c.time)
                    val rec = all[iso]
                    val wd = bnWeekDaysShort[c.get(Calendar.DAY_OF_WEEK) - 1]
                    bars.add(ChartBar(wd, rec?.totalStudyMinutes() ?: 0, ((rec?.wasteSec ?: 0L) / 60L).toInt(), ((rec?.sleepOtherSec ?: 0L) / 60L).toInt()))
                    c.add(Calendar.DAY_OF_YEAR, 1)
                }
            }
            ReportPeriodType.MONTH -> {
                val ym = startIso.take(7)
                for (day in 1..totalDaysCount) {
                    val iso = String.format(Locale.US, "%s-%02d", ym, day)
                    val rec = all[iso]
                    bars.add(ChartBar(toBnDigits(day), rec?.totalStudyMinutes() ?: 0, ((rec?.wasteSec ?: 0L) / 60L).toInt(), ((rec?.sleepOtherSec ?: 0L) / 60L).toInt()))
                }
            }
            ReportPeriodType.YEAR -> {
                val yr = startIso.take(4)
                for (m in 1..12) {
                    val ym = String.format(Locale.US, "%s-%02d", yr, m)
                    val mDays = filtered.filter { it.date.startsWith(ym) }
                    bars.add(ChartBar(
                        bnMonthsShort[m - 1],
                        mDays.sumOf { it.totalStudyMinutes() },
                        mDays.sumOf { (it.wasteSec / 60L).toInt() },
                        mDays.sumOf { (it.sleepOtherSec / 60L).toInt() }
                    ))
                }
            }
        }

        val curStreak = getCurrentStreak(ctx)
        val savedLongest = prefs(ctx).getInt("saved_longest_streak", 0).coerceAtLeast(periodMaxStreak).coerceAtLeast(curStreak)

        return UnifiedReportData(
            type = type,
            anchorIso = fmt.format(anchorCal.time),
            rangeStartIso = startIso,
            rangeEndIso = endIso,
            periodLabelBn = periodLabelBn,
            isPartialCurrentPeriod = isPartialCurrent,
            elapsedDaysCount = elapsedDaysCount,
            totalDaysCount = totalDaysCount,
            totalStudyMin = totStudy,
            totalWasteMin = totWaste,
            totalEatMin = totEat,
            totalSleepMin = totSleep,
            totalAwayMin = totAway,
            flipMin = flipM,
            manualMin = manM,
            onlineMin = onM,
            avgDailyStudyMin = avgDaily,
            goalCompletionPct = goalPct,
            wasteRatioScore = wasteScore,
            bestDayLabel = bestDayLabel,
            bestDayMin = bestMin,
            currentStreak = curStreak,
            longestStreak = savedLongest,
            subjects = subMap,
            wasteReasons = wrMap,
            awayReasons = awMap,
            bars = bars,
            hasAnyDataInPeriod = hasAnyData
        )
    }

    private const val KEY_SR_MORNING_GREETED_DATE = "sr_morning_greeted_date"
    private const val KEY_SR_LAST_ACTIVE_DATE = "sr_last_active_date"

    fun getSrMorningGreetedDate(ctx: Context): String = prefs(ctx).getString(KEY_SR_MORNING_GREETED_DATE, "") ?: ""
    fun setSrMorningGreetedDate(ctx: Context, d: String) = prefs(ctx).edit().putString(KEY_SR_MORNING_GREETED_DATE, d).apply()
    fun getSrLastActiveDate(ctx: Context): String = prefs(ctx).getString(KEY_SR_LAST_ACTIVE_DATE, "") ?: ""
    fun setSrLastActiveDate(ctx: Context, d: String) = prefs(ctx).edit().putString(KEY_SR_LAST_ACTIVE_DATE, d).apply()

    // v9.2: বাইরের সময়, ব্রেক লেজার, কাস্টম অপচয় কারণ ও বাজেট
    private const val KEY_SR_AWAY_START_MS = "sr_away_start_ms"
    private const val KEY_SR_AWAY_REASON = "sr_away_reason"
    private const val KEY_SR_LIVE_WASTE_REASON = "sr_live_waste_reason"
    private const val KEY_SR_WASTE_BUDGET_HRS = "sr_waste_budget_hours"
    private const val KEY_SR_CUSTOM_WASTE_REASONS = "sr_custom_waste_reasons"
    private const val KEY_SR_LAST_BREAK_PROMPT_MS = "sr_last_break_prompt_ms"
    private const val KEY_SR_HELP_HINT_SHOWN = "sr_help_hint_shown"
    private const val KEY_SR_BREAK_LEDGER = "sr_break_ledger"

    fun getSrAwayStartMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_AWAY_START_MS, 0L)
    fun setSrAwayStartMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_AWAY_START_MS, ms).apply()

    fun getSrAwayReason(ctx: Context): String = prefs(ctx).getString(KEY_SR_AWAY_REASON, "অন্যান্য") ?: "অন্যান্য"
    fun setSrAwayReason(ctx: Context, r: String) = prefs(ctx).edit().putString(KEY_SR_AWAY_REASON, r.trim().ifEmpty { "অন্যান্য" }).apply()

    fun getSrLiveWasteReason(ctx: Context): String = prefs(ctx).getString(KEY_SR_LIVE_WASTE_REASON, "অপচয় সময়") ?: "অপচয় সময়"
    fun setSrLiveWasteReason(ctx: Context, r: String) = prefs(ctx).edit().putString(KEY_SR_LIVE_WASTE_REASON, r.trim().ifEmpty { "অপচয় সময়" }).apply()

    fun getWasteBudgetHours(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_WASTE_BUDGET_HRS, 0).coerceIn(0, 12)
    fun setWasteBudgetHours(ctx: Context, h: Int) = prefs(ctx).edit().putInt(KEY_SR_WASTE_BUDGET_HRS, h.coerceIn(0, 12)).apply()

    fun getLastBreakPromptMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_LAST_BREAK_PROMPT_MS, 0L)
    fun setLastBreakPromptMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_LAST_BREAK_PROMPT_MS, ms).apply()

    fun isHelpHintShown(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_HELP_HINT_SHOWN, false)
    fun setHelpHintShown(ctx: Context) = prefs(ctx).edit().putBoolean(KEY_SR_HELP_HINT_SHOWN, true).apply()

    fun getWasteReasonsList(ctx: Context): List<String> {
        val raw = prefs(ctx).getString(KEY_SR_CUSTOM_WASTE_REASONS, "") ?: ""
        if (raw.isBlank()) return ReasonCatalog.DEFAULT_WASTE_REASONS
        return try {
            val arr = JSONArray(raw)
            val out = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val s = arr.optString(i).trim()
                if (s.isNotEmpty() && s !in out) out.add(s)
            }
            if (out.isEmpty()) ReasonCatalog.DEFAULT_WASTE_REASONS else out.take(8)
        } catch (_: Exception) { ReasonCatalog.DEFAULT_WASTE_REASONS }
    }

    fun saveWasteReasonsList(ctx: Context, list: List<String>) {
        val clean = list.map { it.trim() }.filter { it.isNotEmpty() }.distinct().take(8)
        val arr = JSONArray().apply { clean.forEach { put(it) } }
        prefs(ctx).edit().putString(KEY_SR_CUSTOM_WASTE_REASONS, arr.toString()).apply()
    }

    @Synchronized
    fun recordBreakLedger(ctx: Context, startMs: Long, endMs: Long, type: String) {
        if (endMs <= startMs) return
        val cutoff = System.currentTimeMillis() - 48 * 3600_000L
        val entries = getBreakLedger(ctx).filter { it.second >= cutoff }.toMutableList()
        entries.add(Triple(startMs, endMs, type))
        val trimmed = if (entries.size > 20) entries.takeLast(20) else entries
        val arr = JSONArray()
        for ((s, e, t) in trimmed) {
            arr.put(JSONArray().apply { put(s); put(e); put(t) })
        }
        prefs(ctx).edit().putString(KEY_SR_BREAK_LEDGER, arr.toString()).apply()
    }

    fun getBreakLedger(ctx: Context): List<Triple<Long, Long, String>> {
        val raw = prefs(ctx).getString(KEY_SR_BREAK_LEDGER, "") ?: ""
        if (raw.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            val cutoff = System.currentTimeMillis() - 48 * 3600_000L
            val out = mutableListOf<Triple<Long, Long, String>>()
            for (i in 0 until arr.length()) {
                val item = arr.optJSONArray(i) ?: continue
                val s = item.optLong(0, 0L)
                val e = item.optLong(1, 0L)
                val t = item.optString(2, "")
                if (s > 0L && e > s && e >= cutoff) out.add(Triple(s, e, t))
            }
            out
        } catch (_: Exception) { emptyList() }
    }

    fun subtractIntervals(startMs: Long, endMs: Long, excluded: List<Pair<Long, Long>>): List<Pair<Long, Long>> {
        if (endMs <= startMs) return emptyList()
        var current = listOf(startMs to endMs)
        for ((es, ee) in excluded) {
            if (ee <= es) continue
            val next = mutableListOf<Pair<Long, Long>>()
            for ((cs, ce) in current) {
                if (ee <= cs || es >= ce) {
                    next.add(cs to ce)
                } else {
                    if (es > cs) next.add(cs to es)
                    if (ee < ce) next.add(ee to ce)
                }
            }
            current = next
            if (current.isEmpty()) break
        }
        return current
    }

    @Synchronized
    fun addAway(ctx: Context, startMs: Long, endMs: Long, reason: String = "অন্যান্য") {
        val safeReason = reason.trim().ifEmpty { "অন্যান্য" }
        val segments = splitByDay(startMs, endMs)
        if (segments.isEmpty()) return
        val map = loadAllDays(ctx)
        for ((iso, sec) in segments) {
            if (sec <= 0L) continue
            val rec = map[iso] ?: DayRecord(date = iso, subject = getCurrentSubject(ctx))
            rec.awaySec += sec
            rec.awayReasons[safeReason] = (rec.awayReasons[safeReason] ?: 0L) + sec
            rec.synced = false
            map[iso] = rec
        }
        saveAllDays(ctx, map)
    }

    fun getUntaggedWasteSecToday(ctx: Context): Long {
        val today = getToday(ctx)
        return listOf("অপচয় সময়", "অপচয় সময়", "ফোন চালানো").sumOf { today.wasteReasons[it] ?: 0L }
    }

    /** আজকের অট্যাগড অপচয় ("অপচয় সময়" ও "ফোন চালানো") নির্দিষ্ট কারণে ট্যাগ করে; পূর্বাবস্থার জন্য (কারণ, সেকেন্ড, উৎস) ফেরত দেয়। */
    @Synchronized
    fun tagWaste(ctx: Context, reason: String, maxSeconds: Long = Long.MAX_VALUE): Triple<String, Long, Map<String, Long>>? {
        val cleanReason = reason.trim().ifEmpty { return null }
        val map = loadAllDays(ctx)
        val iso = todayIso()
        val rec = map[iso] ?: return null
        var remaining = maxSeconds.coerceAtLeast(0L)
        val movedFrom = mutableMapOf<String, Long>()
        for (srcKey in listOf("অপচয় সময়", "অপচয় সময়", "ফোন চালানো")) {
            if (remaining <= 0L) break
            val avail = rec.wasteReasons[srcKey] ?: 0L
            if (avail > 0L) {
                val take = minOf(avail, remaining)
                val left = avail - take
                if (left > 0L) rec.wasteReasons[srcKey] = left else rec.wasteReasons.remove(srcKey)
                rec.wasteReasons[cleanReason] = (rec.wasteReasons[cleanReason] ?: 0L) + take
                movedFrom[srcKey] = take
                remaining -= take
            }
        }
        val totalMoved = movedFrom.values.sum()
        if (totalMoved <= 0L) return null
        rec.wasteReason = cleanReason
        rec.synced = false
        map[iso] = rec
        saveAllDays(ctx, map)
        return Triple(cleanReason, totalMoved, movedFrom)
    }

    @Synchronized
    fun undoTagWaste(ctx: Context, reason: String, movedFrom: Map<String, Long>) {
        val map = loadAllDays(ctx)
        val iso = todayIso()
        val rec = map[iso] ?: return
        var totalRestore = 0L
        for ((srcKey, sec) in movedFrom) {
            if (sec <= 0L) continue
            rec.wasteReasons[srcKey] = (rec.wasteReasons[srcKey] ?: 0L) + sec
            totalRestore += sec
        }
        val cur = rec.wasteReasons[reason] ?: 0L
        val left = (cur - totalRestore).coerceAtLeast(0L)
        if (left > 0L) rec.wasteReasons[reason] = left else rec.wasteReasons.remove(reason)
        rec.synced = false
        map[iso] = rec
        saveAllDays(ctx, map)
    }
}
