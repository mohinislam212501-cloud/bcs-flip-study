package com.bcs.flipstudy

import android.content.Context
import android.content.SharedPreferences
import androidx.core.util.AtomicFile
import android.provider.Settings
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class DayRecord(
    val date: String,
    var subject: String = "",
    var c45: Int = 0,
    var c25: Int = 0,
    var studySec: Long = 0L,
    var wasteSec: Long = 0L,
    var wasteReason: String = "",
    var sleepOtherSec: Long = 0L,
    var wordTarget: Boolean = false,
    var synced: Boolean = false,
    // ধাপ ২.৩: নতুন ফিল্ড (পুরোনো ডেটায় না থাকলে ডিফল্ট নেবে)
    var subjects: MutableMap<String, Long> = mutableMapOf(),
    var wasteReasons: MutableMap<String, Long> = mutableMapOf(),
    var mode: String = "flip",
    var estimated: Boolean = false,
    var eatSec: Long = 0L,
    var flipSec: Long = 0L,
    var manualSec: Long = 0L,
    var onlineSec: Long = 0L,
    var awaySec: Long = 0L,
    var awayReasons: MutableMap<String, Long> = mutableMapOf(),
    var otherSec: Long = 0L,
    var unassignedSec: Long = 0L,
    var timelineJson: String = ""
) {
    fun totalStudyMinutes(): Int {
        if (studySec > 0L) return (studySec / 60L).toInt()
        return (c45 * 45) + (c25 * 25)
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("date", date)
        put("subject", subject)
        put("c45", c45)
        put("c25", c25)
        put("studySec", studySec)
        put("wasteSec", wasteSec)
        put("wasteReason", wasteReason)
        put("sleepOtherSec", sleepOtherSec)
        put("wordTarget", wordTarget)
        put("synced", synced)
        put("mode", mode)
        put("estimated", estimated)
        put("eatSec", eatSec)
        put("flipSec", flipSec)
        put("manualSec", manualSec)
        put("onlineSec", onlineSec)
        put("awaySec", awaySec)
        put("otherSec", otherSec)
        put("unassignedSec", unassignedSec)
        put("timelineJson", timelineJson)
        val awObj = JSONObject()
        for ((k, v) in awayReasons) awObj.put(k, v)
        put("awayReasons", awObj)
        val subObj = JSONObject()
        for ((k, v) in subjects) subObj.put(k, v)
        put("subjects", subObj)
        val wrObj = JSONObject()
        for ((k, v) in wasteReasons) wrObj.put(k, v)
        put("wasteReasons", wrObj)
    }

    companion object {
        fun fromJson(o: JSONObject): DayRecord {
            val subMap = mutableMapOf<String, Long>()
            o.optJSONObject("subjects")?.let { so ->
                val it = so.keys()
                while (it.hasNext()) {
                    val k = it.next()
                    subMap[k] = so.optLong(k, 0L)
                }
            }
            val wrMap = mutableMapOf<String, Long>()
        val awMap = mutableMapOf<String, Long>()
            o.optJSONObject("wasteReasons")?.let { wo ->
                val it = wo.keys()
                while (it.hasNext()) {
                    val k = it.next()
                    wrMap[k] = wo.optLong(k, 0L)
                }
            }
            return DayRecord(
                date = o.optString("date", DataStore.todayIso()),
                subject = o.optString("subject", ""),
                c45 = o.optInt("c45", 0),
                c25 = o.optInt("c25", 0),
                studySec = o.optLong("studySec", 0L),
                wasteSec = o.optLong("wasteSec", 0L),
                wasteReason = o.optString("wasteReason", ""),
                sleepOtherSec = o.optLong("sleepOtherSec", 0L),
                wordTarget = o.optBoolean("wordTarget", false),
                synced = o.optBoolean("synced", false),
                subjects = subMap,
                wasteReasons = wrMap,
                mode = o.optString("mode", "flip"),
                estimated = o.optBoolean("estimated", false),
                eatSec = o.optLong("eatSec", 0L),
                flipSec = o.optLong("flipSec", 0L),
                manualSec = o.optLong("manualSec", 0L),
                onlineSec = o.optLong("onlineSec", 0L),
                awaySec = o.optLong("awaySec", 0L),
                otherSec = o.optLong("otherSec", 0L),
                unassignedSec = o.optLong("unassignedSec", 0L),
                timelineJson = o.optString("timelineJson", ""),
                awayReasons = mutableMapOf<String, Long>().apply {
                    o.optJSONObject("awayReasons")?.let { ao ->
                        val it = ao.keys()
                        while (it.hasNext()) { val k = it.next(); this[k] = ao.optLong(k, 0L) }
                    }
                }
            )
        }
    }
}

data class GapRecord(
    val id: String,
    val startMs: Long,
    val endMs: Long,
    var status: String = "UNKNOWN", // UNKNOWN, GUESSED, CONFIRMED
    var category: String = "",
    var note: String = "",
    var snoozeUntilMs: Long = 0L
) {
    fun durationMin(): Int = ((endMs - startMs) / 60_000L).toInt().coerceAtLeast(0)
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("startMs", startMs); put("endMs", endMs)
        put("status", status); put("category", category); put("note", note)
        put("snoozeUntilMs", snoozeUntilMs)
    }
    companion object {
        fun fromJson(o: JSONObject): GapRecord = GapRecord(
            id = o.optString("id", ""),
            startMs = o.optLong("startMs", 0L),
            endMs = o.optLong("endMs", 0L),
            status = o.optString("status", "UNKNOWN"),
            category = o.optString("category", ""),
            note = o.optString("note", ""),
            snoozeUntilMs = o.optLong("snoozeUntilMs", 0L)
        )
    }
}

data class ChartBar(val label: String, val studyMin: Int, val wasteMin: Int, val sleepMin: Int)

data class ReportData(
    val period: String,
    val isYearly: Boolean,
    val totalStudyMin: Int,
    val totalWasteMin: Int,
    val totalSleepMin: Int,
    val avgDailyStudyMin: Int,
    val bestDay: String,
    val bestDayMin: Int,
    val currentStreak: Int,
    val longestStreak: Int,
    val productivityScore: Int,
    val subjects: Map<String, Long>,
    val wasteReasons: Map<String, Long>,
    val bars: List<ChartBar>,
    val isOffline: Boolean,
    val totalAwayMin: Int = 0,
    val awayReasons: Map<String, Long> = emptyMap()
)

enum class ReportPeriodType { DAY, WEEK, MONTH, YEAR }

data class UnifiedReportData(
    val type: ReportPeriodType,
    val anchorIso: String,
    val rangeStartIso: String,
    val rangeEndIso: String,
    val periodLabelBn: String,
    val isPartialCurrentPeriod: Boolean,
    val elapsedDaysCount: Int,
    val totalDaysCount: Int,
    val totalStudyMin: Int,
    val totalWasteMin: Int,
    val totalEatMin: Int,
    val totalSleepMin: Int,
    val totalAwayMin: Int,
    val totalOtherMin: Int = 0,
    val totalUnassignedMin: Int = 0,
    val flipMin: Int,
    val manualMin: Int,
    val onlineMin: Int,
    val avgDailyStudyMin: Int,
    val goalCompletionPct: Int,
    val wasteRatioScore: Int,
    val bestDayLabel: String,
    val bestDayMin: Int,
    val currentStreak: Int,
    val longestStreak: Int,
    val subjects: Map<String, Long>,
    val wasteReasons: Map<String, Long>,
    val awayReasons: Map<String, Long> = emptyMap(),
    val bars: List<ChartBar>,
    val hasAnyDataInPeriod: Boolean
)

data class RuntimeTrackerState(
    val running: Boolean,
    val mode: String, // IDLE, STUDY, BREAK, WASTE
    val stateStartMs: Long,
    val remainingSec: Int,
    val faceDown: Boolean,
    val source: String = "manual"
)

object DataStore {
    private const val PREF = "bcs_flip_study_prefs"
    private const val KEY_DAYS = "days_map_json"
    private const val KEY_GAS_URL = "gas_webapp_url"
    private const val KEY_SYNC_KEY = "gas_sync_secret_key"
    private const val KEY_PRESET_MIN = "preset_min"
    private const val KEY_ONLINE_STUDY = "online_study"
    private const val KEY_ALARM_ON = "alarm_on"
    private const val KEY_LAST_CLOSED = "last_closed_ms"
    private const val KEY_LAST_SYNC_TEXT = "last_sync_text"
    private const val KEY_SUBJECT = "current_subject"

    private const val KEY_GOAL_HOURS = "daily_goal_hours"
    private const val KEY_GOAL_NOTIF = "daily_goal_notif"
    private const val KEY_GOAL_NOTIFIED_DATE = "goal_notified_date"
    private const val KEY_EXAM_NAME = "exam_name"
    private const val KEY_EXAM_DATE = "exam_date_iso"
    private const val KEY_GRACE_SEC = "flip_grace_sec"
    private const val KEY_ALARM_MODE = "alarm_mode" // vibrate, sound, silent
    private const val KEY_THEME_MODE = "theme_mode" // day, night, auto
    private const val KEY_COLOR_PALETTE = "color_palette" // sage, ocean, espresso, nordic
    private const val KEY_FLIP_ENABLED = "flip_sensor_enabled"

    // ধাপ ১.৭: প্রসেস মারা গেলেও অবস্থা ধরে রাখার জন্য
    private const val KEY_RT_RUNNING = "rt_running"
    private const val KEY_RT_MODE = "rt_mode"
    private const val KEY_RT_START_MS = "rt_state_start_ms"
    private const val KEY_RT_REM_SEC = "rt_remaining_sec"
    private const val KEY_RT_FACE_DOWN = "rt_face_down"
    private const val KEY_RT_SOURCE = "rt_source"

    private const val KEY_DAY_START_MIN = "day_start_min"
    private const val KEY_DAY_CUTOVER_ISO = "day_cutover_iso"
    private const val KEY_DAY_CUTOVER_EXTRA_SEC = "day_cutover_extra_sec"

    @Volatile
    private var cachedDayStartMin: Int = -1

    fun initDayBoundary(ctx: Context) {
        if (cachedDayStartMin < 0) {
            cachedDayStartMin = prefs(ctx).getInt(KEY_DAY_START_MIN, 0).coerceIn(0, 1439)
        }
    }

    fun getDayStartMin(ctx: Context): Int {
        val v = prefs(ctx).getInt(KEY_DAY_START_MIN, 0).coerceIn(0, 1439)
        cachedDayStartMin = v
        return v
    }

    fun setDayStartMin(ctx: Context, newMin: Int) {
        val safeNew = newMin.coerceIn(0, 1439)
        val oldMin = getDayStartMin(ctx)
        cachedDayStartMin = safeNew
        val ed = prefs(ctx).edit().putInt(KEY_DAY_START_MIN, safeNew)
        if (safeNew > oldMin) {
            val extra = ((safeNew - oldMin) * 60L).coerceAtMost(43_200L)
            ed.putString(KEY_DAY_CUTOVER_ISO, dayIsoOf(System.currentTimeMillis()))
            ed.putLong(KEY_DAY_CUTOVER_EXTRA_SEC, extra)
        }
        ed.apply()
    }

    private fun activeDayStartMin(): Int = if (cachedDayStartMin >= 0) cachedDayStartMin else 0

    fun dayIsoOf(ms: Long): String {
        val shiftMs = activeDayStartMin() * 60_000L
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(ms - shiftMs))
    }

    fun dayStartMs(iso: String): Long {
        return try {
            val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val d = fmt.parse(iso) ?: return startOfTodayMs()
            val c = Calendar.getInstance().apply {
                time = d
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            c.timeInMillis + activeDayStartMin() * 60_000L
        } catch (_: Exception) { startOfTodayMs() }
    }

    fun dayEndMs(iso: String): Long {
        return try {
            val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val d = fmt.parse(iso) ?: return startOfTodayMs() + 86_400_000L
            val c = Calendar.getInstance().apply {
                time = d
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                add(Calendar.DAY_OF_YEAR, 1)
            }
            c.timeInMillis + activeDayStartMin() * 60_000L
        } catch (_: Exception) { startOfTodayMs() + 86_400_000L }
    }

    fun todayIso(): String = dayIsoOf(System.currentTimeMillis())
    fun currentMonthIso(): String = todayIso().substring(0, 7)
    fun currentYearIso(): String = todayIso().substring(0, 4)

    fun toBnDigits(input: Any): String {
        val bn = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
        val s = input.toString()
        val sb = StringBuilder(s.length)
        for (ch in s) {
            if (ch in '0'..'9') sb.append(bn[ch - '0']) else sb.append(ch)
        }
        return sb.toString()
    }

    fun formatHoursMinBn(totalSec: Long): String {
        val mins = (totalSec / 60L).coerceAtLeast(0L)
        val h = mins / 60L
        val m = mins % 60L
        return if (h > 0) "${toBnDigits(h)}ঘ ${toBnDigits(m)}মি" else "${toBnDigits(m)}মি"
    }

    private fun prefs(ctx: Context): SharedPreferences {
        val sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        if (cachedDayStartMin < 0) cachedDayStartMin = sp.getInt(KEY_DAY_START_MIN, 0).coerceIn(0, 1439)
        return sp
    }

    fun getGasUrl(ctx: Context): String = prefs(ctx).getString(KEY_GAS_URL, "") ?: ""
    fun setGasUrl(ctx: Context, url: String) = prefs(ctx).edit().putString(KEY_GAS_URL, url.trim()).apply()

    private const val KEY_SYNC_KEY_ENC = "gas_sync_secret_key_enc"
    private const val KEYSTORE_ALIAS_SYNC = "bcs_flip_sync_key_aes"

    private fun getOrCreateSyncAesKey(): SecretKey? {
        return try {
            val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            (ks.getKey(KEYSTORE_ALIAS_SYNC, null) as? SecretKey) ?: run {
                val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
                kg.init(
                    KeyGenParameterSpec.Builder(
                        KEYSTORE_ALIAS_SYNC,
                        KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                    )
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                        .setKeySize(256)
                        .build()
                )
                kg.generateKey()
            }
        } catch (_: Exception) { null }
    }

    fun getSyncKey(ctx: Context): String {
        val p = prefs(ctx)
        val enc = p.getString(KEY_SYNC_KEY_ENC, "") ?: ""
        if (enc.isNotEmpty()) {
            try {
                val raw = Base64.decode(enc, Base64.NO_WRAP)
                if (raw.size > 12) {
                    val iv = raw.copyOfRange(0, 12)
                    val ct = raw.copyOfRange(12, raw.size)
                    val key = getOrCreateSyncAesKey()
                    if (key != null) {
                        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
                        return String(cipher.doFinal(ct), Charsets.UTF_8)
                    }
                }
            } catch (_: Exception) {}
        }
        val legacy = p.getString(KEY_SYNC_KEY, "") ?: ""
        if (legacy.isNotEmpty()) {
            setSyncKey(ctx, legacy)
            return legacy
        }
        return ""
    }

    fun setSyncKey(ctx: Context, k: String) {
        val clean = k.trim()
        val p = prefs(ctx)
        if (clean.isEmpty()) {
            p.edit().remove(KEY_SYNC_KEY_ENC).remove(KEY_SYNC_KEY).apply()
            return
        }
        try {
            val key = getOrCreateSyncAesKey()
            if (key != null) {
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.ENCRYPT_MODE, key)
                val iv = cipher.iv
                val ct = cipher.doFinal(clean.toByteArray(Charsets.UTF_8))
                val combined = ByteArray(iv.size + ct.size)
                System.arraycopy(iv, 0, combined, 0, iv.size)
                System.arraycopy(ct, 0, combined, iv.size, ct.size)
                p.edit()
                    .putString(KEY_SYNC_KEY_ENC, Base64.encodeToString(combined, Base64.NO_WRAP))
                    .remove(KEY_SYNC_KEY)
                    .apply()
                return
            }
        } catch (_: Exception) {}
        p.edit().putString(KEY_SYNC_KEY, clean).apply()
    }

    fun getPresetMin(ctx: Context): Int = prefs(ctx).getInt(KEY_PRESET_MIN, 45)
    fun setPresetMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_PRESET_MIN, min).apply()

    fun isOnlineStudy(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_ONLINE_STUDY, false)
    fun setOnlineStudy(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_ONLINE_STUDY, on).apply()

    fun isAlarmOn(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_ALARM_ON, true)
    fun setAlarmOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_ALARM_ON, on).apply()

    fun getCurrentSubject(ctx: Context): String = prefs(ctx).getString(KEY_SUBJECT, "BCS প্রস্তুতি") ?: "BCS প্রস্তুতি"
    fun setCurrentSubject(ctx: Context, sub: String) {
        val clean = sub.trim().ifEmpty { "BCS প্রস্তুতি" }
        prefs(ctx).edit()
            .putString(KEY_SUBJECT, clean)
            .putString("current_subject_day_iso", todayIso())
            .apply()
    }

    private const val KEY_PENDING_DAILY_BCS_RESET = "pending_daily_bcs_reset"

    /** নতুন দিন শুরু হলে ডিফল্ট বিষয় "BCS প্রস্তুতি"-তে ফেরায়; পড়া রানিং থাকলে শেষ হওয়া পর্যন্ত অপেক্ষা করে। */
    fun ensureDailySubjectReset(ctx: Context) {
        val p = prefs(ctx)
        val today = todayIso()
        val lastDay = p.getString("current_subject_day_iso", "") ?: ""
        if (lastDay.isEmpty()) {
            p.edit().putString("current_subject_day_iso", today).apply()
            return
        }
        if (lastDay != today) {
            val cur = getCurrentSubject(ctx)
            val rt = loadRuntimeState(ctx)
            val studyRunning = rt.running && rt.mode == "STUDY"
            if (cur != "BCS প্রস্তুতি") {
                if (studyRunning) {
                    p.edit().putBoolean(KEY_PENDING_DAILY_BCS_RESET, true).putString("current_subject_day_iso", today).apply()
                } else {
                    p.edit().putString(KEY_SUBJECT, "BCS প্রস্তুতি")
                        .putBoolean(KEY_PENDING_DAILY_BCS_RESET, false)
                        .putString("current_subject_day_iso", today)
                        .apply()
                }
            } else {
                p.edit().putBoolean(KEY_PENDING_DAILY_BCS_RESET, false).putString("current_subject_day_iso", today).apply()
            }
        }
    }

    /** রানিং পড়া শেষ হলে পেন্ডিং নতুন দিনের "BCS প্রস্তুতি" রিসেট প্রয়োগ করে ও নোটিফিকেশন দেয়। */
    fun applyPendingDailyBcsResetIfNeeded(ctx: Context): Boolean {
        val p = prefs(ctx)
        val today = todayIso()
        val lastDay = p.getString("current_subject_day_iso", "") ?: ""
        val pending = p.getBoolean(KEY_PENDING_DAILY_BCS_RESET, false)
        val crossedDay = lastDay.isNotEmpty() && lastDay != today
        if (!pending && !crossedDay) return false
        val cur = getCurrentSubject(ctx)
        p.edit().putBoolean(KEY_PENDING_DAILY_BCS_RESET, false).putString("current_subject_day_iso", today).apply()
        if (cur == "BCS প্রস্তুতি") return false
        p.edit().putString(KEY_SUBJECT, "BCS প্রস্তুতি").apply()
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            val chId = "bcs_study_daily_reset"
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                val ch = android.app.NotificationChannel(chId, "নতুন দিনের ডিফল্ট বিষয়", android.app.NotificationManager.IMPORTANCE_DEFAULT)
                nm.createNotificationChannel(ch)
            }
            val n = androidx.core.app.NotificationCompat.Builder(ctx, chId)
                .setSmallIcon(R.drawable.ic_notif_mascot)
                .setContentTitle("নতুন দিন · ডিফল্ট বিষয় আপডেট")
                .setContentText("আগের সেশন শেষ হয়েছে — এখন পড়া 'BCS প্রস্তুতি'-তে (অস্থায়ী) জমা হবে।")
                .setAutoCancel(true)
                .build()
            nm.notify(5492, n)
        } catch (_: Exception) {}
        return true
    }


    fun formatHmsBn(totalSec: Long): String {
        val s = totalSec.coerceAtLeast(0L)
        val h = s / 3600L
        val m = (s % 3600L) / 60L
        val sec = s % 60L
        return toBnDigits(String.format(Locale.US, "%02d:%02d:%02d", h, m, sec))
    }

    fun getDailyGoalHours(ctx: Context): Int = prefs(ctx).getInt(KEY_GOAL_HOURS, 4).coerceIn(1, 16)
    fun setDailyGoalHours(ctx: Context, h: Int) = prefs(ctx).edit().putInt(KEY_GOAL_HOURS, h.coerceIn(1, 16)).apply()

    fun isGoalNotifOn(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_GOAL_NOTIF, true)
    fun setGoalNotifOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_GOAL_NOTIF, on).apply()

    fun getGoalNotifiedDate(ctx: Context): String = prefs(ctx).getString(KEY_GOAL_NOTIFIED_DATE, "") ?: ""
    fun setGoalNotifiedDate(ctx: Context, d: String) = prefs(ctx).edit().putString(KEY_GOAL_NOTIFIED_DATE, d).apply()

    fun checkAndNotifyDailyGoalReached(ctx: Context, todayRec: DayRecord? = null) {
        if (!isGoalNotifOn(ctx)) return
        val today = todayIso()
        if (getGoalNotifiedDate(ctx) == today) return
        val rec = todayRec ?: getToday(ctx)
        if (rec.date != today) return
        val goalH = getDailyGoalHours(ctx)
        if (rec.totalStudyMinutes() < goalH * 60) return
        setGoalNotifiedDate(ctx, today)
        HapticManager.goalReached(ctx)
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            val chId = "bcs_daily_goal_reached"
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                val ch = android.app.NotificationChannel(chId, "দৈনিক লক্ষ্য পূরণ", android.app.NotificationManager.IMPORTANCE_DEFAULT)
                nm.createNotificationChannel(ch)
            }
            val openPi = android.app.PendingIntent.getActivity(
                ctx, 1002, android.content.Intent(ctx, MainActivity::class.java),
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
            val notif = androidx.core.app.NotificationCompat.Builder(ctx, chId)
                .setSmallIcon(R.drawable.ic_notif_mascot)
                .setContentTitle("আজকের লক্ষ্য পূরণ হয়েছে!")
                .setContentText("অভিনন্দন! তুমি আজ ${toBnDigits(goalH)} ঘণ্টা পড়া পূর্ণ করেছ।")
                .setContentIntent(openPi)
                .setAutoCancel(true)
                .build()
            nm.notify(1002, notif)
        } catch (_: Exception) {}
    }

    fun getExamName(ctx: Context): String = prefs(ctx).getString(KEY_EXAM_NAME, "BCS পরীক্ষা") ?: "BCS পরীক্ষা"
    fun setExamName(ctx: Context, name: String) = prefs(ctx).edit().putString(KEY_EXAM_NAME, name.trim().ifEmpty { "BCS পরীক্ষা" }).apply()

    fun getSubjectList(): List<String> = listOf("বাংলা", "ইংরেজি", "গণিত", "সাধারণ জ্ঞান", "বিজ্ঞান")

    private const val KEY_EXAM_TIME_MIN = "exam_time_min"
    fun getExamTimeMin(ctx: Context): Int = prefs(ctx).getInt(KEY_EXAM_TIME_MIN, 600).coerceIn(0, 1439)
    fun setExamTimeMin(ctx: Context, minOfDay: Int) = prefs(ctx).edit().putInt(KEY_EXAM_TIME_MIN, minOfDay.coerceIn(0, 1439)).apply()

    fun getExamDateIso(ctx: Context): String = prefs(ctx).getString(KEY_EXAM_DATE, "2027-02-26") ?: "2027-02-26"
    fun setExamDateIso(ctx: Context, iso: String) = prefs(ctx).edit().putString(KEY_EXAM_DATE, iso.trim()).apply()

    fun getExamRemainingMs(ctx: Context): Long {
        return try {
            val parts = getExamDateIso(ctx).split("-")
            if (parts.size != 3) return 0L
            val tMin = getExamTimeMin(ctx)
            val c = Calendar.getInstance().apply {
                set(Calendar.YEAR, parts[0].toInt())
                set(Calendar.MONTH, parts[1].toInt() - 1)
                set(Calendar.DAY_OF_MONTH, parts[2].toInt())
                set(Calendar.HOUR_OF_DAY, tMin / 60)
                set(Calendar.MINUTE, tMin % 60)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            (c.timeInMillis - System.currentTimeMillis()).coerceAtLeast(0L)
        } catch (_: Exception) { 0L }
    }

    fun formatExamCountdownBn(ctx: Context): String {
        val remMs = getExamRemainingMs(ctx)
        if (remMs <= 0L) return "আজ পরীক্ষা"
        val totalMin = ((remMs + 59_999L) / 60_000L).toInt().coerceAtLeast(1)
        val days = totalMin / 1440
        val hrs = (totalMin % 1440) / 60
        val mins = totalMin % 60
        return when {
            days >= 1 -> if (hrs > 0) "${toBnDigits(days)} দিন ${toBnDigits(hrs)} ঘণ্টা" else "${toBnDigits(days)} দিন"
            hrs >= 1 -> if (mins > 0) "${toBnDigits(hrs)} ঘণ্টা ${toBnDigits(mins)} মি." else "${toBnDigits(hrs)} ঘণ্টা"
            else -> "${toBnDigits(mins)} মিনিট"
        }
    }

    fun formatTime12hBn(minOfDay: Int): String {
        val h24 = (minOfDay / 60).coerceIn(0, 23)
        val m = (minOfDay % 60).coerceIn(0, 59)
        val period = when {
            h24 < 6 -> "ভোর"
            h24 < 12 -> "সকাল"
            h24 < 16 -> "দুপুর"
            h24 < 19 -> "বিকেল"
            else -> "রাত"
        }
        val h12 = when {
            h24 == 0 -> 12
            h24 > 12 -> h24 - 12
            else -> h24
        }
        return "$period ${toBnDigits(h12)}:${toBnDigits(String.format(Locale.US, "%02d", m))}"
    }

    fun isValidIsoDate(iso: String): Boolean = try {
        val f = SimpleDateFormat("yyyy-MM-dd", Locale.US); f.isLenient = false
        f.parse(iso.trim()) != null && iso.trim().length == 10
    } catch (_: Exception) { false }

    fun getDaysUntilExam(ctx: Context): Int {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val target = sdf.parse(getExamDateIso(ctx)) ?: return 0
            val today = sdf.parse(todayIso()) ?: return 0
            val diff = ((target.time - today.time) / 86_400_000L).toInt()
            diff.coerceAtLeast(0)
        } catch (_: Exception) { 0 }
    }

    fun getGraceSec(ctx: Context): Int = prefs(ctx).getInt(KEY_GRACE_SEC, 5)
    fun setGraceSec(ctx: Context, sec: Int) = prefs(ctx).edit().putInt(KEY_GRACE_SEC, sec).apply()

    fun getAlarmMode(ctx: Context): String = prefs(ctx).getString(KEY_ALARM_MODE, "vibrate") ?: "vibrate"
    fun setAlarmMode(ctx: Context, mode: String) = prefs(ctx).edit().putString(KEY_ALARM_MODE, mode).apply()

    fun getThemeMode(ctx: Context): String = prefs(ctx).getString(KEY_THEME_MODE, "auto") ?: "auto"
    fun setThemeMode(ctx: Context, mode: String) = prefs(ctx).edit().putString(KEY_THEME_MODE, mode).apply()

    fun getColorPalette(ctx: Context): String = prefs(ctx).getString(KEY_COLOR_PALETTE, "ocean") ?: "ocean"
    fun setColorPalette(ctx: Context, id: String) = prefs(ctx).edit().putString(KEY_COLOR_PALETTE, id).apply()

    fun wasNotifPermAsked(ctx: Context): Boolean = prefs(ctx).getBoolean("notif_perm_asked", false)
    fun setNotifPermAsked(ctx: Context) = prefs(ctx).edit().putBoolean("notif_perm_asked", true).apply()

    fun isFlipEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_FLIP_ENABLED, false)
    fun setFlipEnabled(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_FLIP_ENABLED, on).apply()

    @Volatile private var cachedStreak: Int = -1
    @Volatile private var cachedStreakDate: String = ""

    fun getCurrentStreak(ctx: Context): Int {
        val today = todayIso()
        if (cachedStreak >= 0 && cachedStreakDate == today) return cachedStreak
        val map = getAllDaysMerged(ctx)
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance().apply {
            time = try { fmt.parse(today) ?: Date() } catch (_: Exception) { Date() }
        }
        var streak = 0
        for (i in 0..365) {
            val c = cal.clone() as Calendar
            c.add(Calendar.DAY_OF_YEAR, -i)
            val rec = map[fmt.format(c.time)]
            if (rec != null && rec.totalStudyMinutes() > 0) streak++
            else if (i > 0) break
        }
        cachedStreak = streak
        cachedStreakDate = today
        val prevBest = prefs(ctx).getInt("saved_longest_streak", 0)
        prefs(ctx).edit()
            .putInt("saved_current_streak", streak)
            .putInt("saved_longest_streak", maxOf(prevBest, streak))
            .apply()
        return streak
    }

    fun getLast28DaysMinutes(ctx: Context): List<Int> {
        val map = getAllDaysMerged(ctx)
        val today = todayIso()
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance().apply {
            time = try { fmt.parse(today) ?: Date() } catch (_: Exception) { Date() }
        }
        val out = mutableListOf<Int>()
        for (i in 27 downTo 0) {
            val c = cal.clone() as Calendar
            c.add(Calendar.DAY_OF_YEAR, -i)
            out.add(map[fmt.format(c.time)]?.totalStudyMinutes() ?: 0)
        }
        return out
    }

    fun getCurrentMonthDays(ctx: Context): List<DayRecord> {
        val map = getAllDaysMerged(ctx)
        val ym = currentMonthIso()
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance().apply {
            time = try { fmt.parse("$ym-01") ?: Date() } catch (_: Exception) { Date() }
        }
        val maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val list = mutableListOf<DayRecord>()
        for (d in 1..maxDay) {
            val iso = String.format(Locale.US, "%s-%02d", ym, d)
            list.add(map[iso] ?: DayRecord(date = iso))
        }
        return list
    }

    private fun csvEscape(raw: String): String {
        val clean = raw.replace("\r\n", " ").replace("\n", " ").replace("\r", " ")
        return if (clean.contains(",") || clean.contains("\"")) {
            val doubled = clean.replace("\"", "\"\"")
            "\"$doubled\""
        } else clean
    }

    fun buildCsvExport(ctx: Context, startIso: String? = null, endIso: String? = null): String {
        val map = getAllDaysMerged(ctx)
        val sb = StringBuilder("\uFEFFDate,Subject,StudyMin,FlipMin,ManualMin,OnlineMin,45mCircles,25mCircles,WasteMin,EatMin,SleepOtherMin,Mode,WordTarget,SubjectsJson,WasteReasonsJson,AwayMin,AwayReasonsJson,OtherMin,UnassignedMin\n")
        val rows = map.values.filter { r ->
            (startIso == null || r.date >= startIso) && (endIso == null || r.date <= endIso)
        }.sortedBy { it.date }
        for (rec in rows) {
            val flipM = rec.flipSec / 60L
            val manM = rec.manualSec / 60L
            val onM = rec.onlineSec / 60L
            val subJson = JSONObject().apply { rec.subjects.forEach { (k, v) -> put(k, v / 60L) } }.toString()
            val wrJson = JSONObject().apply { rec.wasteReasons.forEach { (k, v) -> put(k, v / 60L) } }.toString()
            sb.append(
                listOf(
                    csvEscape(rec.date),
                    csvEscape(rec.subject),
                    rec.totalStudyMinutes().toString(),
                    flipM.toString(),
                    manM.toString(),
                    onM.toString(),
                    rec.c45.toString(),
                    rec.c25.toString(),
                    (rec.wasteSec / 60L).toString(),
                    (rec.eatSec / 60L).toString(),
                    (rec.sleepOtherSec / 60L).toString(),
                    csvEscape(rec.mode),
                    rec.wordTarget.toString(),
                    csvEscape(subJson),
                    csvEscape(wrJson),
                    (rec.awaySec / 60L).toString(),
                    csvEscape(JSONObject().apply { rec.awayReasons.forEach { (k, v) -> put(k, v / 60L) } }.toString()),
                    (rec.otherSec / 60L).toString(),
                    (rec.unassignedSec / 60L).toString()
                ).joinToString(",")
            ).append("\n")
        }
        return sb.toString()
    }

    fun exportCsvToFile(ctx: Context, startIso: String? = null, endIso: String? = null, tag: String = "all"): File {
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val safeTag = tag.replace(Regex("[^a-zA-Z0-9_-]"), "_")
        val file = File(dir, "bcs_study_${safeTag}.csv")
        file.writeText(buildCsvExport(ctx, startIso, endIso), Charsets.UTF_8)
        return file
    }

    fun exportJsonToFile(ctx: Context): File {
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "bcs_study_backup_${todayIso()}.json")
        file.writeText(buildJsonExport(ctx), Charsets.UTF_8)
        return file
    }

    fun getLastSyncText(ctx: Context): String = prefs(ctx).getString(KEY_LAST_SYNC_TEXT, "এখনো সিঙ্ক হয়নি") ?: "এখনো সিঙ্ক হয়নি"
    fun setLastSyncText(ctx: Context, txt: String) = prefs(ctx).edit().putString(KEY_LAST_SYNC_TEXT, txt).apply()

    fun saveRuntimeState(ctx: Context, rt: RuntimeTrackerState) {
        prefs(ctx).edit()
            .putBoolean(KEY_RT_RUNNING, rt.running)
            .putString(KEY_RT_MODE, rt.mode)
            .putLong(KEY_RT_START_MS, rt.stateStartMs)
            .putInt(KEY_RT_REM_SEC, rt.remainingSec)
            .putBoolean(KEY_RT_FACE_DOWN, rt.faceDown)
            .putString(KEY_RT_SOURCE, rt.source)
            .apply()
    }

    fun loadRuntimeState(ctx: Context): RuntimeTrackerState {
        val p = prefs(ctx)
        return RuntimeTrackerState(
            running = p.getBoolean(KEY_RT_RUNNING, false),
            mode = p.getString(KEY_RT_MODE, "IDLE") ?: "IDLE",
            stateStartMs = p.getLong(KEY_RT_START_MS, 0L),
            remainingSec = p.getInt(KEY_RT_REM_SEC, getPresetMin(ctx) * 60),
            faceDown = p.getBoolean(KEY_RT_FACE_DOWN, false),
            source = p.getString(KEY_RT_SOURCE, "manual") ?: "manual"
        )
    }

    fun markAppClosedNow(ctx: Context) {
        prefs(ctx).edit().putLong(KEY_LAST_CLOSED, System.currentTimeMillis()).apply()
    }

    fun absorbClosedTimeAsSleepOther(ctx: Context): Long {
        val lastClosed = prefs(ctx).getLong(KEY_LAST_CLOSED, 0L)
        if (lastClosed <= 0L) return 0L
        val now = System.currentTimeMillis()
        val gapSec = (now - lastClosed) / 1000L
        prefs(ctx).edit().putLong(KEY_LAST_CLOSED, 0L).apply()
        if (gapSec in 60L..86400L) {
            val excluded = getBreakLedger(ctx).map { it.first to it.second }.toMutableList()
            val phase = getSrPhase(ctx)
            if (phase == SmartReminderManager.PHASE_EATING) {
                val bs = getSrEatStartMs(ctx)
                val bu = getSrEatUntilMs(ctx)
                if (bs > 0L) excluded.add(bs to minOf(now, if (bu > 0L) bu else now))
            } else if (phase == SmartReminderManager.PHASE_AWAY) {
                val bs = getSrAwayStartMs(ctx)
                val bu = getSrAwayUntilMs(ctx)
                if (bs > 0L) excluded.add(bs to minOf(now, if (bu > 0L) bu else now))
            }
            val remainingRanges = subtractIntervals(lastClosed, now, excluded)
            var totalAbsorbed = 0L
            if (remainingRanges.isNotEmpty()) {
                val map = loadAllDays(ctx)
                for ((rs, re) in remainingRanges) {
                    val durMin = ((re - rs) / 60_000L).toInt()
                    if (durMin < 20) {
                        for ((iso, sec) in splitByDay(rs, re)) {
                            if (sec <= 0L) continue
                            val rec = map[iso] ?: DayRecord(date = iso, subject = getCurrentSubject(ctx))
                            val room = (maxTrackableSecForDay(ctx, iso) - usedSec(rec)).coerceAtLeast(0L)
                            val add = minOf(sec, room)
                            if (add > 0L) {
                                rec.otherSec += add
                                rec.synced = false
                                map[iso] = rec
                                totalAbsorbed += add
                            }
                        }
                    } else {
                        // >= 20 মিনিট গ্যাপ: নীরব সময়ের মধ্যে পড়লে ঘুম অনুমান, নইলে অজানা গ্যাপ হিসেবে জমা
                        val midMs = rs + (re - rs) / 2L
                        val midCal = Calendar.getInstance().apply { timeInMillis = midMs }
                        val midMin = midCal.get(Calendar.HOUR_OF_DAY) * 60 + midCal.get(Calendar.MINUTE)
                        val qStart = getSrQuietStartMin(ctx)
                        val qEnd = getSrQuietEndMin(ctx)
                        val inSleepWin = isSrQuietOn(ctx) && if (qStart <= qEnd) (midMin in qStart until qEnd) else (midMin >= qStart || midMin < qEnd)
                        if (isGapAutoSleepOn(ctx) && inSleepWin && durMin >= 60) {
                            for ((iso, sec) in splitByDay(rs, re)) {
                                if (sec <= 0L) continue
                                val rec = map[iso] ?: DayRecord(date = iso, subject = getCurrentSubject(ctx))
                                val room = (maxTrackableSecForDay(ctx, iso) - usedSec(rec)).coerceAtLeast(0L)
                                val add = minOf(sec, room)
                                if (add > 0L) {
                                    rec.sleepOtherSec += add
                                    rec.synced = false
                                    map[iso] = rec
                                    totalAbsorbed += add
                                }
                            }
                            recordBreakLedger(ctx, rs, re, "SLEEP")
                        } else {
                            addPendingGap(ctx, rs, re)
                        }
                    }
                }
                if (totalAbsorbed > 0L) saveAllDays(ctx, map)
            }
            return totalAbsorbed
        }
        return 0L
    }

    @Volatile private var daysCache: MutableMap<String, DayRecord>? = null

    @Synchronized
    fun loadAllDays(ctx: Context): MutableMap<String, DayRecord> {
        daysCache?.let { cached ->
            return cached.toMutableMap()
        }
        val raw = prefs(ctx).getString(KEY_DAYS, "{}") ?: "{}"
        val map = mutableMapOf<String, DayRecord>()
        try {
            val obj = JSONObject(raw)
            val it = obj.keys()
            while (it.hasNext()) {
                val k = it.next()
                val child = obj.optJSONObject(k)
                if (child != null) map[k] = DayRecord.fromJson(child)
            }
        } catch (_: Exception) {}
        daysCache = map.toMutableMap()
        return map
    }

    @Synchronized
    fun saveAllDays(ctx: Context, map: Map<String, DayRecord>) {
        val copy = map.toMutableMap()
        daysCache = copy
        val obj = JSONObject()
        for ((k, v) in copy) obj.put(k, v.toJson())
        prefs(ctx).edit().putString(KEY_DAYS, obj.toString()).apply()
        cachedStreak = -1
    }

    @Synchronized
    fun getAllDaysMerged(ctx: Context): Map<String, DayRecord> =
        mergeDays(loadAllDays(ctx), loadDriveCache(ctx))


    fun usedSec(rec: DayRecord): Long =
        rec.studySec + rec.wasteSec + rec.eatSec + rec.awaySec + rec.sleepOtherSec + rec.otherSec + rec.unassignedSec

    fun outsideSec(rec: DayRecord): Long =
        rec.wasteSec + rec.eatSec + rec.awaySec + rec.sleepOtherSec + rec.otherSec + rec.unassignedSec

    fun pendingUnassignedGapSecForDay(ctx: Context, iso: String): Long {
        var total = 0L
        for (g in loadGaps(ctx)) {
            if (g.status != "UNKNOWN" && g.status != "DEFERRED") continue
            for ((dIso, sec) in splitByDay(g.startMs, g.endMs)) {
                if (dIso == iso && sec > 0L) total += sec
            }
        }
        return total
    }

    @Synchronized
    fun addWaste(ctx: Context, startMs: Long, endMs: Long, reason: String = "অপচয় সময়") {
        val safeEnd = endMs
        val maxSpanMs = 4L * 3600L * 1000L
        val safeStart = if (startMs <= 0L || safeEnd <= startMs) safeEnd else maxOf(startMs, safeEnd - maxSpanMs)
        val segments = splitByDay(safeStart, safeEnd)
        if (segments.isEmpty()) return
        val isUntaggedDefault = reason.trim().let { it.isEmpty() || it == "অপচয় সময়" || it == "অপচয় সময়" }
        val map = loadAllDays(ctx)
        for ((iso, rawSec) in segments) {
            if (rawSec <= 0L) continue
            val rec = map[iso] ?: DayRecord(date = iso, subject = getCurrentSubject(ctx))
            val room = (maxTrackableSecForDay(ctx, iso) - usedSec(rec)).coerceAtLeast(0L)
            val sec = minOf(rawSec, room)
            if (sec <= 0L) continue
            if (isUntaggedDefault) {
                rec.unassignedSec += sec
            } else {
                rec.wasteSec += sec
                rec.wasteReasons[reason] = (rec.wasteReasons[reason] ?: 0L) + sec
            }
            rec.synced = false
            map[iso] = rec
        }
        saveAllDays(ctx, map)
        recordBreakLedger(ctx, safeStart, safeEnd, "WASTE")
        recordTimelineInterval(ctx, safeStart, safeEnd, "waste", if (isUntaggedDefault) "অপচয় সময়" else reason.trim(), "ফোন", "")
    }

    /** একক স্টাডি-লগিং পথ: মাঝরাত ভাগ, সোর্স (flip/manual/online) ও সর্বাধিক ৪ ঘণ্টা ক্যাপসহ। */
    @Synchronized
    fun addStudy(ctx: Context, startMs: Long, endMs: Long, source: String, circlePresetMin: Int = 0): DayRecord {
        val safeEnd = endMs
        val maxSpanMs = 4L * 3600L * 1000L
        val safeStart = if (startMs <= 0L || safeEnd <= startMs) safeEnd else maxOf(startMs, safeEnd - maxSpanMs)
        val sub = getCurrentSubject(ctx)
        val segments = splitByDay(safeStart, safeEnd)
        val today = todayIso()
        val map = loadAllDays(ctx)

        for ((iso, rawSec) in segments) {
            if (rawSec <= 0L) continue
            val rec = map[iso] ?: DayRecord(date = iso, subject = sub)
            val room = (maxTrackableSecForDay(ctx, iso) - usedSec(rec)).coerceAtLeast(0L)
            val sec = minOf(rawSec, room)
            if (sec <= 0L) continue
            rec.studySec += sec
            when (source) {
                "online" -> rec.onlineSec += sec
                "flip" -> rec.flipSec += sec
                else -> rec.manualSec += sec
            }
            rec.subject = sub
            rec.subjects[sub] = (rec.subjects[sub] ?: 0L) + sec
            rec.mode = source
            rec.synced = false
            map[iso] = rec
        }

        val todayRec = map[today] ?: DayRecord(date = today, subject = sub)
        if (circlePresetMin >= 40) {
            todayRec.c45 += 1
            todayRec.synced = false
            map[today] = todayRec
        } else if (circlePresetMin >= 20) {
            todayRec.c25 += 1
            todayRec.synced = false
            map[today] = todayRec
        }
        saveAllDays(ctx, map)
        if (segments.isNotEmpty()) {
            recordBreakLedger(ctx, safeStart, safeEnd, "STUDY")
            recordStudySessionLog(ctx, safeStart, safeEnd, sub)
            val srcBn = when (source) { "online" -> "অনলাইন"; "flip" -> "ফ্লিপ"; else -> "ম্যানুয়াল" }
            val tType = if (source == "online") "online" else "study"
            recordTimelineInterval(ctx, safeStart, safeEnd, tType, sub, srcBn, sub)
        }
        val resToday = map[today] ?: todayRec
        checkAndNotifyDailyGoalReached(ctx, resToday)
        return resToday
    }

    @Synchronized
    fun getToday(ctx: Context): DayRecord {
        val today = todayIso()
        val map = loadAllDays(ctx)
        return map[today] ?: DayRecord(date = today, subject = getCurrentSubject(ctx))
    }

    @Synchronized
    fun updateToday(ctx: Context, block: (DayRecord) -> Unit): DayRecord = updateDay(ctx, todayIso(), block)

    @Synchronized
    fun updateDay(ctx: Context, iso: String, block: (DayRecord) -> Unit): DayRecord {
        val map = loadAllDays(ctx)
        val rec = map[iso] ?: DayRecord(date = iso, subject = getCurrentSubject(ctx))
        block(rec)
        map[iso] = rec
        saveAllDays(ctx, map)
        return rec
    }

    /** ওই তারিখে সর্বোচ্চ কত সেকেন্ড ট্র্যাক হওয়া সম্ভব: আজ হলে মাঝরাত থেকে এখন পর্যন্ত, অতীত হলে ২৪ ঘণ্টা। */
    fun maxTrackableSecForDay(iso: String): Long {
        if (iso != todayIso()) return 86_400L
        return ((System.currentTimeMillis() - startOfTodayMs()) / 1000L).coerceIn(0L, 86_400L)
    }

    fun maxTrackableSecForDay(ctx: Context, iso: String): Long {
        val p = prefs(ctx)
        val extra = if (p.getString(KEY_DAY_CUTOVER_ISO, "") == iso) p.getLong(KEY_DAY_CUTOVER_EXTRA_SEC, 0L) else 0L
        val cap = 86_400L + extra
        if (iso != todayIso()) return cap
        return ((System.currentTimeMillis() - startOfTodayMs()) / 1000L).coerceIn(0L, cap)
    }

    /**
     * পুরোনো বাগে (একই ফোন-ব্যবহার বারবার অপচয়ে যোগ হওয়া) অসম্ভব অপচয় জমে থাকলে
     * (যেমন ২৫ ঘণ্টা/দিন) সেটি সম্ভাব্য সর্বোচ্চে নামিয়ে আনে। স্বাভাবিক ডেটা অক্ষত থাকে।
     */
    @Synchronized
    fun repairImpossibleWaste(ctx: Context): Int {
        val map = loadAllDays(ctx)
        var fixed = 0
        for ((iso, rec) in map) {
            val allowed = (maxTrackableSecForDay(ctx, iso) - (rec.studySec + rec.eatSec + rec.awaySec + rec.sleepOtherSec + rec.otherSec + rec.unassignedSec)).coerceAtLeast(0L)
            if (rec.wasteSec <= allowed) continue
            val ratio = allowed.toDouble() / rec.wasteSec.toDouble()
            val keys = rec.wasteReasons.keys.toList()
            var sum = 0L
            for (k in keys) {
                val v = ((rec.wasteReasons[k] ?: 0L) * ratio).toLong()
                if (v > 0L) { rec.wasteReasons[k] = v; sum += v } else rec.wasteReasons.remove(k)
            }
            rec.wasteSec = if (keys.isEmpty()) allowed else sum
            rec.synced = false
            fixed++
        }
        if (fixed > 0) saveAllDays(ctx, map)
        val dMap = loadDriveCache(ctx).toMutableMap()
        var dFixed = false
        for ((iso, rec) in dMap) {
            val allowed = (maxTrackableSecForDay(ctx, iso) - (rec.studySec + rec.eatSec + rec.awaySec + rec.sleepOtherSec + rec.otherSec + rec.unassignedSec)).coerceAtLeast(0L)
            if (rec.wasteSec > allowed) {
                rec.wasteSec = allowed
                dFixed = true
            }
        }
        if (dFixed) saveDriveCache(ctx, dMap)
        return fixed
    }

    fun startOfTodayMs(): Long = dayStartMs(todayIso())

    /** একটি সময়-খণ্ড দিন-সীমায় ভাগ করে (তারিখ, সেকেন্ড) তালিকা দেয়, যাতে দিন বদলের পরের সেশন ঠিক দিনে বসে। */
    fun splitByDay(startMs: Long, endMs: Long): List<Pair<String, Long>> {
        val out = mutableListOf<Pair<String, Long>>()
        if (endMs <= startMs) return out
        var cursor = startMs
        var guard = 0
        while (cursor < endMs && guard < 40) {
            val iso = dayIsoOf(cursor)
            val segEnd = minOf(endMs, dayEndMs(iso))
            val sec = (segEnd - cursor) / 1000L
            if (sec > 0L) out.add(Pair(iso, sec))
            cursor = segEnd.coerceAtLeast(cursor + 1000L)
            guard++
        }
        return out
    }

    // সিঙ্কের সময় ডেটা বদলেছে কিনা বুঝতে কনটেন্ট-সিগনেচার (synced ফ্ল্যাগ বাদে)
    private fun contentSig(r: DayRecord): String =
        "${r.studySec}|${r.flipSec}|${r.manualSec}|${r.onlineSec}|${r.mode}|${r.wasteSec}|${r.sleepOtherSec}|${r.eatSec}|${r.c45}|${r.c25}|${r.wordTarget}|${r.subject}|${r.wasteReason}|" +
            r.subjects.toSortedMap() + "|" + r.wasteReasons.toSortedMap() + "|${r.awaySec}|" + r.awayReasons.toSortedMap() + "|${r.otherSec}|${r.unassignedSec}|${r.timelineJson.hashCode()}"

    fun getLast7Days(ctx: Context): List<DayRecord> {
        val map = getAllDaysMerged(ctx)
        val today = todayIso()
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance().apply {
            time = try { fmt.parse(today) ?: Date() } catch (_: Exception) { Date() }
        }
        val list = mutableListOf<DayRecord>()
        for (i in 6 downTo 0) {
            val c = cal.clone() as Calendar
            c.add(Calendar.DAY_OF_YEAR, -i)
            val d = fmt.format(c.time)
            list.add(map[d] ?: DayRecord(date = d))
        }
        return list
    }

    fun hasUnsyncedDays(ctx: Context): Boolean = loadAllDays(ctx).values.any { !it.synced }

    // ধাপ ২.১ ও ২.৪: শুধু synced=false দিন পাঠানো, {"ok":true} পেলেই synced=true, লোকাল ডেটা কখনো মুছবে না
    fun syncToGoogleDrive(ctx: Context): Pair<Boolean, String> {
        val urlStr = getGasUrl(ctx)
        if (urlStr.isBlank() || !urlStr.startsWith("http")) {
            return Pair(false, "সেটিংসে আগে Apps Script লিংক বসাও")
        }
        val map = loadAllDays(ctx)
        val unsynced = map.values.filter { !it.synced }.sortedBy { it.date }
        val sentSigs = unsynced.associate { it.date to contentSig(it) }
        if (unsynced.isEmpty()) {
            return Pair(true, "নতুন কোনো অসিঙ্কড ডেটা নেই (সব আপডেট আছে)")
        }
        return try {
            val arr = JSONArray()
            for (rec in unsynced) arr.put(rec.toJson())
            val payload = JSONObject().apply {
                put("appKey", "study_tracker")
                put("key", getSyncKey(ctx))
                put("updatedAt", System.currentTimeMillis())
                put("days", arr)
            }.toString()

            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                instanceFollowRedirects = true
                connectTimeout = 15000
                readTimeout = 15000
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            }
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val respText = if (stream != null) BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() } else ""
            conn.disconnect()

            val okJson = try { JSONObject(respText).optBoolean("ok", false) } catch (_: Exception) { false }
            if (code in 200..299 && okJson) {
                markSyncedIfUnchanged(ctx, sentSigs)
                pruneSyncedOldDays(ctx)
                val stamp = SimpleDateFormat("dd MMM, hh:mm a", Locale.US).format(Date())
                setLastSyncText(ctx, "সিঙ্কড: $stamp")
                Pair(true, "${toBnDigits(unsynced.size)}টি দিনের ডেটা ড্রাইভে সিঙ্ক হয়েছে!")
            } else {
                val errMsg = try { JSONObject(respText).optString("error", "") } catch (_: Exception) { "" }
                Pair(false, if (errMsg.isNotEmpty()) "সার্ভার ত্রুটি: $errMsg" else "সিঙ্ক ব্যর্থ (কোড: $code)")
            }
        } catch (e: Exception) {
            Pair(false, "নেটওয়ার্ক ত্রুটি: ${e.localizedMessage ?: "অজানা"}")
        }
    }

    // নেটওয়ার্ক কলের সময় সার্ভিস নতুন ডেটা লিখলে সেটি যেন মুছে না যায় এবং "synced" ভুলভাবে না বসে
    @Synchronized
    private fun markSyncedIfUnchanged(ctx: Context, sentSigs: Map<String, String>) {
        val fresh = loadAllDays(ctx)
        for ((date, sig) in sentSigs) {
            val rec = fresh[date] ?: continue
            if (contentSig(rec) == sig) rec.synced = true
        }
        saveAllDays(ctx, fresh)
    }

    // ধাপ ৪: মাসিক/বার্ষিক রিপোর্ট (লোকাল + ড্রাইভ ক্যাশ মার্জ, খালি থাকলে সার্ভার ফলব্যাক)
    fun fetchOrComputeReport(ctx: Context, period: String, isYearly: Boolean): ReportData {
        val merged = mergeDays(loadAllDays(ctx), loadDriveCache(ctx))
        val hasMerged = merged.values.any {
            it.date.startsWith(period) && (it.totalStudyMinutes() > 0 || it.wasteSec > 0L || it.sleepOtherSec > 0L || it.eatSec > 0L || it.awaySec > 0L || it.otherSec > 0L || it.unassignedSec > 0L)
        }
        if (hasMerged) {
            return computeReportFromMap(merged, period, isYearly, false)
        }
        val cacheKey = "report_cache_${if (isYearly) "y" else "m"}_$period"
        val cacheTsKey = "${cacheKey}_ts"
        val p = prefs(ctx)
        val isCurrent = if (isYearly) period == currentYearIso() else period == currentMonthIso()
        val cachedRaw = p.getString(cacheKey, null)
        val cachedTs = p.getLong(cacheTsKey, 0L)
        val now = System.currentTimeMillis()

        // আগের মাস/বছর একবার ক্যাশ হলে আর আনতে হবে না; চলতি মাস ১ ঘণ্টার মধ্যে ক্যাশ ব্যবহার
        if (cachedRaw != null && (!isCurrent || (now - cachedTs) < 3600_000L)) {
            parseServerReport(cachedRaw, period, isYearly, false)?.let { return it }
        }

        val urlStr = getGasUrl(ctx)
        if (urlStr.startsWith("http")) {
            try {
                val paramName = if (isYearly) "year" else "month"
                val payload = JSONObject().apply {
                    put("appKey", "study_tracker")
                    put("action", "report")
                    put("key", getSyncKey(ctx))
                    put(paramName, period)
                }.toString()
                val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    instanceFollowRedirects = true
                    connectTimeout = 10000
                    readTimeout = 12000
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                }
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload) }
                val code = conn.responseCode
                val txt = if (code in 200..299) BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { it.readText() } else ""
                conn.disconnect()
                val parsed = parseServerReport(txt, period, isYearly, false)
                if (parsed != null) {
                    p.edit().putString(cacheKey, txt).putLong(cacheTsKey, now).apply()
                    return parsed
                }
            } catch (_: Exception) {}
        }

        // অফলাইন বা সার্ভার না পেলে ক্যাশ অথবা লোকাল ডেটা থেকে হিসাব
        if (cachedRaw != null) {
            parseServerReport(cachedRaw, period, isYearly, true)?.let { return it }
        }
        return computeLocalReport(ctx, period, isYearly)
    }

    private fun parseServerReport(raw: String, period: String, isYearly: Boolean, offline: Boolean): ReportData? {
        return try {
            val o = JSONObject(raw)
            if (!o.optBoolean("ok", false)) return null
            val subMap = mutableMapOf<String, Long>()
            o.optJSONObject("subjects")?.let { so ->
                val it = so.keys()
                while (it.hasNext()) { val k = it.next(); subMap[k] = so.optLong(k, 0L) }
            }
            val wrMap = mutableMapOf<String, Long>()
            o.optJSONObject("wasteReasons")?.let { wo ->
                val it = wo.keys()
                while (it.hasNext()) { val k = it.next(); wrMap[k] = wo.optLong(k, 0L) }
            }
            val bars = mutableListOf<ChartBar>()
            val arr = o.optJSONArray("bars") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val b = arr.getJSONObject(i)
                bars.add(ChartBar(b.optString("label"), b.optInt("studyMin"), b.optInt("wasteMin"), b.optInt("sleepMin")))
            }
            ReportData(
                period = period,
                isYearly = isYearly,
                totalStudyMin = o.optInt("totalStudyMin"),
                totalWasteMin = o.optInt("totalWasteMin"),
                totalSleepMin = o.optInt("totalSleepMin"),
                avgDailyStudyMin = o.optInt("avgDailyStudyMin"),
                bestDay = o.optString("bestDay", "—"),
                bestDayMin = o.optInt("bestDayMin"),
                currentStreak = o.optInt("currentStreak"),
                longestStreak = o.optInt("longestStreak"),
                productivityScore = o.optInt("productivityScore"),
                subjects = subMap,
                wasteReasons = wrMap,
                bars = bars,
                isOffline = offline
            )
        } catch (_: Exception) { null }
    }

    private fun computeLocalReport(ctx: Context, period: String, isYearly: Boolean): ReportData =
        computeReportFromMap(mergeDays(loadAllDays(ctx), loadDriveCache(ctx)), period, isYearly, true)

    private fun computeReportFromMap(all: Map<String, DayRecord>, period: String, isYearly: Boolean, offline: Boolean): ReportData {
        val filtered = all.values.filter { it.date.startsWith(period) }.sortedBy { it.date }
        var totStudy = 0
        var totWaste = 0
        var totSleep = 0
        var bestDay = "—"
        var bestMin = 0
        val subMap = mutableMapOf<String, Long>()
        val wrMap = mutableMapOf<String, Long>()
        var curStreak = 0
        var maxStreak = 0
        var prevStudyIso = ""

        for (d in filtered) {
            val sm = d.totalStudyMinutes()
            val wm = (d.wasteSec / 60L).toInt()
            val slm = (d.sleepOtherSec / 60L).toInt()
            totStudy += sm
            totWaste += wm
            totSleep += slm
            if (sm > bestMin) { bestMin = sm; bestDay = d.date.takeLast(2) }
            if (sm > 0) {
                curStreak = if (prevStudyIso.isNotEmpty() && isNextCalendarDay(prevStudyIso, d.date)) curStreak + 1 else 1
                prevStudyIso = d.date
                if (curStreak > maxStreak) maxStreak = curStreak
            } else {
                curStreak = 0
                prevStudyIso = ""
            }
            for ((k, v) in d.subjects) subMap[k] = (subMap[k] ?: 0L) + v
            if (d.subjects.isEmpty() && d.subject.isNotEmpty() && sm > 0) {
                subMap[d.subject] = (subMap[d.subject] ?: 0L) + (sm * 60L)
            }
            for ((k, v) in d.wasteReasons) wrMap[ReasonCatalog.mapLegacyWasteReason(k)] = (wrMap[ReasonCatalog.mapLegacyWasteReason(k)] ?: 0L) + v
            if (d.wasteReasons.isEmpty() && d.wasteReason.isNotEmpty() && wm > 0) {
                wrMap[d.wasteReason] = (wrMap[d.wasteReason] ?: 0L) + (wm * 60L)
            }
        }

        val activeDays = filtered.count { it.totalStudyMinutes() > 0 }
        val avgDaily = if (activeDays > 0) (totStudy / activeDays) else 0

        // Period-independent currentStreak: আজ পড়া না থাকলে গতকাল পর্যন্ত স্ট্রিক বজায় থাকে
        val allSorted = all.values.filter { it.totalStudyMinutes() > 0 }.sortedBy { it.date }
        var globalCurStreak = 0
        var gPrev = ""
        for (gd in allSorted) {
            globalCurStreak = if (gPrev.isNotEmpty() && isNextCalendarDay(gPrev, gd.date)) globalCurStreak + 1 else 1
            gPrev = gd.date
        }
        val today = todayIso()
        val yesterday = dayIsoOf(System.currentTimeMillis() - 86_400_000L)
        if (gPrev.isEmpty() || (gPrev != today && gPrev != yesterday)) {
            globalCurStreak = 0
        }
        curStreak = globalCurStreak
        val denom = totStudy + totWaste
        val score = if (denom > 0) ((totStudy * 100) / denom) else 0

        val bars = mutableListOf<ChartBar>()
        if (isYearly) {
            val bnMonths = arrayOf("জানু", "ফেব্রু", "মার্চ", "এপ্রি", "মে", "জুন", "জুলা", "আগ", "সেপ্টে", "অক্টো", "নভে", "ডিসে")
            for (m in 1..12) {
                val ym = String.format(Locale.US, "%s-%02d", period, m)
                val mDays = filtered.filter { it.date.startsWith(ym) }
                bars.add(ChartBar(
                    bnMonths[m - 1],
                    mDays.sumOf { it.totalStudyMinutes() },
                    mDays.sumOf { (it.wasteSec / 60L).toInt() },
                    mDays.sumOf { (it.sleepOtherSec / 60L).toInt() }
                ))
            }
        } else {
            val parts = period.split("-")
            val cal = Calendar.getInstance().apply {
                set(Calendar.YEAR, parts.getOrNull(0)?.toIntOrNull() ?: 2026)
                set(Calendar.MONTH, (parts.getOrNull(1)?.toIntOrNull() ?: 1) - 1)
                set(Calendar.DAY_OF_MONTH, 1)
            }
            val maxD = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
            for (day in 1..maxD) {
                val iso = String.format(Locale.US, "%s-%02d", period, day)
                val rec = all[iso]
                bars.add(ChartBar(
                    toBnDigits(day),
                    rec?.totalStudyMinutes() ?: 0,
                    ((rec?.wasteSec ?: 0L) / 60L).toInt(),
                    ((rec?.sleepOtherSec ?: 0L) / 60L).toInt()
                ))
            }
        }

        return ReportData(period, isYearly, totStudy, totWaste, totSleep, avgDaily, bestDay, bestMin, curStreak, maxStreak, score, subMap, wrMap, bars, offline)
    }

    // v7: স্মার্ট রিমাইন্ডার সেটিংস ও রানটাইম স্টেট (সব নতুন কী; পুরোনো কিছু বদলানো হয়নি)
    private const val KEY_SR_ENABLED = "sr_enabled"
    private const val KEY_SR_ASK_DELAY_MIN = "sr_ask_delay_min"
    private const val KEY_SR_REPEAT_MIN = "sr_repeat_min"
    private const val KEY_SR_READ_RECHECK_MIN = "sr_read_recheck_min"
    private const val KEY_SR_READ_RESET_MIN = "sr_read_reset_min"
    private const val KEY_SR_IDLE_MIN = "sr_idle_min"
    private const val KEY_SR_QUIET_ON = "sr_quiet_on"
    private const val KEY_SR_QUIET_START_MIN = "sr_quiet_start_min"
    private const val KEY_SR_QUIET_END_MIN = "sr_quiet_end_min"
    private const val KEY_SR_MASCOT_STYLE = "sr_mascot_style"
    private const val KEY_SR_POPUP_OVERLAY = "sr_popup_overlay"

    private const val KEY_SR_PHASE = "sr_phase"
    private const val KEY_SR_LEVEL = "sr_level"
    private const val KEY_SR_USE_ACCUM_MS = "sr_use_accum_ms"
    private const val KEY_SR_USE_SEGMENT_START_MS = "sr_use_segment_start_ms"
    private const val KEY_SR_SCREEN_OFF_SINCE_MS = "sr_screen_off_since_ms"
    private const val KEY_SR_PREV_ONLINE = "sr_prev_online"
    private const val KEY_SR_SESSION_STARTED_BY_REMINDER = "sr_session_started_by_reminder"
    private const val KEY_SR_LAST_STUDY_END_MS = "sr_last_study_end_ms"
    private const val KEY_SR_IDLE_FIRED_EPISODE = "sr_idle_fired_episode"
    private const val KEY_SR_APP_FG = "sr_app_fg"
    private const val KEY_SR_MIGRATED_V7 = "sr_migrated_v7"

    fun isSrEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_ENABLED, true)
    fun setSrEnabled(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_ENABLED, on).apply()

    fun getSrAskDelayMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_ASK_DELAY_MIN, 2).coerceIn(1, 60)
    fun setSrAskDelayMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_ASK_DELAY_MIN, min).apply()

    fun getSrRepeatMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_REPEAT_MIN, 5).coerceIn(1, 60)
    fun setSrRepeatMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_REPEAT_MIN, min).apply()

    fun getSrReadRecheckMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_READ_RECHECK_MIN, 15).coerceIn(1, 120)
    fun setSrReadRecheckMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_READ_RECHECK_MIN, min).apply()

    fun getSrReadResetMin(ctx: Context): Int {
        val p = prefs(ctx)
        if (!p.getBoolean("sr_reset_migrated_v39", false)) {
            val cur = p.getInt(KEY_SR_READ_RESET_MIN, 20)
            p.edit().putBoolean("sr_reset_migrated_v39", true).putInt(KEY_SR_READ_RESET_MIN, if (cur == 3) 20 else cur).apply()
        }
        return p.getInt(KEY_SR_READ_RESET_MIN, 20).coerceIn(1, 120)
    }
    fun setSrReadResetMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_READ_RESET_MIN, min).apply()

    fun getSrIdleMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_IDLE_MIN, 45).coerceAtLeast(0)
    fun setSrIdleMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_IDLE_MIN, min).apply()

    fun isSrQuietOn(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_QUIET_ON, true)
    fun setSrQuietOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_QUIET_ON, on).apply()

    fun getSrQuietStartMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_QUIET_START_MIN, 0).coerceIn(0, 1439)
    fun setSrQuietStartMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_QUIET_START_MIN, min.coerceIn(0, 1439)).apply()

    fun getSrQuietEndMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_QUIET_END_MIN, 360).coerceIn(0, 1439)
    fun setSrQuietEndMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_QUIET_END_MIN, min.coerceIn(0, 1439)).apply()

    fun getSrMascotStyle(ctx: Context): String = prefs(ctx).getString(KEY_SR_MASCOT_STYLE, "auto") ?: "auto"
    fun setSrMascotStyle(ctx: Context, style: String) = prefs(ctx).edit().putString(KEY_SR_MASCOT_STYLE, style).apply()

    fun isSrPopupOverlayOn(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_POPUP_OVERLAY, true)
    fun setSrPopupOverlayOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_POPUP_OVERLAY, on).apply()

    fun getSrPhase(ctx: Context): String = prefs(ctx).getString(KEY_SR_PHASE, SmartReminderManager.PHASE_NORMAL) ?: SmartReminderManager.PHASE_NORMAL
    fun setSrPhase(ctx: Context, phase: String) = prefs(ctx).edit().putString(KEY_SR_PHASE, phase).apply()

    fun getSrLevel(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_LEVEL, 0).coerceIn(0, 5)
    fun setSrLevel(ctx: Context, lvl: Int) = prefs(ctx).edit().putInt(KEY_SR_LEVEL, lvl.coerceIn(0, 5)).apply()

    fun getSrUseAccumMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_USE_ACCUM_MS, 0L).coerceAtLeast(0L)
    fun setSrUseAccumMs(ctx: Context, ms: Long) {
        val e = prefs(ctx).edit().putLong(KEY_SR_USE_ACCUM_MS, ms.coerceAtLeast(0L))
        // জমা হওয়া ফোন-ব্যবহার শূন্য হলে "ইতিমধ্যে অপচয়ে যোগ হয়েছে" কাউন্টারও শূন্য হবে (নইলে একই সময় বারবার যোগ হয়)
        if (ms <= 0L) e.putLong(KEY_SR_WASTE_COMMITTED_MS, 0L)
        e.apply()
    }

    fun getSrUseSegmentStartMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_USE_SEGMENT_START_MS, 0L)
    fun setSrUseSegmentStartMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_USE_SEGMENT_START_MS, ms).apply()

    fun getSrScreenOffSinceMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_SCREEN_OFF_SINCE_MS, 0L)
    fun setSrScreenOffSinceMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_SCREEN_OFF_SINCE_MS, ms).apply()

    fun getSrPrevOnline(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_PREV_ONLINE, false)
    fun setSrPrevOnline(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_PREV_ONLINE, on).apply()

    fun isSrSessionStartedByReminder(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_SESSION_STARTED_BY_REMINDER, false)
    fun setSrSessionStartedByReminder(ctx: Context, started: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_SESSION_STARTED_BY_REMINDER, started).apply()

    fun getSrLastStudyEndMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_LAST_STUDY_END_MS, 0L)
    fun setSrLastStudyEndMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_LAST_STUDY_END_MS, ms).apply()

    fun isSrIdleFiredEpisode(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_IDLE_FIRED_EPISODE, false)
    fun setSrIdleFiredEpisode(ctx: Context, fired: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_IDLE_FIRED_EPISODE, fired).apply()

    fun isSrAppForeground(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_APP_FG, false)
    fun setSrAppForeground(ctx: Context, fg: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_APP_FG, fg).apply()

    fun isSrMigratedV7(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_MIGRATED_V7, false)
    fun setSrMigratedV7(ctx: Context, done: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_MIGRATED_V7, done).apply()

    fun formatTimeMinBn(totalMin: Int): String {
        val m = totalMin.coerceIn(0, 1439)
        return toBnDigits(String.format(Locale.US, "%02d:%02d", m / 60, m % 60))
    }

    // v7.1: ফলো-আপ দেরি, খাচ্ছি, বাইরে আছি ও স্ট্রিক্ট মোড কী
    private const val KEY_SR_FALLBACK_SEC = "sr_fallback_delay_sec"
    private const val KEY_SR_EAT_MIN = "sr_eat_min"
    private const val KEY_SR_STRICT_AFTER_MIN = "sr_strict_after_min"
    private const val KEY_SR_EAT_START_MS = "sr_eat_start_ms"
    private const val KEY_SR_EAT_UNTIL_MS = "sr_eat_until_ms"
    private const val KEY_SR_AWAY_UNTIL_MS = "sr_away_until_ms"
    private const val KEY_SR_AWAY_TOTAL_MIN = "sr_away_total_min"
    private const val KEY_SR_MSG_INDEX = "sr_msg_index"
    private const val KEY_SR_FB_KIND = "sr_pending_fb_kind"
    private const val KEY_SR_FB_LEVEL = "sr_pending_fb_level"
    private const val KEY_SR_FB_ELAPSED = "sr_pending_fb_elapsed"
    private const val KEY_SR_FB_MSG_IDX = "sr_pending_fb_msg_idx"

    fun getSrFallbackDelaySec(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_FALLBACK_SEC, 20).coerceIn(5, 120)
    fun setSrFallbackDelaySec(ctx: Context, sec: Int) = prefs(ctx).edit().putInt(KEY_SR_FALLBACK_SEC, sec.coerceIn(5, 120)).apply()

    fun getSrEatMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_EAT_MIN, 45).coerceIn(10, 180)
    fun setSrEatMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_EAT_MIN, min.coerceIn(10, 180)).apply()

    fun getSrStrictAfterMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_STRICT_AFTER_MIN, 30).coerceAtLeast(0)
    fun setSrStrictAfterMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_STRICT_AFTER_MIN, min.coerceAtLeast(0)).apply()

    fun getSrEatStartMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_EAT_START_MS, 0L)
    fun setSrEatStartMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_EAT_START_MS, ms).apply()

    fun getSrEatUntilMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_EAT_UNTIL_MS, 0L)
    fun setSrEatUntilMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_EAT_UNTIL_MS, ms).apply()

    fun getSrAwayUntilMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_AWAY_UNTIL_MS, 0L)
    fun setSrAwayUntilMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_AWAY_UNTIL_MS, ms).apply()

    fun getSrAwayTotalMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_AWAY_TOTAL_MIN, 0)
    fun setSrAwayTotalMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_AWAY_TOTAL_MIN, min).apply()

    fun getSrMsgIndex(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_MSG_INDEX, 0)
    fun setSrMsgIndex(ctx: Context, idx: Int) = prefs(ctx).edit().putInt(KEY_SR_MSG_INDEX, idx).apply()

    fun setSrPendingFallback(ctx: Context, kind: String, level: Int, elapsed: Int, msgIdx: Int) {
        prefs(ctx).edit()
            .putString(KEY_SR_FB_KIND, kind)
            .putInt(KEY_SR_FB_LEVEL, level)
            .putInt(KEY_SR_FB_ELAPSED, elapsed)
            .putInt(KEY_SR_FB_MSG_IDX, msgIdx)
            .apply()
    }
    fun clearSrPendingFallback(ctx: Context) {
        prefs(ctx).edit().putString(KEY_SR_FB_KIND, "").apply()
    }
    fun getSrPendingFbKind(ctx: Context): String = prefs(ctx).getString(KEY_SR_FB_KIND, "") ?: ""
    fun getSrPendingFbLevel(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_FB_LEVEL, 1)
    fun getSrPendingFbElapsed(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_FB_ELAPSED, 0)
    fun getSrPendingFbMsgIdx(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_FB_MSG_IDX, 0)

    // v7.2: কলে থাকলে কাস্টম সময় পরপর ৩বার ভাইব্রেট
    private const val KEY_SR_CALL_VIB_MIN = "sr_call_vib_min"
    fun getSrCallVibMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_CALL_VIB_MIN, 10).coerceAtLeast(0)
    fun setSrCallVibMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_CALL_VIB_MIN, min.coerceAtLeast(0)).apply()

    private const val KEY_SR_MAX_RAGE_NOTIF_SENT = "sr_max_rage_notif_sent"
    fun isSrMaxRageNotifSent(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_MAX_RAGE_NOTIF_SENT, false)
    fun setSrMaxRageNotifSent(ctx: Context, sent: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_MAX_RAGE_NOTIF_SENT, sent).apply()

    private const val KEY_SR_WASTE_COMMITTED_MS = "sr_waste_committed_ms"
    fun getSrWasteCommittedMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_WASTE_COMMITTED_MS, 0L).coerceAtLeast(0L)
    fun setSrWasteCommittedMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_WASTE_COMMITTED_MS, ms.coerceAtLeast(0L)).apply()

    // v8.7: শর্তসাপেক্ষ নিরাপদ প্রুনিং (JSON >= ১ MB এবং ৪ মাসের পুরোনো synced=true দিন, দিনে সর্বোচ্চ ১ বার)
    @Synchronized
    fun pruneSyncedOldDays(ctx: Context) {
        val today = todayIso()
        if (prefs(ctx).getString("sr_last_prune_date", "") == today) return
        val raw = prefs(ctx).getString(KEY_DAYS, "{}") ?: "{}"
        if (raw.length < 1_000_000) return

        val cal = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            add(Calendar.MONTH, -3) // চলতি মাস + আগের ৩টি পূর্ণ মাস রাখা হবে
        }
        val cutoffYm = SimpleDateFormat("yyyy-MM", Locale.US).format(cal.time)
        val map = loadAllDays(ctx)
        val driveCache = loadDriveCache(ctx).toMutableMap()
        val toPrune = mutableListOf<String>()
        for ((k, v) in map) {
            if (k.take(7) < cutoffYm && v.synced) {
                driveCache[k] = v
                toPrune.add(k)
            }
        }
        if (toPrune.isEmpty()) {
            prefs(ctx).edit().putString("sr_last_prune_date", today).apply()
            return
        }
        // আগে অ্যাটমিকভাবে drive_days.json সেভ নিশ্চিত করো, ব্যর্থ হলে প্রুনিং বাতিল
        if (!saveDriveCache(ctx, driveCache)) return
        for (k in toPrune) map.remove(k)
        saveAllDays(ctx, map)
        prefs(ctx).edit().putString("sr_last_prune_date", today).apply()
    }

    private fun driveCacheFile(ctx: Context): File = File(ctx.filesDir, "drive_days.json")

    @Synchronized
    fun loadDriveCache(ctx: Context): Map<String, DayRecord> {
        val f = driveCacheFile(ctx)
        if (!f.exists()) return emptyMap()
        val out = mutableMapOf<String, DayRecord>()
        try {
            val obj = JSONObject(f.readText(Charsets.UTF_8))
            val it = obj.keys()
            while (it.hasNext()) {
                val k = it.next()
                obj.optJSONObject(k)?.let { out[k] = DayRecord.fromJson(it) }
            }
        } catch (_: Exception) {}
        return out
    }

    @Synchronized
    fun saveDriveCache(ctx: Context, map: Map<String, DayRecord>): Boolean {
        val af = AtomicFile(driveCacheFile(ctx))
        var fos: java.io.FileOutputStream? = null
        return try {
            val obj = JSONObject()
            for ((k, v) in map) obj.put(k, v.toJson())
            fos = af.startWrite()
            fos.write(obj.toString().toByteArray(Charsets.UTF_8))
            af.finishWrite(fos)
            true
        } catch (_: Exception) {
            if (fos != null) af.failWrite(fos)
            false
        }
    }

    /** তারিখ ধরে মার্জ: লোকালে যে তারিখ আছে সেখানে লোকাল সবসময় জেতে, ড্রাইভ শুধু লোকালে-না-থাকা দিন ভরে। */
    fun mergeDays(local: Map<String, DayRecord>, drive: Map<String, DayRecord>): Map<String, DayRecord> {
        val merged = linkedMapOf<String, DayRecord>()
        for ((k, v) in drive) merged[k] = v
        for ((k, v) in local) merged[k] = v
        return merged
    }

    fun buildJsonExport(ctx: Context): String {
        val map = getAllDaysMerged(ctx)
        val obj = JSONObject()
        for ((k, v) in map.toSortedMap()) obj.put(k, v.toJson())
        return obj.toString(2)
    }

    /** ড্রাইভ (Apps Script action=all_days) থেকে ইনক্রিমেন্টাল (since=) ডেটা এনে ক্যাশ ও মার্জ করে। */
    fun fetchAllDaysFromDrive(ctx: Context, timeoutMs: Int = 10000): Pair<Boolean, Map<String, DayRecord>> {
        val cached = loadDriveCache(ctx).toMutableMap()
        val urlStr = getGasUrl(ctx)
        if (!urlStr.startsWith("http")) {
            return Pair(false, mergeDays(loadAllDays(ctx), cached))
        }
        return try {
            val lastDate = cached.keys.maxOrNull()?.let { iso ->
                try {
                    val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                    val c = Calendar.getInstance().apply { time = fmt.parse(iso)!!; add(Calendar.DAY_OF_YEAR, -2) }
                    fmt.format(c.time)
                } catch (_: Exception) { iso }
            } ?: ""
            val payload = JSONObject().apply {
                put("appKey", "study_tracker")
                put("action", "all_days")
                put("key", getSyncKey(ctx))
                if (lastDate.isNotEmpty()) put("since", lastDate)
            }.toString()
            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                instanceFollowRedirects = true
                connectTimeout = timeoutMs
                readTimeout = timeoutMs
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            }
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload) }
            var code = conn.responseCode
            var txt = if (code in 200..299) BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { it.readText() } else ""
            conn.disconnect()
            val o = try { JSONObject(txt) } catch (_: Exception) { JSONObject() }
            if (code in 200..299 && o.optBoolean("ok", false)) {
                val arr = o.optJSONArray("days") ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val rec = DayRecord.fromJson(arr.getJSONObject(i)).apply { synced = true }
                    cached[rec.date] = rec
                }
                saveDriveCache(ctx, cached)
                Pair(true, mergeDays(loadAllDays(ctx), cached))
            } else {
                Pair(false, mergeDays(loadAllDays(ctx), cached))
            }
        } catch (_: Exception) {
            Pair(false, mergeDays(loadAllDays(ctx), cached))
        }
    }

    // v8.5: শেষ ৮টি মেসেজের ইতিহাস ও সিম ডেটা ড্যাশবোর্ড পছন্দ
    private const val KEY_SR_RECENT_MSGS = "sr_recent_msgs"
    private const val KEY_SR_DASH_CELL_ALWAYS = "sr_dash_cell_always"

    fun getSrRecentMsgs(ctx: Context): List<String> {
        val raw = prefs(ctx).getString(KEY_SR_RECENT_MSGS, "") ?: ""
        return if (raw.isEmpty()) emptyList() else raw.split("|").filter { it.isNotEmpty() }
    }

    fun recordSrRecentMsg(ctx: Context, key: String) {
        val list = getSrRecentMsgs(ctx).toMutableList()
        list.remove(key)
        list.add(key)
        while (list.size > 8) list.removeAt(0)
        prefs(ctx).edit().putString(KEY_SR_RECENT_MSGS, list.joinToString("|")).apply()
    }

    fun isSrDashCellAlways(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_DASH_CELL_ALWAYS, false)
    fun setSrDashCellAlways(ctx: Context, always: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_DASH_CELL_ALWAYS, always).apply()

    // v9.20: অফলাইন ডিভাইস-লক (সল্টেড PBKDF2-HMAC-SHA256 ৫০,০০০ রাউন্ড + ৫-বার ভুল লকআউট)
    private const val KEY_DEVICE_UNLOCK_TOKEN = "app_device_unlock_token"
    private const val KEY_APP_LOCK_FAILS = "app_lock_fail_cnt"
    private const val KEY_APP_LOCK_UNTIL = "app_lock_until_ms"
    private const val APP_LOCK_SALT_HEX = "399e2c3895d1767c85fd3e6e99e10521"
    private const val APP_LOCK_PBKDF2_HEX = "617f99a5d059b80d30bd21d881791ced401ab3a8f669f856e3d77345342524aa"

    fun sha256Hex(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun pbkdf2Hex(secretStr: String, saltHex: String, iterations: Int = 50_000): String {
        val salt = ByteArray(saltHex.length / 2) { i ->
            saltHex.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
        val spec = javax.crypto.spec.PBEKeySpec(secretStr.toCharArray(), salt, iterations, 256)
        val skf = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val bytes = skf.generateSecret(spec).encoded
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun expectedDeviceToken(ctx: Context): String {
        val androidId = try {
            Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "bcs_dev"
        } catch (_: Exception) { "bcs_dev" }
        return sha256Hex("$APP_LOCK_PBKDF2_HEX|$androidId")
    }

    fun isDeviceUnlocked(ctx: Context): Boolean {
        val saved = prefs(ctx).getString(KEY_DEVICE_UNLOCK_TOKEN, "") ?: ""
        return saved.isNotEmpty() && saved == expectedDeviceToken(ctx)
    }

    fun getAppLockUntilMs(ctx: Context): Long = prefs(ctx).getLong(KEY_APP_LOCK_UNTIL, 0L)

    fun verifyAndUnlockDevice(ctx: Context, rawPassword: String): Boolean {
        val now = System.currentTimeMillis()
        if (getAppLockUntilMs(ctx) > now) return false
        val derived = pbkdf2Hex(sha256Hex(rawPassword.trim()), APP_LOCK_SALT_HEX)
        if (derived == APP_LOCK_PBKDF2_HEX) {
            prefs(ctx).edit()
                .putString(KEY_DEVICE_UNLOCK_TOKEN, expectedDeviceToken(ctx))
                .putInt(KEY_APP_LOCK_FAILS, 0)
                .putLong(KEY_APP_LOCK_UNTIL, 0L)
                .apply()
            return true
        }
        val nextFails = prefs(ctx).getInt(KEY_APP_LOCK_FAILS, 0) + 1
        val until = if (nextFails >= 5) now + 60_000L else 0L
        prefs(ctx).edit()
            .putInt(KEY_APP_LOCK_FAILS, if (nextFails >= 5) 0 else nextFails)
            .putLong(KEY_APP_LOCK_UNTIL, until)
            .apply()
        return false
    }

    // v9.0: একক রিপোর্ট গণনা, ক্যালেন্ডার পিরিয়ড, সিঙ্ক টেস্ট/রিসেট ও মাস্টার পাসওয়ার্ড রিকভারি
    private const val KEY_REPORT_PERIOD_TYPE = "report_period_type"
    private const val KEY_REPORT_ANCHOR_ISO = "report_anchor_iso"
    private const val KEY_WEEK_START_DAY = "report_week_start_day"
    private const val KEY_SYNC_LOCK_FAILS = "sync_lock_fails"
    private const val KEY_SYNC_LOCK_UNTIL = "sync_lock_until_ms"

    fun getReportPeriodType(ctx: Context): ReportPeriodType {
        val raw = prefs(ctx).getString(KEY_REPORT_PERIOD_TYPE, "DAY") ?: "DAY"
        return try { ReportPeriodType.valueOf(raw) } catch (_: Exception) { ReportPeriodType.DAY }
    }

    fun setReportPeriodType(ctx: Context, type: ReportPeriodType) {
        prefs(ctx).edit().putString(KEY_REPORT_PERIOD_TYPE, type.name).apply()
    }

    fun getReportAnchorIso(ctx: Context): String {
        val saved = prefs(ctx).getString(KEY_REPORT_ANCHOR_ISO, "") ?: ""
        return if (isValidIsoDate(saved)) saved else todayIso()
    }

    fun setReportAnchorIso(ctx: Context, iso: String) {
        if (isValidIsoDate(iso)) prefs(ctx).edit().putString(KEY_REPORT_ANCHOR_ISO, iso).apply()
    }

    fun getLastOpenIso(ctx: Context): String = prefs(ctx).getString("last_open_iso", "") ?: ""
    fun setLastOpenIso(ctx: Context, iso: String) = prefs(ctx).edit().putString("last_open_iso", iso).apply()

    fun getWeekStartDay(ctx: Context): Int {
        val v = prefs(ctx).getInt(KEY_WEEK_START_DAY, Calendar.SUNDAY)
        return if (v == Calendar.SATURDAY) Calendar.SATURDAY else Calendar.SUNDAY
    }

    fun setWeekStartDay(ctx: Context, day: Int) {
        val safe = if (day == Calendar.SATURDAY) Calendar.SATURDAY else Calendar.SUNDAY
        prefs(ctx).edit().putInt(KEY_WEEK_START_DAY, safe).apply()
    }

    fun isSyncUrlValid(urlStr: String): Boolean {
        val u = urlStr.trim()
        return u.startsWith("https://") && u.contains("script.google.com") && u.endsWith("/exec")
    }

    fun testSyncConnection(ctx: Context, urlStr: String, syncKey: String): Pair<Boolean, String> {
        val cleanUrl = urlStr.trim()
        if (!isSyncUrlValid(cleanUrl)) {
            return Pair(false, "সঠিক Apps Script লিংক দাও (https://... এবং /exec দিয়ে শেষ)")
        }
        return try {
            val payload = JSONObject().apply {
                put("appKey", "study_tracker")
                put("action", "ping")
                put("key", syncKey.trim())
                put("days", JSONArray())
            }.toString()
            val conn = (URL(cleanUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                instanceFollowRedirects = true
                connectTimeout = 12000
                readTimeout = 12000
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            }
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val txt = if (stream != null) BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() } else ""
            conn.disconnect()
            val o = try { JSONObject(txt) } catch (_: Exception) { JSONObject() }
            if (code in 200..299 && o.optBoolean("ok", false)) {
                Pair(true, "সংযোগ সফল! সার্ভারে পাসওয়ার্ড মিলেছে।")
            } else {
                val err = o.optString("error", "")
                Pair(false, if (err.isNotEmpty()) "সার্ভার ত্রুটি: $err" else "সংযোগ ব্যর্থ (কোড: $code)")
            }
        } catch (e: Exception) {
            Pair(false, "নেটওয়ার্ক ত্রুটি: ${e.localizedMessage ?: "অজানা"}")
        }
    }

    @Synchronized
    fun resetSyncStateForNewUrl(ctx: Context, resendAllDays: Boolean, clearDriveCache: Boolean) {
        if (resendAllDays) {
            val local = loadAllDays(ctx)
            for (rec in local.values) rec.synced = false
            saveAllDays(ctx, local)
        }
        if (clearDriveCache) {
            try { driveCacheFile(ctx).delete() } catch (_: Exception) {}
        }
        cachedStreak = -1
    }

    fun verifyAppMasterPassword(rawPassword: String): Boolean {
        return pbkdf2Hex(sha256Hex(rawPassword.trim()), APP_LOCK_SALT_HEX) == APP_LOCK_PBKDF2_HEX
    }

    fun getSyncLockFailCount(ctx: Context): Int = prefs(ctx).getInt(KEY_SYNC_LOCK_FAILS, 0)
    fun getSyncLockUntilMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SYNC_LOCK_UNTIL, 0L)
    fun recordSyncLockFailure(ctx: Context): Long {
        val next = getSyncLockFailCount(ctx) + 1
        val until = if (next >= 5) System.currentTimeMillis() + 60_000L else 0L
        prefs(ctx).edit().putInt(KEY_SYNC_LOCK_FAILS, next).putLong(KEY_SYNC_LOCK_UNTIL, until).apply()
        return until
    }
    fun resetSyncLockFailures(ctx: Context) {
        prefs(ctx).edit().putInt(KEY_SYNC_LOCK_FAILS, 0).putLong(KEY_SYNC_LOCK_UNTIL, 0L).apply()
    }

    fun computeUnifiedReport(ctx: Context, type: ReportPeriodType, anchorIso: String): UnifiedReportData {
        val all = getAllDaysMerged(ctx)
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val today = todayIso()
        val anchorCal = Calendar.getInstance().apply {
            time = try { fmt.parse(anchorIso) ?: Date() } catch (_: Exception) { Date() }
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val bnMonthsFull = arrayOf("জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর")
        val bnMonthsShort = arrayOf("জানু", "ফেব্রু", "মার্চ", "এপ্রি", "মে", "জুন", "জুলা", "আগ", "সেপ্টে", "অক্টো", "নভে", "ডিসে")
        val bnWeekDaysShort = arrayOf("রবি", "সোম", "মঙ্গল", "বুধ", "বৃহ", "শুক্র", "শনি")

        val startIso: String
        val endIso: String
        val totalDaysCount: Int
        val elapsedDaysCount: Int
        val isPartialCurrent: Boolean
        val baseLabel: String

        when (type) {
            ReportPeriodType.DAY -> {
                startIso = fmt.format(anchorCal.time)
                endIso = startIso
                totalDaysCount = 1
                elapsedDaysCount = 1
                isPartialCurrent = false
                val mName = bnMonthsFull[anchorCal.get(Calendar.MONTH)]
                baseLabel = "${toBnDigits(anchorCal.get(Calendar.DAY_OF_MONTH))} $mName ${toBnDigits(anchorCal.get(Calendar.YEAR))}"
            }
            ReportPeriodType.WEEK -> {
                val weekStart = getWeekStartDay(ctx)
                val startCal = anchorCal.clone() as Calendar
                while (startCal.get(Calendar.DAY_OF_WEEK) != weekStart) {
                    startCal.add(Calendar.DAY_OF_YEAR, -1)
                }
                val endCal = startCal.clone() as Calendar
                endCal.add(Calendar.DAY_OF_YEAR, 6)
                startIso = fmt.format(startCal.time)
                endIso = fmt.format(endCal.time)
                totalDaysCount = 7
                isPartialCurrent = today in startIso..endIso && today < endIso
                elapsedDaysCount = if (today in startIso..endIso) {
                    var cnt = 0
                    val tmp = startCal.clone() as Calendar
                    while (fmt.format(tmp.time) <= today) { cnt++; tmp.add(Calendar.DAY_OF_YEAR, 1) }
                    cnt.coerceIn(1, 7)
                } else 7
                val sDay = toBnDigits(startCal.get(Calendar.DAY_OF_MONTH))
                val eDay = toBnDigits(endCal.get(Calendar.DAY_OF_MONTH))
                val sMon = bnMonthsShort[startCal.get(Calendar.MONTH)]
                val eMon = bnMonthsShort[endCal.get(Calendar.MONTH)]
                baseLabel = if (sMon == eMon) "$sDay–$eDay $eMon" else "$sDay $sMon – $eDay $eMon"
            }
            ReportPeriodType.MONTH -> {
                val ym = SimpleDateFormat("yyyy-MM", Locale.US).format(anchorCal.time)
                val maxD = anchorCal.getActualMaximum(Calendar.DAY_OF_MONTH)
                startIso = "$ym-01"
                endIso = String.format(Locale.US, "%s-%02d", ym, maxD)
                totalDaysCount = maxD
                isPartialCurrent = today.startsWith(ym) && today < endIso
                elapsedDaysCount = if (today.startsWith(ym)) {
                    (today.takeLast(2).toIntOrNull() ?: maxD).coerceIn(1, maxD)
                } else maxD
                baseLabel = "${bnMonthsFull[anchorCal.get(Calendar.MONTH)]} ${toBnDigits(anchorCal.get(Calendar.YEAR))}"
            }
            ReportPeriodType.YEAR -> {
                val yr = anchorCal.get(Calendar.YEAR)
                startIso = "$yr-01-01"
                endIso = "$yr-12-31"
                totalDaysCount = anchorCal.getActualMaximum(Calendar.DAY_OF_YEAR)
                isPartialCurrent = today.startsWith("$yr-") && today < endIso
                elapsedDaysCount = if (today.startsWith("$yr-")) {
                    val tCal = Calendar.getInstance().apply {
                        time = try { fmt.parse(today) ?: Date() } catch (_: Exception) { Date() }
                    }
                    tCal.get(Calendar.DAY_OF_YEAR).coerceIn(1, totalDaysCount)
                } else totalDaysCount
                baseLabel = "সাল ${toBnDigits(yr)}"
            }
        }

        val periodLabelBn = if (isPartialCurrent && type != ReportPeriodType.DAY) {
            val prefix = when (type) {
                ReportPeriodType.WEEK -> "চলতি সপ্তাহ"
                ReportPeriodType.MONTH -> "চলতি মাস"
                else -> "চলতি বছর"
            }
            "$prefix (${toBnDigits(elapsedDaysCount)}/${toBnDigits(totalDaysCount)} দিন)"
        } else baseLabel

        val filtered = all.values.filter { it.date in startIso..endIso }.sortedBy { it.date }
        var totStudy = 0
        var totWaste = 0
        var totEat = 0
        var totSleep = 0
        var totAway = 0
        var totOther = 0
        var totUnassigned = 0
        var flipM = 0
        var manM = 0
        var onM = 0
        var bestDayLabel = "—"
        var bestMin = 0
        val subMap = mutableMapOf<String, Long>()
        val wrMap = mutableMapOf<String, Long>()
        val awMap = mutableMapOf<String, Long>()
        var periodMaxStreak = 0
        var runningStreak = 0
        var prevStudyIso2 = ""

        for (d in filtered) {
            val sm = d.totalStudyMinutes()
            val wm = (d.wasteSec / 60L).toInt()
            val em = (d.eatSec / 60L).toInt()
            val slm = (d.sleepOtherSec / 60L).toInt()
            val awm = (d.awaySec / 60L).toInt()
            val otm = (d.otherSec / 60L).toInt()
            val uam = ((d.unassignedSec + pendingUnassignedGapSecForDay(ctx, d.date)) / 60L).toInt()
            totStudy += sm
            totWaste += wm
            totEat += em
            totSleep += slm
            totAway += awm
            totOther += otm
            totUnassigned += uam
            val fMin = (d.flipSec / 60L).toInt()
            val mMin = (d.manualSec / 60L).toInt()
            val oMin = (d.onlineSec / 60L).toInt()
            if (fMin + mMin + oMin > 0) {
                flipM += fMin; manM += mMin; onM += oMin
            } else if (sm > 0) {
                if (d.mode == "online") onM += sm else flipM += sm
            }
            if (sm > bestMin) {
                bestMin = sm
                bestDayLabel = "${toBnDigits(d.date.takeLast(2))} ${bnMonthsShort[(d.date.substring(5, 7).toIntOrNull() ?: 1) - 1]}"
            }
            if (sm > 0) {
                runningStreak = if (prevStudyIso2.isNotEmpty() && isNextCalendarDay(prevStudyIso2, d.date)) runningStreak + 1 else 1
                prevStudyIso2 = d.date
                if (runningStreak > periodMaxStreak) periodMaxStreak = runningStreak
            } else {
                runningStreak = 0
                prevStudyIso2 = ""
            }
            for ((k, v) in d.subjects) subMap[k] = (subMap[k] ?: 0L) + v
            if (d.subjects.isEmpty() && d.subject.isNotEmpty() && sm > 0) {
                subMap[d.subject] = (subMap[d.subject] ?: 0L) + (sm * 60L)
            }
            for ((k, v) in d.wasteReasons) wrMap[ReasonCatalog.mapLegacyWasteReason(k)] = (wrMap[ReasonCatalog.mapLegacyWasteReason(k)] ?: 0L) + v
            for ((k, v) in d.awayReasons) awMap[k] = (awMap[k] ?: 0L) + v
            if (d.wasteReasons.isEmpty() && d.wasteReason.isNotEmpty() && wm > 0) {
                wrMap[d.wasteReason] = (wrMap[d.wasteReason] ?: 0L) + (wm * 60L)
            }
        }

        val hasAnyData = filtered.any { it.totalStudyMinutes() > 0 || it.wasteSec > 0L || it.eatSec > 0L || it.sleepOtherSec > 0L || it.awaySec > 0L || it.otherSec > 0L || it.unassignedSec > 0L }
        val avgDaily = totStudy / elapsedDaysCount.coerceAtLeast(1)
        val targetTotalMin = (getDailyGoalHours(ctx) * 60) * elapsedDaysCount.coerceAtLeast(1)
        val goalPct = if (targetTotalMin > 0) ((totStudy * 100) / targetTotalMin).coerceAtMost(999) else 0
        val denom = totStudy + totWaste
        val wasteScore = if (denom > 0) ((totStudy * 100) / denom) else 0

        val bars = mutableListOf<ChartBar>()
        when (type) {
            ReportPeriodType.DAY -> { /* দিনে বার চার্ট দেখানো হয় না */ }
            ReportPeriodType.WEEK -> {
                val c = Calendar.getInstance().apply { time = fmt.parse(startIso) ?: Date() }
                for (i in 0..6) {
                    val iso = fmt.format(c.time)
                    val rec = all[iso]
                    val wd = bnWeekDaysShort[c.get(Calendar.DAY_OF_WEEK) - 1]
                    bars.add(ChartBar(wd, rec?.totalStudyMinutes() ?: 0, ((rec?.wasteSec ?: 0L) / 60L).toInt(), ((rec?.sleepOtherSec ?: 0L) / 60L).toInt()))
                    c.add(Calendar.DAY_OF_YEAR, 1)
                }
            }
            ReportPeriodType.MONTH -> {
                val ym = startIso.take(7)
                for (day in 1..totalDaysCount) {
                    val iso = String.format(Locale.US, "%s-%02d", ym, day)
                    val rec = all[iso]
                    bars.add(ChartBar(toBnDigits(day), rec?.totalStudyMinutes() ?: 0, ((rec?.wasteSec ?: 0L) / 60L).toInt(), ((rec?.sleepOtherSec ?: 0L) / 60L).toInt()))
                }
            }
            ReportPeriodType.YEAR -> {
                val yr = startIso.take(4)
                for (m in 1..12) {
                    val ym = String.format(Locale.US, "%s-%02d", yr, m)
                    val mDays = filtered.filter { it.date.startsWith(ym) }
                    bars.add(ChartBar(
                        bnMonthsShort[m - 1],
                        mDays.sumOf { it.totalStudyMinutes() },
                        mDays.sumOf { (it.wasteSec / 60L).toInt() },
                        mDays.sumOf { (it.sleepOtherSec / 60L).toInt() }
                    ))
                }
            }
        }

        val curStreak = getCurrentStreak(ctx)
        val savedLongest = prefs(ctx).getInt("saved_longest_streak", 0).coerceAtLeast(periodMaxStreak).coerceAtLeast(curStreak)

        return UnifiedReportData(
            type = type,
            anchorIso = fmt.format(anchorCal.time),
            rangeStartIso = startIso,
            rangeEndIso = endIso,
            periodLabelBn = periodLabelBn,
            isPartialCurrentPeriod = isPartialCurrent,
            elapsedDaysCount = elapsedDaysCount,
            totalDaysCount = totalDaysCount,
            totalStudyMin = totStudy,
            totalWasteMin = totWaste,
            totalEatMin = totEat,
            totalSleepMin = totSleep,
            totalAwayMin = totAway,
            totalOtherMin = totOther,
            totalUnassignedMin = totUnassigned,
            flipMin = flipM,
            manualMin = manM,
            onlineMin = onM,
            avgDailyStudyMin = avgDaily,
            goalCompletionPct = goalPct,
            wasteRatioScore = wasteScore,
            bestDayLabel = bestDayLabel,
            bestDayMin = bestMin,
            currentStreak = curStreak,
            longestStreak = savedLongest,
            subjects = subMap,
            wasteReasons = wrMap,
            awayReasons = awMap,
            bars = bars,
            hasAnyDataInPeriod = hasAnyData
        )
    }

    private const val KEY_SR_MORNING_GREETED_DATE = "sr_morning_greeted_date"
    private const val KEY_SR_LAST_ACTIVE_DATE = "sr_last_active_date"

    fun getSrMorningGreetedDate(ctx: Context): String = prefs(ctx).getString(KEY_SR_MORNING_GREETED_DATE, "") ?: ""
    fun setSrMorningGreetedDate(ctx: Context, d: String) = prefs(ctx).edit().putString(KEY_SR_MORNING_GREETED_DATE, d).apply()
    fun getSrLastActiveDate(ctx: Context): String = prefs(ctx).getString(KEY_SR_LAST_ACTIVE_DATE, "") ?: ""
    fun setSrLastActiveDate(ctx: Context, d: String) = prefs(ctx).edit().putString(KEY_SR_LAST_ACTIVE_DATE, d).apply()

    // v9.2: বাইরের সময়, ব্রেক লেজার, কাস্টম অপচয় কারণ ও বাজেট
    private const val KEY_SR_AWAY_START_MS = "sr_away_start_ms"
    private const val KEY_SR_AWAY_REASON = "sr_away_reason"
    private const val KEY_SR_LIVE_WASTE_REASON = "sr_live_waste_reason"
    private const val KEY_SR_WASTE_BUDGET_HRS = "sr_waste_budget_hours"
    private const val KEY_SR_CUSTOM_WASTE_REASONS = "sr_custom_waste_reasons"
    private const val KEY_SR_LAST_BREAK_PROMPT_MS = "sr_last_break_prompt_ms"
    private const val KEY_SR_HELP_HINT_SHOWN = "sr_help_hint_shown"
    private const val KEY_SR_BREAK_LEDGER = "sr_break_ledger"

    fun getSrAwayStartMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_AWAY_START_MS, 0L)
    fun setSrAwayStartMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_AWAY_START_MS, ms).apply()

    fun getSrAwayReason(ctx: Context): String = prefs(ctx).getString(KEY_SR_AWAY_REASON, "অন্যান্য") ?: "অন্যান্য"
    fun setSrAwayReason(ctx: Context, r: String) = prefs(ctx).edit().putString(KEY_SR_AWAY_REASON, r.trim().ifEmpty { "অন্যান্য" }).apply()

    fun getSrLiveWasteReason(ctx: Context): String = prefs(ctx).getString(KEY_SR_LIVE_WASTE_REASON, "অপচয় সময়") ?: "অপচয় সময়"
    fun setSrLiveWasteReason(ctx: Context, r: String) = prefs(ctx).edit().putString(KEY_SR_LIVE_WASTE_REASON, r.trim().ifEmpty { "অপচয় সময়" }).apply()

    fun getWasteBudgetHours(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_WASTE_BUDGET_HRS, 0).coerceIn(0, 12)
    fun setWasteBudgetHours(ctx: Context, h: Int) = prefs(ctx).edit().putInt(KEY_SR_WASTE_BUDGET_HRS, h.coerceIn(0, 12)).apply()

    fun getLastBreakPromptMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_LAST_BREAK_PROMPT_MS, 0L)
    fun setLastBreakPromptMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_LAST_BREAK_PROMPT_MS, ms).apply()

    fun isHelpHintShown(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_HELP_HINT_SHOWN, false)
    fun setHelpHintShown(ctx: Context) = prefs(ctx).edit().putBoolean(KEY_SR_HELP_HINT_SHOWN, true).apply()

    fun getWasteReasonsList(ctx: Context): List<String> {
        val raw = prefs(ctx).getString(KEY_SR_CUSTOM_WASTE_REASONS, "") ?: ""
        if (raw.isBlank()) return ReasonCatalog.DEFAULT_WASTE_REASONS
        return try {
            val arr = JSONArray(raw)
            val out = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val s = arr.optString(i).trim()
                if (s.isNotEmpty() && s !in out) out.add(s)
            }
            if (out.isEmpty()) ReasonCatalog.DEFAULT_WASTE_REASONS else out.take(8)
        } catch (_: Exception) { ReasonCatalog.DEFAULT_WASTE_REASONS }
    }

    fun saveWasteReasonsList(ctx: Context, list: List<String>) {
        val clean = list.map { it.trim() }.filter { it.isNotEmpty() }.distinct().take(8)
        val arr = JSONArray().apply { clean.forEach { put(it) } }
        prefs(ctx).edit().putString(KEY_SR_CUSTOM_WASTE_REASONS, arr.toString()).apply()
    }

    @Synchronized
    fun recordBreakLedger(ctx: Context, startMs: Long, endMs: Long, type: String) {
        if (endMs <= startMs) return
        val cutoff = System.currentTimeMillis() - 48 * 3600_000L
        val entries = getBreakLedger(ctx).filter { it.second >= cutoff }.toMutableList()
        entries.add(Triple(startMs, endMs, type))
        val trimmed = if (entries.size > 40) entries.takeLast(40) else entries
        val arr = JSONArray()
        for ((s, e, t) in trimmed) {
            arr.put(JSONArray().apply { put(s); put(e); put(t) })
        }
        prefs(ctx).edit().putString(KEY_SR_BREAK_LEDGER, arr.toString()).apply()
    }

    fun getBreakLedger(ctx: Context): List<Triple<Long, Long, String>> {
        val raw = prefs(ctx).getString(KEY_SR_BREAK_LEDGER, "") ?: ""
        if (raw.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            val cutoff = System.currentTimeMillis() - 48 * 3600_000L
            val out = mutableListOf<Triple<Long, Long, String>>()
            for (i in 0 until arr.length()) {
                val item = arr.optJSONArray(i) ?: continue
                val s = item.optLong(0, 0L)
                val e = item.optLong(1, 0L)
                val t = item.optString(2, "")
                if (s > 0L && e > s && e >= cutoff) out.add(Triple(s, e, t))
            }
            out
        } catch (_: Exception) { emptyList() }
    }

    fun subtractIntervals(startMs: Long, endMs: Long, excluded: List<Pair<Long, Long>>): List<Pair<Long, Long>> {
        if (endMs <= startMs) return emptyList()
        var current = listOf(startMs to endMs)
        for ((es, ee) in excluded) {
            if (ee <= es) continue
            val next = mutableListOf<Pair<Long, Long>>()
            for ((cs, ce) in current) {
                if (ee <= cs || es >= ce) {
                    next.add(cs to ce)
                } else {
                    if (es > cs) next.add(cs to es)
                    if (ee < ce) next.add(ee to ce)
                }
            }
            current = next
            if (current.isEmpty()) break
        }
        return current
    }

    @Synchronized
    fun addEat(ctx: Context, startMs: Long, endMs: Long) {
        val segments = splitByDay(startMs, endMs)
        if (segments.isEmpty()) return
        val map = loadAllDays(ctx)
        for ((iso, rawSec) in segments) {
            if (rawSec <= 0L) continue
            val rec = map[iso] ?: DayRecord(date = iso, subject = getCurrentSubject(ctx))
            val room = (maxTrackableSecForDay(ctx, iso) - usedSec(rec)).coerceAtLeast(0L)
            val sec = minOf(rawSec, room)
            if (sec <= 0L) continue
            rec.eatSec += sec
            rec.synced = false
            map[iso] = rec
        }
        saveAllDays(ctx, map)
    }

    @Synchronized
    fun addAway(ctx: Context, startMs: Long, endMs: Long, reason: String = "অন্যান্য") {
        val safeReason = reason.trim().ifEmpty { "অন্যান্য" }
        val segments = splitByDay(startMs, endMs)
        if (segments.isEmpty()) return
        val map = loadAllDays(ctx)
        for ((iso, rawSec) in segments) {
            if (rawSec <= 0L) continue
            val rec = map[iso] ?: DayRecord(date = iso, subject = getCurrentSubject(ctx))
            val room = (maxTrackableSecForDay(ctx, iso) - usedSec(rec)).coerceAtLeast(0L)
            val sec = minOf(rawSec, room)
            if (sec <= 0L) continue
            rec.awaySec += sec
            rec.awayReasons[safeReason] = (rec.awayReasons[safeReason] ?: 0L) + sec
            rec.synced = false
            map[iso] = rec
        }
        saveAllDays(ctx, map)
    }

    fun getUntaggedWasteSecToday(ctx: Context): Long {
        val today = getToday(ctx)
        return listOf("অপচয় সময়", "অপচয় সময়", "ফোন চালানো").sumOf { today.wasteReasons[it] ?: 0L }
    }

    /** আজকের অট্যাগড অপচয় ("অপচয় সময়" ও "ফোন চালানো") নির্দিষ্ট কারণে ট্যাগ করে; পূর্বাবস্থার জন্য (কারণ, সেকেন্ড, উৎস) ফেরত দেয়। */
    @Synchronized
    fun tagWaste(ctx: Context, reason: String, maxSeconds: Long = Long.MAX_VALUE): Triple<String, Long, Map<String, Long>>? {
        val cleanReason = reason.trim().ifEmpty { return null }
        val map = loadAllDays(ctx)
        val iso = todayIso()
        val rec = map[iso] ?: return null
        var remaining = maxSeconds.coerceAtLeast(0L)
        val movedFrom = mutableMapOf<String, Long>()
        for (srcKey in listOf("অপচয় সময়", "অপচয় সময়", "ফোন চালানো")) {
            if (remaining <= 0L) break
            val avail = rec.wasteReasons[srcKey] ?: 0L
            if (avail > 0L) {
                val take = minOf(avail, remaining)
                val left = avail - take
                if (left > 0L) rec.wasteReasons[srcKey] = left else rec.wasteReasons.remove(srcKey)
                rec.wasteReasons[cleanReason] = (rec.wasteReasons[cleanReason] ?: 0L) + take
                movedFrom[srcKey] = take
                remaining -= take
            }
        }
        val totalMoved = movedFrom.values.sum()
        if (totalMoved <= 0L) return null
        rec.wasteReason = cleanReason
        rec.synced = false
        map[iso] = rec
        saveAllDays(ctx, map)
        return Triple(cleanReason, totalMoved, movedFrom)
    }

    @Synchronized
    fun undoTagWaste(ctx: Context, reason: String, movedFrom: Map<String, Long>) {
        val map = loadAllDays(ctx)
        val iso = todayIso()
        val rec = map[iso] ?: return
        var totalRestore = 0L
        for ((srcKey, sec) in movedFrom) {
            if (sec <= 0L) continue
            rec.wasteReasons[srcKey] = (rec.wasteReasons[srcKey] ?: 0L) + sec
            totalRestore += sec
        }
        val cur = rec.wasteReasons[reason] ?: 0L
        val left = (cur - totalRestore).coerceAtLeast(0L)
        if (left > 0L) rec.wasteReasons[reason] = left else rec.wasteReasons.remove(reason)
        rec.synced = false
        map[iso] = rec
        saveAllDays(ctx, map)
    }

    // v9.6: প্রোফাইল কর্নার ও সিরিয়াস মোড
    private const val KEY_PROF_NICKNAME = "prof_nickname"
    private const val KEY_PROF_DOB_ISO = "prof_dob_iso"
    private const val KEY_PROF_GENDER = "prof_gender"
    private const val KEY_PROF_STATUS = "prof_status"
    private const val KEY_PROF_CADRE = "prof_target_cadre"
    private const val KEY_PROF_TARGET_YEAR = "prof_target_year"
    private const val KEY_PROF_MAX_AGE = "prof_max_age"

    private const val KEY_SR_SERIOUS_MODE = "sr_serious_mode"
    private const val KEY_SR_SERIOUS_COUNT = "sr_serious_daily_count"
    private const val KEY_SR_SERIOUS_DATE = "sr_serious_count_date"
    private const val KEY_SR_SERIOUS_HR_WIN = "sr_serious_hr_win"
    private const val KEY_SR_SERIOUS_HR_CNT = "sr_serious_hr_cnt"
    private const val KEY_SR_SERIOUS_MAX_HR = "sr_serious_max_hr"
    private const val KEY_SR_SERIOUS_AFTER_MIN = "sr_serious_after_min"

    fun getProfNickname(ctx: Context): String = prefs(ctx).getString(KEY_PROF_NICKNAME, "") ?: ""
    fun setProfNickname(ctx: Context, v: String) = prefs(ctx).edit().putString(KEY_PROF_NICKNAME, v.trim()).apply()

    fun getProfDobIso(ctx: Context): String = prefs(ctx).getString(KEY_PROF_DOB_ISO, "") ?: ""
    fun setProfDobIso(ctx: Context, v: String) = prefs(ctx).edit().putString(KEY_PROF_DOB_ISO, v.trim()).apply()

    fun getProfGender(ctx: Context): String = prefs(ctx).getString(KEY_PROF_GENDER, "") ?: ""
    fun setProfGender(ctx: Context, v: String) = prefs(ctx).edit().putString(KEY_PROF_GENDER, v.trim()).apply()

    fun getProfStatus(ctx: Context): String = prefs(ctx).getString(KEY_PROF_STATUS, "ছাত্র") ?: "ছাত্র"
    fun setProfStatus(ctx: Context, v: String) = prefs(ctx).edit().putString(KEY_PROF_STATUS, v.trim()).apply()

    fun getProfCadre(ctx: Context): String = prefs(ctx).getString(KEY_PROF_CADRE, "BCS ক্যাডার") ?: "BCS ক্যাডার"
    fun setProfCadre(ctx: Context, v: String) = prefs(ctx).edit().putString(KEY_PROF_CADRE, v.trim()).apply()

    fun getProfTargetYear(ctx: Context): String = prefs(ctx).getString(KEY_PROF_TARGET_YEAR, "২০২৭") ?: "২০২৭"
    fun setProfTargetYear(ctx: Context, v: String) = prefs(ctx).edit().putString(KEY_PROF_TARGET_YEAR, v.trim()).apply()

    fun getProfMaxAge(ctx: Context): Int = prefs(ctx).getInt(KEY_PROF_MAX_AGE, 32).coerceIn(25, 45)
    fun setProfMaxAge(ctx: Context, age: Int) = prefs(ctx).edit().putInt(KEY_PROF_MAX_AGE, age.coerceIn(25, 45)).apply()

    fun computeProfileAgeAndRemaining(ctx: Context): Pair<Int, String>? {
        val dobStr = getProfDobIso(ctx)
        if (!isValidIsoDate(dobStr)) return null
        return try {
            val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val dob = Calendar.getInstance().apply { time = fmt.parse(dobStr)!! }
            val now = Calendar.getInstance()
            var ageY = now.get(Calendar.YEAR) - dob.get(Calendar.YEAR)
            if (now.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)) ageY--
            val maxAge = getProfMaxAge(ctx)
            val limitCal = (dob.clone() as Calendar).apply { add(Calendar.YEAR, maxAge) }
            if (now.after(limitCal)) return Pair(ageY.coerceAtLeast(0), "সীমা শেষ")
            var remY = limitCal.get(Calendar.YEAR) - now.get(Calendar.YEAR)
            var remM = limitCal.get(Calendar.MONTH) - now.get(Calendar.MONTH)
            if (limitCal.get(Calendar.DAY_OF_MONTH) < now.get(Calendar.DAY_OF_MONTH)) remM--
            if (remM < 0) { remY--; remM += 12 }
            val remTxt = when {
                remY > 0 && remM > 0 -> "${toBnDigits(remY)} বছর ${toBnDigits(remM)} মাস"
                remY > 0 -> "${toBnDigits(remY)} বছর"
                else -> "${toBnDigits(remM.coerceAtLeast(0))} মাস"
            }
            Pair(ageY.coerceAtLeast(0), remTxt)
        } catch (_: Exception) { null }
    }

    fun isSrSeriousMode(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_SERIOUS_MODE, false)
    fun setSrSeriousMode(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_SERIOUS_MODE, on).apply()

    fun getSrSeriousMaxPerHour(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_SERIOUS_MAX_HR, 4).coerceIn(0, 30)
    fun setSrSeriousMaxPerHour(ctx: Context, v: Int) = prefs(ctx).edit().putInt(KEY_SR_SERIOUS_MAX_HR, v.coerceIn(0, 30)).apply()

    fun getSrSeriousAfterMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_SERIOUS_AFTER_MIN, 30).coerceIn(0, 360)
    fun setSrSeriousAfterMin(ctx: Context, v: Int) = prefs(ctx).edit().putInt(KEY_SR_SERIOUS_AFTER_MIN, v.coerceIn(0, 360)).apply()

    fun getSrSeriousDailyCount(ctx: Context): Int {
        val today = todayIso()
        return if (prefs(ctx).getString(KEY_SR_SERIOUS_DATE, "") == today) prefs(ctx).getInt(KEY_SR_SERIOUS_COUNT, 0) else 0
    }

    fun recordSeriousDailyExtreme(ctx: Context): Int {
        val today = todayIso()
        val next = getSrSeriousDailyCount(ctx) + 1
        prefs(ctx).edit()
            .putString(KEY_SR_SERIOUS_DATE, today)
            .putInt(KEY_SR_SERIOUS_COUNT, next)
            .apply()
        return next
    }

    fun recordSeriousHourlyFire(ctx: Context) {
        val hrWin = System.currentTimeMillis() / 3_600_000L
        val prevWin = prefs(ctx).getLong(KEY_SR_SERIOUS_HR_WIN, -1L)
        val hrCnt = if (prevWin == hrWin) prefs(ctx).getInt(KEY_SR_SERIOUS_HR_CNT, 0) + 1 else 1
        prefs(ctx).edit()
            .putLong(KEY_SR_SERIOUS_HR_WIN, hrWin)
            .putInt(KEY_SR_SERIOUS_HR_CNT, hrCnt)
            .apply()
    }

    fun recordSeriousTrigger(ctx: Context): Int {
        val next = recordSeriousDailyExtreme(ctx)
        recordSeriousHourlyFire(ctx)
        return next
    }

    fun canFireSeriousHourly(ctx: Context): Boolean {
        val cap = getSrSeriousMaxPerHour(ctx)
        if (cap <= 0) return true
        val hrWin = System.currentTimeMillis() / 3_600_000L
        val prevWin = prefs(ctx).getLong(KEY_SR_SERIOUS_HR_WIN, -1L)
        return prevWin != hrWin || prefs(ctx).getInt(KEY_SR_SERIOUS_HR_CNT, 0) < cap
    }

    fun resetSeriousDailyCount(ctx: Context) {
        prefs(ctx).edit().putInt(KEY_SR_SERIOUS_COUNT, 0).apply()
    }

    // v9.7: অজানা গ্যাপ তালিকা, শ্রেণিবিন্যাস ও রাতের রিমাইন্ডার স্টেট
    private const val KEY_SR_GAPS_JSON = "sr_gaps_json"
    private const val KEY_SR_GAP_PHONE_MIN = "sr_gap_phone_min"
    private const val KEY_SR_GAP_SHEET_LAST_MS = "sr_gap_sheet_last_ms"
    private const val KEY_SR_GAP_SESSION_SHOWN = "sr_gap_session_shown"
    private const val KEY_SR_NIGHT_GAP_DATE = "sr_night_gap_date"

    fun getGapPhoneMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_GAP_PHONE_MIN, 5).coerceIn(3, 15)
    fun setGapPhoneMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_GAP_PHONE_MIN, min.coerceIn(3, 15)).apply()

    fun getLastGapSheetMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_GAP_SHEET_LAST_MS, 0L)
    fun setLastGapSheetMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_GAP_SHEET_LAST_MS, ms).apply()

    fun isGapPromptedInSession(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_GAP_SESSION_SHOWN, false)
    fun setGapPromptedInSession(ctx: Context, shown: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_GAP_SESSION_SHOWN, shown).apply()

    fun getNightGapNotifiedDate(ctx: Context): String = prefs(ctx).getString(KEY_SR_NIGHT_GAP_DATE, "") ?: ""
    fun setNightGapNotifiedDate(ctx: Context, d: String) = prefs(ctx).edit().putString(KEY_SR_NIGHT_GAP_DATE, d).apply()

    @Synchronized
    fun loadGaps(ctx: Context): MutableList<GapRecord> {
        val raw = prefs(ctx).getString(KEY_SR_GAPS_JSON, "") ?: ""
        if (raw.isBlank()) return mutableListOf()
        val cutoff = System.currentTimeMillis() - 7L * 86_400_000L
        return try {
            val arr = JSONArray(raw)
            val out = mutableListOf<GapRecord>()
            for (i in 0 until arr.length()) {
                val g = GapRecord.fromJson(arr.getJSONObject(i))
                if (g.endMs > g.startMs && g.endMs >= cutoff) out.add(g)
            }
            out
        } catch (_: Exception) { mutableListOf() }
    }

    @Synchronized
    fun saveGaps(ctx: Context, list: List<GapRecord>) {
        val trimmed = if (list.size > 40) list.takeLast(40) else list
        val arr = JSONArray().apply { trimmed.forEach { put(it.toJson()) } }
        prefs(ctx).edit().putString(KEY_SR_GAPS_JSON, arr.toString()).apply()
    }

    @Synchronized
    fun addPendingGap(ctx: Context, startMs: Long, endMs: Long) {
        if (endMs - startMs < 20 * 60_000L) return
        val list = loadGaps(ctx)
        val mergeTolMs = 10 * 60_000L
        val ledger = getBreakLedger(ctx)
        val match = list.firstOrNull { g ->
            if (g.status != "UNKNOWN") return@firstOrNull false
            if (startMs > g.endMs + mergeTolMs || endMs < g.startMs - mergeTolMs) return@firstOrNull false
            val bridgeStart = minOf(g.endMs, endMs)
            val bridgeEnd = maxOf(g.startMs, startMs)
            val hasActivityBetween = bridgeEnd > bridgeStart && ledger.any { (ls, le, _) ->
                le > bridgeStart && ls < bridgeEnd
            }
            !hasActivityBetween
        }
        if (match != null) {
            val mergedStart = minOf(match.startMs, startMs)
            val mergedEnd = maxOf(match.endMs, endMs)
            list.remove(match)
            list.add(GapRecord("g_${mergedStart}_${mergedEnd}", mergedStart, mergedEnd, status = "UNKNOWN", snoozeUntilMs = match.snoozeUntilMs))
            saveGaps(ctx, list)
            return
        }
        val id = "g_${startMs}_${endMs}"
        list.add(GapRecord(id, startMs, endMs, status = "UNKNOWN"))
        saveGaps(ctx, list)
    }

    fun getUnansweredGaps(ctx: Context): List<GapRecord> {
        val now = System.currentTimeMillis()
        val cutoff72h = now - 72L * 3_600_000L
        return loadGaps(ctx)
            .filter { it.status == "UNKNOWN" && it.durationMin() >= 20 && it.endMs >= cutoff72h && it.snoozeUntilMs <= now }
            .sortedByDescending { it.endMs }
    }

    @Synchronized
    fun snoozeGap(ctx: Context, gapId: String, untilMs: Long) {
        val list = loadGaps(ctx)
        val g = list.firstOrNull { it.id == gapId } ?: return
        g.snoozeUntilMs = untilMs
        saveGaps(ctx, list)
        try { (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).cancel(5451) } catch (_: Exception) {}
    }

    @Synchronized
    fun deferGap(ctx: Context, gapId: String) {
        val list = loadGaps(ctx)
        val g = list.firstOrNull { it.id == gapId } ?: return
        g.status = "DEFERRED"
        saveGaps(ctx, list)
        try { (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).cancel(5451) } catch (_: Exception) {}
    }

    fun formatGapWindowBn(startMs: Long, endMs: Long): String {
        val fmt = SimpleDateFormat("hh:mm a", Locale.US)
        val s = toBnDigits(fmt.format(Date(startMs)))
        val e = toBnDigits(fmt.format(Date(endMs)))
        val dur = MascotContent.formatDurationBn(((endMs - startMs) / 60_000L).toInt().coerceAtLeast(1))
        return "$s – $e ($dur)"
    }

    fun applyToCategory(ctx: Context, rec: DayRecord, category: String, sec: Long, note: String = "") {
        if (sec <= 0L) return
        when (category) {
            "STUDY" -> {
                rec.studySec += sec
                checkAndNotifyDailyGoalReached(ctx, rec)
                rec.manualSec += sec
                val sub = note.trim().ifEmpty { getCurrentSubject(ctx) }
                rec.subjects[sub] = (rec.subjects[sub] ?: 0L) + sec
            }
            "AWAY" -> {
                rec.awaySec += sec
                val r = note.trim().ifEmpty { "বাইরে যাওয়া" }
                rec.awayReasons[r] = (rec.awayReasons[r] ?: 0L) + sec
            }
            "EAT" -> rec.eatSec += sec
            "WASTE" -> {
                rec.wasteSec += sec
                val r = note.trim().ifEmpty { "কারণ ঠিক করা হয়নি" }
                rec.wasteReasons[r] = (rec.wasteReasons[r] ?: 0L) + sec
            }
            "SLEEP" -> rec.sleepOtherSec += sec
            else -> rec.otherSec += sec
        }
        rec.synced = false
    }

    fun getLatestReclassifiableUnassigned(ctx: Context): Pair<String, Long>? {
        val map = loadAllDays(ctx)
        val today = todayIso()
        val todayRec = map[today]
        if (todayRec != null && todayRec.unassignedSec >= 60L) return today to todayRec.unassignedSec
        val cutoffIso = dayIsoOf(System.currentTimeMillis() - 72L * 3_600_000L)
        return map.values
            .filter { it.date >= cutoffIso && it.unassignedSec >= 60L }
            .maxByOrNull { it.date }
            ?.let { it.date to it.unassignedSec }
    }

    @Synchronized
    fun reclassifyUnassignedForDay(ctx: Context, iso: String, category: String, note: String = "", amountSec: Long = Long.MAX_VALUE): Long {
        val map = loadAllDays(ctx)
        val rec = map[iso] ?: return 0L
        val avail = rec.unassignedSec
        val moved = minOf(avail, amountSec).coerceAtLeast(0L)
        if (moved <= 0L) return 0L
        rec.unassignedSec = (rec.unassignedSec - moved).coerceAtLeast(0L)
        applyToCategory(ctx, rec, category, moved, note)
        map[iso] = rec
        saveAllDays(ctx, map)
        return moved
    }

    @Synchronized
    fun reclassifyUnassignedToday(ctx: Context, category: String, note: String = "", amountSec: Long = Long.MAX_VALUE): Long =
        reclassifyUnassignedForDay(ctx, todayIso(), category, note, amountSec)

    @Synchronized
    fun autoFinalizeExpiredUnassignedAndGaps(ctx: Context): Int {
        var count = 0
        val now = System.currentTimeMillis()
        val cutoff72h = now - 72L * 3_600_000L
        val cutoffIso = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(cutoff72h))

        val map = loadAllDays(ctx)
        var mapDirty = false
        for ((iso, rec) in map) {
            if (iso < cutoffIso && rec.unassignedSec > 0L) {
                val sec = rec.unassignedSec
                rec.unassignedSec = 0L
                applyToCategory(ctx, rec, "WASTE", sec, "কারণ ঠিক করা হয়নি")
                map[iso] = rec
                mapDirty = true
                count++
            }
        }
        if (mapDirty) saveAllDays(ctx, map)

        val oldGaps = loadGaps(ctx).filter { (it.status == "UNKNOWN" || it.status == "DEFERRED") && it.endMs < cutoff72h }
        for (g in oldGaps) {
            if (classifyGap(ctx, g.id, "WASTE", "কারণ ঠিক করা হয়নি")) count++
        }
        return count
    }

    @Synchronized
    fun classifyGap(ctx: Context, gapId: String, category: String, note: String = ""): Boolean {
        val list = loadGaps(ctx)
        val g = list.firstOrNull { it.id == gapId } ?: return false
        if (g.status == "CONFIRMED") return false
        val segs = splitByDay(g.startMs, g.endMs)
        val map = loadAllDays(ctx)
        var totalAdded = 0L
        for ((iso, rawSec) in segs) {
            if (rawSec <= 0L) continue
            val rec = map[iso] ?: DayRecord(date = iso, subject = getCurrentSubject(ctx))
            val room = (maxTrackableSecForDay(ctx, iso) - usedSec(rec)).coerceAtLeast(0L)
            val sec = minOf(rawSec, room)
            if (sec <= 0L) continue
            applyToCategory(ctx, rec, category, sec, note)
            map[iso] = rec
            totalAdded += sec
        }
        if (totalAdded > 0L) saveAllDays(ctx, map)
        recordBreakLedger(ctx, g.startMs, g.endMs, category)
        g.status = "CONFIRMED"
        g.category = category
        g.note = note.trim()
        saveGaps(ctx, list)
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            nm.cancel(5451)
        } catch (_: Exception) {}
        return true
    }

    // v9.8 + v9.13: গ্যাপ ও পপআপের ৪টি স্বাধীন অপশনাল সুইচ + দৈনিক সীমা
    private const val KEY_GAP_APP_SHEET_ON = "sr_gap_app_sheet_on"
    private const val KEY_GAP_PHONE_POPUP_ON = "sr_gap_phone_popup_on"
    private const val KEY_GAP_NIGHT_NOTIF_ON = "sr_gap_night_notif_on"
    private const val KEY_GAP_AUTO_SLEEP_ON = "sr_gap_auto_sleep_on"
    private const val KEY_GAP_SHEET_LAST_DATE = "sr_gap_sheet_last_date"
    private const val KEY_GAP_POPUP_LAST_DATE = "sr_gap_popup_last_date"
    private const val KEY_GAP_POPUP_MIGRATED_V913 = "sr_gap_popup_migrated_v913"

    fun ensureGapPhonePopupDefaultOffOnce(ctx: Context) {
        if (!prefs(ctx).getBoolean(KEY_GAP_POPUP_MIGRATED_V913, false)) {
            prefs(ctx).edit()
                .putBoolean(KEY_GAP_PHONE_POPUP_ON, false)
                .putBoolean(KEY_GAP_POPUP_MIGRATED_V913, true)
                .apply()
        }
    }

    fun getLastGapSheetDate(ctx: Context): String = prefs(ctx).getString(KEY_GAP_SHEET_LAST_DATE, "") ?: ""
    fun setLastGapSheetDate(ctx: Context, iso: String) = prefs(ctx).edit().putString(KEY_GAP_SHEET_LAST_DATE, iso).apply()

    fun getLastGapPopupDate(ctx: Context): String = prefs(ctx).getString(KEY_GAP_POPUP_LAST_DATE, "") ?: ""
    fun setLastGapPopupDate(ctx: Context, iso: String) = prefs(ctx).edit().putString(KEY_GAP_POPUP_LAST_DATE, iso).apply()

    fun isGapAppSheetOn(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_GAP_APP_SHEET_ON, true)
    fun setGapAppSheetOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_GAP_APP_SHEET_ON, on).apply()

    fun isGapPhonePopupOn(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_GAP_PHONE_POPUP_ON, false)
    fun setGapPhonePopupOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_GAP_PHONE_POPUP_ON, on).apply()

    fun isGapNightNotifOn(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_GAP_NIGHT_NOTIF_ON, true)
    fun setGapNightNotifOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_GAP_NIGHT_NOTIF_ON, on).apply()

    fun isGapAutoSleepOn(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_GAP_AUTO_SLEEP_ON, true)
    fun setGapAutoSleepOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_GAP_AUTO_SLEEP_ON, on).apply()

    fun getItemDailyBreakdown(
        ctx: Context,
        kind: String,
        key: String,
        startIso: String,
        endIso: String
    ): List<Pair<String, Long>> {
        val all = getAllDaysMerged(ctx)
        val out = mutableListOf<Pair<String, Long>>()
        for (d in all.values) {
            if (d.date < startIso || d.date > endIso) continue
            val sec = when (kind) {
                "SUBJECT" -> d.subjects[key] ?: 0L
                "WASTE" -> d.wasteSec + d.awaySec
                "WASTE_REASON" -> d.wasteReasons[key] ?: 0L
                "EAT" -> d.eatSec
                "AWAY" -> d.awaySec
                "AWAY_REASON" -> d.awayReasons[key] ?: 0L
                "SLEEP" -> d.sleepOtherSec
                "OTHER" -> d.otherSec
                "UNASSIGNED" -> d.unassignedSec + pendingUnassignedGapSecForDay(ctx, d.date)
                else -> 0L
            }
            if (sec > 0L) out.add(d.date to sec)
        }
        return out.sortedByDescending { it.first }
    }

    fun formatFullDateBn(iso: String): String {
        val parts = iso.split("-")
        if (parts.size != 3) return toBnDigits(iso)
        val months = arrayOf("জানু", "ফেব্রু", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টে", "অক্টো", "নভে", "ডিসে")
        val y = parts[0]
        val m = parts[1].toIntOrNull()?.coerceIn(1, 12) ?: 1
        val d = parts[2].toIntOrNull() ?: 1
        return "${toBnDigits(d)} ${months[m - 1]} ${toBnDigits(y)}"
    }

    // v9.14: ১-সংখ্যার সহমৌলিক নন-রিপিটিং মেসেজ কার্সার ও সিড (কোনো হিস্টোরি লিস্ট ছাড়াই ৩৬৫+ দিন শূন্য রিপিট)
    private const val KEY_MSG_PERM_SEED = "sr_msg_perm_seed_v1"

    fun getOrInitMsgSeed(ctx: Context): Long {
        val p = prefs(ctx)
        val existing = p.getLong(KEY_MSG_PERM_SEED, -1L)
        if (existing >= 0L) return existing
        val fresh = (System.currentTimeMillis() xor 0x5DEECE66DL).let { if (it < 0) -it else it } % 999_983L
        p.edit().putLong(KEY_MSG_PERM_SEED, fresh).apply()
        return fresh
    }

    @Synchronized
    fun nextMsgCursor(ctx: Context, catKey: String): Long {
        val k = "sr_msg_cur_$catKey"
        val cur = prefs(ctx).getLong(k, 0L)
        prefs(ctx).edit().putLong(k, cur + 1L).apply()
        return cur
    }

    // v9.15: দৈনিক আনুমানিক ব্যাটারি খরচ (অ্যাপ/সেশন চলাকালীন ড্রপ %)
    private const val KEY_BATT_DATE = "app_batt_drop_date"
    private const val KEY_BATT_DROP_PCT = "app_batt_drop_pct"
    private const val KEY_BATT_LAST_PCT = "app_batt_last_pct"

    fun getTodayBatteryDropPct(ctx: Context): Int {
        val today = todayIso()
        return if (prefs(ctx).getString(KEY_BATT_DATE, "") == today) prefs(ctx).getInt(KEY_BATT_DROP_PCT, 0) else 0
    }

    fun sampleBatteryDrop(ctx: Context) {
        try {
            val intent = ctx.applicationContext.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED)) ?: return
            val level = intent.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100)
            val status = intent.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1)
            if (level < 0 || scale <= 0) return
            val pct = (level * 100) / scale
            val isCharging = status == android.os.BatteryManager.BATTERY_STATUS_CHARGING || status == android.os.BatteryManager.BATTERY_STATUS_FULL
            val p = prefs(ctx)
            val today = todayIso()
            val savedDate = p.getString(KEY_BATT_DATE, "") ?: ""
            val prevPct = p.getInt(KEY_BATT_LAST_PCT, -1)
            var drop = if (savedDate == today) p.getInt(KEY_BATT_DROP_PCT, 0) else 0
            if (!isCharging && savedDate == today && prevPct > pct && (prevPct - pct) <= 10) {
                drop += (prevPct - pct)
            }
            p.edit()
                .putString(KEY_BATT_DATE, today)
                .putInt(KEY_BATT_DROP_PCT, drop)
                .putInt(KEY_BATT_LAST_PCT, pct)
                .apply()
        } catch (_: Exception) {}
    }

    private fun isNextCalendarDay(prevIso: String, curIso: String): Boolean {
        return try {
            val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val c = Calendar.getInstance().apply {
                time = fmt.parse(prevIso) ?: return false
                add(Calendar.DAY_OF_YEAR, 1)
            }
            fmt.format(c.time) == curIso
        } catch (_: Exception) { false }
    }

    // v9.22: হালকা হ্যাপটিক ফিডব্যাক সেটিংস
    private const val KEY_HAPTIC_GLOBAL_ON = "haptic_global_on"
    private const val KEY_HAPTIC_INTENSITY = "haptic_intensity" // 0=বন্ধ, 1=খুব হালকা, 2=হালকা, 3=স্বাভাবিক
    private const val KEY_HAPTIC_FLIP_ON = "haptic_flip_on"
    private const val KEY_HAPTIC_GOAL_ON = "haptic_goal_on"

    fun isHapticGlobalOn(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_HAPTIC_GLOBAL_ON, true)
    fun setHapticGlobalOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_HAPTIC_GLOBAL_ON, on).apply()

    fun getHapticIntensity(ctx: Context): Int {
        val p = prefs(ctx)
        if (!p.getBoolean("haptic_migrated_v38", false)) {
            val cur = p.getInt(KEY_HAPTIC_INTENSITY, 3)
            p.edit().putBoolean("haptic_migrated_v38", true).putInt(KEY_HAPTIC_INTENSITY, if (cur == 1) 3 else cur).apply()
        }
        return p.getInt(KEY_HAPTIC_INTENSITY, 3).coerceIn(0, 3)
    }
    fun setHapticIntensity(ctx: Context, v: Int) = prefs(ctx).edit().putInt(KEY_HAPTIC_INTENSITY, v.coerceIn(0, 3)).apply()

    fun isHapticFlipOn(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_HAPTIC_FLIP_ON, true)
    fun setHapticFlipOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_HAPTIC_FLIP_ON, on).apply()

    fun isHapticGoalOn(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_HAPTIC_GOAL_ON, true)
    fun setHapticGoalOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_HAPTIC_GOAL_ON, on).apply()

    private const val KEY_LAST_ALARM_START_MS = "last_alarm_committed_start_ms"
    fun getLastAlarmCommittedStartMs(ctx: Context): Long = prefs(ctx).getLong(KEY_LAST_ALARM_START_MS, 0L)
    fun setLastAlarmCommittedStartMs(ctx: Context, startMs: Long) {
        prefs(ctx).edit().putLong(KEY_LAST_ALARM_START_MS, startMs).apply()
    }

    private const val KEY_MSG_HIST_SIGS = "msg_hist_sigs_v1"
    private const val KEY_MSG_HIST_LEADS = "msg_hist_leads_v1"

    fun isRecentMsgOrLead(ctx: Context, sig: String, lead: String): Boolean {
        val p = prefs(ctx)
        val sigs = (p.getString(KEY_MSG_HIST_SIGS, "") ?: "").split("|~|").filter { it.isNotEmpty() }
        if (sig.isNotEmpty() && sig in sigs) return true
        val leads = (p.getString(KEY_MSG_HIST_LEADS, "") ?: "").split("|~|").filter { it.isNotEmpty() }
        if (lead.isNotEmpty() && lead in leads) return true
        return false
    }

    fun recordMsgHistory(ctx: Context, sig: String, lead: String) {
        val p = prefs(ctx)
        val sigs = (p.getString(KEY_MSG_HIST_SIGS, "") ?: "").split("|~|").filter { it.isNotEmpty() }.toMutableList()
        if (sig.isNotEmpty()) {
            sigs.remove(sig)
            sigs.add(sig)
            while (sigs.size > 28) sigs.removeAt(0)
        }
        val leads = (p.getString(KEY_MSG_HIST_LEADS, "") ?: "").split("|~|").filter { it.isNotEmpty() }.toMutableList()
        if (lead.isNotEmpty()) {
            leads.remove(lead)
            leads.add(lead)
            while (leads.size > 3) leads.removeAt(0)
        }
        p.edit()
            .putString(KEY_MSG_HIST_SIGS, sigs.joinToString("|~|"))
            .putString(KEY_MSG_HIST_LEADS, leads.joinToString("|~|"))
            .apply()
    }

    private const val KEY_SR_POPUP_STYLE = "sr_popup_style"
    fun getSrPopupStyle(ctx: Context): String = prefs(ctx).getString(KEY_SR_POPUP_STYLE, "default") ?: "default"
    fun setSrPopupStyle(ctx: Context, style: String) {
        val safe = if (style in listOf("default", "compact", "standard", "focus")) style else "default"
        prefs(ctx).edit().putString(KEY_SR_POPUP_STYLE, safe).apply()
    }

    private const val K_BCS_P_DAY = "bcs_alloc_prompt_day_iso"
    private const val K_BCS_P_CNT = "bcs_alloc_prompt_count"
    private const val K_BCS_P_MS = "bcs_alloc_prompt_last_ms"
    private const val K_BCS_N_DAY = "bcs_alloc_notif_day_iso"

    fun canPromptBcsAlloc(ctx: Context): Boolean {
        val p = prefs(ctx)
        if (p.getString(K_BCS_P_DAY, "") != todayIso()) return true
        val cnt = p.getInt(K_BCS_P_CNT, 0)
        val gap = System.currentTimeMillis() - p.getLong(K_BCS_P_MS, 0L)
        return cnt < 2 && gap >= 3L * 3600_000L
    }

    fun markBcsAllocPrompted(ctx: Context) {
        val p = prefs(ctx)
        val cnt = if (p.getString(K_BCS_P_DAY, "") == todayIso()) p.getInt(K_BCS_P_CNT, 0) else 0
        p.edit()
            .putString(K_BCS_P_DAY, todayIso())
            .putInt(K_BCS_P_CNT, cnt + 1)
            .putLong(K_BCS_P_MS, System.currentTimeMillis())
            .apply()
    }

    fun getBcsAllocNotifDay(ctx: Context): String = prefs(ctx).getString(K_BCS_N_DAY, "") ?: ""
    fun setBcsAllocNotifDay(ctx: Context, d: String) = prefs(ctx).edit().putString(K_BCS_N_DAY, d).apply()

    private const val KEY_STUDY_SESSION_LOG = "study_session_log_14d"

    data class MergedStudyBlock(
        val startMs: Long,
        val endMs: Long,
        val actualStudySec: Long,
        val sessionIds: List<Long>
    )

    @Synchronized
    fun recordStudySessionLog(ctx: Context, startMs: Long, endMs: Long, subject: String) {
        if (endMs <= startMs || (endMs - startMs) < 30_000L) return
        val cutoff = System.currentTimeMillis() - 14L * 86_400_000L
        val raw = prefs(ctx).getString(KEY_STUDY_SESSION_LOG, "") ?: ""
        val kept = JSONArray()
        if (raw.isNotBlank()) {
            try {
                val arr = JSONArray(raw)
                val startIdx = (arr.length() - 299).coerceAtLeast(0)
                for (i in startIdx until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    if (o.optLong("e", 0L) >= cutoff) kept.put(o)
                }
            } catch (_: Exception) {}
        }
        kept.put(JSONObject().apply {
            put("id", startMs)
            put("s", startMs)
            put("e", endMs)
            put("sub", subject)
            put("alloc", false)
        })
        prefs(ctx).edit().putString(KEY_STUDY_SESSION_LOG, kept.toString()).apply()
    }

    /** নির্দিষ্ট দিনের অ-অ্যালোকেটেড "BCS প্রস্তুতি" সেশনগুলো (<১৫ মি. ফাঁক জুড়ে) ব্লক আকারে ফেরত দেয়। */
    fun getMergedStudyBlocksForDay(ctx: Context, iso: String): List<MergedStudyBlock> {
        val startBound = dayStartMs(iso)
        val endBound = dayEndMs(iso)
        val raw = prefs(ctx).getString(KEY_STUDY_SESSION_LOG, "") ?: ""
        val items = mutableListOf<Triple<Long, Long, Long>>() // (id, start, end)
        if (raw.isNotBlank()) {
            try {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    if (o.optBoolean("alloc", false)) continue
                    val sub = o.optString("sub", "")
                    if (sub.isNotEmpty() && sub != "BCS প্রস্তুতি") continue
                    val s = o.optLong("s", 0L)
                    val e = o.optLong("e", 0L)
                    if (e > startBound && s < endBound) {
                        val cs = maxOf(s, startBound)
                        val ce = minOf(e, endBound)
                        if (ce - cs >= 60_000L) items.add(Triple(o.optLong("id", s), cs, ce))
                    }
                }
            } catch (_: Exception) {}
        }
        // পুরোনো সেশনের জন্য BreakLedger ফলব্যাক
        if (items.isEmpty()) {
            for (t in getBreakLedger(ctx)) {
                if (t.third == "STUDY" && t.second > startBound && t.first < endBound) {
                    val cs = maxOf(t.first, startBound)
                    val ce = minOf(t.second, endBound)
                    if (ce - cs >= 60_000L) items.add(Triple(cs, cs, ce))
                }
            }
        }
        if (items.isEmpty()) return emptyList()
        items.sortBy { it.second }

        val gapMergeMs = 15L * 60_000L
        val blocks = mutableListOf<MergedStudyBlock>()
        var bStart = items[0].second
        var bEnd = items[0].third
        var bStudySec = ((bEnd - bStart) / 1000L).coerceAtLeast(60L)
        var bIds = mutableListOf(items[0].first)

        for (i in 1 until items.size) {
            val (id, s, e) = items[i]
            val segSec = ((e - s) / 1000L).coerceAtLeast(60L)
            if (s - bEnd < gapMergeMs) {
                if (e > bEnd) bEnd = e
                bStudySec += segSec
                bIds.add(id)
            } else {
                blocks.add(MergedStudyBlock(bStart, bEnd, bStudySec, bIds))
                bStart = s
                bEnd = e
                bStudySec = segSec
                bIds = mutableListOf(id)
            }
        }
        blocks.add(MergedStudyBlock(bStart, bEnd, bStudySec, bIds))
        return blocks
    }

    @Synchronized
    private fun markStudySessionsAllocated(ctx: Context, ids: Set<Long>, markAllForIso: String? = null) {
        val raw = prefs(ctx).getString(KEY_STUDY_SESSION_LOG, "") ?: ""
        if (raw.isBlank()) return
        try {
            val arr = JSONArray(raw)
            val sBound = markAllForIso?.let { dayStartMs(it) } ?: Long.MAX_VALUE
            val eBound = markAllForIso?.let { dayEndMs(it) } ?: Long.MIN_VALUE
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optLong("id", 0L)
                val s = o.optLong("s", 0L)
                val e = o.optLong("e", 0L)
                if (id in ids || (markAllForIso != null && e > sBound && s < eBound && o.optString("sub", "") == "BCS প্রস্তুতি")) {
                    o.put("alloc", true)
                }
            }
            prefs(ctx).edit().putString(KEY_STUDY_SESSION_LOG, arr.toString()).apply()
        } catch (_: Exception) {}
    }

    /** নির্দিষ্ট দিনের "BCS প্রস্তুতি" সময়কে নির্বাচিত বিষয়গুলোতে ভাগ/স্থানান্তর করে। */
    @Synchronized
    fun allocateBcsSubjectForDay(
        ctx: Context,
        iso: String,
        allocations: Map<String, Long>,
        allocatedSessionIds: Set<Long> = emptySet()
    ): Long {
        val map = loadAllDays(ctx)
        val rec = map[iso] ?: return 0L
        val available = rec.subjects["BCS প্রস্তুতি"] ?: 0L
        if (available <= 0L) return 0L

        var remaining = available
        var movedTotal = 0L
        var lastTarget = ""
        for ((rawTarget, rawSec) in allocations) {
            val target = rawTarget.trim()
            if (target.isEmpty() || target == "BCS প্রস্তুতি" || rawSec <= 0L || remaining <= 0L) continue
            val take = minOf(rawSec, remaining)
            rec.subjects[target] = (rec.subjects[target] ?: 0L) + take
            remaining -= take
            movedTotal += take
            lastTarget = target
        }
        if (movedTotal <= 0L) return 0L
        if (remaining <= 0L) {
            rec.subjects.remove("BCS প্রস্তুতি")
            markStudySessionsAllocated(ctx, allocatedSessionIds, markAllForIso = iso)
            if (iso == todayIso() && lastTarget.isNotEmpty() && getCurrentSubject(ctx) == "BCS প্রস্তুতি") {
                setCurrentSubject(ctx, lastTarget)
            }
        } else {
            rec.subjects["BCS প্রস্তুতি"] = remaining
            if (allocatedSessionIds.isNotEmpty()) markStudySessionsAllocated(ctx, allocatedSessionIds)
        }
        if (lastTarget.isNotEmpty()) rec.subject = lastTarget
        rec.synced = false
        map[iso] = rec
        saveAllDays(ctx, map)
        return movedTotal
    }

    private const val KEY_SR_EAT_MID_MIN = "sr_eat_mid_min"
    private const val KEY_SR_EAT_END_NOTIF = "sr_eat_end_notif"
    private const val KEY_SR_EAT_CARRY_MAX = "sr_eat_carry_max"
    private const val KEY_SR_EAT_SCR_ACCUM = "sr_eat_scr_accum_ms"
    private const val KEY_SR_EAT_SCR_SEG = "sr_eat_scr_seg_ms"
    private const val KEY_SR_EAT_CARRY_MIN = "sr_eat_carry_min"
    private const val KEY_SR_EAT_CARRY_REM = "sr_eat_carry_rem"

    fun getSrEatMidMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_EAT_MID_MIN, 25).coerceIn(0, 90)
    fun setSrEatMidMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_SR_EAT_MID_MIN, min.coerceIn(0, 90)).apply()

    fun isSrEatEndNotifOn(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SR_EAT_END_NOTIF, true)
    fun setSrEatEndNotifOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_SR_EAT_END_NOTIF, on).apply()

    fun getSrEatCarryMax(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_EAT_CARRY_MAX, 3).coerceIn(0, 5)
    fun setSrEatCarryMax(ctx: Context, cnt: Int) = prefs(ctx).edit().putInt(KEY_SR_EAT_CARRY_MAX, cnt.coerceIn(0, 5)).apply()

    fun getSrEatScreenAccumMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_EAT_SCR_ACCUM, 0L)
    fun setSrEatScreenAccumMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_EAT_SCR_ACCUM, ms.coerceAtLeast(0L)).apply()
    fun getSrEatScreenSegMs(ctx: Context): Long = prefs(ctx).getLong(KEY_SR_EAT_SCR_SEG, 0L)
    fun setSrEatScreenSegMs(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(KEY_SR_EAT_SCR_SEG, ms.coerceAtLeast(0L)).apply()

    fun getSrEatCarryMin(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_EAT_CARRY_MIN, 0).coerceAtLeast(0)
    fun getSrEatCarryRem(ctx: Context): Int = prefs(ctx).getInt(KEY_SR_EAT_CARRY_REM, 0).coerceAtLeast(0)
    fun setSrEatCarry(ctx: Context, eatMin: Int, remPopups: Int) {
        prefs(ctx).edit()
            .putInt(KEY_SR_EAT_CARRY_MIN, eatMin.coerceAtLeast(0))
            .putInt(KEY_SR_EAT_CARRY_REM, remPopups.coerceIn(0, 5))
            .apply()
    }
    fun consumeSrEatCarry(ctx: Context) {
        val rem = getSrEatCarryRem(ctx)
        if (rem <= 1) {
            clearSrEatCarry(ctx)
        } else {
            prefs(ctx).edit().putInt(KEY_SR_EAT_CARRY_REM, rem - 1).apply()
        }
    }
    fun clearSrEatCarry(ctx: Context) {
        prefs(ctx).edit().putInt(KEY_SR_EAT_CARRY_MIN, 0).putInt(KEY_SR_EAT_CARRY_REM, 0).apply()
    }

    // v9.46: হিসাব সহকারী পেঁচা (Scholar Owl) সেটিংস
    private const val KEY_OWL_ENABLED = "owl_assistant_enabled"
    private const val KEY_OWL_EDGE_MODE = "owl_edge_mode"          // all, right, left, top_bottom
    private const val KEY_OWL_STAY_SEC = "owl_stay_sec"            // 3..60 (default 10)
    private const val KEY_OWL_MAX_OPEN = "owl_max_per_open"        // 0..10 (0 = unlimited, default 3)
    private const val KEY_OWL_PACING = "owl_pacing_mode"           // front, steady, escalate
    private const val KEY_OWL_INTERVAL_MIN = "owl_interval_min"    // 2..120 (default 15)
    private const val KEY_OWL_ANGRY_HOURS = "owl_angry_hours"      // 0..6 (0 = off, default 2)

    fun isOwlEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_OWL_ENABLED, true)
    fun setOwlEnabled(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_OWL_ENABLED, on).apply()

    fun getOwlEdgeMode(ctx: Context): String = prefs(ctx).getString(KEY_OWL_EDGE_MODE, "all") ?: "all"
    fun setOwlEdgeMode(ctx: Context, m: String) = prefs(ctx).edit().putString(KEY_OWL_EDGE_MODE, m).apply()

    fun getOwlStaySec(ctx: Context): Int = prefs(ctx).getInt(KEY_OWL_STAY_SEC, 10).coerceIn(3, 60)
    fun setOwlStaySec(ctx: Context, sec: Int) = prefs(ctx).edit().putInt(KEY_OWL_STAY_SEC, sec.coerceIn(3, 60)).apply()

    fun getOwlMaxPerOpen(ctx: Context): Int = prefs(ctx).getInt(KEY_OWL_MAX_OPEN, 3).coerceIn(0, 10)
    fun setOwlMaxPerOpen(ctx: Context, cnt: Int) = prefs(ctx).edit().putInt(KEY_OWL_MAX_OPEN, cnt.coerceIn(0, 10)).apply()

    fun getOwlPacing(ctx: Context): String = prefs(ctx).getString(KEY_OWL_PACING, "front") ?: "front"
    fun setOwlPacing(ctx: Context, p: String) = prefs(ctx).edit().putString(KEY_OWL_PACING, p).apply()

    fun getOwlIntervalMin(ctx: Context): Int = prefs(ctx).getInt(KEY_OWL_INTERVAL_MIN, 15).coerceIn(2, 120)
    fun setOwlIntervalMin(ctx: Context, m: Int) = prefs(ctx).edit().putInt(KEY_OWL_INTERVAL_MIN, m.coerceIn(2, 120)).apply()

    fun getOwlAngryHours(ctx: Context): Int = prefs(ctx).getInt(KEY_OWL_ANGRY_HOURS, 2).coerceIn(0, 6)
    fun setOwlAngryHours(ctx: Context, h: Int) = prefs(ctx).edit().putInt(KEY_OWL_ANGRY_HOURS, h.coerceIn(0, 6)).apply()

    // ================= v10.0: ২৪-ঘণ্টা হাইব্রিড টাইমলাইন ও এডিট সীমা =================
    private const val KEY_TIMELINE_EDIT_DAYS = "timeline_edit_days" // 1, 3 (default), 7, 14, 30

    fun getTimelineEditDays(ctx: Context): Int = prefs(ctx).getInt(KEY_TIMELINE_EDIT_DAYS, 3).coerceIn(1, 30)
    fun setTimelineEditDays(ctx: Context, days: Int) = prefs(ctx).edit().putInt(KEY_TIMELINE_EDIT_DAYS, days.coerceIn(1, 30)).apply()

    fun getTimelineEditDaysLabel(days: Int): String = when (days) {
        1 -> "শুধু আজ (১ দিন)"
        3 -> "গত ৩ দিন (ডিফল্ট)"
        7 -> "গত ৭ দিন"
        14 -> "গত ১৪ দিন"
        30 -> "গত ৩০ দিন"
        else -> "গত ${toBnDigits(days)} দিন"
    }

    fun isTimelineEditable(ctx: Context, iso: String): Boolean {
        val today = todayIso()
        if (iso > today) return false
        if (iso == today) return true
        val limit = getTimelineEditDays(ctx)
        if (limit <= 1) return false
        return try {
            val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val d1 = fmt.parse(iso)?.time ?: return false
            val d2 = fmt.parse(today)?.time ?: return false
            val diffDays = ((d2 - d1) / 86_400_000L).toInt()
            diffDays in 0 until limit
        } catch (_: Exception) {
            false
        }
    }

    data class TimelineSeg(
        var start: Int,
        var end: Int,
        var type: String,
        var label: String,
        var source: String = "",
        var subject: String = ""
    )

    private fun parseTimelineArray(raw: String): MutableList<TimelineSeg> {
        val out = mutableListOf<TimelineSeg>()
        if (raw.isBlank()) return out
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val st = o.optInt("s", o.optInt("start", -1)).coerceIn(0, 1440)
                val en = o.optInt("e", o.optInt("end", -1)).coerceIn(0, 1440)
                if (en <= st) continue
                val tp = o.optString("t", o.optString("type", "gap"))
                val lb = o.optString("l", o.optString("label", ""))
                val sr = o.optString("src", o.optString("source", ""))
                val sb = o.optString("sub", o.optString("subject", ""))
                out.add(TimelineSeg(st, en, tp, lb, sr, sb))
            }
        } catch (_: Exception) {}
        return out
    }

    private fun serializeTimelineArray(list: List<TimelineSeg>): String {
        val arr = JSONArray()
        for (seg in list) {
            if (seg.end <= seg.start) continue
            arr.put(JSONObject().apply {
                put("s", seg.start)
                put("e", seg.end)
                put("t", seg.type)
                put("l", seg.label)
                if (seg.source.isNotEmpty()) put("src", seg.source)
                if (seg.subject.isNotEmpty()) put("sub", seg.subject)
            })
        }
        return arr.toString()
    }

    private fun mergeAdjacentSame(list: List<TimelineSeg>): MutableList<TimelineSeg> {
        val sorted = list.filter { it.end > it.start }.sortedBy { it.start }
        val merged = mutableListOf<TimelineSeg>()
        for (seg in sorted) {
            val prev = merged.lastOrNull()
            if (prev != null && prev.end == seg.start && prev.type == seg.type && prev.subject == seg.subject && prev.label == seg.label && prev.source == seg.source) {
                prev.end = seg.end
            } else {
                merged.add(seg.copy())
            }
        }
        return merged
    }

    private fun insertNonOverlapping(existing: List<TimelineSeg>, incoming: TimelineSeg): MutableList<TimelineSeg> {
        val out = mutableListOf<TimelineSeg>()
        for (seg in existing) {
            if (seg.end <= incoming.start || seg.start >= incoming.end) {
                out.add(seg.copy())
            } else {
                if (seg.start < incoming.start) {
                    out.add(seg.copy(end = incoming.start))
                }
                if (seg.end > incoming.end) {
                    out.add(seg.copy(start = incoming.end))
                }
            }
        }
        out.add(incoming.copy())
        return mergeAdjacentSame(out)
    }

    @Synchronized
    fun recordTimelineInterval(ctx: Context, startMs: Long, endMs: Long, type: String, label: String, source: String, subject: String) {
        if (endMs <= startMs || (endMs - startMs) < 60_000L) return
        val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val map = loadAllDays(ctx)
        var cur = startMs
        var touched = false
        while (cur < endMs) {
            val cal = Calendar.getInstance().apply { timeInMillis = cur }
            val iso = dayFmt.format(cal.time)
            val startMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
            val nextMidnight = Calendar.getInstance().apply {
                timeInMillis = cur
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                add(Calendar.DAY_OF_YEAR, 1)
            }.timeInMillis
            val segEndMs = minOf(endMs, nextMidnight)
            val endMin = if (segEndMs == nextMidnight) 1440 else {
                val c2 = Calendar.getInstance().apply { timeInMillis = segEndMs }
                (c2.get(Calendar.HOUR_OF_DAY) * 60 + c2.get(Calendar.MINUTE)).coerceAtLeast(startMin + 1)
            }
            if (endMin > startMin) {
                val rec = map[iso] ?: DayRecord(date = iso, subject = getCurrentSubject(ctx))
                val existing = parseTimelineArray(rec.timelineJson)
                val updated = insertNonOverlapping(existing, TimelineSeg(startMin, endMin, type, label, source, subject))
                rec.timelineJson = serializeTimelineArray(updated)
                rec.synced = false
                map[iso] = rec
                touched = true
            }
            cur = segEndMs
        }
        if (touched) saveAllDays(ctx, map)
    }

    private fun fillGapsForRange(existing: List<TimelineSeg>, dayMaxMin: Int): List<TimelineSeg> {
        val clipped = existing.mapNotNull {
            val st = it.start.coerceIn(0, dayMaxMin)
            val en = it.end.coerceIn(0, dayMaxMin)
            if (en > st) it.copy(start = st, end = en) else null
        }.sortedBy { it.start }
        val result = mutableListOf<TimelineSeg>()
        var cursor = 0
        for (seg in clipped) {
            val st = maxOf(cursor, seg.start)
            if (st > cursor) {
                result.add(TimelineSeg(cursor, st, "gap", "অনির্ধারিত গ্যাপ", "অজানা", ""))
            }
            if (seg.end > st) {
                result.add(seg.copy(start = st))
                cursor = seg.end
            }
        }
        if (cursor < dayMaxMin) {
            result.add(TimelineSeg(cursor, dayMaxMin, "gap", "অনির্ধারিত গ্যাপ", "অজানা", ""))
        }
        return mergeAdjacentSame(result)
    }

    fun buildTimelinePayloadForDay(ctx: Context, iso: String): String {
        val today = todayIso()
        val isToday = iso == today
        val merged = getAllDaysMerged(ctx)
        val rec = merged[iso] ?: DayRecord(date = iso, subject = getCurrentSubject(ctx))

        val dayMaxMin = if (isToday) {
            val c = Calendar.getInstance()
            val curMin = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
            (((curMin + 4) / 5) * 5).coerceIn(30, 1440)
        } else {
            1440
        }

        var segs = parseTimelineArray(rec.timelineJson)
        // পুরোনো দিনে timelineJson না থাকলে study_session_log_14d থেকে হাইড্রেট করা
        if (segs.isEmpty()) {
            try {
                val rawLog = prefs(ctx).getString(KEY_STUDY_SESSION_LOG, "") ?: ""
                if (rawLog.isNotBlank()) {
                    val arr = JSONArray(rawLog)
                    val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                    for (i in 0 until arr.length()) {
                        val o = arr.optJSONObject(i) ?: continue
                        val stMs = o.optLong("s", 0L)
                        val enMs = o.optLong("e", 0L)
                        if (enMs <= stMs) continue
                        val c1 = Calendar.getInstance().apply { timeInMillis = stMs }
                        if (dayFmt.format(c1.time) != iso) continue
                        val sMin = c1.get(Calendar.HOUR_OF_DAY) * 60 + c1.get(Calendar.MINUTE)
                        val c2 = Calendar.getInstance().apply { timeInMillis = enMs }
                        val eMin = (c2.get(Calendar.HOUR_OF_DAY) * 60 + c2.get(Calendar.MINUTE)).coerceAtLeast(sMin + 1)
                        val sub = o.optString("sub", "BCS প্রস্তুতি")
                        segs = insertNonOverlapping(segs, TimelineSeg(sMin, eMin.coerceAtMost(dayMaxMin), "study", sub, "ফ্লিপ", sub))
                    }
                }
            } catch (_: Exception) {}
        }

        val fullSegs = fillGapsForRange(segs, dayMaxMin)
        val segArr = JSONArray()
        for ((idx, sg) in fullSegs.withIndex()) {
            segArr.put(JSONObject().apply {
                put("id", "sg_$idx")
                put("start", sg.start)
                put("end", sg.end)
                put("type", sg.type)
                put("label", if (sg.label.isNotEmpty()) sg.label else "অনির্ধারিত গ্যাপ")
                put("source", sg.source)
                put("subject", sg.subject)
            })
        }

        val subjArr = JSONArray()
        for (sub in getSubjects(ctx)) subjArr.put(sub)

        val sizeKb = String.format(Locale.US, "%.1f", maxOf(0.4, rec.timelineJson.toByteArray(Charsets.UTF_8).size / 1024.0))
        val editable = isTimelineEditable(ctx, iso)
        val editLimit = getTimelineEditDays(ctx)

        return JSONObject().apply {
            put("dateIso", iso)
            put("isToday", isToday)
            put("dayMaxMin", dayMaxMin)
            put("editable", editable)
            put("editDaysLimit", editLimit)
            put("synced", rec.synced)
            put("sizeKb", sizeKb)
            put("subjects", subjArr)
            put("segments", segArr)
        }.toString()
    }

    @Synchronized
    fun saveEditedTimelineForDay(ctx: Context, iso: String, segmentsJson: String): Pair<Boolean, String> {
        if (!isTimelineEditable(ctx, iso)) {
            return Pair(false, "সেটিংস অনুযায়ী গত ${toBnDigits(getTimelineEditDays(ctx))} দিনের বেশি পুরোনো দিন এডিট করা যাবে না")
        }
        val parsed = mergeAdjacentSame(parseTimelineArray(segmentsJson))
        val nonGap = parsed.filter { it.type != "gap" }
        val compactJson = serializeTimelineArray(nonGap)

        val map = loadAllDays(ctx)
        val existingFromDrive = loadDriveCache(ctx)[iso]
        val rec = map[iso] ?: existingFromDrive?.copy() ?: DayRecord(date = iso, subject = getCurrentSubject(ctx))

        var studySec = 0L
        var flipSec = 0L
        var onlineSec = 0L
        var manualSec = 0L
        var wasteSec = 0L
        var eatSec = 0L
        var sleepSec = 0L
        var otherSec = 0L
        var unassignedSec = 0L
        val subjMap = mutableMapOf<String, Long>()

        for (seg in parsed) {
            val sec = ((seg.end - seg.start).coerceAtLeast(0) * 60L)
            if (sec <= 0L) continue
            when (seg.type) {
                "study" -> {
                    studySec += sec
                    if (seg.source == "ফ্লিপ") flipSec += sec else manualSec += sec
                    val sub = seg.subject.ifBlank { seg.label.ifBlank { "BCS প্রস্তুতি" } }
                    subjMap[sub] = (subjMap[sub] ?: 0L) + sec
                }
                "online" -> {
                    studySec += sec
                    onlineSec += sec
                    val sub = seg.subject.ifBlank { seg.label.ifBlank { "BCS প্রস্তুতি" } }
                    subjMap[sub] = (subjMap[sub] ?: 0L) + sec
                }
                "eat" -> eatSec += sec
                "sleep" -> sleepSec += sec
                "routine" -> otherSec += sec
                "waste" -> wasteSec += sec
                else -> unassignedSec += sec
            }
        }

        rec.timelineJson = compactJson
        rec.studySec = studySec
        rec.flipSec = flipSec
        rec.onlineSec = onlineSec
        rec.manualSec = manualSec
        rec.wasteSec = wasteSec
        rec.eatSec = eatSec
        rec.sleepOtherSec = sleepSec
        rec.otherSec = otherSec
        rec.unassignedSec = unassignedSec
        rec.subjects = subjMap
        if (subjMap.isNotEmpty()) {
            rec.subject = subjMap.maxByOrNull { it.value }?.key ?: rec.subject
        }
        rec.synced = false
        map[iso] = rec
        saveAllDays(ctx, map)
        if (iso == todayIso()) {
            checkAndNotifyDailyGoalReached(ctx, rec)
        }
        return Pair(true, buildTimelinePayloadForDay(ctx, iso))
    }


    fun formatClockMinBn(minOfDay: Int): String {
        val m = minOfDay.coerceIn(0, 1440)
        val h24 = (m / 60) % 24
        val mm = m % 60
        val p = if (h24 >= 12) "PM" else "AM"
        val h12 = if (h24 % 12 == 0) 12 else h24 % 12
        return toBnDigits(String.format(Locale.US, "%02d:%02d %s", h12, mm, p))
    }

    fun getTimelineSessionsForItem(ctx: Context, iso: String, kind: String, key: String): List<TimelineSeg> {
        val rawPayload = buildTimelinePayloadForDay(ctx, iso)
        val out = mutableListOf<TimelineSeg>()
        try {
            val arr = JSONObject(rawPayload).optJSONArray("segments") ?: return out
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val seg = TimelineSeg(
                    start = o.optInt("start", 0),
                    end = o.optInt("end", 0),
                    type = o.optString("type", "gap"),
                    label = o.optString("label", ""),
                    source = o.optString("source", ""),
                    subject = o.optString("subject", "")
                )
                if (seg.end <= seg.start) continue
                val matched = when (kind) {
                    "SUBJECT" -> (seg.type == "study" || seg.type == "online") &&
                        (seg.subject.equals(key, ignoreCase = true) || seg.label.equals(key, ignoreCase = true))
                    "WASTE" -> seg.type == "waste"
                    "WASTE_REASON" -> seg.type == "waste" && (seg.label.contains(key, ignoreCase = true) || key == "অন্যান্য অপচয়")
                    "EAT" -> seg.type == "eat"
                    "SLEEP" -> seg.type == "sleep"
                    "OTHER" -> seg.type == "routine"
                    "UNASSIGNED" -> seg.type == "gap"
                    else -> false
                }
                if (matched) out.add(seg)
            }
        } catch (_: Exception) {}
        return out
    }


    // v10.4: ভূত ↔ ড্রাগন অটো-সুইচ কাস্টম সময় (মিনিটে, ডিফল্ট রাত ৯:০০ – ভোর ৬:০০)
    private const val KEY_GHOST_START_MIN = "sr_ghost_start_min"
    private const val KEY_GHOST_END_MIN = "sr_ghost_end_min"

    fun getSrGhostStartMin(ctx: Context): Int = prefs(ctx).getInt(KEY_GHOST_START_MIN, 21 * 60).coerceIn(0, 1439)
    fun setSrGhostStartMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_GHOST_START_MIN, min.coerceIn(0, 1439)).apply()

    fun getSrGhostEndMin(ctx: Context): Int = prefs(ctx).getInt(KEY_GHOST_END_MIN, 6 * 60).coerceIn(0, 1439)
    fun setSrGhostEndMin(ctx: Context, min: Int) = prefs(ctx).edit().putInt(KEY_GHOST_END_MIN, min.coerceIn(0, 1439)).apply()


    // v10.5: ফ্লিপ সাউন্ড ও বাংলা ভয়েস কনফার্মেশন
    private const val KEY_FLIP_AUDIO_MODE = "flip_audio_mode"       // off, tone (default), voice, both
    private const val KEY_FLIP_AUDIO_QUIET = "flip_audio_quiet_mute"

    fun getFlipAudioMode(ctx: Context): String = prefs(ctx).getString(KEY_FLIP_AUDIO_MODE, "tone") ?: "tone"
    fun setFlipAudioMode(ctx: Context, mode: String) = prefs(ctx).edit().putString(KEY_FLIP_AUDIO_MODE, mode).apply()

    fun getFlipAudioModeLabel(mode: String): String = when (mode) {
        "off" -> "বন্ধ"
        "voice" -> "বাংলা ভয়েস ("পড়া শুরু হয়েছে")"
        "both" -> "সাউন্ড + বাংলা ভয়েস"
        else -> "হালকা সাউন্ড (ডিফল্ট)"
    }

    fun isFlipAudioQuietMute(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_FLIP_AUDIO_QUIET, true)
    fun setFlipAudioQuietMute(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(KEY_FLIP_AUDIO_QUIET, on).apply()

}
