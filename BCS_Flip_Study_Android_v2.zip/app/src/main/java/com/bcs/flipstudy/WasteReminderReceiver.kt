package com.bcs.flipstudy

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * v7-এ পুরোনো ৫-মিনিটের অপচয়-সতর্কতা বাদ দিয়ে স্মার্ট রিমাইন্ডার সিস্টেম চালু হয়েছে।
 * v6 থেকে আপডেটের পর কোনো পুরোনো অ্যালার্ম ফায়ার করলে নিরাপদে বাতিল করার জন্য খালি স্টাব।
 */
class WasteReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        SmartReminderManager.ensureMigratedAndStarted(context)
    }
}
