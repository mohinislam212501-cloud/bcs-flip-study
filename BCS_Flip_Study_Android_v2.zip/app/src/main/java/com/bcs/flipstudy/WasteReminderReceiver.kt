package com.bcs.flipstudy

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat

class WasteReminderReceiver : BroadcastReceiver() {

    companion object {
        const val CHANNEL_WASTE = "bcs_waste_alerts_v4"
        const val NOTIF_WASTE_ID = 1003
        const val EXTRA_LEVEL = "mascot_level"
        private const val REQ_CODE = 3003

        fun scheduleNext(ctx: Context, level: Int) {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val triggerAt = System.currentTimeMillis() + (5 * 60 * 1000L)
            val pi = pendingIntent(ctx, level)
            try {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                }
            } catch (_: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            }
        }

        fun cancel(ctx: Context) {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(pendingIntent(ctx, 1))
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.cancel(NOTIF_WASTE_ID)
        }

        private fun pendingIntent(ctx: Context, level: Int): PendingIntent {
            val i = Intent(ctx, WasteReminderReceiver::class.java).apply {
                putExtra(EXTRA_LEVEL, level.coerceIn(1, 5))
            }
            return PendingIntent.getBroadcast(
                ctx, REQ_CODE, i,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        fun mascotResForLevel(level: Int): Int = when (level.coerceIn(1, 5)) {
            1 -> R.drawable.mascot_1
            2 -> R.drawable.mascot_2
            3 -> R.drawable.mascot_3
            4 -> R.drawable.mascot_4
            else -> R.drawable.mascot_5
        }

        fun titleForLevel(level: Int): String = when (level.coerceIn(1, 5)) {
            1 -> "৫ মিনিট অপচয় হলো!"
            2 -> "১০ মিনিট নষ্ট হচ্ছে!"
            3 -> "১৫ মিনিট চলে গেল!"
            4 -> "২০ মিনিট অপচয়! রাগ উঠে যাচ্ছে!"
            else -> "২৫+ মিনিট শেষ!! চূড়ান্ত সতর্কতা!"
        }

        fun messageForLevel(level: Int): String = when (level.coerceIn(1, 5)) {
            1 -> "এই যে! ৫ মিনিট হয়ে গেল, চলো পড়ায় ফিরি!"
            2 -> "১০ মিনিট নষ্ট হলো কিন্তু! এবার ফোনটা উল্টে রাখো!"
            3 -> "১৫ মিনিট চলে গেল! BCS সিলেবাস কিন্তু অপেক্ষা করছে না!"
            4 -> "২০ মিনিট অপচয়! এখনই ফোন রাখো, নাহলে আজকের লক্ষ্য শেষ!"
            else -> "২৫ মিনিট শেষ!! আর এক সেকেন্ডও নয়—এখনই ফোন উল্টাও!"
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        val rt = DataStore.loadRuntimeState(context)
        if (!rt.running || rt.mode != "WASTE") return

        val level = intent.getIntExtra(EXTRA_LEVEL, 1).coerceIn(1, 5)
        ensureChannel(context)

        val bmp = BitmapFactory.decodeResource(context.resources, mascotResForLevel(level))
        val openApp = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_LEVEL, level)
        }
        val pi = PendingIntent.getActivity(
            context, 3010 + level, openApp,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(context, CHANNEL_WASTE)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(titleForLevel(level))
            .setContentText(messageForLevel(level))
            .setLargeIcon(bmp)
            .setStyle(
                NotificationCompat.BigPictureStyle()
                    .bigPicture(bmp)
                    .bigLargeIcon(null as Bitmap?)
                    .setSummaryText(messageForLevel(level))
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_WASTE_ID, notif)

        // হালকা ভাইব্রেশন (রাগ বাড়লে ভাইব্রেশনও একটু জোরালো)
        try {
            val vib = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            val pat = if (level >= 4) longArrayOf(0, 250, 120, 250, 120, 350) else longArrayOf(0, 180, 100, 180)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vib.vibrate(VibrationEffect.createWaveform(pat, -1))
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(pat, -1)
            }
        } catch (_: Exception) {}

        // পরের ৫ মিনিটের জন্য আরও রাগান্বিত লেভেল সিডিউল করো
        scheduleNext(context, (level + 1).coerceAtMost(5))
    }

    private fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_WASTE,
                "অপচয় সতর্কতা (প্রতি ৫ মিনিট)",
                NotificationManager.IMPORTANCE_HIGH
            )
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }
}
