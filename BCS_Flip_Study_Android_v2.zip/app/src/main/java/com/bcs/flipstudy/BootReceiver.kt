package com.bcs.flipstudy

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val act = intent.action ?: return
        if (act == Intent.ACTION_BOOT_COMPLETED || act == Intent.ACTION_MY_PACKAGE_REPLACED) {
            DataStore.setSrAppForeground(context, false)
            // রিবুটের আগে ট্র্যাকার চালু থাকলে আবার চালু করো
            val rt = DataStore.loadRuntimeState(context)
            if (rt.running) {
                try {
                    val i = Intent(context, FlipTrackerService::class.java).setAction(FlipTrackerService.ACTION_RESTORE)
                    ContextCompat.startForegroundService(context, i)
                } catch (_: Exception) {}
            }
            SmartReminderManager.onBootOrUpdate(context)
        }
    }
}
