package com.bcs.flipstudy

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat

class StudyAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val rt = DataStore.loadRuntimeState(context)
        if (!rt.running || rt.mode != "STUDY") return

        val now = System.currentTimeMillis()
        val elapsedSec = ((now - rt.stateStartMs) / 1000L).coerceAtLeast(0L)
        val preset = DataStore.getPresetMin(context)
        val subject = DataStore.getCurrentSubject(context)

        val updated = DataStore.updateToday(context) { rec ->
            rec.studySec += elapsedSec
            if (preset >= 40) rec.c45 += 1 else if (preset >= 20) rec.c25 += 1
            rec.subject = subject
            rec.subjects[subject] = (rec.subjects[subject] ?: 0L) + elapsedSec
            rec.mode = if (DataStore.isOnlineStudy(context)) "manual" else "flip"
            rec.synced = false
        }

        // অ্যালার্ম মোড: vibrate / sound / silent
        val alarmMode = DataStore.getAlarmMode(context)
        if (alarmMode == "sound") {
            try {
                val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                RingtoneManager.getRingtone(context.applicationContext, uri)?.play()
            } catch (_: Exception) {}
        }
        if (alarmMode == "sound" || alarmMode == "vibrate") {
            try {
                val vib = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vib.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 450, 200, 450, 200, 600), -1))
                } else {
                    @Suppress("DEPRECATION")
                    vib.vibrate(longArrayOf(0, 450, 200, 450), -1)
                }
            } catch (_: Exception) {}
        }

        // দৈনিক লক্ষ্য পূরণ নোটিফিকেশন
        val goalMin = DataStore.getDailyGoalHours(context) * 60
        val today = DataStore.todayIso()
        if (DataStore.isGoalNotifOn(context) && updated.totalStudyMinutes() >= goalMin && DataStore.getGoalNotifiedDate(context) != today) {
            DataStore.setGoalNotifiedDate(context, today)
            try {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                val notif = NotificationCompat.Builder(context, FlipTrackerService.CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                    .setContentTitle("আজকের লক্ষ্য পূরণ হয়েছে!")
                    .setContentText("অভিনন্দন! তুমি আজ ${DataStore.toBnDigits(DataStore.getDailyGoalHours(context))} ঘণ্টা পড়া পূর্ণ করেছ।")
                    .setAutoCancel(true)
                    .build()
                nm.notify(1002, notif)
            } catch (_: Exception) {}
        }

        val nextIntent = Intent(context, FlipTrackerService::class.java).apply {
            action = FlipTrackerService.ACTION_ALARM_COMPLETED
        }
        try {
            context.startService(nextIntent)
        } catch (_: Exception) {}
    }
}
