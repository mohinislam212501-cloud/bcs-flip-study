package com.bcs.flipstudy

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat

class SmartReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val event = intent.getStringExtra(SmartReminderManager.EXTRA_EVENT) ?: SmartReminderManager.EVENT_PHONE_USE
        SmartReminderManager.handleAlarmEvent(context, event)
    }

    companion object {
        fun ensureChannel(ctx: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (nm.getNotificationChannel(SmartReminderManager.CHANNEL_REMINDER) == null) {
                    val ch = NotificationChannel(
                        SmartReminderManager.CHANNEL_REMINDER,
                        "স্মার্ট রিমাইন্ডার (পপ-আপ)",
                        NotificationManager.IMPORTANCE_HIGH
                    ).apply {
                        setSound(null, null)
                        enableVibration(false)
                        description = "ফোন চালানো ও পড়াশোনার স্মার্ট পপ-আপ রিমাইন্ডার"
                    }
                    nm.createNotificationChannel(ch)
                }
            }
        }

        fun showReminder(ctx: Context, kind: String, level: Int) {
            val safeLevel = level.coerceIn(1, 5)
            ensureChannel(ctx)

            val title = MascotContent.titleFor(kind, safeLevel)
            val msg = MascotContent.messageFor(kind, safeLevel)
            val bmp = decodeMascotBitmap(ctx, MascotContent.mascotResForLevel(safeLevel))

            val kindCode = when (kind) {
                MascotContent.KIND_ASK -> 10
                MascotContent.KIND_RECHECK -> 20
                MascotContent.KIND_IDLE -> 30
                else -> 40
            }

            val openApp = Intent(ctx, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra(SmartReminderManager.EXTRA_LEVEL, safeLevel)
                putExtra(SmartReminderManager.EXTRA_KIND, kind)
            }
            val openPi = PendingIntent.getActivity(
                ctx, 5000 + kindCode + safeLevel, openApp,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val builder = NotificationCompat.Builder(ctx, SmartReminderManager.CHANNEL_REMINDER)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title)
                .setContentText(msg)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setAutoCancel(true)
                .setOnlyAlertOnce(false)
                .setContentIntent(openPi)

            if (bmp != null) {
                builder.setLargeIcon(bmp)
                builder.setStyle(
                    NotificationCompat.BigPictureStyle()
                        .bigPicture(bmp)
                        .bigLargeIcon(null as Bitmap?)
                        .setSummaryText(msg)
                )
            } else {
                builder.setStyle(NotificationCompat.BigTextStyle().bigText(msg))
            }

            when (kind) {
                MascotContent.KIND_RECHECK -> {
                    builder.addAction(
                        0, "হ্যাঁ, পড়ছি",
                        actionPendingIntent(ctx, 5201, SmartReminderActionReceiver.ACTION_SR_READING_YES)
                    )
                    builder.addAction(
                        0, "না, পড়ছি না",
                        actionPendingIntent(ctx, 5202, SmartReminderActionReceiver.ACTION_SR_READING_NO)
                    )
                }
                MascotContent.KIND_IDLE -> {
                    builder.addAction(
                        0, "পড়া শুরু করি",
                        actionPendingIntent(ctx, 5301, SmartReminderActionReceiver.ACTION_SR_START_STUDY)
                    )
                    builder.addAction(
                        0, "পরে",
                        actionPendingIntent(ctx, 5302, SmartReminderActionReceiver.ACTION_SR_SNOOZE)
                    )
                }
                else -> {
                    builder.addAction(
                        0, "পড়ছি",
                        actionPendingIntent(ctx, 5100 + kindCode + safeLevel, SmartReminderActionReceiver.ACTION_SR_READING_YES)
                    )
                    builder.addAction(
                        0, "পড়ছি না",
                        actionPendingIntent(ctx, 5150 + kindCode + safeLevel, SmartReminderActionReceiver.ACTION_SR_READING_NO)
                    )
                }
            }

            try {
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.notify(SmartReminderManager.NOTIF_REMINDER_ID, builder.build())
            } catch (_: Exception) {}

            // স্ক্রিন ON থাকলে লাইভ ৬০fps ফ্লোটিং পপ-আপ দেখাও
            if (SmartReminderManager.isScreenOn(ctx)) {
                SmartReminderPopupOverlay.show(ctx, kind, safeLevel)
            }

            // সাউন্ড/ভাইব্রেশন বিদ্যমান alarm_mode অনুযায়ী ম্যানুয়ালি (silent হলে চুপ, তবু নোটিফিকেশন ও পপ-আপ আসবে)
            playAlertIfNeeded(ctx, safeLevel)
        }

        private fun actionPendingIntent(ctx: Context, reqCode: Int, action: String): PendingIntent {
            val i = Intent(ctx, SmartReminderActionReceiver::class.java).setAction(action)
            return PendingIntent.getBroadcast(
                ctx, reqCode, i,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        private fun decodeMascotBitmap(ctx: Context, resId: Int): Bitmap? {
            return try {
                val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeResource(ctx.resources, resId, opts)
                var sample = 1
                while (opts.outWidth / sample > 256 && opts.outHeight / sample > 256) {
                    sample *= 2
                }
                val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sample }
                BitmapFactory.decodeResource(ctx.resources, resId, decodeOpts)
            } catch (_: Exception) {
                null
            }
        }

        private fun playAlertIfNeeded(ctx: Context, level: Int) {
            val mode = DataStore.getAlarmMode(ctx)
            if (mode == "silent") return

            if (mode == "sound") {
                try {
                    val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                    RingtoneManager.getRingtone(ctx.applicationContext, uri)?.play()
                } catch (_: Exception) {}
            }
            if (mode == "sound" || mode == "vibrate") {
                try {
                    val vib = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    val pat = if (level >= 4) {
                        longArrayOf(0, 220, 110, 220, 110, 320)
                    } else {
                        longArrayOf(0, 160, 90, 160)
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vib.vibrate(VibrationEffect.createWaveform(pat, -1))
                    } else {
                        @Suppress("DEPRECATION")
                        vib.vibrate(pat, -1)
                    }
                } catch (_: Exception) {}
            }
        }
    }
}
