package com.bcs.flipstudy

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.core.content.ContextCompat
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat

class SmartReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val event = intent.getStringExtra(SmartReminderManager.EXTRA_EVENT) ?: SmartReminderManager.EVENT_PHONE_USE
        SmartReminderManager.handleAlarmEvent(context, event)
    }

    companion object {
        fun ensureChannel(ctx: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (nm.getNotificationChannel(SmartReminderManager.CHANNEL_REMINDER) == null) {
                    val ch = NotificationChannel(
                        SmartReminderManager.CHANNEL_REMINDER,
                        "স্মার্ট রিমাইন্ডার (পপ-আপ)",
                        NotificationManager.IMPORTANCE_HIGH
                    ).apply {
                        setSound(null, null)
                        enableVibration(false)
                        description = "ফোন চালানো ও পড়াশোনার স্মার্ট পপ-আপ রিমাইন্ডার"
                    }
                    nm.createNotificationChannel(ch)
                }
            }
        }

        /**
         * স্ক্রিন চালু ও ওভারলে চালু থাকলে শুধু ফ্লোটিং পপ-আপ দেখাবে।
         * পপ-আপ ইগনোর করলে নির্ধারিত সেকেন্ড পর showSystemNotificationOnly() কল হবে।
         * স্ক্রিন বন্ধ থাকলে (Idle/Away) বা ওভারলে বন্ধ থাকলে সরাসরি সিস্টেম নোটিফিকেশন দেখাবে।
         */
        fun showReminder(ctx: Context, kind: String, level: Int, elapsedMin: Int = 0, msgIndex: Int = 0) {
            val safeLevel = level.coerceIn(1, 5)
            val useFloatingPopup = SmartReminderManager.isScreenOn(ctx) &&
                SmartReminderPopupOverlay.canDrawOverlay(ctx) &&
                DataStore.isSrPopupOverlayOn(ctx)

            if (useFloatingPopup) {
                try {
                    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    nm.cancel(SmartReminderManager.NOTIF_REMINDER_ID)
                } catch (_: Exception) {}
                SmartReminderPopupOverlay.show(ctx, kind, safeLevel, elapsedMin, msgIndex)
                playAlertIfNeeded(ctx, safeLevel)
            } else {
                showSystemNotificationOnly(ctx, kind, safeLevel, elapsedMin, msgIndex, playAlert = true)
            }
        }

        fun showSystemNotificationOnly(
            ctx: Context,
            kind: String,
            level: Int,
            elapsedMin: Int = 0,
            msgIndex: Int = 0,
            playAlert: Boolean = false
        ) {
            val safeLevel = level.coerceIn(1, 5)
            ensureChannel(ctx)

            val character = MascotContent.resolveCharacter(ctx)
            val title = MascotContent.titleFor(kind, safeLevel, elapsedMin)
            val msg = MascotContent.messageFor(ctx, kind, safeLevel, elapsedMin, msgIndex)
            val bmp = decodeMascotBitmap(ctx, MascotContent.mascotResFor(character, safeLevel))

            val kindCode = when (kind) {
                MascotContent.KIND_ASK -> 10
                MascotContent.KIND_RECHECK -> 20
                MascotContent.KIND_IDLE -> 30
                MascotContent.KIND_AWAY_PRE -> 50
                MascotContent.KIND_AWAY_END -> 60
                MascotContent.KIND_STRICT -> 70
                else -> 40
            }

            val openApp = Intent(ctx, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra(SmartReminderManager.EXTRA_LEVEL, safeLevel)
                putExtra(SmartReminderManager.EXTRA_KIND, kind)
                putExtra(SmartReminderManager.EXTRA_ELAPSED_MIN, elapsedMin)
            }
            val openPi = PendingIntent.getActivity(
                ctx, 5000 + kindCode + safeLevel, openApp,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val builder = NotificationCompat.Builder(ctx, SmartReminderManager.CHANNEL_REMINDER)
                .setSmallIcon(R.drawable.ic_notif_mascot)
                .setContentTitle(title)
                .setContentText(msg)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setAutoCancel(true)
                .setOnlyAlertOnce(false)
                .setContentIntent(openPi)

            if (bmp != null) {
                builder.setLargeIcon(bmp)
                builder.setStyle(
                    NotificationCompat.BigPictureStyle()
                        .bigPicture(bmp)
                        .bigLargeIcon(null as Bitmap?)
                        .setSummaryText(msg)
                )
            } else {
                builder.setStyle(NotificationCompat.BigTextStyle().bigText(msg))
            }

            when (kind) {
                MascotContent.KIND_RECHECK -> {
                    builder.addAction(0, "হ্যাঁ, পড়ছি", actionPendingIntent(ctx, 5201, SmartReminderActionReceiver.ACTION_SR_READING_YES))
                    builder.addAction(0, "না, পড়ছি না", actionPendingIntent(ctx, 5202, SmartReminderActionReceiver.ACTION_SR_READING_NO))
                    builder.addAction(0, "খাচ্ছি", actionPendingIntent(ctx, 5203, SmartReminderActionReceiver.ACTION_SR_EATING))
                }
                MascotContent.KIND_IDLE, MascotContent.KIND_AWAY_END -> {
                    builder.addAction(0, "পড়ছি", actionPendingIntent(ctx, 5301, SmartReminderActionReceiver.ACTION_SR_START_STUDY))
                    builder.addAction(0, "বাইরে আছি", actionPendingIntent(ctx, 5302, SmartReminderActionReceiver.ACTION_SR_AWAY_PICKER))
                }
                MascotContent.KIND_AWAY_PRE -> {
                    builder.addAction(0, "পড়া শুরু করি", actionPendingIntent(ctx, 5311, SmartReminderActionReceiver.ACTION_SR_START_STUDY))
                    builder.addAction(0, "ঠিক আছে", actionPendingIntent(ctx, 5312, SmartReminderActionReceiver.ACTION_SR_SNOOZE))
                }
                else -> {
                    builder.addAction(0, "পড়ছি", actionPendingIntent(ctx, 5100 + kindCode + safeLevel, SmartReminderActionReceiver.ACTION_SR_READING_YES))
                    builder.addAction(0, "পড়ছি না", actionPendingIntent(ctx, 5150 + kindCode + safeLevel, SmartReminderActionReceiver.ACTION_SR_READING_NO))
                    builder.addAction(0, "খাচ্ছি", actionPendingIntent(ctx, 5250 + kindCode + safeLevel, SmartReminderActionReceiver.ACTION_SR_EATING))
                }
            }

            try {
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.notify(SmartReminderManager.NOTIF_REMINDER_ID, builder.build())
            } catch (_: Exception) {}

            if (playAlert) {
                playAlertIfNeeded(ctx, safeLevel)
            }
        }

        private fun actionPendingIntent(ctx: Context, reqCode: Int, action: String): PendingIntent {
            val i = Intent(ctx, SmartReminderActionReceiver::class.java).setAction(action)
            return PendingIntent.getBroadcast(
                ctx, reqCode, i,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        private fun decodeMascotBitmap(ctx: Context, resId: Int): Bitmap? {
            return try {
                val d = ContextCompat.getDrawable(ctx, resId) ?: return null
                val size = 768
                val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bmp)
                d.setBounds(0, 0, size, size)
                d.draw(canvas)
                bmp
            } catch (_: Exception) {
                null
            }
        }

        private fun playAlertIfNeeded(ctx: Context, level: Int) {
            val mode = DataStore.getAlarmMode(ctx)
            if (mode == "silent") return

            if (mode == "sound") {
                try {
                    val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                    RingtoneManager.getRingtone(ctx.applicationContext, uri)?.play()
                } catch (_: Exception) {}
            }
            if (mode == "sound" || mode == "vibrate") {
                try {
                    val vib = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    val pat = if (level >= 4) {
                        longArrayOf(0, 220, 110, 220, 110, 320)
                    } else {
                        longArrayOf(0, 160, 90, 160)
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vib.vibrate(VibrationEffect.createWaveform(pat, -1))
                    } else {
                        @Suppress("DEPRECATION")
                        vib.vibrate(pat, -1)
                    }
                } catch (_: Exception) {}
            }
        }
    }
}
