package com.bcs.flipstudy

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.media.AudioManager
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.content.ContextCompat
import java.util.Calendar

data class ActiveBreakInfo(
    val type: String,
    val remainingMs: Long,
    val totalMin: Int,
    val reason: String
)

object SmartReminderManager {

    const val PHASE_NORMAL = "NORMAL"
    const val PHASE_ASKED = "ASKED"
    const val PHASE_READING_PHONE = "READING_PHONE"
    const val PHASE_ANGRY = "ANGRY"
    const val PHASE_EATING = "EATING"
    const val PHASE_AWAY = "AWAY"

    const val SR_OFF_RESET_MIN = 25

    const val CHANNEL_REMINDER = "bcs_smart_reminder_v7"
    const val CHANNEL_WATCHER = "bcs_smart_watcher_v7"
    const val NOTIF_REMINDER_ID = 1004
    const val NOTIF_WATCHER_ID = 1005

    const val EXTRA_LEVEL = "mascot_level"
    const val EXTRA_KIND = "sr_kind"
    const val EXTRA_ELAPSED_MIN = "sr_elapsed_min"
    const val EXTRA_EVENT = "sr_event"
    const val EXTRA_START_STUDY_FALLBACK = "sr_start_study_fallback"
    const val EXTRA_SHOW_AWAY_PICKER = "sr_show_away_picker"

    const val EVENT_PHONE_USE = "EVENT_PHONE_USE"
    const val EVENT_RECHECK = "EVENT_RECHECK"
    const val EVENT_READ_RESET = "EVENT_READ_RESET"
    const val EVENT_IDLE = "EVENT_IDLE"
    const val EVENT_QUIET_END = "EVENT_QUIET_END"
    const val EVENT_GAP_PROMPT = "EVENT_GAP_PROMPT"
    const val EVENT_POPUP_FALLBACK = "EVENT_POPUP_FALLBACK"
    const val EVENT_EAT_END = "EVENT_EAT_END"
    const val EVENT_AWAY_PRE = "EVENT_AWAY_PRE"
    const val EVENT_AWAY_END = "EVENT_AWAY_END"
    const val EVENT_CALL_REMIND = "EVENT_CALL_REMIND"

    private const val REQ_PHONE_USE = 4101
    private const val REQ_GAP_PROMPT = 4111
    private const val REQ_RECHECK = 4102
    private const val REQ_READ_RESET = 4103
    private const val REQ_IDLE = 4104
    private const val REQ_QUIET_END = 4105
    private const val REQ_POPUP_FALLBACK = 4106
    private const val REQ_EAT_END = 4107
    private const val REQ_AWAY_PRE = 4108
    private const val REQ_AWAY_END = 4109
    private const val REQ_CALL_REMIND = 4110

    @Volatile
    private var appInForeground = false

    @Volatile
    private var internalOpUntilMs = 0L

    private fun markInternalOp() {
        internalOpUntilMs = System.currentTimeMillis() + 2500L
    }

    private fun isInternalOp(): Boolean = System.currentTimeMillis() < internalOpUntilMs

    // ------------------------------------------------------------------ lifecycle & migration

    fun ensureMigratedAndStarted(ctx: Context) {
        val appCtx = ctx.applicationContext
        if (!DataStore.isSrMigratedV7(appCtx)) {
            try {
                val am = appCtx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val oldPi = PendingIntent.getBroadcast(
                    appCtx, 3003, Intent(appCtx, WasteReminderReceiver::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                am.cancel(oldPi)
            } catch (_: Exception) {}
            try {
                val nm = appCtx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.cancel(1003)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    nm.deleteNotificationChannel("bcs_waste_alerts_v4")
                }
            } catch (_: Exception) {}
            DataStore.setSrMigratedV7(appCtx, true)
        }

        if (DataStore.isSrEnabled(appCtx)) {
            startWatcherService(appCtx)
        } else {
            stopWatcherService(appCtx)
        }
    }

    fun onBootOrUpdate(ctx: Context) {
        val appCtx = ctx.applicationContext
        ensureMigratedAndStarted(appCtx)
        if (!DataStore.isSrEnabled(appCtx)) return
        val now = System.currentTimeMillis()
        checkExpiredEatOrAway(appCtx, now)
        val phase = DataStore.getSrPhase(appCtx)
        if (phase == PHASE_EATING || phase == PHASE_AWAY) return

        if (isScreenOn(appCtx)) {
            evaluatePhoneUseSchedule(appCtx, now)
        } else {
            scheduleIdleIfEligible(appCtx, now)
        }
    }

    /** ওয়াচার সার্ভিস চালু/রিস্টার্ট হওয়ার সময় স্ক্রিন আগে থেকেই ON থাকলে সাথে সাথে গোনা শুরু করবে। */
    fun onWatcherStarted(ctx: Context) {
        val appCtx = ctx.applicationContext
        if (!DataStore.isSrEnabled(appCtx)) return
        val now = System.currentTimeMillis()
        checkExpiredEatOrAway(appCtx, now)
        val phase = DataStore.getSrPhase(appCtx)
        if (phase == PHASE_EATING || phase == PHASE_AWAY || phase == PHASE_READING_PHONE) return

        if (isScreenOn(appCtx)) {
            val offSince = DataStore.getSrScreenOffSinceMs(appCtx)
        DataStore.setSrScreenOffSinceMs(appCtx, 0L)
        if (offSince > 0L && (now - offSince) >= 3 * 60_000L) DataStore.setGapPromptedInSession(appCtx, false)
        val longSleepGap = offSince > 0L && (now - offSince) >= 4 * 3600_000L
        val dateChanged = DataStore.getSrLastActiveDate(appCtx).let { it.isNotEmpty() && it != DataStore.todayIso() }
        if (longSleepGap || dateChanged) {
            handleMorningResetAndGreeting(appCtx, now, fireGreeting = !isAppInForeground(appCtx) && !isRealStudyRunning(appCtx))
        } else {
            DataStore.setSrLastActiveDate(appCtx, DataStore.todayIso())
        }
            if (!isAppInForeground(appCtx)) {
                evaluatePhoneUseSchedule(appCtx, now)
            }
        } else {
            scheduleIdleIfEligible(appCtx, now)
        }
    }

    fun onSettingsChanged(ctx: Context) {
        val appCtx = ctx.applicationContext
        val now = System.currentTimeMillis()
        if (!DataStore.isSrEnabled(appCtx)) {
            if (DataStore.getSrPhase(appCtx) == PHASE_READING_PHONE) {
                endReminderStudySession(appCtx)
            }
            val ph = DataStore.getSrPhase(appCtx)
            if (ph == PHASE_EATING || ph == PHASE_AWAY) endBreak(appCtx, ph, now, null, scheduleNext = false)
            cancelAllAlarms(appCtx)
            dismissReminderUi(appCtx)
            resetState(appCtx)
            stopWatcherService(appCtx)
            return
        }

        startWatcherService(appCtx)
        if (isDailyGoalReached(appCtx)) {
            cancelAllAlarms(appCtx)
            dismissReminderUi(appCtx)
            return
        }

        checkExpiredEatOrAway(appCtx, now)
        val phase = DataStore.getSrPhase(appCtx)
        if (phase == PHASE_EATING || phase == PHASE_AWAY) return

        if (phase == PHASE_READING_PHONE) {
            if (isScreenOn(appCtx)) {
                scheduleAlarm(appCtx, REQ_RECHECK, EVENT_RECHECK, now + DataStore.getSrReadRecheckMin(appCtx) * 60_000L)
            } else {
                scheduleAlarm(appCtx, REQ_READ_RESET, EVENT_READ_RESET, now + DataStore.getSrReadResetMin(appCtx) * 60_000L)
            }
        } else {
            if (isScreenOn(appCtx)) {
                cancelAlarm(appCtx, REQ_IDLE)
                evaluatePhoneUseSchedule(appCtx, now)
            } else {
                cancelAlarm(appCtx, REQ_PHONE_USE)
                scheduleIdleIfEligible(appCtx, now)
            }
        }
    }

    fun startWatcherService(ctx: Context) {
        try {
            val i = Intent(ctx, ReminderWatcherService::class.java).setAction(ReminderWatcherService.ACTION_START_WATCHER)
            ContextCompat.startForegroundService(ctx, i)
        } catch (_: Exception) {}
    }

    fun stopWatcherService(ctx: Context) {
        try {
            ctx.stopService(Intent(ctx, ReminderWatcherService::class.java))
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ app foreground & screen events

    fun onAppForeground(ctx: Context, foreground: Boolean) {
        val appCtx = ctx.applicationContext
        appInForeground = foreground
        DataStore.setSrAppForeground(appCtx, foreground)
        if (!DataStore.isSrEnabled(appCtx)) return

        val now = System.currentTimeMillis()
        if (foreground) {
            pauseSegment(appCtx, now)
            commitSmartWasteIfEligible(appCtx, now)
            cancelAlarm(appCtx, REQ_PHONE_USE)
            cancelAlarm(appCtx, REQ_QUIET_END)
            cancelPendingPopupFallback(appCtx)
        } else {
            checkExpiredEatOrAway(appCtx, now)
            if (isScreenOn(appCtx)) {
                evaluatePhoneUseSchedule(appCtx, now)
            }
        }
    }

    fun onScreenOn(ctx: Context) {
        val appCtx = ctx.applicationContext
        cancelAlarm(appCtx, REQ_IDLE)
        cancelAlarm(appCtx, REQ_READ_RESET)
        if (!DataStore.isSrEnabled(appCtx)) return

        val now = System.currentTimeMillis()
        val offSince = DataStore.getSrScreenOffSinceMs(appCtx)
        DataStore.setSrScreenOffSinceMs(appCtx, 0L)
        DataStore.setSrIdleFiredEpisode(appCtx, false)
        DataStore.setGapPromptedInSession(appCtx, false)
        cancelAlarm(appCtx, REQ_GAP_PROMPT)

        if (isDailyGoalReached(appCtx)) {
            cancelAllAlarms(appCtx)
            dismissReminderUi(appCtx)
            return
        }

        checkExpiredEatOrAway(appCtx, now)
        val phase = DataStore.getSrPhase(appCtx)
        if (phase == PHASE_EATING || phase == PHASE_AWAY) return

        if (phase == PHASE_READING_PHONE) {
            val resetMs = DataStore.getSrReadResetMin(appCtx) * 60_000L
            if (offSince > 0L && (now - offSince) >= resetMs) {
                endReminderStudySession(appCtx)
                resetState(appCtx)
                evaluatePhoneUseSchedule(appCtx, now)
            } else {
                resumeReadingPhoneSession(appCtx)
                scheduleAlarm(appCtx, REQ_RECHECK, EVENT_RECHECK, now + DataStore.getSrReadRecheckMin(appCtx) * 60_000L)
            }
            return
        }

        // NORMAL / ASKED / ANGRY: ২৫ মিনিট বা বেশি বন্ধ থাকলে lazy রিসেট
        if (offSince > 0L && (now - offSince) >= SR_OFF_RESET_MIN * 60_000L) {
            resetState(appCtx)
            dismissReminderUi(appCtx)
        }

        evaluatePhoneUseSchedule(appCtx, now)
    }

    fun onScreenOff(ctx: Context) {
        val appCtx = ctx.applicationContext
        val now = System.currentTimeMillis()
        DataStore.setSrScreenOffSinceMs(appCtx, now)
        val curPh = DataStore.getSrPhase(appCtx)
        if (curPh == PHASE_EATING || curPh == PHASE_AWAY) endBreak(appCtx, curPh, now, null, scheduleNext = false)
        pauseSegment(appCtx, now)
        commitSmartWasteIfEligible(appCtx, now)
        cancelAlarm(appCtx, REQ_PHONE_USE)
        cancelAlarm(appCtx, REQ_GAP_PROMPT)
        cancelAlarm(appCtx, REQ_QUIET_END)
        SmartReminderPopupOverlay.dismiss()

        if (!DataStore.isSrEnabled(appCtx)) return
        if (isDailyGoalReached(appCtx)) {
            cancelAllAlarms(appCtx)
            return
        }

        checkExpiredEatOrAway(appCtx, now)
        val phase = DataStore.getSrPhase(appCtx)
        if (phase == PHASE_EATING || phase == PHASE_AWAY) return

        if (phase == PHASE_READING_PHONE) {
            cancelAlarm(appCtx, REQ_RECHECK)
            pauseReadingPhoneSession(appCtx)
            val resetMs = DataStore.getSrReadResetMin(appCtx) * 60_000L
            scheduleAlarm(appCtx, REQ_READ_RESET, EVENT_READ_RESET, now + resetMs)
            return
        }

        scheduleIdleIfEligible(appCtx, now)
    }

    // ------------------------------------------------------------------ study state hooks

    fun onStudyStateChanged(ctx: Context) {
        val appCtx = ctx.applicationContext
        if (!DataStore.isSrEnabled(appCtx)) return
        if (isInternalOp()) return

        val now = System.currentTimeMillis()
        val rt = DataStore.loadRuntimeState(appCtx)
        val phase = DataStore.getSrPhase(appCtx)

        if (rt.running && rt.mode == "STUDY") {
            // ব্যবহারকারী নিজে পড়া শুরু করেছে -> খাচ্ছি/বাইরে আছি থাকলে শেষ করো, সব রিমাইন্ডার বাতিল ও রিসেট
            if (phase == PHASE_EATING || phase == PHASE_AWAY) endBreak(appCtx, phase, now, null, scheduleNext = false)
            if (phase != PHASE_READING_PHONE) {
                cancelAllAlarms(appCtx)
                dismissReminderUi(appCtx)
                resetState(appCtx)
                DataStore.setSrIdleFiredEpisode(appCtx, false)
            }
            return
        }

        DataStore.setSrLastStudyEndMs(appCtx, now)
        DataStore.setSrIdleFiredEpisode(appCtx, false)

        if (phase == PHASE_READING_PHONE) {
            cancelAlarm(appCtx, REQ_RECHECK)
            cancelAlarm(appCtx, REQ_READ_RESET)
            resetState(appCtx)
        }

        if (isDailyGoalReached(appCtx)) {
            cancelAllAlarms(appCtx)
            dismissReminderUi(appCtx)
            return
        }

        checkExpiredEatOrAway(appCtx, now)
        val curPhase = DataStore.getSrPhase(appCtx)
        if (curPhase == PHASE_EATING || curPhase == PHASE_AWAY) return

        if (isScreenOn(appCtx)) {
            evaluatePhoneUseSchedule(appCtx, now)
        } else {
            scheduleIdleIfEligible(appCtx, now)
        }
    }

    fun onStudyProgressUpdated(ctx: Context) {
        val appCtx = ctx.applicationContext
        if (!DataStore.isSrEnabled(appCtx)) return
        if (isDailyGoalReached(appCtx)) {
            cancelAllAlarms(appCtx)
            dismissReminderUi(appCtx)
        }
    }

    // ------------------------------------------------------------------ popup ignore fallback

    fun onPopupDismissedWithoutAction(ctx: Context, kind: String, level: Int, elapsedMin: Int, msgIndex: Int) {
        val appCtx = ctx.applicationContext
        if (!DataStore.isSrEnabled(appCtx)) return
        if (isDailyGoalReached(appCtx)) return
        if (isRealStudyRunning(appCtx)) return
        val phase = DataStore.getSrPhase(appCtx)
        if (phase == PHASE_EATING || phase == PHASE_AWAY) return

        // পপ-আপ ইগনোর করলে শুধু চূড়ান্ত রাগে (লেভেল ৫ / স্ট্রিক্ট) একবারই ফলো-আপ নোটিফিকেশন দেবে
        val isMaxRage = level >= 5 || kind == MascotContent.KIND_STRICT
        if (!isMaxRage) return
        if (DataStore.isSrMaxRageNotifSent(appCtx)) return

        DataStore.setSrPendingFallback(appCtx, kind, level, elapsedMin, msgIndex)
        val delayMs = DataStore.getSrFallbackDelaySec(appCtx) * 1000L
        scheduleAlarm(appCtx, REQ_POPUP_FALLBACK, EVENT_POPUP_FALLBACK, System.currentTimeMillis() + delayMs)
    }

    private fun cancelPendingPopupFallback(ctx: Context) {
        cancelAlarm(ctx, REQ_POPUP_FALLBACK)
        DataStore.clearSrPendingFallback(ctx)
        DataStore.setSrMaxRageNotifSent(ctx, false)
        // ⚠ এখানে আগে setSrWasteCommittedMs(0) ছিল: অ্যাপ খুললেই কাউন্টার শূন্য হতো কিন্তু জমা সময় থেকে যেত,
        // ফলে পরের বার পুরো জমা সময় আবার অপচয়ে যোগ হতো (ডাবল গণনা → ২৫+ ঘণ্টা অপচয়)।
        // এখন কাউন্টার শূন্য হয় শুধু জমা-সময় শূন্য হলে (DataStore.setSrUseAccumMs)।
    }

    /** ফ্লিপ/ম্যানুয়াল বন্ধ থাকলে পপ-আপ বা স্ক্রিন-অফ ইভেন্টে নতুন অপচয় সময় যোগ করে (ডাবল গোনা ছাড়াই)। */
    private fun commitSmartWasteIfEligible(ctx: Context, now: Long) {
        val phase = DataStore.getSrPhase(ctx)
        if (phase != PHASE_ANGRY) return
        if (DataStore.loadRuntimeState(ctx).running) return

        val totalMs = currentAccumulatedMs(ctx, now)
        val committed = DataStore.getSrWasteCommittedMs(ctx)
        val deltaMs = (totalMs - committed).coerceAtLeast(0L)
        if (deltaMs >= 30_000L) {
            DataStore.addWaste(ctx, now - deltaMs, now, "ফোন চালানো")
            DataStore.setSrWasteCommittedMs(ctx, totalMs)
        }
    }

    // ------------------------------------------------------------------ user actions (notification / popup / dialog)

    fun onReadingYes(ctx: Context) {
        val appCtx = ctx.applicationContext
        cancelPendingPopupFallback(appCtx)
        dismissReminderUi(appCtx)
        if (!DataStore.isSrEnabled(appCtx)) return
        if (isDailyGoalReached(appCtx)) {
            cancelAllAlarms(appCtx)
            return
        }

        val now = System.currentTimeMillis()
        val curPh = DataStore.getSrPhase(appCtx)
        if (curPh == PHASE_EATING || curPh == PHASE_AWAY) endBreak(appCtx, curPh, now, null, scheduleNext = false)

        val phase = DataStore.getSrPhase(appCtx)
        if (phase != PHASE_READING_PHONE) {
            val rt = DataStore.loadRuntimeState(appCtx)
            DataStore.setSrPrevOnline(appCtx, DataStore.isOnlineStudy(appCtx))
            DataStore.setSrSessionStartedByReminder(appCtx, !rt.running)
            DataStore.setOnlineStudy(appCtx, true)
            DataStore.setSrPhase(appCtx, PHASE_READING_PHONE)
            DataStore.setSrLevel(appCtx, 0)
            DataStore.setSrUseAccumMs(appCtx, 0L)
            DataStore.setSrUseSegmentStartMs(appCtx, 0L)
            DataStore.setSrIdleFiredEpisode(appCtx, false)

            cancelAlarm(appCtx, REQ_PHONE_USE)
            cancelAlarm(appCtx, REQ_IDLE)
            cancelAlarm(appCtx, REQ_READ_RESET)
            cancelAlarm(appCtx, REQ_QUIET_END)
            cancelAlarm(appCtx, REQ_AWAY_PRE)
            cancelAlarm(appCtx, REQ_AWAY_END)

            startOrUpdateOnlineStudyService(appCtx, rt.running)
        }
        scheduleAlarm(appCtx, REQ_RECHECK, EVENT_RECHECK, now + DataStore.getSrReadRecheckMin(appCtx) * 60_000L)
    }

    fun onReadingNo(ctx: Context) {
        val appCtx = ctx.applicationContext
        cancelPendingPopupFallback(appCtx)
        dismissReminderUi(appCtx)
        if (!DataStore.isSrEnabled(appCtx)) return
        if (isDailyGoalReached(appCtx)) {
            cancelAllAlarms(appCtx)
            return
        }

        val now = System.currentTimeMillis()
        val prevPhase = DataStore.getSrPhase(appCtx)

        if (prevPhase == PHASE_READING_PHONE) {
            endReminderStudySession(appCtx)
            cancelAlarm(appCtx, REQ_RECHECK)
            cancelAlarm(appCtx, REQ_READ_RESET)
        }

        // গুরুত্বপূর্ণ ফিক্স: আগে থেকেই ANGRY অবস্থায় থাকলে (যেমন লেভেল ৫) আবার লেভেল ১-এ নামবে না!
        if (prevPhase == PHASE_ANGRY) {
            ensureSegmentRunning(appCtx, now)
            commitSmartWasteIfEligible(appCtx, now)
            if (!isScreenOn(appCtx)) {
                scheduleIdleIfEligible(appCtx, now)
                return
            }
            if (isInQuietHours(appCtx, now)) {
                scheduleAlarm(appCtx, REQ_QUIET_END, EVENT_QUIET_END, nextQuietEndMs(appCtx, now))
                return
            }
            val nextAngMs = now + nextPhoneIntervalMs(appCtx, now)
            scheduleAlarm(appCtx, REQ_PHONE_USE, EVENT_PHONE_USE, nextAngMs)
            scheduleGapPromptIfEligible(appCtx, now, nextAngMs)
            return
        }

        // প্রথমবার [পড়ছি না] চাপলে সঙ্গে সঙ্গে লেভেল ১ রাগান্বিত পপ-আপ (ফোন-চালানোর সময় অক্ষত রেখে)
        DataStore.setSrPhase(appCtx, PHASE_ANGRY)
        commitSmartWasteIfEligible(appCtx, now)
        DataStore.setSrLevel(appCtx, 1)
        ensureSegmentRunning(appCtx, now)

        if (!isScreenOn(appCtx)) {
            scheduleIdleIfEligible(appCtx, now)
            return
        }
        if (isInQuietHours(appCtx, now)) {
            scheduleAlarm(appCtx, REQ_QUIET_END, EVENT_QUIET_END, nextQuietEndMs(appCtx, now))
            return
        }

        val accumMs = currentAccumulatedMs(appCtx, now)
        val firstAngryTargetMs = DataStore.getSrRepeatMin(appCtx) * 60_000L
        if (prevPhase == PHASE_ASKED && accumMs + 30_000L < firstAngryTargetMs) {
            // যেমন ২ মি.-এ প্রশ্ন এলে ও 'পড়ছি না' বললে বাকি ৩ মি. পর (মোট ৫ মি. পূর্তিতে) ১ম রাগান্বিত পপ-আপ
            DataStore.setSrLevel(appCtx, 0)
            scheduleAlarm(appCtx, REQ_PHONE_USE, EVENT_PHONE_USE, now + (firstAngryTargetMs - accumMs))
        } else {
            val elapsedMin = getPhoneUseMinutes(appCtx, now)
            val idx = nextMsgIndex(appCtx)
            showAngryWithSeriousTracking(appCtx, MascotContent.KIND_ANGRY, 1, elapsedMin, idx)
            scheduleAlarm(appCtx, REQ_PHONE_USE, EVENT_PHONE_USE, now + nextPhoneIntervalMs(appCtx, now))
        }
    }

    fun onEatingMode(ctx: Context) {
        val appCtx = ctx.applicationContext
        val now = System.currentTimeMillis()
        cancelPendingPopupFallback(appCtx)
        dismissReminderUi(appCtx)
        if (DataStore.getSrPhase(appCtx) == PHASE_READING_PHONE) {
            endReminderStudySession(appCtx)
        }
        cancelAllAlarms(appCtx)

        pauseSegment(appCtx, now)
        commitSmartWasteIfEligible(appCtx, now)
        val eatMin = DataStore.getSrEatMin(appCtx)
        DataStore.setSrPhase(appCtx, PHASE_EATING)
        DataStore.setSrLevel(appCtx, 0)
        DataStore.setSrUseAccumMs(appCtx, 0L)
        DataStore.setSrUseSegmentStartMs(appCtx, 0L)
        DataStore.setSrEatStartMs(appCtx, now)
        DataStore.setSrEatUntilMs(appCtx, now + eatMin * 60_000L)
        scheduleAlarm(appCtx, REQ_EAT_END, EVENT_EAT_END, now + eatMin * 60_000L)
    }

    fun onStartStudyFromIdle(ctx: Context) {
        val appCtx = ctx.applicationContext
        val now = System.currentTimeMillis()
        cancelPendingPopupFallback(appCtx)
        dismissReminderUi(appCtx)
        if (DataStore.getSrPhase(appCtx) == PHASE_EATING) commitEatingTimeIfActive(appCtx, now)
        cancelAllAlarms(appCtx)
        resetState(appCtx)
        DataStore.setSrIdleFiredEpisode(appCtx, false)

        val rt = DataStore.loadRuntimeState(appCtx)
        if (!(rt.running && rt.mode == "STUDY")) {
            val i = Intent(appCtx, FlipTrackerService::class.java).setAction(FlipTrackerService.ACTION_MANUAL_STUDY)
            try {
                if (rt.running) appCtx.startService(i)
                else ContextCompat.startForegroundService(appCtx, i)
            } catch (_: Exception) {
                launchMainStudyFallback(appCtx, FlipTrackerService.ACTION_MANUAL_STUDY)
            }
        }
    }

    fun openAwayPicker(ctx: Context) {
        val appCtx = ctx.applicationContext
        cancelPendingPopupFallback(appCtx)
        dismissReminderUi(appCtx)
        try {
            val open = Intent(appCtx, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra(EXTRA_SHOW_AWAY_PICKER, true)
            }
            appCtx.startActivity(open)
        } catch (_: Exception) {}
    }

    fun onSetAwayMinutes(ctx: Context, minutes: Int, reason: String? = null) {
        val appCtx = ctx.applicationContext
        val mins = minutes.coerceIn(5, 720)
        val now = System.currentTimeMillis()
        cancelPendingPopupFallback(appCtx)
        dismissReminderUi(appCtx)
        val curPh = DataStore.getSrPhase(appCtx)
        if (curPh == PHASE_READING_PHONE) {
            endReminderStudySession(appCtx)
        }
        if (curPh == PHASE_EATING || curPh == PHASE_AWAY) {
            endBreak(appCtx, curPh, now, null, scheduleNext = false)
        }
        cancelAllAlarms(appCtx)

        if (!reason.isNullOrBlank()) DataStore.setSrAwayReason(appCtx, reason)
        val totalMs = mins * 60_000L
        val endMs = now + totalMs
        DataStore.setSrPhase(appCtx, PHASE_AWAY)
        DataStore.setSrLevel(appCtx, 0)
        DataStore.setSrUseAccumMs(appCtx, 0L)
        DataStore.setSrUseSegmentStartMs(appCtx, 0L)
        DataStore.setSrAwayStartMs(appCtx, now)
        DataStore.setSrAwayUntilMs(appCtx, endMs)
        DataStore.setSrAwayTotalMin(appCtx, mins)

        // শেষ হওয়ার ১/৪ সময় আগে প্রস্তুতি রিমাইন্ডার (ন্যূনতম ৮ মি. হলে)
        if (mins >= 8) {
            val preAt = now + (totalMs * 3L / 4L)
            scheduleAlarm(appCtx, REQ_AWAY_PRE, EVENT_AWAY_PRE, preAt)
        }
        scheduleAlarm(appCtx, REQ_AWAY_END, EVENT_AWAY_END, endMs)
    }

    /** সেটিংস থেকে ম্যানুয়ালি স্ক্রিনটাইম ও রিমাইন্ডার স্টেট একদম শূন্যে (প্রথম স্ক্রিন-অন অবস্থায়) রিসেট করে। */
    fun resetPhoneUseAndReminderNow(ctx: Context) {
        val appCtx = ctx.applicationContext
        if (DataStore.getSrPhase(appCtx) == PHASE_READING_PHONE) {
            endReminderStudySession(appCtx)
        }
        cancelAllAlarms(appCtx)
        dismissReminderUi(appCtx)
        resetState(appCtx)
        DataStore.setSrScreenOffSinceMs(appCtx, 0L)
        DataStore.setSrIdleFiredEpisode(appCtx, false)
    }

    fun onSnoozeIdle(ctx: Context) {
        cancelPendingPopupFallback(ctx.applicationContext)
        dismissReminderUi(ctx.applicationContext)
    }

    // ------------------------------------------------------------------ alarm handlers

    fun handleAlarmEvent(ctx: Context, event: String) {
        val appCtx = ctx.applicationContext
        if (!DataStore.isSrEnabled(appCtx)) {
            cancelAllAlarms(appCtx)
            return
        }
        if (isDailyGoalReached(appCtx)) {
            cancelAllAlarms(appCtx)
            dismissReminderUi(appCtx)
            return
        }

        val now = System.currentTimeMillis()
        when (event) {
            EVENT_POPUP_FALLBACK -> handlePopupFallbackAlarm(appCtx, now)
            EVENT_EAT_END -> handleEatEndAlarm(appCtx, now)
            EVENT_AWAY_PRE -> handleAwayPreAlarm(appCtx, now)
            EVENT_AWAY_END -> handleAwayEndAlarm(appCtx, now)
            EVENT_CALL_REMIND -> handleCallRemindAlarm(appCtx, now)
            EVENT_READ_RESET -> handleReadResetAlarm(appCtx, now)
            EVENT_IDLE -> handleIdleAlarm(appCtx, now)
            EVENT_RECHECK -> handleRecheckAlarm(appCtx, now)
            EVENT_GAP_PROMPT -> handleGapPromptAlarm(appCtx, now)
            EVENT_QUIET_END -> {
                checkExpiredEatOrAway(appCtx, now)
                handleMorningResetAndGreeting(appCtx, now, fireGreeting = isScreenOn(appCtx) && !isAppInForeground(appCtx) && !isRealStudyRunning(appCtx))
                if (isScreenOn(appCtx) && !isAppInForeground(appCtx)) {
                    evaluatePhoneUseSchedule(appCtx, now)
                } else if (!isScreenOn(appCtx)) {
                    scheduleIdleIfEligible(appCtx, now)
                }
            }
            else -> handlePhoneUseAlarm(appCtx, now)
        }
    }

    private fun handlePopupFallbackAlarm(ctx: Context, now: Long) {
        val kind = DataStore.getSrPendingFbKind(ctx)
        if (kind.isEmpty()) return
        val level = DataStore.getSrPendingFbLevel(ctx)
        val elapsed = DataStore.getSrPendingFbElapsed(ctx)
        val msgIdx = DataStore.getSrPendingFbMsgIdx(ctx)
        DataStore.clearSrPendingFallback(ctx)

        if (isRealStudyRunning(ctx)) return
        if (isInQuietHours(ctx, now)) {
            cancelAlarm(ctx, REQ_IDLE)
            return
        }
        val offSince = DataStore.getSrScreenOffSinceMs(ctx)
        if (offSince > 0L && (now - offSince) >= 5 * 3600_000L) {
            cancelAlarm(ctx, REQ_IDLE)
            return
        }
        if (isAppInForeground(ctx)) return
        val phase = DataStore.getSrPhase(ctx)
        if (phase == PHASE_EATING || phase == PHASE_AWAY) return
        if (isInQuietHours(ctx, now)) return
        if (isInCall(ctx)) { handleInCallTrigger(ctx, now); return }
        if (DataStore.isSrMaxRageNotifSent(ctx)) return

        DataStore.setSrMaxRageNotifSent(ctx, true)
        SmartReminderReceiver.showSystemNotificationOnly(ctx, kind, level, elapsed, msgIdx, playAlert = false)
    }

    private fun handleEatEndAlarm(ctx: Context, now: Long) {
        if (DataStore.getSrPhase(ctx) != PHASE_EATING) return
        endBreak(ctx, PHASE_EATING, now, null, scheduleNext = true)
    }

    private fun handleAwayPreAlarm(ctx: Context, now: Long) {
        if (DataStore.getSrPhase(ctx) != PHASE_AWAY) return
        if (isInQuietHours(ctx, now)) return
        val until = DataStore.getSrAwayUntilMs(ctx)
        val remMin = ((until - now) / 60_000L).toInt().coerceAtLeast(1)
        SmartReminderReceiver.showReminder(ctx, MascotContent.KIND_AWAY_PRE, 1, remMin, nextMsgIndex(ctx))
    }

    private fun handleAwayEndAlarm(ctx: Context, now: Long) {
        if (DataStore.getSrPhase(ctx) != PHASE_AWAY) return
        val totalMin = DataStore.getSrAwayTotalMin(ctx)
        endBreak(ctx, PHASE_AWAY, now, null, scheduleNext = true)
        if (!isInQuietHours(ctx, now)) {
            SmartReminderReceiver.showReminder(ctx, MascotContent.KIND_AWAY_END, 2, totalMin, nextMsgIndex(ctx))
        }
    }

    private fun handlePhoneUseAlarm(ctx: Context, now: Long) {
        checkExpiredEatOrAway(ctx, now)
        if (!isScreenOn(ctx)) return
        if (isAppInForeground(ctx)) return
        if (isRealStudyRunning(ctx)) {
            resetState(ctx)
            return
        }
        val phase = DataStore.getSrPhase(ctx)
        if (phase == PHASE_READING_PHONE || phase == PHASE_EATING || phase == PHASE_AWAY) return

        if (isInQuietHours(ctx, now)) {
            scheduleAlarm(ctx, REQ_QUIET_END, EVENT_QUIET_END, nextQuietEndMs(ctx, now))
            return
        }
        if (isInCall(ctx)) {
            handleInCallTrigger(ctx, now)
            return
        }

        // স্ক্রিন এখন ON — কোনো পুরোনো screen_off টাইমস্ট্যাম্প থাকলে মুছে দাও যাতে ভুল ২৫-মি. রিসেট না হয়
        DataStore.setSrScreenOffSinceMs(ctx, 0L)
        if (DataStore.getSrUseSegmentStartMs(ctx) <= 0L) {
            // সেগমেন্ট আগে চালু না থাকলে অন্তত বর্তমান ব্যবধান যোগ করে ধরো যাতে ১ মি. না দেখায়
            val fallbackAddMs = when (phase) {
                PHASE_NORMAL -> DataStore.getSrAskDelayMin(ctx) * 60_000L
                else -> DataStore.getSrRepeatMin(ctx) * 60_000L
            }
            if (DataStore.getSrUseAccumMs(ctx) < fallbackAddMs) {
                DataStore.setSrUseAccumMs(ctx, fallbackAddMs)
            }
            DataStore.setSrUseSegmentStartMs(ctx, now)
        }
        val elapsedMin = getPhoneUseMinutes(ctx, now)
        val strictNow = isStrictModeActive(ctx, now)

        when (phase) {
            PHASE_NORMAL -> {
                val totalAccum = currentAccumulatedMs(ctx, now)
                val targetMs = DataStore.getSrAskDelayMin(ctx) * 60_000L
                if (totalAccum + 2000L < targetMs) {
                    val rem = (targetMs - totalAccum).coerceAtLeast(5_000L)
                    scheduleAlarm(ctx, REQ_PHONE_USE, EVENT_PHONE_USE, now + rem)
                    return
                }
                DataStore.setSrPhase(ctx, PHASE_ASKED)
                DataStore.setSrLevel(ctx, 1)
                SmartReminderReceiver.showReminder(ctx, MascotContent.KIND_ASK, 1, elapsedMin, nextMsgIndex(ctx))
                // স্ক্রিন চালুর সময় (০ মি.) থেকেই প্রথম রাগান্বিত পপ-আপের সময় হিসাব (অযথা ১০ মি. দেরি নয়)
                val firstAngryTargetMs = DataStore.getSrRepeatMin(ctx) * 60_000L
                val remToAngry = (firstAngryTargetMs - totalAccum).coerceAtLeast(60_000L)
                scheduleAlarm(ctx, REQ_PHONE_USE, EVENT_PHONE_USE, now + remToAngry)
            }
            PHASE_ASKED -> {
                DataStore.setSrPhase(ctx, PHASE_ANGRY)
                commitSmartWasteIfEligible(ctx, now)
                DataStore.setSrLevel(ctx, if (strictNow) 5 else 1)
                val kind = if (strictNow) MascotContent.KIND_STRICT else MascotContent.KIND_ANGRY
                val lvl = if (strictNow) 5 else 1
                val idx = nextMsgIndex(ctx)
                showAngryWithSeriousTracking(ctx, kind, lvl, elapsedMin, idx)
                scheduleAlarm(ctx, REQ_PHONE_USE, EVENT_PHONE_USE, now + nextPhoneIntervalMs(ctx, now))
            }
            PHASE_ANGRY -> {
                commitSmartWasteIfEligible(ctx, now)
                val nextLvl = if (strictNow) 5 else (DataStore.getSrLevel(ctx) + 1).coerceIn(1, 5)
                DataStore.setSrLevel(ctx, nextLvl)
                val kind = if (strictNow) MascotContent.KIND_STRICT else MascotContent.KIND_ANGRY
                val idx = nextMsgIndex(ctx)
                showAngryWithSeriousTracking(ctx, kind, nextLvl, elapsedMin, idx)
                scheduleAlarm(ctx, REQ_PHONE_USE, EVENT_PHONE_USE, now + nextPhoneIntervalMs(ctx, now))
            }
        }
    }

    private fun handleRecheckAlarm(ctx: Context, now: Long) {
        if (DataStore.getSrPhase(ctx) != PHASE_READING_PHONE) return
        if (!isScreenOn(ctx)) return
        if (isInQuietHours(ctx, now)) {
            scheduleAlarm(ctx, REQ_QUIET_END, EVENT_QUIET_END, nextQuietEndMs(ctx, now))
            return
        }
        if (isInCall(ctx)) {
            handleInCallTrigger(ctx, now)
            return
        }
        SmartReminderReceiver.showReminder(ctx, MascotContent.KIND_RECHECK, 1, 0, nextMsgIndex(ctx))
        scheduleAlarm(ctx, REQ_RECHECK, EVENT_RECHECK, now + DataStore.getSrRepeatMin(ctx) * 60_000L)
    }

    private fun handleReadResetAlarm(ctx: Context, now: Long) {
        if (DataStore.getSrPhase(ctx) != PHASE_READING_PHONE) return
        if (isScreenOn(ctx)) return
        endReminderStudySession(ctx)
        resetState(ctx)
        cancelAlarm(ctx, REQ_RECHECK)
        scheduleIdleIfEligible(ctx, now)
    }

    private fun handleIdleAlarm(ctx: Context, now: Long) {
        val idleMin = DataStore.getSrIdleMin(ctx)
        if (idleMin <= 0) return
        checkExpiredEatOrAway(ctx, now)
        if (isScreenOn(ctx)) return
        if (isRealStudyRunning(ctx)) return
        val phase = DataStore.getSrPhase(ctx)
        if (phase == PHASE_READING_PHONE || phase == PHASE_EATING || phase == PHASE_AWAY) return

        if (isInQuietHours(ctx, now)) {
            scheduleAlarm(ctx, REQ_QUIET_END, EVENT_QUIET_END, nextQuietEndMs(ctx, now))
            return
        }

        if (isInCall(ctx)) {
            handleInCallTrigger(ctx, now)
            return
        }
        val awayMin = getIdleMinutes(ctx, now)
        SmartReminderReceiver.showReminder(ctx, MascotContent.KIND_IDLE, 1, awayMin, nextMsgIndex(ctx))
        // ডিসপ্লে বন্ধ থাকলে প্রতি sr_idle_min (ডিফল্ট ৪৫ মি.) পরপর আবার নোটিফিকেশন দেবে
        scheduleAlarm(ctx, REQ_IDLE, EVENT_IDLE, now + idleMin * 60_000L)
    }

    // ------------------------------------------------------------------ scheduling helpers

    private fun evaluatePhoneUseSchedule(ctx: Context, now: Long) {
        if (!DataStore.isSrEnabled(ctx)) return
        if (isDailyGoalReached(ctx)) return
        if (!isScreenOn(ctx)) return
        if (isAppInForeground(ctx)) return
        if (isRealStudyRunning(ctx)) return

        checkExpiredEatOrAway(ctx, now)
        val phase = DataStore.getSrPhase(ctx)
        if (phase == PHASE_READING_PHONE || phase == PHASE_EATING || phase == PHASE_AWAY) return

        if (isInQuietHours(ctx, now)) {
            pauseSegment(ctx, now)
            scheduleAlarm(ctx, REQ_QUIET_END, EVENT_QUIET_END, nextQuietEndMs(ctx, now))
            return
        }

        DataStore.setSrScreenOffSinceMs(ctx, 0L)
        ensureSegmentRunning(ctx, now)
        val accum = currentAccumulatedMs(ctx, now)
        if (phase == PHASE_NORMAL) {
            val targetMs = DataStore.getSrAskDelayMin(ctx) * 60_000L
            val rem = (targetMs - accum).coerceAtLeast(3_000L)
            scheduleAlarm(ctx, REQ_PHONE_USE, EVENT_PHONE_USE, now + rem)
        } else if (phase == PHASE_ASKED || (phase == PHASE_ANGRY && DataStore.getSrLevel(ctx) == 0)) {
            val targetMs = DataStore.getSrRepeatMin(ctx) * 60_000L
            val rem = (targetMs - accum).coerceAtLeast(15_000L)
            scheduleAlarm(ctx, REQ_PHONE_USE, EVENT_PHONE_USE, now + rem)
        } else {
            scheduleAlarm(ctx, REQ_PHONE_USE, EVENT_PHONE_USE, now + nextPhoneIntervalMs(ctx, now))
        }
    }

    private fun scheduleIdleIfEligible(ctx: Context, now: Long) {
        val idleMin = DataStore.getSrIdleMin(ctx)
        if (idleMin <= 0) {
            cancelAlarm(ctx, REQ_IDLE)
            return
        }
        if (isRealStudyRunning(ctx)) return
        val phase = DataStore.getSrPhase(ctx)
        if (phase == PHASE_READING_PHONE || phase == PHASE_EATING || phase == PHASE_AWAY) return

        val base = maxOf(
            DataStore.getSrScreenOffSinceMs(ctx),
            DataStore.getSrLastStudyEndMs(ctx),
            now
        )
        scheduleAlarm(ctx, REQ_IDLE, EVENT_IDLE, base + idleMin * 60_000L)
    }

    fun checkExpiredBreaks(ctx: Context, now: Long = System.currentTimeMillis()) {
        checkExpiredEatOrAway(ctx.applicationContext, now)
    }

    private fun checkExpiredEatOrAway(ctx: Context, now: Long) {
        val phase = DataStore.getSrPhase(ctx)
        if (phase == PHASE_EATING) {
            val until = DataStore.getSrEatUntilMs(ctx)
            if (until in 1L..now) {
                endBreak(ctx, PHASE_EATING, until, null, scheduleNext = false)
            }
        } else if (phase == PHASE_AWAY) {
            val until = DataStore.getSrAwayUntilMs(ctx)
            if (until in 1L..now) {
                endBreak(ctx, PHASE_AWAY, until, null, scheduleNext = false)
            }
        }
    }

    private fun commitEatingTimeIfActive(ctx: Context, now: Long) {
        val start = DataStore.getSrEatStartMs(ctx)
        if (start > 0L) {
            val maxSec = (DataStore.getSrEatMin(ctx) * 60L) + 60L
            val sec = ((now - start) / 1000L).coerceIn(0L, maxSec)
            if (sec >= 30L) {
                DataStore.updateToday(ctx) { rec ->
                    rec.eatSec += sec
                    rec.synced = false
                }
            }
        }
        DataStore.setSrEatStartMs(ctx, 0L)
        DataStore.setSrEatUntilMs(ctx, 0L)
    }

    fun isSeriousActiveNow(ctx: Context, kind: String, level: Int, elapsedMin: Int): Boolean {
        if (!DataStore.isSrSeriousMode(ctx)) return false
        if (kind != MascotContent.KIND_ANGRY && kind != MascotContent.KIND_STRICT) return false
        if (!DataStore.canFireSeriousHourly(ctx)) return false
        val afterMin = DataStore.getSrSeriousAfterMin(ctx)
        val crossedTime = afterMin > 0 && elapsedMin >= afterMin
        val reachedExtreme = DataStore.getSrSeriousDailyCount(ctx) >= 2 && level >= 4
        return crossedTime || reachedExtreme
    }

    private fun showAngryWithSeriousTracking(ctx: Context, kind: String, level: Int, elapsedMin: Int, msgIndex: Int) {
        if (DataStore.isSrSeriousMode(ctx) && (kind == MascotContent.KIND_ANGRY || kind == MascotContent.KIND_STRICT)) {
            val afterMin = DataStore.getSrSeriousAfterMin(ctx)
            val crossedTime = afterMin > 0 && elapsedMin >= afterMin
            if (level >= 4 || kind == MascotContent.KIND_STRICT || crossedTime) {
                DataStore.recordSeriousDailyExtreme(ctx)
            }
        }
        val willFireSerious = isSeriousActiveNow(ctx, kind, level, elapsedMin)
        SmartReminderReceiver.showReminder(ctx, kind, level, elapsedMin, msgIndex)
        if (willFireSerious) {
            DataStore.recordSeriousHourlyFire(ctx)
        }
    }

    private fun isStrictModeActive(ctx: Context, now: Long): Boolean {
        val thr = DataStore.getSrStrictAfterMin(ctx)
        return thr > 0 && getPhoneUseMinutes(ctx, now) >= thr
    }

    private fun nextPhoneIntervalMs(ctx: Context, now: Long): Long {
        return if (isStrictModeActive(ctx, now)) {
            2 * 60_000L
        } else {
            DataStore.getSrRepeatMin(ctx) * 60_000L
        }
    }

    private fun nextMsgIndex(ctx: Context): Int {
        val cur = DataStore.getSrMsgIndex(ctx)
        DataStore.setSrMsgIndex(ctx, cur + 1)
        return cur
    }

    fun getPhoneUseMinutes(ctx: Context, now: Long): Int {
        val ms = currentAccumulatedMs(ctx, now)
        return ((ms + 30_000L) / 60_000L).toInt().coerceAtLeast(1)
    }

    fun getIdleMinutes(ctx: Context, now: Long): Int {
        val off = DataStore.getSrScreenOffSinceMs(ctx)
        val lastEnd = DataStore.getSrLastStudyEndMs(ctx)
        val ref = when {
            off > 0L && lastEnd > 0L -> maxOf(off, lastEnd)
            off > 0L -> off
            lastEnd > 0L -> lastEnd
            else -> now - DataStore.getSrIdleMin(ctx) * 60_000L
        }
        return (((now - ref).coerceAtLeast(60_000L) + 30_000L) / 60_000L).toInt().coerceAtLeast(1)
    }

    private fun ensureSegmentRunning(ctx: Context, now: Long) {
        if (DataStore.getSrUseSegmentStartMs(ctx) <= 0L) {
            DataStore.setSrUseSegmentStartMs(ctx, now)
        }
    }

    private fun startOrUpdateOnlineStudyService(ctx: Context, serviceAlreadyRunning: Boolean) {
        markInternalOp()
        val action = if (serviceAlreadyRunning) FlipTrackerService.ACTION_ONLINE_CHANGED else FlipTrackerService.ACTION_START_ONLINE_ONLY
        val i = Intent(ctx, FlipTrackerService::class.java).setAction(action)
        try {
            if (serviceAlreadyRunning) ctx.startService(i)
            else ContextCompat.startForegroundService(ctx, i)
        } catch (_: Exception) {
            launchMainStudyFallback(ctx, action)
        }
    }

    private fun pauseReadingPhoneSession(ctx: Context) {
        markInternalOp()
        if (DataStore.isSrSessionStartedByReminder(ctx)) {
            try {
                ctx.startService(Intent(ctx, FlipTrackerService::class.java).setAction(FlipTrackerService.ACTION_STOP))
            } catch (_: Exception) {}
        } else {
            DataStore.setOnlineStudy(ctx, DataStore.getSrPrevOnline(ctx))
            if (DataStore.loadRuntimeState(ctx).running) {
                try {
                    ctx.startService(Intent(ctx, FlipTrackerService::class.java).setAction(FlipTrackerService.ACTION_ONLINE_CHANGED))
                } catch (_: Exception) {}
            }
        }
    }

    private fun resumeReadingPhoneSession(ctx: Context) {
        markInternalOp()
        DataStore.setOnlineStudy(ctx, true)
        val rt = DataStore.loadRuntimeState(ctx)
        startOrUpdateOnlineStudyService(ctx, rt.running)
    }

    private fun endReminderStudySession(ctx: Context) {
        markInternalOp()
        val prevOnline = DataStore.getSrPrevOnline(ctx)
        DataStore.setOnlineStudy(ctx, prevOnline)
        if (DataStore.isSrSessionStartedByReminder(ctx)) {
            if (DataStore.loadRuntimeState(ctx).running) {
                try {
                    ctx.startService(Intent(ctx, FlipTrackerService::class.java).setAction(FlipTrackerService.ACTION_STOP))
                } catch (_: Exception) {}
            }
        } else {
            if (DataStore.loadRuntimeState(ctx).running) {
                try {
                    ctx.startService(Intent(ctx, FlipTrackerService::class.java).setAction(FlipTrackerService.ACTION_ONLINE_CHANGED))
                } catch (_: Exception) {}
            }
        }
        DataStore.setSrSessionStartedByReminder(ctx, false)
    }

    private fun launchMainStudyFallback(ctx: Context, action: String) {
        try {
            val open = Intent(ctx, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra(EXTRA_START_STUDY_FALLBACK, action)
            }
            ctx.startActivity(open)
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ state & utility helpers

    private fun pauseSegment(ctx: Context, now: Long) {
        val segStart = DataStore.getSrUseSegmentStartMs(ctx)
        if (segStart > 0L) {
            val delta = (now - segStart).coerceAtLeast(0L)
            DataStore.setSrUseAccumMs(ctx, DataStore.getSrUseAccumMs(ctx) + delta)
            DataStore.setSrUseSegmentStartMs(ctx, 0L)
        }
    }

    private fun currentAccumulatedMs(ctx: Context, now: Long): Long {
        val base = DataStore.getSrUseAccumMs(ctx)
        val segStart = DataStore.getSrUseSegmentStartMs(ctx)
        return if (segStart > 0L) base + (now - segStart).coerceAtLeast(0L) else base
    }

    private fun resetState(ctx: Context) {
        DataStore.setSrPhase(ctx, PHASE_NORMAL)
        DataStore.setSrLevel(ctx, 0)
        DataStore.setSrUseAccumMs(ctx, 0L)
        DataStore.setSrUseSegmentStartMs(ctx, 0L)
        DataStore.setSrSessionStartedByReminder(ctx, false)
        DataStore.setSrEatStartMs(ctx, 0L)
        DataStore.setSrEatUntilMs(ctx, 0L)
        DataStore.setSrAwayUntilMs(ctx, 0L)
        DataStore.setSrAwayTotalMin(ctx, 0)
        DataStore.clearSrPendingFallback(ctx)
    }

    fun dismissReminderUi(ctx: Context) {
        try {
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(NOTIF_REMINDER_ID)
        } catch (_: Exception) {}
        SmartReminderPopupOverlay.dismiss()
    }

    fun isScreenOn(ctx: Context): Boolean {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isInteractive
    }

    private fun isAppInForeground(ctx: Context): Boolean = appInForeground || DataStore.isSrAppForeground(ctx)

    private fun isRealStudyRunning(ctx: Context): Boolean {
        val rt = DataStore.loadRuntimeState(ctx)
        return rt.running && rt.mode == "STUDY"
    }

    fun isDailyGoalReached(ctx: Context): Boolean {
        val goalMin = DataStore.getDailyGoalHours(ctx) * 60
        return DataStore.getToday(ctx).totalStudyMinutes() >= goalMin
    }

    fun isInQuietHours(ctx: Context, nowMs: Long): Boolean {
        if (!DataStore.isSrQuietOn(ctx)) return false
        val start = DataStore.getSrQuietStartMin(ctx)
        val end = DataStore.getSrQuietEndMin(ctx)
        if (start == end) return false
        val cal = Calendar.getInstance().apply { timeInMillis = nowMs }
        val cur = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        return if (start < end) {
            cur in start until end
        } else {
            cur >= start || cur < end
        }
    }

    fun nextQuietEndMs(ctx: Context, nowMs: Long): Long {
        val end = DataStore.getSrQuietEndMin(ctx)
        val cal = Calendar.getInstance().apply {
            timeInMillis = nowMs
            set(Calendar.HOUR_OF_DAY, end / 60)
            set(Calendar.MINUTE, end % 60)
            set(Calendar.SECOND, 5)
            set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= nowMs) {
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return cal.timeInMillis
    }

    private fun scheduleAlarm(ctx: Context, reqCode: Int, event: String, triggerAtMs: Long) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val safeTrigger = maxOf(triggerAtMs, System.currentTimeMillis() + 2_000L)
        val pi = alarmPendingIntent(ctx, reqCode, event)
        try {
            val isNonUrgent = reqCode == REQ_IDLE || reqCode == REQ_GAP_PROMPT
            if (!isNonUrgent && (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms())) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, safeTrigger, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, safeTrigger, pi)
            }
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, safeTrigger, pi)
        }
    }

    private fun cancelAlarm(ctx: Context, reqCode: Int) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(alarmPendingIntent(ctx, reqCode, ""))
    }

    private fun handleCallRemindAlarm(ctx: Context, now: Long) {
        if (!isInCall(ctx)) {
            // কল শেষ -> স্বাভাবিক সিডিউলে ফিরে যাও
            if (isScreenOn(ctx)) evaluatePhoneUseSchedule(ctx, now)
            else scheduleIdleIfEligible(ctx, now)
            return
        }
        if (isInQuietHours(ctx, now)) {
            scheduleAlarm(ctx, REQ_QUIET_END, EVENT_QUIET_END, nextQuietEndMs(ctx, now))
            return
        }
        handleInCallTrigger(ctx, now)
    }

    private fun handleInCallTrigger(ctx: Context, now: Long) {
        val callMin = DataStore.getSrCallVibMin(ctx)
        if (callMin > 0) {
            vibrateThreeTimes(ctx)
            scheduleAlarm(ctx, REQ_CALL_REMIND, EVENT_CALL_REMIND, now + callMin * 60_000L)
        } else {
            // কলের সময় ভাইব্রেশন বন্ধ থাকলে শুধু ৩ মি. পর কল শেষ হয়েছে কি না চেক করবে
            scheduleAlarm(ctx, REQ_CALL_REMIND, EVENT_CALL_REMIND, now + 3 * 60_000L)
        }
    }

    fun isInCall(ctx: Context): Boolean {
        return try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val m = am.mode
            m == AudioManager.MODE_IN_CALL ||
                m == AudioManager.MODE_IN_COMMUNICATION ||
                m == AudioManager.MODE_RINGTONE
        } catch (_: Exception) {
            false
        }
    }

    private fun vibrateThreeTimes(ctx: Context) {
        try {
            val vib = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            val pat = longArrayOf(0, 140, 120, 140, 120, 140)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vib.vibrate(VibrationEffect.createWaveform(pat, -1))
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(pat, -1)
            }
        } catch (_: Exception) {}
    }

    fun cancelAllAlarms(ctx: Context) {
        cancelAlarm(ctx, REQ_PHONE_USE)
        cancelAlarm(ctx, REQ_RECHECK)
        cancelAlarm(ctx, REQ_READ_RESET)
        cancelAlarm(ctx, REQ_IDLE)
        cancelAlarm(ctx, REQ_QUIET_END)
        cancelAlarm(ctx, REQ_POPUP_FALLBACK)
        cancelAlarm(ctx, REQ_EAT_END)
        cancelAlarm(ctx, REQ_AWAY_PRE)
        cancelAlarm(ctx, REQ_AWAY_END)
        cancelAlarm(ctx, REQ_CALL_REMIND)
    }

    private fun alarmPendingIntent(ctx: Context, reqCode: Int, event: String): PendingIntent {
        val i = Intent(ctx, SmartReminderReceiver::class.java).apply {
            putExtra(EXTRA_EVENT, event)
        }
        return PendingIntent.getBroadcast(
            ctx, reqCode, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun handleMorningResetAndGreeting(ctx: Context, now: Long, fireGreeting: Boolean) {
        resetState(ctx)
        val today = DataStore.todayIso()
        DataStore.setSrLastActiveDate(ctx, today)
        DataStore.resetSeriousDailyCount(ctx)
        if (fireGreeting && !isInQuietHours(ctx, now) && !isDailyGoalReached(ctx) &&
            DataStore.getSrMorningGreetedDate(ctx) != today
        ) {
            DataStore.setSrMorningGreetedDate(ctx, today)
            SmartReminderReceiver.showReminder(ctx, MascotContent.KIND_MORNING, 1, 0, nextMsgIndex(ctx))
        }
    }

    private fun endBreak(ctx: Context, type: String, endMs: Long, reasonOrNull: String?, scheduleNext: Boolean) {
        if (type == PHASE_EATING) {
            val start = DataStore.getSrEatStartMs(ctx)
            val until = DataStore.getSrEatUntilMs(ctx)
            val cappedEnd = if (until > 0L) minOf(endMs, until + 60_000L) else endMs
            if (start > 0L && cappedEnd - start >= 30_000L) {
                val segs = DataStore.splitByDay(start, cappedEnd)
                if (segs.isNotEmpty()) {
                    val map = DataStore.loadAllDays(ctx)
                    for ((iso, sec) in segs) {
                        if (sec <= 0L) continue
                        val rec = map[iso] ?: DayRecord(date = iso, subject = DataStore.getCurrentSubject(ctx))
                        rec.eatSec += sec
                        rec.synced = false
                        map[iso] = rec
                    }
                    DataStore.saveAllDays(ctx, map)
                }
                DataStore.recordBreakLedger(ctx, start, cappedEnd, PHASE_EATING)
            }
            DataStore.setSrEatStartMs(ctx, 0L)
            DataStore.setSrEatUntilMs(ctx, 0L)
            cancelAlarm(ctx, REQ_EAT_END)
        } else if (type == PHASE_AWAY) {
            val start = DataStore.getSrAwayStartMs(ctx)
            val until = DataStore.getSrAwayUntilMs(ctx)
            val cappedEnd = if (until > 0L) minOf(endMs, until + 60_000L) else endMs
            val reason = reasonOrNull?.trim()?.takeIf { it.isNotEmpty() } ?: DataStore.getSrAwayReason(ctx)
            if (start > 0L && cappedEnd - start >= 30_000L) {
                DataStore.addAway(ctx, start, cappedEnd, reason)
                DataStore.recordBreakLedger(ctx, start, cappedEnd, PHASE_AWAY)
            }
            DataStore.setSrAwayStartMs(ctx, 0L)
            DataStore.setSrAwayUntilMs(ctx, 0L)
            DataStore.setSrAwayTotalMin(ctx, 0)
            cancelAlarm(ctx, REQ_AWAY_PRE)
            cancelAlarm(ctx, REQ_AWAY_END)
        }
        resetState(ctx)
        if (scheduleNext) {
            if (isScreenOn(ctx) && !isAppInForeground(ctx)) {
                evaluatePhoneUseSchedule(ctx, endMs)
            } else if (!isScreenOn(ctx)) {
                scheduleIdleIfEligible(ctx, endMs)
            }
        }
    }

    fun getActiveBreakInfo(ctx: Context): ActiveBreakInfo? {
        val appCtx = ctx.applicationContext
        val now = System.currentTimeMillis()
        checkExpiredEatOrAway(appCtx, now)
        val phase = DataStore.getSrPhase(appCtx)
        return when (phase) {
            PHASE_EATING -> {
                val until = DataStore.getSrEatUntilMs(appCtx)
                if (until > now) ActiveBreakInfo(PHASE_EATING, until - now, DataStore.getSrEatMin(appCtx), "খাওয়া") else null
            }
            PHASE_AWAY -> {
                val until = DataStore.getSrAwayUntilMs(appCtx)
                if (until > now) ActiveBreakInfo(PHASE_AWAY, until - now, DataStore.getSrAwayTotalMin(appCtx), DataStore.getSrAwayReason(appCtx)) else null
            }
            else -> null
        }
    }

    fun finishEatingNow(ctx: Context) {
        val appCtx = ctx.applicationContext
        val now = System.currentTimeMillis()
        cancelPendingPopupFallback(appCtx)
        dismissReminderUi(appCtx)
        if (DataStore.getSrPhase(appCtx) == PHASE_EATING) {
            endBreak(appCtx, PHASE_EATING, now, null, scheduleNext = true)
        }
    }

    fun returnFromAway(ctx: Context) {
        val appCtx = ctx.applicationContext
        val now = System.currentTimeMillis()
        cancelPendingPopupFallback(appCtx)
        dismissReminderUi(appCtx)
        if (DataStore.getSrPhase(appCtx) == PHASE_AWAY) {
            endBreak(appCtx, PHASE_AWAY, now, null, scheduleNext = true)
        }
    }

    private fun scheduleGapPromptIfEligible(ctx: Context, now: Long, nextAngryAtMs: Long) {
        if (!DataStore.isGapPhonePopupOn(ctx)) return
        if (DataStore.getLastGapPopupDate(ctx) == DataStore.todayIso()) return
        if (isInQuietHours(ctx, now) || isDailyGoalReached(ctx) || isRealStudyRunning(ctx)) return
        val phase = DataStore.getSrPhase(ctx)
        if (phase == PHASE_EATING || phase == PHASE_AWAY || phase == PHASE_READING_PHONE) return
        val gaps = DataStore.getUnansweredGaps(ctx)
        if (gaps.isEmpty()) return

        val waitMs = DataStore.getGapPhoneMin(ctx) * 60_000L
        val targetMs = now + waitMs
        // পরের রাগ-মেসেজ আসতে ৩ মিনিটের কম বাকি থাকলে এই সেশনে বাদ, এবং কমপক্ষে ২ মি. দূরত্ব
        if (nextAngryAtMs > now && (nextAngryAtMs - now) < 3 * 60_000L) return
        val safeTarget = if (kotlin.math.abs(nextAngryAtMs - targetMs) < 90_000L) {
            minOf(targetMs, nextAngryAtMs - 90_000L).coerceAtLeast(now + 60_000L)
        } else targetMs
        scheduleAlarm(ctx, REQ_GAP_PROMPT, EVENT_GAP_PROMPT, safeTarget)
    }

    private fun handleGapPromptAlarm(ctx: Context, now: Long) {
        if (!DataStore.isGapPhonePopupOn(ctx)) return
        if (DataStore.getLastGapPopupDate(ctx) == DataStore.todayIso()) return
        if (!isScreenOn(ctx) || isAppInForeground(ctx) || isRealStudyRunning(ctx)) return
        if (isInQuietHours(ctx, now) || isDailyGoalReached(ctx) || isInCall(ctx)) return
        val phase = DataStore.getSrPhase(ctx)
        if (phase == PHASE_EATING || phase == PHASE_AWAY || phase == PHASE_READING_PHONE) return
        val gap = DataStore.getUnansweredGaps(ctx).firstOrNull() ?: return
        DataStore.setLastGapPopupDate(ctx, DataStore.todayIso())
        if (!SmartReminderPopupOverlay.showGapPrompt(ctx, gap)) {
            SmartReminderReceiver.showGapNotification(ctx, gap)
        }
    }
}
