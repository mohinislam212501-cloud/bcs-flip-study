package com.bcs.flipstudy

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import androidx.core.content.ContextCompat
import java.util.Calendar

object SmartReminderManager {

    const val PHASE_NORMAL = "NORMAL"
    const val PHASE_ASKED = "ASKED"
    const val PHASE_READING_PHONE = "READING_PHONE"
    const val PHASE_ANGRY = "ANGRY"

    const val SR_OFF_RESET_MIN = 25

    const val CHANNEL_REMINDER = "bcs_smart_reminder_v7"
    const val CHANNEL_WATCHER = "bcs_smart_watcher_v7"
    const val NOTIF_REMINDER_ID = 1004
    const val NOTIF_WATCHER_ID = 1005

    const val EXTRA_LEVEL = "mascot_level"
    const val EXTRA_KIND = "sr_kind"
    const val EXTRA_EVENT = "sr_event"
    const val EXTRA_START_STUDY_FALLBACK = "sr_start_study_fallback"

    const val EVENT_PHONE_USE = "EVENT_PHONE_USE"
    const val EVENT_RECHECK = "EVENT_RECHECK"
    const val EVENT_READ_RESET = "EVENT_READ_RESET"
    const val EVENT_IDLE = "EVENT_IDLE"
    const val EVENT_QUIET_END = "EVENT_QUIET_END"

    private const val REQ_PHONE_USE = 4101
    private const val REQ_RECHECK = 4102
    private const val REQ_READ_RESET = 4103
    private const val REQ_IDLE = 4104
    private const val REQ_QUIET_END = 4105

    @Volatile
    private var appInForeground = false

    @Volatile
    private var internalOpUntilMs = 0L

    private fun markInternalOp() {
        internalOpUntilMs = System.currentTimeMillis() + 2500L
    }

    private fun isInternalOp(): Boolean = System.currentTimeMillis() < internalOpUntilMs

    // ------------------------------------------------------------------ lifecycle & migration

    fun ensureMigratedAndStarted(ctx: Context) {
        val appCtx = ctx.applicationContext
        if (!DataStore.isSrMigratedV7(appCtx)) {
            try {
                val am = appCtx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val oldPi = PendingIntent.getBroadcast(
                    appCtx, 3003, Intent(appCtx, WasteReminderReceiver::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                am.cancel(oldPi)
            } catch (_: Exception) {}
            try {
                val nm = appCtx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.cancel(1003)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    nm.deleteNotificationChannel("bcs_waste_alerts_v4")
                }
            } catch (_: Exception) {}
            DataStore.setSrMigratedV7(appCtx, true)
        }

        if (DataStore.isSrEnabled(appCtx)) {
            startWatcherService(appCtx)
        } else {
            stopWatcherService(appCtx)
        }
    }

    fun onBootOrUpdate(ctx: Context) {
        val appCtx = ctx.applicationContext
        ensureMigratedAndStarted(appCtx)
        if (!DataStore.isSrEnabled(appCtx)) return
        val now = System.currentTimeMillis()
        if (isScreenOn(appCtx)) {
            evaluatePhoneUseSchedule(appCtx, now)
        } else {
            scheduleIdleIfEligible(appCtx, now)
        }
    }

    fun onSettingsChanged(ctx: Context) {
        val appCtx = ctx.applicationContext
        val now = System.currentTimeMillis()
        if (!DataStore.isSrEnabled(appCtx)) {
            // মূল সুইচ বন্ধ: সব অ্যালার্ম/নোটিফিকেশন/পপ-আপ ও ওয়াচার সার্ভিস বন্ধ
            if (DataStore.getSrPhase(appCtx) == PHASE_READING_PHONE) {
                endReminderStudySession(appCtx)
            }
            cancelAllAlarms(appCtx)
            dismissReminderUi(appCtx)
            resetState(appCtx)
            stopWatcherService(appCtx)
            return
        }

        startWatcherService(appCtx)
        if (isDailyGoalReached(appCtx)) {
            cancelAllAlarms(appCtx)
            dismissReminderUi(appCtx)
            return
        }

        val phase = DataStore.getSrPhase(appCtx)
        if (phase == PHASE_READING_PHONE) {
            if (isScreenOn(appCtx)) {
                scheduleAlarm(appCtx, REQ_RECHECK, EVENT_RECHECK, now + DataStore.getSrReadRecheckMin(appCtx) * 60_000L)
            } else {
                scheduleAlarm(appCtx, REQ_READ_RESET, EVENT_READ_RESET, now + DataStore.getSrReadResetMin(appCtx) * 60_000L)
            }
        } else {
            if (isScreenOn(appCtx)) {
                cancelAlarm(appCtx, REQ_IDLE)
                evaluatePhoneUseSchedule(appCtx, now)
            } else {
                cancelAlarm(appCtx, REQ_PHONE_USE)
                scheduleIdleIfEligible(appCtx, now)
            }
        }
    }

    fun startWatcherService(ctx: Context) {
        try {
            val i = Intent(ctx, ReminderWatcherService::class.java).setAction(ReminderWatcherService.ACTION_START_WATCHER)
            ContextCompat.startForegroundService(ctx, i)
        } catch (_: Exception) {}
    }

    fun stopWatcherService(ctx: Context) {
        try {
            ctx.stopService(Intent(ctx, ReminderWatcherService::class.java))
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ app foreground & screen events

    fun onAppForeground(ctx: Context, foreground: Boolean) {
        val appCtx = ctx.applicationContext
        appInForeground = foreground
        DataStore.setSrAppForeground(appCtx, foreground)
        if (!DataStore.isSrEnabled(appCtx)) return

        val now = System.currentTimeMillis()
        if (foreground) {
            // BCS অ্যাপ সামনে থাকলে টাইমার থামবে, রিসেট হবে না
            pauseSegment(appCtx, now)
            cancelAlarm(appCtx, REQ_PHONE_USE)
            cancelAlarm(appCtx, REQ_QUIET_END)
        } else {
            if (isScreenOn(appCtx)) {
                evaluatePhoneUseSchedule(appCtx, now)
            }
        }
    }

    fun onScreenOn(ctx: Context) {
        val appCtx = ctx.applicationContext
        cancelAlarm(appCtx, REQ_IDLE)
        cancelAlarm(appCtx, REQ_READ_RESET)
        if (!DataStore.isSrEnabled(appCtx)) return

        val now = System.currentTimeMillis()
        val offSince = DataStore.getSrScreenOffSinceMs(appCtx)
        DataStore.setSrScreenOffSinceMs(appCtx, 0L)
        DataStore.setSrIdleFiredEpisode(appCtx, false)

        if (isDailyGoalReached(appCtx)) {
            cancelAllAlarms(appCtx)
            dismissReminderUi(appCtx)
            return
        }

        val phase = DataStore.getSrPhase(appCtx)
        if (phase == PHASE_READING_PHONE) {
            val resetMs = DataStore.getSrReadResetMin(appCtx) * 60_000L
            if (offSince > 0L && (now - offSince) >= resetMs) {
                // ডিসপ্লে রিসেট সময়ের বেশি বন্ধ ছিল -> সেশন শেষ ও NORMAL
                endReminderStudySession(appCtx)
                resetState(appCtx)
                evaluatePhoneUseSchedule(appCtx, now)
            } else {
                // রিসেট সময়ের আগেই স্ক্রিন ON -> অনলাইন পড়া পুনরায় চালু
                resumeReadingPhoneSession(appCtx)
                scheduleAlarm(appCtx, REQ_RECHECK, EVENT_RECHECK, now + DataStore.getSrReadRecheckMin(appCtx) * 60_000L)
            }
            return
        }

        // NORMAL / ASKED / ANGRY: ২৫ মিনিট বা বেশি বন্ধ থাকলে lazy রিসেট
        if (offSince > 0L && (now - offSince) >= SR_OFF_RESET_MIN * 60_000L) {
            resetState(appCtx)
            dismissReminderUi(appCtx)
        }

        evaluatePhoneUseSchedule(appCtx, now)
    }

    fun onScreenOff(ctx: Context) {
        val appCtx = ctx.applicationContext
        val now = System.currentTimeMillis()
        DataStore.setSrScreenOffSinceMs(appCtx, now)
        pauseSegment(appCtx, now)
        cancelAlarm(appCtx, REQ_PHONE_USE)
        cancelAlarm(appCtx, REQ_QUIET_END)
        SmartReminderPopupOverlay.dismiss()

        if (!DataStore.isSrEnabled(appCtx)) return
        if (isDailyGoalReached(appCtx)) {
            cancelAllAlarms(appCtx)
            return
        }

        val phase = DataStore.getSrPhase(appCtx)
        if (phase == PHASE_READING_PHONE) {
            // পড়া গোনা স্ক্রিন বন্ধ হওয়ার মুহূর্তে থামবে (বন্ধ থাকা সময় পড়া হিসেবে নয়)
            cancelAlarm(appCtx, REQ_RECHECK)
            pauseReadingPhoneSession(appCtx)
            val resetMs = DataStore.getSrReadResetMin(appCtx) * 60_000L
            scheduleAlarm(appCtx, REQ_READ_RESET, EVENT_READ_RESET, now + resetMs)
            return
        }

        scheduleIdleIfEligible(appCtx, now)
    }

    // ------------------------------------------------------------------ study state hooks

    fun onStudyStateChanged(ctx: Context) {
        val appCtx = ctx.applicationContext
        if (!DataStore.isSrEnabled(appCtx)) return
        if (isInternalOp()) return

        val now = System.currentTimeMillis()
        val rt = DataStore.loadRuntimeState(appCtx)
        val phase = DataStore.getSrPhase(appCtx)

        if (rt.running && rt.mode == "STUDY") {
            // ব্যবহারকারী নিজে পড়া শুরু করেছে -> সব রিমাইন্ডার বাতিল ও রিসেট
            if (phase != PHASE_READING_PHONE) {
                cancelAllAlarms(appCtx)
                dismissReminderUi(appCtx)
                resetState(appCtx)
                DataStore.setSrIdleFiredEpisode(appCtx, false)
            }
            return
        }

        // পড়া বন্ধ বা WASTE মোডে এসেছে
        DataStore.setSrLastStudyEndMs(appCtx, now)
        DataStore.setSrIdleFiredEpisode(appCtx, false)

        if (phase == PHASE_READING_PHONE) {
            // READING_PHONE চলাকালীন ব্যবহারকারী নিজে প্লে/পজ বা বন্ধ করেছে
            cancelAlarm(appCtx, REQ_RECHECK)
            cancelAlarm(appCtx, REQ_READ_RESET)
            resetState(appCtx)
        }

        if (isDailyGoalReached(appCtx)) {
            cancelAllAlarms(appCtx)
            dismissReminderUi(appCtx)
            return
        }

        if (isScreenOn(appCtx)) {
            evaluatePhoneUseSchedule(appCtx, now)
        } else {
            scheduleIdleIfEligible(appCtx, now)
        }
    }

    fun onStudyProgressUpdated(ctx: Context) {
        val appCtx = ctx.applicationContext
        if (!DataStore.isSrEnabled(appCtx)) return
        if (isDailyGoalReached(appCtx)) {
            cancelAllAlarms(appCtx)
            dismissReminderUi(appCtx)
        }
    }

    // ------------------------------------------------------------------ user actions (notification / popup / dialog)

    fun onReadingYes(ctx: Context) {
        val appCtx = ctx.applicationContext
        dismissReminderUi(appCtx)
        if (!DataStore.isSrEnabled(appCtx)) return
        if (isDailyGoalReached(appCtx)) {
            cancelAllAlarms(appCtx)
            return
        }

        val now = System.currentTimeMillis()
        val phase = DataStore.getSrPhase(appCtx)
        if (phase != PHASE_READING_PHONE) {
            val rt = DataStore.loadRuntimeState(appCtx)
            DataStore.setSrPrevOnline(appCtx, DataStore.isOnlineStudy(appCtx))
            DataStore.setSrSessionStartedByReminder(appCtx, !rt.running)
            DataStore.setOnlineStudy(appCtx, true)
            DataStore.setSrPhase(appCtx, PHASE_READING_PHONE)
            DataStore.setSrLevel(appCtx, 0)
            DataStore.setSrUseAccumMs(appCtx, 0L)
            DataStore.setSrUseSegmentStartMs(appCtx, 0L)
            DataStore.setSrIdleFiredEpisode(appCtx, false)

            cancelAlarm(appCtx, REQ_PHONE_USE)
            cancelAlarm(appCtx, REQ_IDLE)
            cancelAlarm(appCtx, REQ_READ_RESET)
            cancelAlarm(appCtx, REQ_QUIET_END)

            startOrUpdateOnlineStudyService(appCtx, rt.running)
        }
        scheduleAlarm(appCtx, REQ_RECHECK, EVENT_RECHECK, now + DataStore.getSrReadRecheckMin(appCtx) * 60_000L)
    }

    fun onReadingNo(ctx: Context) {
        val appCtx = ctx.applicationContext
        dismissReminderUi(appCtx)
        if (!DataStore.isSrEnabled(appCtx)) return
        if (isDailyGoalReached(appCtx)) {
            cancelAllAlarms(appCtx)
            return
        }

        val now = System.currentTimeMillis()
        if (DataStore.getSrPhase(appCtx) == PHASE_READING_PHONE) {
            endReminderStudySession(appCtx)
            cancelAlarm(appCtx, REQ_RECHECK)
            cancelAlarm(appCtx, REQ_READ_RESET)
        }

        DataStore.setSrPhase(appCtx, PHASE_ANGRY)
        DataStore.setSrLevel(appCtx, 1)
        DataStore.setSrUseAccumMs(appCtx, 0L)
        DataStore.setSrUseSegmentStartMs(appCtx, 0L)

        if (!isScreenOn(appCtx)) {
            scheduleIdleIfEligible(appCtx, now)
            return
        }
        if (isInQuietHours(appCtx, now)) {
            scheduleAlarm(appCtx, REQ_QUIET_END, EVENT_QUIET_END, nextQuietEndMs(appCtx, now))
            return
        }

        SmartReminderReceiver.showReminder(appCtx, MascotContent.KIND_ANGRY, 1)
        scheduleAlarm(appCtx, REQ_PHONE_USE, EVENT_PHONE_USE, now + DataStore.getSrRepeatMin(appCtx) * 60_000L)
    }

    fun onStartStudyFromIdle(ctx: Context) {
        val appCtx = ctx.applicationContext
        dismissReminderUi(appCtx)
        cancelAllAlarms(appCtx)
        resetState(appCtx)
        DataStore.setSrIdleFiredEpisode(appCtx, false)

        val rt = DataStore.loadRuntimeState(appCtx)
        if (!(rt.running && rt.mode == "STUDY")) {
            val i = Intent(appCtx, FlipTrackerService::class.java).setAction(FlipTrackerService.ACTION_MANUAL_STUDY)
            try {
                if (rt.running) appCtx.startService(i)
                else ContextCompat.startForegroundService(appCtx, i)
            } catch (_: Exception) {
                launchMainStudyFallback(appCtx, FlipTrackerService.ACTION_MANUAL_STUDY)
            }
        }
    }

    fun onSnoozeIdle(ctx: Context) {
        dismissReminderUi(ctx.applicationContext)
    }

    // ------------------------------------------------------------------ alarm handlers

    fun handleAlarmEvent(ctx: Context, event: String) {
        val appCtx = ctx.applicationContext
        if (!DataStore.isSrEnabled(appCtx)) {
            cancelAllAlarms(appCtx)
            return
        }
        if (isDailyGoalReached(appCtx)) {
            cancelAllAlarms(appCtx)
            dismissReminderUi(appCtx)
            return
        }

        val now = System.currentTimeMillis()
        when (event) {
            EVENT_READ_RESET -> handleReadResetAlarm(appCtx, now)
            EVENT_IDLE -> handleIdleAlarm(appCtx, now)
            EVENT_RECHECK -> handleRecheckAlarm(appCtx, now)
            EVENT_QUIET_END -> {
                if (isScreenOn(appCtx) && !isAppInForeground(appCtx)) {
                    evaluatePhoneUseSchedule(appCtx, now)
                }
            }
            else -> handlePhoneUseAlarm(appCtx, now)
        }
    }

    private fun handlePhoneUseAlarm(ctx: Context, now: Long) {
        if (!isScreenOn(ctx)) return
        if (isAppInForeground(ctx)) return
        if (isRealStudyRunning(ctx)) {
            resetState(ctx)
            return
        }
        if (DataStore.getSrPhase(ctx) == PHASE_READING_PHONE) return

        if (isInQuietHours(ctx, now)) {
            scheduleAlarm(ctx, REQ_QUIET_END, EVENT_QUIET_END, nextQuietEndMs(ctx, now))
            return
        }

        val phase = DataStore.getSrPhase(ctx)
        val repeatMs = DataStore.getSrRepeatMin(ctx) * 60_000L

        when (phase) {
            PHASE_NORMAL -> {
                val totalAccum = currentAccumulatedMs(ctx, now)
                val targetMs = DataStore.getSrAskDelayMin(ctx) * 60_000L
                if (totalAccum + 2000L < targetMs) {
                    val rem = (targetMs - totalAccum).coerceAtLeast(5_000L)
                    scheduleAlarm(ctx, REQ_PHONE_USE, EVENT_PHONE_USE, now + rem)
                    return
                }
                DataStore.setSrPhase(ctx, PHASE_ASKED)
                DataStore.setSrLevel(ctx, 1)
                DataStore.setSrUseAccumMs(ctx, targetMs)
                DataStore.setSrUseSegmentStartMs(ctx, 0L)
                SmartReminderReceiver.showReminder(ctx, MascotContent.KIND_ASK, 1)
                // উত্তর না দিলে sr_repeat_min পর "না" ধরা হবে
                scheduleAlarm(ctx, REQ_PHONE_USE, EVENT_PHONE_USE, now + repeatMs)
            }
            PHASE_ASKED -> {
                // প্রথম প্রশ্নে উত্তর না দেওয়ায় রাগান্বিত লেভেল ১
                DataStore.setSrPhase(ctx, PHASE_ANGRY)
                DataStore.setSrLevel(ctx, 1)
                SmartReminderReceiver.showReminder(ctx, MascotContent.KIND_ANGRY, 1)
                scheduleAlarm(ctx, REQ_PHONE_USE, EVENT_PHONE_USE, now + repeatMs)
            }
            PHASE_ANGRY -> {
                val nextLvl = (DataStore.getSrLevel(ctx) + 1).coerceIn(1, 5)
                DataStore.setSrLevel(ctx, nextLvl)
                SmartReminderReceiver.showReminder(ctx, MascotContent.KIND_ANGRY, nextLvl)
                scheduleAlarm(ctx, REQ_PHONE_USE, EVENT_PHONE_USE, now + repeatMs)
            }
        }
    }

    private fun handleRecheckAlarm(ctx: Context, now: Long) {
        if (DataStore.getSrPhase(ctx) != PHASE_READING_PHONE) return
        if (!isScreenOn(ctx)) return
        if (isInQuietHours(ctx, now)) {
            scheduleAlarm(ctx, REQ_QUIET_END, EVENT_QUIET_END, nextQuietEndMs(ctx, now))
            return
        }
        SmartReminderReceiver.showReminder(ctx, MascotContent.KIND_RECHECK, 1)
        // উত্তর না দিলে প্রতি sr_repeat_min মিনিটে একই প্রশ্ন আবার (লেভেল বাড়বে না, ফেজ বদলাবে না)
        scheduleAlarm(ctx, REQ_RECHECK, EVENT_RECHECK, now + DataStore.getSrRepeatMin(ctx) * 60_000L)
    }

    private fun handleReadResetAlarm(ctx: Context, now: Long) {
        if (DataStore.getSrPhase(ctx) != PHASE_READING_PHONE) return
        if (isScreenOn(ctx)) return
        endReminderStudySession(ctx)
        resetState(ctx)
        cancelAlarm(ctx, REQ_RECHECK)
        scheduleIdleIfEligible(ctx, now)
    }

    private fun handleIdleAlarm(ctx: Context, now: Long) {
        if (DataStore.getSrIdleMin(ctx) <= 0) return
        if (isScreenOn(ctx)) return
        if (isRealStudyRunning(ctx)) return
        if (DataStore.getSrPhase(ctx) == PHASE_READING_PHONE) return
        if (DataStore.isSrIdleFiredEpisode(ctx)) return
        if (isInQuietHours(ctx, now)) {
            // নীরব সময়ে Idle অ্যালার্ম সেই পর্বের জন্য বাদ
            DataStore.setSrIdleFiredEpisode(ctx, true)
            return
        }
        DataStore.setSrIdleFiredEpisode(ctx, true)
        SmartReminderReceiver.showReminder(ctx, MascotContent.KIND_IDLE, 1)
    }

    // ------------------------------------------------------------------ scheduling helpers

    private fun evaluatePhoneUseSchedule(ctx: Context, now: Long) {
        if (!DataStore.isSrEnabled(ctx)) return
        if (isDailyGoalReached(ctx)) return
        if (!isScreenOn(ctx)) return
        if (isAppInForeground(ctx)) return
        if (isRealStudyRunning(ctx)) return

        val phase = DataStore.getSrPhase(ctx)
        if (phase == PHASE_READING_PHONE) return

        if (isInQuietHours(ctx, now)) {
            pauseSegment(ctx, now)
            scheduleAlarm(ctx, REQ_QUIET_END, EVENT_QUIET_END, nextQuietEndMs(ctx, now))
            return
        }

        if (phase == PHASE_NORMAL) {
            if (DataStore.getSrUseSegmentStartMs(ctx) <= 0L) {
                DataStore.setSrUseSegmentStartMs(ctx, now)
            }
            val accum = currentAccumulatedMs(ctx, now)
            val targetMs = DataStore.getSrAskDelayMin(ctx) * 60_000L
            val rem = (targetMs - accum).coerceAtLeast(3_000L)
            scheduleAlarm(ctx, REQ_PHONE_USE, EVENT_PHONE_USE, now + rem)
        } else {
            // ASKED বা ANGRY অবস্থায় স্ক্রিন আবার ON হলে repeat ব্যবধানে চলবে
            scheduleAlarm(ctx, REQ_PHONE_USE, EVENT_PHONE_USE, now + DataStore.getSrRepeatMin(ctx) * 60_000L)
        }
    }

    private fun scheduleIdleIfEligible(ctx: Context, now: Long) {
        val idleMin = DataStore.getSrIdleMin(ctx)
        if (idleMin <= 0) {
            cancelAlarm(ctx, REQ_IDLE)
            return
        }
        if (isRealStudyRunning(ctx)) return
        if (DataStore.getSrPhase(ctx) == PHASE_READING_PHONE) return
        if (DataStore.isSrIdleFiredEpisode(ctx)) return

        val base = maxOf(
            DataStore.getSrScreenOffSinceMs(ctx),
            DataStore.getSrLastStudyEndMs(ctx),
            now
        )
        scheduleAlarm(ctx, REQ_IDLE, EVENT_IDLE, base + idleMin * 60_000L)
    }

    private fun startOrUpdateOnlineStudyService(ctx: Context, serviceAlreadyRunning: Boolean) {
        markInternalOp()
        val action = if (serviceAlreadyRunning) FlipTrackerService.ACTION_ONLINE_CHANGED else FlipTrackerService.ACTION_START
        val i = Intent(ctx, FlipTrackerService::class.java).setAction(action)
        try {
            if (serviceAlreadyRunning) ctx.startService(i)
            else ContextCompat.startForegroundService(ctx, i)
        } catch (_: Exception) {
            launchMainStudyFallback(ctx, action)
        }
    }

    private fun pauseReadingPhoneSession(ctx: Context) {
        markInternalOp()
        if (DataStore.isSrSessionStartedByReminder(ctx)) {
            try {
                ctx.startService(Intent(ctx, FlipTrackerService::class.java).setAction(FlipTrackerService.ACTION_STOP))
            } catch (_: Exception) {}
        } else {
            DataStore.setOnlineStudy(ctx, DataStore.getSrPrevOnline(ctx))
            if (DataStore.loadRuntimeState(ctx).running) {
                try {
                    ctx.startService(Intent(ctx, FlipTrackerService::class.java).setAction(FlipTrackerService.ACTION_ONLINE_CHANGED))
                } catch (_: Exception) {}
            }
        }
    }

    private fun resumeReadingPhoneSession(ctx: Context) {
        markInternalOp()
        DataStore.setOnlineStudy(ctx, true)
        val rt = DataStore.loadRuntimeState(ctx)
        startOrUpdateOnlineStudyService(ctx, rt.running)
    }

    private fun endReminderStudySession(ctx: Context) {
        markInternalOp()
        val prevOnline = DataStore.getSrPrevOnline(ctx)
        DataStore.setOnlineStudy(ctx, prevOnline)
        if (DataStore.isSrSessionStartedByReminder(ctx)) {
            if (DataStore.loadRuntimeState(ctx).running) {
                try {
                    ctx.startService(Intent(ctx, FlipTrackerService::class.java).setAction(FlipTrackerService.ACTION_STOP))
                } catch (_: Exception) {}
            }
        } else {
            if (DataStore.loadRuntimeState(ctx).running) {
                try {
                    ctx.startService(Intent(ctx, FlipTrackerService::class.java).setAction(FlipTrackerService.ACTION_ONLINE_CHANGED))
                } catch (_: Exception) {}
            }
        }
        DataStore.setSrSessionStartedByReminder(ctx, false)
    }

    private fun launchMainStudyFallback(ctx: Context, action: String) {
        try {
            val open = Intent(ctx, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra(EXTRA_START_STUDY_FALLBACK, action)
            }
            ctx.startActivity(open)
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ state & utility helpers

    private fun pauseSegment(ctx: Context, now: Long) {
        val segStart = DataStore.getSrUseSegmentStartMs(ctx)
        if (segStart > 0L) {
            val delta = (now - segStart).coerceAtLeast(0L)
            DataStore.setSrUseAccumMs(ctx, DataStore.getSrUseAccumMs(ctx) + delta)
            DataStore.setSrUseSegmentStartMs(ctx, 0L)
        }
    }

    private fun currentAccumulatedMs(ctx: Context, now: Long): Long {
        val base = DataStore.getSrUseAccumMs(ctx)
        val segStart = DataStore.getSrUseSegmentStartMs(ctx)
        return if (segStart > 0L) base + (now - segStart).coerceAtLeast(0L) else base
    }

    private fun resetState(ctx: Context) {
        DataStore.setSrPhase(ctx, PHASE_NORMAL)
        DataStore.setSrLevel(ctx, 0)
        DataStore.setSrUseAccumMs(ctx, 0L)
        DataStore.setSrUseSegmentStartMs(ctx, 0L)
        DataStore.setSrSessionStartedByReminder(ctx, false)
    }

    fun dismissReminderUi(ctx: Context) {
        try {
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(NOTIF_REMINDER_ID)
        } catch (_: Exception) {}
        SmartReminderPopupOverlay.dismiss()
    }

    fun isScreenOn(ctx: Context): Boolean {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isInteractive
    }

    private fun isAppInForeground(ctx: Context): Boolean = appInForeground || DataStore.isSrAppForeground(ctx)

    private fun isRealStudyRunning(ctx: Context): Boolean {
        val rt = DataStore.loadRuntimeState(ctx)
        return rt.running && rt.mode == "STUDY"
    }

    fun isDailyGoalReached(ctx: Context): Boolean {
        val goalMin = DataStore.getDailyGoalHours(ctx) * 60
        return DataStore.getToday(ctx).totalStudyMinutes() >= goalMin
    }

    fun isInQuietHours(ctx: Context, nowMs: Long): Boolean {
        if (!DataStore.isSrQuietOn(ctx)) return false
        val start = DataStore.getSrQuietStartMin(ctx)
        val end = DataStore.getSrQuietEndMin(ctx)
        if (start == end) return false
        val cal = Calendar.getInstance().apply { timeInMillis = nowMs }
        val cur = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        return if (start < end) {
            cur in start until end
        } else {
            // মাঝরাত পার হওয়া রেঞ্জ (যেমন ২৩:০০–০৬:০০)
            cur >= start || cur < end
        }
    }

    fun nextQuietEndMs(ctx: Context, nowMs: Long): Long {
        val end = DataStore.getSrQuietEndMin(ctx)
        val cal = Calendar.getInstance().apply {
            timeInMillis = nowMs
            set(Calendar.HOUR_OF_DAY, end / 60)
            set(Calendar.MINUTE, end % 60)
            set(Calendar.SECOND, 5)
            set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= nowMs) {
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return cal.timeInMillis
    }

    private fun scheduleAlarm(ctx: Context, reqCode: Int, event: String, triggerAtMs: Long) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val safeTrigger = maxOf(triggerAtMs, System.currentTimeMillis() + 2_000L)
        val pi = alarmPendingIntent(ctx, reqCode, event)
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, safeTrigger, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, safeTrigger, pi)
            }
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, safeTrigger, pi)
        }
    }

    private fun cancelAlarm(ctx: Context, reqCode: Int) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(alarmPendingIntent(ctx, reqCode, ""))
    }

    fun cancelAllAlarms(ctx: Context) {
        cancelAlarm(ctx, REQ_PHONE_USE)
        cancelAlarm(ctx, REQ_RECHECK)
        cancelAlarm(ctx, REQ_READ_RESET)
        cancelAlarm(ctx, REQ_IDLE)
        cancelAlarm(ctx, REQ_QUIET_END)
    }

    private fun alarmPendingIntent(ctx: Context, reqCode: Int, event: String): PendingIntent {
        val i = Intent(ctx, SmartReminderReceiver::class.java).apply {
            putExtra(EXTRA_EVENT, event)
        }
        return PendingIntent.getBroadcast(
            ctx, reqCode, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
