package com.bcs.flipstudy

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class FlipTrackerService : Service(), SensorEventListener {

    companion object {
        const val CHANNEL_ID = "bcs_flip_tracker_v3"
        const val NOTIF_ID = 1001
        const val ACTION_START = "com.bcs.flipstudy.START"
        const val ACTION_STOP = "com.bcs.flipstudy.STOP"
        const val ACTION_MANUAL_STUDY = "com.bcs.flipstudy.MANUAL_STUDY"
        const val ACTION_MANUAL_WASTE = "com.bcs.flipstudy.MANUAL_WASTE"
        const val ACTION_RESET_TIMER = "com.bcs.flipstudy.RESET"
        const val ACTION_ONLINE_CHANGED = "com.bcs.flipstudy.ONLINE_CHANGED"
        const val ACTION_ALARM_COMPLETED = "com.bcs.flipstudy.ALARM_COMPLETED"
        const val BROADCAST_STATE_CHANGED = "com.bcs.flipstudy.STATE_CHANGED"
    }

    private lateinit var sensorManager: SensorManager
    private var accelSensor: Sensor? = null

    private var isRunning = false
    private var currentMode = "IDLE" // IDLE, STUDY, WASTE
    private var stateStartMs = 0L
    private var remainingSec = 45 * 60
    private var isFaceDown = false

    private var pendingFaceDown: Boolean? = null
    private var pendingSinceMs = 0L

    override fun onCreate() {
        super.onCreate()
        createChannel()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER, true)
            ?: sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            restoreFromPrefsIfRunning()
            return START_STICKY
        }

        when (intent.action) {
            ACTION_STOP -> {
                DataStore.setFlipEnabled(this, false)
                stopTracking()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_MANUAL_STUDY -> {
                toggleManualMode("STUDY")
                return if (isRunning) START_STICKY else START_NOT_STICKY
            }
            ACTION_MANUAL_WASTE -> {
                toggleManualMode("WASTE")
                return if (isRunning) START_STICKY else START_NOT_STICKY
            }
            ACTION_RESET_TIMER -> {
                if (isRunning) {
                    commitElapsed(System.currentTimeMillis())
                    remainingSec = DataStore.getPresetMin(this) * 60
                    stateStartMs = System.currentTimeMillis()
                    persistRuntime()
                    if (currentMode == "STUDY") {
                        scheduleStudyAlarm(); WasteReminderReceiver.cancel(this)
                    } else {
                        cancelStudyAlarm(); WasteReminderReceiver.scheduleNext(this, 1)
                    }
                    updateNotification()
                    broadcastStateChanged()
                }
                return START_STICKY
            }
            ACTION_ONLINE_CHANGED -> {
                if (isRunning && DataStore.isFlipEnabled(this)) {
                    evaluateFlipTransition(System.currentTimeMillis())
                }
                return START_STICKY
            }
            ACTION_ALARM_COMPLETED -> {
                // সার্ভিস প্রসেস মরে নতুন করে উঠলে আগে সংরক্ষিত অবস্থা ফিরিয়ে আনো
                if (!isRunning) restoreFromPrefsIfRunning()
                if (isRunning && currentMode == "STUDY") {
                    remainingSec = DataStore.getPresetMin(this) * 60
                    stateStartMs = System.currentTimeMillis()
                    persistRuntime()
                    scheduleStudyAlarm()
                    updateNotification()
                    broadcastStateChanged()
                }
                return START_STICKY
            }
            else -> {
                // Flip Mode ON
                DataStore.setFlipEnabled(this, true)
                startFlipTracking()
                return START_STICKY
            }
        }
    }

    private fun toggleManualMode(target: String) {
        val now = System.currentTimeMillis()
        // যদি আগে থেকেই একই মোড চালু থাকে, তবে পজ (বন্ধ) করো!
        if (isRunning && currentMode == target) {
            DataStore.setFlipEnabled(this, false)
            stopTracking()
            stopSelf()
            return
        }
        // অন্যথায় নতুন ম্যানুয়াল মোড চালু করো (ফ্লিপ সেন্সর ছাড়াই কাজ করবে!)
        DataStore.setFlipEnabled(this, false)
        sensorManager.unregisterListener(this)
        if (isRunning) {
            commitElapsed(now)
        } else {
            DataStore.absorbClosedTimeAsSleepOther(this)
            val savedRem = DataStore.loadRuntimeState(this).remainingSec
            remainingSec = if (savedRem > 5) savedRem else DataStore.getPresetMin(this) * 60
        }
        isRunning = true
        currentMode = target
        stateStartMs = now
        persistRuntime()
        startForeground(NOTIF_ID, buildNotification())
        if (currentMode == "STUDY") {
            scheduleStudyAlarm(); WasteReminderReceiver.cancel(this)
        } else {
            cancelStudyAlarm(); WasteReminderReceiver.scheduleNext(this, 1)
        }
        broadcastStateChanged()
    }

    private fun restoreFromPrefsIfRunning() {
        val rt = DataStore.loadRuntimeState(this)
        if (!rt.running) {
            stopSelf()
            return
        }
        isRunning = true
        currentMode = rt.mode
        stateStartMs = if (rt.stateStartMs > 0L) rt.stateStartMs else System.currentTimeMillis()
        remainingSec = rt.remainingSec.coerceAtLeast(1)
        isFaceDown = rt.faceDown
        startForeground(NOTIF_ID, buildNotification())
        if (DataStore.isFlipEnabled(this)) registerBatchedSensor()
        if (currentMode == "STUDY") scheduleStudyAlarm()
    }

    private fun startFlipTracking() {
        val now = System.currentTimeMillis()
        if (isRunning) {
            commitElapsed(now)
        } else {
            DataStore.absorbClosedTimeAsSleepOther(this)
            remainingSec = DataStore.getPresetMin(this) * 60
        }

        isRunning = true
        isFaceDown = false
        pendingFaceDown = null
        stateStartMs = now
        currentMode = if (DataStore.isOnlineStudy(this)) "STUDY" else "WASTE"

        persistRuntime()
        startForeground(NOTIF_ID, buildNotification())
        registerBatchedSensor()
        if (currentMode == "STUDY") {
            scheduleStudyAlarm(); WasteReminderReceiver.cancel(this)
        } else {
            cancelStudyAlarm(); WasteReminderReceiver.scheduleNext(this, 1)
        }
        broadcastStateChanged()
    }

    private fun stopTracking() {
        if (isRunning) {
            commitElapsed(System.currentTimeMillis())
        }
        isRunning = false
        currentMode = "IDLE"
        cancelStudyAlarm()
        WasteReminderReceiver.cancel(this)
        sensorManager.unregisterListener(this)
        persistRuntime()
        DataStore.markAppClosedNow(this)
        broadcastStateChanged()
    }

    private fun registerBatchedSensor() {
        accelSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL, 2_000_000)
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (!isRunning || !DataStore.isFlipEnabled(this)) return
        val z = event.values[2]
        val now = System.currentTimeMillis()

        val detectedFaceDown = (z < -7.5f)
        if (detectedFaceDown == isFaceDown) {
            pendingFaceDown = null
            return
        }

        val graceMs = if (!detectedFaceDown) (DataStore.getGraceSec(this) * 1000L) else 1500L
        if (pendingFaceDown != detectedFaceDown) {
            pendingFaceDown = detectedFaceDown
            pendingSinceMs = now
        } else if (now - pendingSinceMs >= graceMs) {
            isFaceDown = detectedFaceDown
            pendingFaceDown = null
            evaluateFlipTransition(now)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun evaluateFlipTransition(now: Long) {
        val shouldStudy = isFaceDown || DataStore.isOnlineStudy(this)
        val targetMode = if (shouldStudy) "STUDY" else "WASTE"
        if (targetMode == currentMode) return

        commitElapsed(now)
        currentMode = targetMode
        stateStartMs = now
        persistRuntime()

        if (currentMode == "STUDY") {
            scheduleStudyAlarm(); WasteReminderReceiver.cancel(this)
        } else {
            cancelStudyAlarm(); WasteReminderReceiver.scheduleNext(this, 1)
        }
        updateNotification()
        broadcastStateChanged()
    }

    private fun commitElapsed(now: Long) {
        if (stateStartMs <= 0L) return
        val elapsedSec = ((now - stateStartMs) / 1000L).coerceAtLeast(0L)
        if (elapsedSec == 0L) return

        if (currentMode == "STUDY") {
            remainingSec = (remainingSec - elapsedSec.toInt()).coerceAtLeast(1)
            val sub = DataStore.getCurrentSubject(this)
            DataStore.updateToday(this) { rec ->
                rec.studySec += elapsedSec
                rec.subject = sub
                rec.subjects[sub] = (rec.subjects[sub] ?: 0L) + elapsedSec
                rec.mode = if (DataStore.isFlipEnabled(this)) "flip" else "manual"
                rec.synced = false
            }
        } else if (currentMode == "WASTE") {
            DataStore.updateToday(this) { rec ->
                rec.wasteSec += elapsedSec
                rec.wasteReasons["অপচয় সময়"] = (rec.wasteReasons["অপচয় সময়"] ?: 0L) + elapsedSec
                rec.synced = false
            }
        }
    }

    private fun scheduleStudyAlarm() {
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        // সেশন শুরুর সময় থেকে হিসাব: সার্ভিস রিস্টার্ট হলেও অ্যালার্ম ঠিক সময়েই বাজবে
        val nowMs = System.currentTimeMillis()
        val baseStart = if (stateStartMs > 0L) stateStartMs else nowMs
        val triggerAt = maxOf(baseStart + remainingSec * 1000L, nowMs + 3000L)
        val pi = alarmPendingIntent()
        val showPi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()) {
                am.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAt, showPi), pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            }
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        }
    }

    private fun cancelStudyAlarm() {
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(alarmPendingIntent())
    }

    private fun alarmPendingIntent(): PendingIntent =
        PendingIntent.getBroadcast(
            this, 2002, Intent(this, StudyAlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun persistRuntime() {
        DataStore.saveRuntimeState(
            this,
            RuntimeTrackerState(isRunning, currentMode, stateStartMs, remainingSec, isFaceDown)
        )
    }

    private fun broadcastStateChanged() {
        sendBroadcast(Intent(BROADCAST_STATE_CHANGED).setPackage(packageName))
    }

    private fun updateNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setSilent(true)
            .setShowWhen(true)
            .setUsesChronometer(true)

        if (currentMode == "STUDY") {
            val endMs = stateStartMs + (remainingSec * 1000L)
            builder.setContentTitle("পড়া চলছে · ${DataStore.getCurrentSubject(this)}")
            builder.setContentText("বাকি সময় (সিস্টেম কাউন্টডাউন)")
            builder.setWhen(endMs)
            builder.setChronometerCountDown(true)
        } else {
            builder.setContentTitle("অপচয় সময় চলছে")
            builder.setContentText("পড়ায় ফিরতে ফোন উল্টাও বা পড়া শুরু চাপো")
            builder.setWhen(stateStartMs)
            builder.setChronometerCountDown(false)
        }
        return builder.build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "BCS ফ্লিপ স্টাডি", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    override fun onDestroy() {
        sensorManager.unregisterListener(this)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
