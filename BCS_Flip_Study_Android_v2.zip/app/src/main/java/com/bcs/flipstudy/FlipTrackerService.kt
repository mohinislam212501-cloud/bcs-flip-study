package com.bcs.flipstudy

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class FlipTrackerService : Service(), SensorEventListener {

    companion object {
        const val CHANNEL_ID = "bcs_flip_tracker_v3"
        const val NOTIF_ID = 1001
        const val ACTION_START = "com.bcs.flipstudy.START"
        const val ACTION_START_ONLINE_ONLY = "com.bcs.flipstudy.START_ONLINE_ONLY"
        const val ACTION_RESTORE = "com.bcs.flipstudy.RESTORE"
        const val ACTION_STOP = "com.bcs.flipstudy.STOP"
        const val ACTION_MANUAL_STUDY = "com.bcs.flipstudy.MANUAL_STUDY"
        const val ACTION_MANUAL_WASTE = "com.bcs.flipstudy.MANUAL_WASTE"
        const val ACTION_RESET_TIMER = "com.bcs.flipstudy.RESET"
        const val ACTION_ONLINE_CHANGED = "com.bcs.flipstudy.ONLINE_CHANGED"
        const val ACTION_ALARM_COMPLETED = "com.bcs.flipstudy.ALARM_COMPLETED"
        const val BROADCAST_STATE_CHANGED = "com.bcs.flipstudy.STATE_CHANGED"
    }

    private lateinit var sensorManager: SensorManager
    private var accelSensor: Sensor? = null

    private var isRunning = false
    private var currentMode = "IDLE" // IDLE, STUDY, WASTE
    private var activeSource = "manual"
    private var stateStartMs = 0L
    private var remainingSec = 45 * 60
    private var isFaceDown = false

    private var pendingFaceDown: Boolean? = null
    private var pendingSinceMs = 0L

    override fun onCreate() {
        super.onCreate()
        createChannel()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER, true)
            ?: sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            restoreFromPrefsIfRunning()
            return START_STICKY
        }

        when (intent.action) {
            ACTION_STOP -> {
                DataStore.setFlipEnabled(this, false)
                stopTracking()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_MANUAL_STUDY -> {
                toggleManualMode("STUDY")
                return if (isRunning) START_STICKY else START_NOT_STICKY
            }
            ACTION_MANUAL_WASTE -> {
                toggleManualMode("WASTE")
                return if (isRunning) START_STICKY else START_NOT_STICKY
            }
            ACTION_RESTORE -> {
                restoreFromPrefsIfRunning()
                return if (isRunning) START_STICKY else START_NOT_STICKY
            }
            ACTION_START_ONLINE_ONLY -> {
                startOnlineOnlyTracking()
                return START_STICKY
            }
            ACTION_RESET_TIMER -> {
                if (!isRunning) restoreFromPrefsIfRunning()
                if (isRunning) {
                    commitElapsed(System.currentTimeMillis())
                    remainingSec = DataStore.getPresetMin(this) * 60
                    stateStartMs = System.currentTimeMillis()
                    persistRuntime()
                    if (currentMode == "STUDY") {
                        scheduleStudyAlarm()
                        SmartReminderManager.onStudyStateChanged(this)
                    } else {
                        cancelStudyAlarm()
                        SmartReminderManager.onStudyStateChanged(this)
                    }
                    updateNotification()
                    broadcastStateChanged()
                }
                return START_STICKY
            }
            ACTION_ONLINE_CHANGED -> {
                if (!isRunning) restoreFromPrefsIfRunning()
                val now = System.currentTimeMillis()
                if (isRunning && DataStore.isFlipEnabled(this)) {
                    if (DataStore.isOnlineStudy(this)) unregisterSensorSafe() else registerBatchedSensor()
                    evaluateFlipTransition(now)
                } else if (isRunning && DataStore.isOnlineStudy(this)) {
                    if (currentMode != "STUDY" || activeSource != "online") {
                        commitElapsed(now)
                        currentMode = "STUDY"
                        activeSource = "online"
                        stateStartMs = now
                        persistRuntime()
                        scheduleStudyAlarm()
                        SmartReminderManager.onStudyStateChanged(this)
                        updateNotification()
                        broadcastStateChanged()
                    }
                } else if (isRunning && !DataStore.isFlipEnabled(this) && !DataStore.isOnlineStudy(this) &&
                    (activeSource == "online" || DataStore.getSrPhase(this) == SmartReminderManager.PHASE_READING_PHONE)
                ) {
                    stopTracking()
                    stopSelf()
                    return START_NOT_STICKY
                }
                return START_STICKY
            }
            ACTION_ALARM_COMPLETED -> {
                // সার্ভিস প্রসেস মরে নতুন করে উঠলে আগে সংরক্ষিত অবস্থা ফিরিয়ে আনো
                if (!isRunning) restoreFromPrefsIfRunning()
                if (isRunning && currentMode == "STUDY") {
                    remainingSec = DataStore.getPresetMin(this) * 60
                    stateStartMs = System.currentTimeMillis()
                    persistRuntime()
                    scheduleStudyAlarm()
                    updateNotification()
                    broadcastStateChanged()
                }
                return START_STICKY
            }
            else -> {
                val now = System.currentTimeMillis()
                if (isRunning) commitElapsed(now)
                DataStore.setFlipEnabled(this, true)
                HapticManager.flipToggleConfirm(this)
                startFlipTracking(alreadyCommitted = true)
                return START_STICKY
            }
        }
    }

    private fun toggleManualMode(target: String) {
        val now = System.currentTimeMillis()
        if (isRunning && currentMode == target) {
            HapticManager.timerPause(this)
            stopTracking()
            DataStore.setFlipEnabled(this, false)
            stopSelf()
            return
        }
        if (isRunning) {
            commitElapsed(now)
        } else {
            DataStore.absorbClosedTimeAsSleepOther(this)
            val savedRem = DataStore.loadRuntimeState(this).remainingSec
            remainingSec = if (savedRem > 5) savedRem else DataStore.getPresetMin(this) * 60
        }
        DataStore.setFlipEnabled(this, false)
        unregisterSensorSafe()
        activeSource = if (target == "STUDY" && DataStore.isOnlineStudy(this)) "online" else "manual"
        isRunning = true
        currentMode = target
        stateStartMs = now
        persistRuntime()
        startForeground(NOTIF_ID, buildNotification())
        if (currentMode == "STUDY") {
            HapticManager.flipStudyOn(this)
            scheduleStudyAlarm()
                        SmartReminderManager.onStudyStateChanged(this)
        } else {
            HapticManager.flipWasteOn(this)
            cancelStudyAlarm()
                        SmartReminderManager.onStudyStateChanged(this)
        }
        broadcastStateChanged()
    }

    private fun restoreFromPrefsIfRunning() {
        val rt = DataStore.loadRuntimeState(this)
        if (!rt.running) {
            stopSelf()
            return
        }
        isRunning = true
        currentMode = rt.mode
        stateStartMs = if (rt.stateStartMs > 0L) rt.stateStartMs else System.currentTimeMillis()
        remainingSec = rt.remainingSec.coerceAtLeast(1)
        isFaceDown = rt.faceDown
        activeSource = rt.source
        startForeground(NOTIF_ID, buildNotification())
        if (DataStore.isFlipEnabled(this)) registerBatchedSensor()
        if (currentMode == "STUDY") scheduleStudyAlarm()
        SmartReminderManager.onStudyStateChanged(this)
    }

    private fun startOnlineOnlyTracking() {
        val now = System.currentTimeMillis()
        if (isRunning) {
            commitElapsed(now)
        } else {
            DataStore.absorbClosedTimeAsSleepOther(this)
            remainingSec = DataStore.getPresetMin(this) * 60
        }
        isRunning = true
        isFaceDown = false
        pendingFaceDown = null
        stateStartMs = now
        currentMode = "STUDY"
        persistRuntime()
        startForeground(NOTIF_ID, buildNotification())
        scheduleStudyAlarm()
        SmartReminderManager.onStudyStateChanged(this)
        broadcastStateChanged()
    }

    private fun startFlipTracking(alreadyCommitted: Boolean = false) {
        val now = System.currentTimeMillis()
        if (isRunning && !alreadyCommitted) {
            commitElapsed(now)
        } else if (!isRunning) {
            DataStore.absorbClosedTimeAsSleepOther(this)
            remainingSec = DataStore.getPresetMin(this) * 60
        }

        isRunning = true
        isFaceDown = false
        pendingFaceDown = null
        stateStartMs = now
        currentMode = if (DataStore.isOnlineStudy(this)) "STUDY" else "WASTE"
        activeSource = if (DataStore.isOnlineStudy(this)) "online" else "flip"

        persistRuntime()
        startForeground(NOTIF_ID, buildNotification())
        registerBatchedSensor()
        if (currentMode == "STUDY") {
            scheduleStudyAlarm()
            SmartReminderManager.onStudyStateChanged(this)
            if (activeSource == "flip") HapticManager.flipStudyOn(this)
        } else {
            cancelStudyAlarm()
            SmartReminderManager.onStudyStateChanged(this)
            if (activeSource == "flip") HapticManager.flipWasteOn(this)
        }
        broadcastStateChanged()
    }

    private fun stopTracking() {
        if (isRunning) {
            commitElapsed(System.currentTimeMillis())
        }
        isRunning = false
        currentMode = "IDLE"
        cancelStudyAlarm()
        unregisterSensorSafe()
        persistRuntime()
        DataStore.markAppClosedNow(this)
        SmartReminderManager.onStudyStateChanged(this)
        broadcastStateChanged()
    }

    private var isSensorRegistered = false

    private fun unregisterSensorSafe() {
        if (isSensorRegistered) {
            sensorManager.unregisterListener(this)
            isSensorRegistered = false
        }
    }

    private fun registerBatchedSensor() {
        if (DataStore.isOnlineStudy(this)) {
            unregisterSensorSafe()
            return
        }
        if (isSensorRegistered) return
        accelSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL, 5_000_000)
            isSensorRegistered = true
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (!isRunning || !DataStore.isFlipEnabled(this)) return
        val z = event.values[2]
        val now = System.currentTimeMillis()

        val detectedFaceDown = (z < -7.5f)
        if (detectedFaceDown == isFaceDown) {
            pendingFaceDown = null
            return
        }

        val graceMs = if (!detectedFaceDown) (DataStore.getGraceSec(this) * 1000L) else 1500L
        if (pendingFaceDown != detectedFaceDown) {
            pendingFaceDown = detectedFaceDown
            pendingSinceMs = now
        } else if (now - pendingSinceMs >= graceMs) {
            isFaceDown = detectedFaceDown
            pendingFaceDown = null
            evaluateFlipTransition(now)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun evaluateFlipTransition(now: Long) {
        val shouldStudy = isFaceDown || DataStore.isOnlineStudy(this)
        val targetMode = if (shouldStudy) "STUDY" else "WASTE"
        if (targetMode == currentMode) return

        commitElapsed(now)
        currentMode = targetMode
        activeSource = if (targetMode == "STUDY" && DataStore.isOnlineStudy(this)) "online" else if (DataStore.isFlipEnabled(this)) "flip" else "manual"
        stateStartMs = now
        persistRuntime()

        if (currentMode == "STUDY") {
            scheduleStudyAlarm()
                        SmartReminderManager.onStudyStateChanged(this)
        } else {
            cancelStudyAlarm()
                        SmartReminderManager.onStudyStateChanged(this)
        }
        updateNotification()
        broadcastStateChanged()
    }

    private fun commitElapsed(now: Long) {
        if (stateStartMs <= 0L) return
        val elapsedSec = ((now - stateStartMs) / 1000L).coerceAtLeast(0L)
        if (elapsedSec == 0L) return

        val fourHoursMs = 4L * 3600_000L
        val spanMs = (now - stateStartMs).coerceAtLeast(0L)

        if (currentMode == "STUDY") {
            val cappedSec = elapsedSec.coerceAtMost(4L * 3600L)
            remainingSec = (remainingSec - cappedSec.toInt()).coerceAtLeast(1)
            if (spanMs > fourHoursMs + 20L * 60_000L) {
                val firstEnd = stateStartMs + fourHoursMs
                DataStore.addStudy(this, stateStartMs, firstEnd, activeSource)
                DataStore.addPendingGap(this, firstEnd, now)
            } else {
                DataStore.addStudy(this, stateStartMs, now, activeSource)
            }
        } else if (currentMode == "WASTE") {
            if (spanMs > fourHoursMs + 20L * 60_000L) {
                val firstEnd = stateStartMs + fourHoursMs
                DataStore.addWaste(this, stateStartMs, firstEnd, DataStore.getSrLiveWasteReason(this))
                DataStore.addPendingGap(this, firstEnd, now)
            } else {
                DataStore.addWaste(this, stateStartMs, now, DataStore.getSrLiveWasteReason(this))
            }
        }
    }

    private fun scheduleStudyAlarm() {
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        // সেশন শুরুর সময় থেকে হিসাব: সার্ভিস রিস্টার্ট হলেও অ্যালার্ম ঠিক সময়েই বাজবে
        val nowMs = System.currentTimeMillis()
        val baseStart = if (stateStartMs > 0L) stateStartMs else nowMs
        val triggerAt = maxOf(baseStart + remainingSec * 1000L, nowMs + 3000L)
        val pi = alarmPendingIntent()
        val showPi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()) {
                am.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAt, showPi), pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            }
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        }
    }

    private fun cancelStudyAlarm() {
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(alarmPendingIntent())
    }

    private fun alarmPendingIntent(): PendingIntent =
        PendingIntent.getBroadcast(
            this, 2002, Intent(this, StudyAlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun persistRuntime() {
        DataStore.saveRuntimeState(
            this,
            RuntimeTrackerState(isRunning, currentMode, stateStartMs, remainingSec, isFaceDown)
        )
    }

    private fun broadcastStateChanged() {
        sendBroadcast(Intent(BROADCAST_STATE_CHANGED).setPackage(packageName))
    }

    private fun updateNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setSilent(true)
            .setShowWhen(true)
            .setUsesChronometer(true)

        if (currentMode == "STUDY") {
            val endMs = stateStartMs + (remainingSec * 1000L)
            builder.setContentTitle("পড়া চলছে · ${DataStore.getCurrentSubject(this)}")
            builder.setContentText("বাকি সময় (সিস্টেম কাউন্টডাউন)")
            builder.setWhen(endMs)
            builder.setChronometerCountDown(true)
        } else {
            builder.setContentTitle("অপচয় সময় চলছে")
            builder.setContentText("পড়ায় ফিরতে ফোন উল্টাও বা পড়া শুরু চাপো")
            builder.setWhen(stateStartMs)
            builder.setChronometerCountDown(false)
        }
        return builder.build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "BCS ফ্লিপ স্টাডি", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    override fun onDestroy() {
        unregisterSensorSafe()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
