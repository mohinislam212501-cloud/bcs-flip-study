package com.bcs.flipstudy

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import org.json.JSONObject
import java.util.Calendar

object MascotContent {

    const val KIND_ASK = "ASK"
    const val KIND_RECHECK = "RECHECK"
    const val KIND_ANGRY = "ANGRY"
    const val KIND_STRICT = "STRICT"
    const val KIND_IDLE = "IDLE"
    const val KIND_AWAY_PRE = "AWAY_PRE"
    const val KIND_AWAY_END = "AWAY_END"
    const val KIND_MORNING = "MORNING"

    @Volatile var debugMockHour: Int = -1

    fun currentHour(): Int = if (debugMockHour in 0..23) debugMockHour else Calendar.getInstance().get(Calendar.HOUR_OF_DAY)

    enum class TimeBucket { DAWN, MORNING, NOON, AFTERNOON, EVENING, NIGHT, LATE_NIGHT }

    fun timeBucket(hour: Int = currentHour()): TimeBucket = when (hour.coerceIn(0, 23)) {
        in 4..6 -> TimeBucket.DAWN
        in 7..10 -> TimeBucket.MORNING
        in 11..14 -> TimeBucket.NOON
        in 15..17 -> TimeBucket.AFTERNOON
        in 18..20 -> TimeBucket.EVENING
        in 21..23 -> TimeBucket.NIGHT
        else -> TimeBucket.LATE_NIGHT
    }

    fun mascotResFor(character: String, level: Int): Int {
        val lvl = level.coerceIn(1, 5)
        return if (character == "ghost") {
            when (lvl) {
                1 -> R.drawable.vec_mascot_ghost_1
                2 -> R.drawable.vec_mascot_ghost_2
                3 -> R.drawable.vec_mascot_ghost_3
                4 -> R.drawable.vec_mascot_ghost_4
                else -> R.drawable.vec_mascot_ghost_5
            }
        } else {
            when (lvl) {
                1 -> R.drawable.vec_mascot_dragon_1
                2 -> R.drawable.vec_mascot_dragon_2
                3 -> R.drawable.vec_mascot_dragon_3
                4 -> R.drawable.vec_mascot_dragon_4
                else -> R.drawable.vec_mascot_dragon_5
            }
        }
    }

    fun mascotResForLevel(level: Int): Int = mascotResFor("dragon", level)

    fun resolveCharacter(ctx: Context, hour: Int = currentHour()): String {
        return when (DataStore.getSrMascotStyle(ctx)) {
            "dragon" -> "dragon"
            "ghost" -> "ghost"
            else -> {
                val sleepStart = if (DataStore.isSrQuietOn(ctx) && DataStore.getSrQuietStartMin(ctx) > 0) DataStore.getSrQuietStartMin(ctx) else 21 * 60
                val wakeEnd = if (DataStore.isSrQuietOn(ctx)) DataStore.getSrQuietEndMin(ctx) else 6 * 60
                val nowMin = hour.coerceIn(0, 23) * 60
                val isNight = if (sleepStart > wakeEnd) (nowMin >= sleepStart || nowMin < wakeEnd) else (nowMin in sleepStart until wakeEnd)
                if (isNight) "ghost" else "dragon"
            }
        }
    }

    fun accentColorFor(character: String, level: Int): Int {
        val lvl = level.coerceIn(1, 5)
        return if (character == "ghost") {
            when (lvl) {
                1 -> Color.parseColor("#7FE3FF")
                2 -> Color.parseColor("#A58BFF")
                3 -> Color.parseColor("#D060FF")
                4 -> Color.parseColor("#FF4A7A")
                else -> Color.parseColor("#FF3B1F")
            }
        } else {
            when (lvl) {
                1 -> Color.parseColor("#34D399")
                2 -> Color.parseColor("#FBBF24")
                3 -> Color.parseColor("#F97316")
                4 -> Color.parseColor("#EF4444")
                else -> Color.parseColor("#FF3B30")
            }
        }
    }

    fun formatDurationBn(minutes: Int): String {
        val m = minutes.coerceAtLeast(1)
        val h = m / 60
        val rem = m % 60
        return when {
            h > 0 && rem > 0 -> "${DataStore.toBnDigits(h)}ঘ ${DataStore.toBnDigits(rem)}মি"
            h > 0 -> "${DataStore.toBnDigits(h)} ঘণ্টা"
            else -> "${DataStore.toBnDigits(m)} মি."
        }
    }

    fun titleFor(kind: String, level: Int, elapsedMin: Int = 0): String = when (kind) {
        KIND_ASK -> "ফোনে কী করছো?"
        KIND_RECHECK -> "এখনো পড়ছো?"
        KIND_IDLE -> "পড়া থেকে দূরে আছো!"
        KIND_AWAY_PRE -> "পড়তে বসার সময় হয়ে এলো!"
        KIND_AWAY_END -> "বাইরে থাকার সময় শেষ!"
        KIND_MORNING -> "শুভ সকাল!"
        KIND_STRICT -> if (elapsedMin > 0) "${formatDurationBn(elapsedMin)} ফোন চালানো হয়েছে!!" else "এখনই পড়তে বসো!!"
        else -> titleForAngryLevel(level)
    }

    fun titleForAngryLevel(level: Int): String = when (level.coerceIn(1, 5)) {
        1 -> "এই যে! পড়ায় ফিরবে না?"
        2 -> "বিরক্ত হচ্ছি কিন্তু!"
        3 -> "এবার সত্যিই রাগ উঠছে!"
        4 -> "ধৈর্যের সীমা ছাড়িয়ে যাচ্ছে!"
        else -> "চূড়ান্ত সতর্কতা!! এখনই ফোন রাখো!"
    }

    // ------------------------------------------------------------------ ৩-অংশের কমা-যুক্ত ক্যারেকটার মেসেজ ইঞ্জিন (বড় ড্যাশ ও মাঝখানে দাঁড়ি ছাড়া)

    private val WEATHER_BY_MONTH = arrayOf(
        "জানুয়ারির হাড়কাঁপানো শীতে",
        "ফাগুনের মিষ্টি বাতাসে",
        "বসন্তের ফুরফুরে হাওয়ায়",
        "বৈশাখী রোদ আর গরমে",
        "জ্যৈষ্ঠের তীব্র তাপদাহে",
        "আষাঢ়ের ঝুম বৃষ্টির দিনে",
        "শ্রাবণের মেঘলা আকাশে",
        "ভাদ্রের ভ্যাপসা গরমে",
        "শরতের নীল আকাশের নিচে",
        "অক্টোবরের স্নিগ্ধ বাতাসে",
        "হেমন্তের মিষ্টি হিমেল হাওয়ায়",
        "ডিসেম্বরের কুয়াশাচ্ছন্ন দিনে"
    )

    // প্রথম প্রশ্ন (ASK) — কমা-যুক্ত ৩ অংশ (কোনো উদ্ভট জোড়া নয়)
    private val ASK_LEAD = arrayOf(
        "{W} ফোন হাতে",
        "হ্যালো বন্ধু, মনটা বেশ ফুরফুরে",
        "সময়ের এক ফোঁড় অসময়ের দশ ফোঁড়",
        "আম্মু-আব্বু আশা নিয়ে তাকিয়ে আছেন",
        "আজকের {S} পড়াটা বাকি আছে",
        "ড্রাগন ও ভূতের ছোট্ট খোঁজ"
    )
    private val ASK_CTX_NORMAL = arrayOf(
        "{D} ধরে স্ক্রিন খোলা",
        "{D} হলো ফোনে আছো",
        "আজকের {R} লক্ষ্য বাকি, {D} হলো ফোনে",
        "{D} ধরে ফোনে সময় যাচ্ছে"
    )
    private val ASK_CTX_EXAM = arrayOf(
        "{E} আর {ED} দিন বাকি, {D} ধরে ফোনে",
        "{E}-এর আর {ED} দিন, {D} হলো স্ক্রিনে"
    )
    private val ASK_ACT = arrayOf(
        "এখন কি {S} পড়ছো?",
        "পড়া চলছে নাকি একটু মজার বিরতি?",
        "ফোনে কি আসলেই পড়া হচ্ছে?",
        "চলো একটু বই নিয়ে বসি?",
        "এই সময়টা কাজে লাগাবে না?",
        "মনোযোগ কি পড়ার দিকে?"
    )

    // ধাপ ১ (মজার / বন্ধুত্বপূর্ণ + প্রবাদ + ক্যারেকটার)
    private val L1_LEAD_COMMON = arrayOf(
        "সময়ের এক ফোঁড় অসময়ের দশ ফোঁড়",
        "আজকের কাজ কালকের জন্য রেখো না",
        "{W} আলসেমি একটু পরেও করা যাবে",
        "ছোট ছোট চেষ্টাই বড় স্বপ্ন গড়ে",
        "আম্মু-আব্বু আশা নিয়ে তোমার দিকে তাকিয়ে",
        "রোজ একটু এগোলেই স্বপ্ন জয় সহজ হয়"
    )
    private val L1_LEAD_DRAGON = arrayOf(
        "নরম রোদের মতো মন ভালো রাখতে",
        "ড্রাগন এখনো বেশ হাসিখুশি আছে"
    )
    private val L1_LEAD_GHOST = arrayOf(
        "শান্ত রাতটা পড়ার জন্য দারুণ",
        "বন্ধুত্বপূর্ণ ভূত নীরবে মনে করাচ্ছে"
    )
    private val L1_CTX_NORMAL = arrayOf(
        "{D} ফোনে কাটলো",
        "আজকের {R} বাকি, {D} ধরে স্ক্রিনে",
        "{D} ধরে ফোনে আছো"
    )
    private val L1_CTX_EXAM = arrayOf(
        "{E} আর {ED} দিন পর, {D} ফোনে কাটলো",
        "{E}-এর {ED} দিন বাকি, {D} ধরে স্ক্রিনে"
    )
    private val L1_ACT = arrayOf(
        "এবার একটু বই খোলো!",
        "১৫ মিনিট পড়েই দেখো!",
        "চলো {S} শুরু করি!",
        "ফোনটা পাশে রাখলে দিনটা জিতবে!",
        "স্বপ্ন পূরণে এক কদম বাড়াও!",
        "ছোট্ট শুরুটাই আজ সেরা হবে!"
    )

    // ধাপ ২ (উক্তি + প্রবাদ + তাগিদ)
    private val L2_LEAD_COMMON = arrayOf(
        "সময় ও স্রোত কারও জন্য থামে না",
        "স্বপ্ন সেটা নয় যা ঘুমিয়ে দেখো",
        "পড়ছো না? অন্যজন পড়ে ঠিকই লক্ষ্যে পৌঁছাচ্ছে",
        "আম্মুর মুখের হাসিটা একবার মনে করো",
        "আব্বুর কষ্টের ঘাম তোমার দিকে তাকিয়ে",
        "পরিশ্রমই সৌভাগ্যের প্রসূতি"
    )
    private val L2_LEAD_DRAGON = arrayOf(
        "ড্রাগনের ভুরু একটু কুঁচকে যাচ্ছে",
        "বড় ডানা ঝাপটে ড্রাগন বলছে"
    )
    private val L2_LEAD_GHOST = arrayOf(
        "রাতের ভূত আধবোজা চোখে দেখছে",
        "আলো-আঁধারির ছায়া থেকে বলছি"
    )
    private val L2_CTX_NORMAL = arrayOf(
        "{D} স্ক্রিনে চলে গেল",
        "লক্ষ্য {R} বাকি, {D} ফোনে নষ্ট",
        "এই {D}-এ একটা টপিক রিভিশন হতো"
    )
    private val L2_CTX_EXAM = arrayOf(
        "{E} আর {ED} দিন, {D} স্ক্রল করে গেল",
        "{E}-এর {ED} দিন বাকি, {D} নষ্ট হলো"
    )
    private val L2_ACT = arrayOf(
        "এবার ফোনটা উল্টে রাখো!",
        "এখন না পড়লে পড়বে কখন?",
        "{S} বইটা হাতে নাও!",
        "বন্ধুর মতো বলছি, এবার থামো!",
        "মনটাকে পড়ায় ফেরাও!",
        "আজকের {R} জমতে দিও না!"
    )

    // ধাপ ৩ ও ৪ (শাসন + ইমোশনাল + ক্যারেকটার)
    private val L34_LEAD_COMMON = arrayOf(
        "নিজের হাতে নিজের স্বপ্ন নষ্ট করছো?",
        "পড়ছো না? অন্যজন পড়ে ঠিকই জায়গা নিচ্ছে",
        "তোমার আম্মু-আব্বু আশা নিয়ে তাকিয়ে আছেন",
        "অতিরিক্ত বিলাসিতাই স্বপ্নভঙ্গের কারণ",
        "সময় নষ্ট করলে সময় তোমাকে নষ্ট করবে",
        "তুমি নিজের লক্ষ্য নিজেই ভাঙছো",
        "{W} অজুহাত এখন আর চলবে না"
    )
    private val L34_LEAD_DRAGON = arrayOf(
        "ড্রাগনের নাক দিয়ে ধোঁয়া বেরোচ্ছে",
        "ধৈর্যের বাঁধ পুড়ে যাচ্ছে",
        "গরম শ্বাস ছেড়ে ড্রাগন বলছে"
    )
    private val L34_LEAD_GHOST = arrayOf(
        "রাতের ছায়া থেকে সব দেখছি",
        "নিশীথের নীরবতা এবার ভাঙছে",
        "অশরীরী দৃষ্টি তোমার স্ক্রিনেই আছে"
    )
    private val L34_CTX_NORMAL = arrayOf(
        "{D} অপচয় হলো",
        "{D} ধরে ফোনে আছো, {R} বাকি",
        "একটানা {D} স্ক্রলিংয়ে গেছে"
    )
    private val L34_CTX_EXAM = arrayOf(
        "{E} আর {ED} দিন বাকি, {D} নষ্ট হলো",
        "{E}-এর {ED} দিন পর, {D} অপচয়"
    )
    private val L34_ACT = arrayOf(
        "এক্ষুনি স্ক্রিন বন্ধ করো!",
        "এখন না পড়লে পড়বে কখন?",
        "এই মুহূর্তে {S} বই খোলো!",
        "ফোন রাখো, আর অজুহাত নয়!",
        "এখনই ফোন উল্টে রাখো!",
        "ভিডিও-স্ক্রল বন্ধ করে পড়ো!",
        "নিজের ভবিষ্যৎ বাঁচাতে বসো!"
    )

    // ধাপ ৫ ও স্ট্রিক্ট মোড (চূড়ান্ত শাসন + গভীর ইমোশনাল + ড্রাগন/ভূত)
    private val L5_LEAD_COMMON = arrayOf(
        "তোমার পুরো ভবিষ্যৎ প্রজন্ম তোমার দিকে তাকিয়ে",
        "অতিরিক্ত বিলাসিতা একদিন কান্নার কারণ হবে",
        "সময় নষ্ট মানে ভবিষ্যৎ নষ্ট",
        "বিলাসিতা সাফল্যের বড় প্রতিবন্ধকতা",
        "প্রতিযোগীরা এই সময়ে ২টা টপিক শেষ করেছে",
        "কষ্ট না করলে কখনোই কেষ্ট মেলে না",
        "আম্মু-আব্বুর স্বপ্ন কি কাগজেই থাকবে?"
    )
    private val L5_LEAD_DRAGON = arrayOf(
        "ড্রাগনের ধৈর্য পুড়ে ছাই হচ্ছে",
        "আগুনের ক্রোধ নামার আগেই থামো",
        "ব্যস, আর এক সেকেন্ডও সহ্য নয়"
    )
    private val L5_LEAD_GHOST = arrayOf(
        "অভিশপ্ত আলসেমি তোমায় গ্রাস করছে",
        "রাতের ক্রোধে বাতাস ভারী হয়ে উঠেছে",
        "ভুতুড়ে মায়া ছেড়ে বাস্তবে ফেরো"
    )
    private val L5_CTX_NORMAL = arrayOf(
        "{D} ফোনে নষ্ট হয়েছে",
        "টানা {D} ধরে স্ক্রিনে, {R} বাকি",
        "{D} অপচয় করে ফেলেছো"
    )
    private val L5_CTX_EXAM = arrayOf(
        "{E} আর মাত্র {ED} দিন, {D} নষ্ট হলো",
        "{E}-এর {ED} দিন বাকি, {D} স্ক্রিনে গেছে"
    )
    private val L5_ACT = arrayOf(
        "এক্ষুনি ফোন উল্টে পড়তে বসো!",
        "এখন না পড়লে পড়বে কখন?!",
        "সব ছেড়ে এক্ষুনি {S} খোলো!",
        "আর ১ মিনিটও স্ক্রিনে নয়!",
        "ফোন রাখো, এখন লড়াইয়ের সময়!",
        "নিজের জন্য হলেও এখন ওঠো!",
        "লক্ষ্য {R} শেষ না করে থামবে না!",
        "আজকের দিনটা বৃথা যেতে দিও না!"
    )

    // পুনঃযাচাই, Idle ও বাইরে
    private val RECHECK_MSGS = arrayOf(
        "{W} দারুণ ফোকাস, এখনো কি {S} পড়ছো?",
        "{E} আর {ED} দিন বাকি, অনলাইন পড়া ঠিকমতো চলছে তো?",
        "আজকের লক্ষ্যের {R} বাকি, মনোযোগ ধরে রেখেছো তো?",
        "ভালো চলছে, এখনো কি ক্লাস বা নোট দেখছো?",
        "আম্মু-আব্বুর স্বপ্ন পূরণে পড়া এখনো চলমান তো?",
        "অনেকক্ষণ হলো, স্ক্রলিংয়ে চলে যাওনি তো?"
    )
    private val IDLE_MSGS = arrayOf(
        "{W} {D} ধরে ফোন বন্ধ, আশা করি বই নিয়ে বসেছো?",
        "{D} ধরে পড়া থেকে দূরে, {E} আর {ED} দিন বাকি",
        "লক্ষ্যের {R} বাকি, {D} বিরতি হলো, অফলাইনে পড়ছো তো?",
        "ছোট ছোট চেষ্টাই {E} জিতবে, {D} পর খোঁজ নিলাম!",
        "তোমার স্বপ্ন অপেক্ষা করছে, {D} ধরে সেশন বন্ধ!",
        "অফলাইনে {S} পড়ছো, নাকি বাইরে আছো?"
    )
    private val AWAY_PRE_MSGS = arrayOf(
        "আর মাত্র {D} বাকি, {E}-র প্রস্তুতিতে ফেরার পালা!",
        "হাতে আর {D}, ধীরে ধীরে {S} নিয়ে টেবিলে বসো!",
        "আর {D} পরই পড়া শুরু, লক্ষ্যের {R} বাকি আছে!"
    )
    private val AWAY_END_MSGS = arrayOf(
        "বাইরে থাকার {D} শেষ, {E} আর {ED} দিন, এবার বসো!",
        "বিরতি শেষ ({D}), আজকের {R} পূরণ করতে টেবিলে এসো!",
        "সময় শেষ, {W} ফ্রেশ হয়ে এবার {S} শুরু করো!"
    )


    private val SERIOUS_STEP1 = arrayOf(
        "ফোন স্ক্রল করেই ক্যাডার হয়ে যাবে, {name}?",
        "বয়স আর মাত্র {ageLeft} বাকি, তবুও নবাবজাদার মতো রিলস দেখছো!",
        "পরীক্ষার হলে রিলসের ভিডিও লিখবে, না বইয়ের পড়া?",
        "নিজের সাথেই নিজে ধোঁকাবাজি করছো, আজকের {R} পড়া কে করবে?",
        "সবাই পড়ছে, আর মহারাজ ফোনের স্ক্রিন ঘষে সময় মারছেন!",
        "এভাবে চললে চাকরি দূরের কথা, নিজেকেই জবাব দিতে পারবে না!"
    )

    private val SERIOUS_STEP2 = arrayOf(
        "এই ফাঁকিবাজ, আর কতক্ষণ ফোন টিপবি? বই খোল এখনই!",
        "এক নম্বর কুঁড়ে হয়ে গেছিস, {D} ধরে ফোনে পড়ে আছিস!",
        "আরে বলদ, যে সময়টা ফোনে গিলছিস, ওটা আর ফিরে পাবি?",
        "ভোঁদাইয়ের মতো তাকিয়ে আছিস কেন স্ক্রিনের দিকে? ফোন রাখ!",
        "নির্লজ্জের মতো আবার নোটিফিকেশন দেখছিস? লজ্জা করে না?",
        "অকর্মণ্য নবাবজাদা, {E}-এর আর {ED} দিন বাকি, এখনো হুঁশ নেই!",
        "বড় পণ্ডিত হয়ে গেছিস নাকি? বই ছাড়া সবই বোঝা যাচ্ছে!",
        "নিজের সময়ের সবচেয়ে বড় চোর তুই নিজেই, এই মুহূর্তে ফোন উল্টা!",
        "বোকার মতো স্ক্রল করে নিজের ভবিষ্যৎ নিজেই নষ্ট করছিস!",
        "পড়ার ভান ধরে ফোনে ভাঁড়ামি বন্ধ কর, এখনই টেবিলে বস!"
    )

    private data class CatPool(val lead: List<String>, val act: List<String>)
    private data class MessageBank(
        val ctxNormal: List<String>,
        val ctxExam: List<String>,
        val cats: Map<String, CatPool>
    )

    @Volatile
    private var cachedBank: MessageBank? = null

    private fun loadBank(ctx: Context): MessageBank? {
        cachedBank?.let { return it }
        return try {
            val raw = ctx.applicationContext.assets.open("messages_bn.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = JSONObject(raw)
            fun strList(arr: org.json.JSONArray?): List<String> {
                if (arr == null) return emptyList()
                val out = ArrayList<String>(arr.length())
                for (i in 0 until arr.length()) out.add(arr.getString(i))
                return out
            }
            val cn = strList(root.optJSONArray("shared_ctx_normal"))
            val ce = strList(root.optJSONArray("shared_ctx_exam"))
            val map = HashMap<String, CatPool>()
            val keys = listOf("ask", "l1", "l2", "l34", "l5", "serious1", "serious2", "morning", "recheck", "idle", "away_pre", "away_end")
            for (k in keys) {
                val obj = root.optJSONObject(k) ?: continue
                val l = strList(obj.optJSONArray("lead"))
                val a = strList(obj.optJSONArray("act"))
                if (l.isNotEmpty() && a.isNotEmpty()) map[k] = CatPool(l, a)
            }
            MessageBank(cn, ce, map).also { cachedBank = it }
        } catch (_: Exception) {
            null
        }
    }

    private fun gcd(a: Long, b: Long): Long {
        var x = if (a < 0) -a else a
        var y = if (b < 0) -b else b
        while (y != 0L) {
            val t = x % y
            x = y
            y = t
        }
        return x
    }

    /** ১-সংখ্যার সহমৌলিক (Co-prime) ফর্মুলা: cursor = 0..N-1 পর্যন্ত একটিও রিপিট হবে না। */
    private fun permuteIndex(cursor: Long, n: Long, seed: Long): Long {
        if (n <= 1L) return 0L
        var step = 7919L % n
        if (step < 1L) step = 1L
        while (gcd(step, n) != 1L) {
            step = (step + 1L) % n
            if (step == 0L) step = 1L
        }
        val offset = ((seed % n) + n) % n
        val pos = ((cursor % n) + n) % n
        return (pos * step + offset) % n
    }

    private fun joinParts(vararg parts: String): String {
        val sb = StringBuilder()
        for (raw in parts) {
            val p = raw.trim()
            if (p.isEmpty()) continue
            if (sb.isNotEmpty()) {
                val last = sb[sb.length - 1]
                if (last == '!' || last == '?' || last == '।' || last == '—') {
                    sb.append(' ')
                } else {
                    sb.append(", ")
                }
            }
            sb.append(p)
        }
        return sb.toString()
    }

    fun messageFor(ctx: Context, kind: String, level: Int, elapsedMin: Int = 0, msgIndex: Int = 0): String {
        val cal = Calendar.getInstance()
        val monthIdx = cal.get(Calendar.MONTH).coerceIn(0, 11)
        val weather = WEATHER_BY_MONTH[monthIdx]
        val dur = if (elapsedMin > 0) formatDurationBn(elapsedMin) else "কিছুক্ষণ"
        val examName = DataStore.getExamName(ctx)
        val daysLeft = DataStore.getDaysUntilExam(ctx)
        val examCountdown = DataStore.formatExamCountdownBn(ctx)
        val subject = DataStore.getCurrentSubject(ctx)
        val hr = currentHour()
        val bucket = timeBucket(hr)
        val timePhrase = when (bucket) {
            TimeBucket.DAWN -> "ভোরের এই স্নিগ্ধ আলোয়"
            TimeBucket.MORNING -> "সকালের এই ফ্রেশ সময়ে"
            TimeBucket.NOON -> "দুপুরের এই শান্ত বেলায়"
            TimeBucket.AFTERNOON -> "বিকেলের ঝিমুনি কাটাতে"
            TimeBucket.EVENING -> "সন্ধ্যার এই চমৎকার সময়ে"
            TimeBucket.NIGHT -> "রাতের এই নীরব প্রহরে"
            TimeBucket.LATE_NIGHT -> "গভীর রাতের এই নির্জনতায়"
        }
        val nick = DataStore.getProfNickname(ctx)
        val ageLeft = DataStore.computeProfileAgeAndRemaining(ctx)?.second ?: "সীমিত সময়"
        val targetYear = DataStore.getProfTargetYear(ctx).trim().let { if (it.isNotEmpty()) DataStore.toBnDigits(it) else "লক্ষ্য" }

        val todayStudyMin = DataStore.getToday(ctx).totalStudyMinutes()
        val goalMin = DataStore.getDailyGoalHours(ctx) * 60
        val remMin = (goalMin - todayStudyMin).coerceAtLeast(0)
        val remText = if (remMin > 0) formatDurationBn(remMin) else "লক্ষ্য পূরণ"

        fun fill(tpl: String): String = tpl
            .replace("{W}", weather)
            .replace("{T}", timePhrase)
            .replace("{name}", nick.ifEmpty { "বন্ধু" })
            .replace("{ageLeft}", ageLeft)
            .replace("{targetYear}", targetYear)
            .replace("{daysToExam}", DataStore.toBnDigits(daysLeft))
            .replace("{D}", dur)
            .replace("{E}", examName)
            .replace("{ED}", examCountdown)
            .replace("{S}", subject)
            .replace("{R}", remText)

        // পরীক্ষার দিন যত কাছে, পরীক্ষার প্রসঙ্গ আসার হার তত বেশি
        val examPct = when {
            daysLeft < 2 -> 75
            daysLeft < 5 -> 70
            daysLeft < 10 -> 60
            daysLeft < 15 -> 40
            daysLeft < 30 -> 20
            else -> 15
        }

        val bank = loadBank(ctx)
        if (bank != null) {
            val seriousAfterMin = DataStore.getSrSeriousAfterMin(ctx)
            val crossedPhoneTime = seriousAfterMin > 0 && elapsedMin >= seriousAfterMin
            val reachedExtreme = DataStore.getSrSeriousDailyCount(ctx) >= 2 && level >= 4
            val isSeriousNow = DataStore.isSrSeriousMode(ctx) && DataStore.canFireSeriousHourly(ctx) &&
                (kind == KIND_ANGRY || kind == KIND_STRICT) && (crossedPhoneTime || reachedExtreme)

            val catKey = when {
                kind == KIND_MORNING -> "morning"
                kind == KIND_RECHECK -> "recheck"
                kind == KIND_IDLE -> "idle"
                kind == KIND_AWAY_PRE -> "away_pre"
                kind == KIND_AWAY_END -> "away_end"
                isSeriousNow -> {
                    val useStep2 = level >= 5 || crossedPhoneTime || DataStore.getSrSeriousDailyCount(ctx) >= 3
                    if (useStep2) "serious2" else "serious1"
                }
                kind == KIND_ASK -> "ask"
                kind == KIND_STRICT || level >= 5 -> "l5"
                level <= 1 -> "l1"
                level == 2 -> "l2"
                else -> "l34"
            }

            val pool = bank.cats[catKey]
            if (pool != null) {
                val seed = DataStore.getOrInitMsgSeed(ctx) + catKey.hashCode().toLong() * 31L
                val cur = DataStore.nextMsgCursor(ctx, catKey)
                val lSz = pool.lead.size.toLong()
                val aSz = pool.act.size.toLong()
                val supportsCtx = catKey in setOf("ask", "l1", "l2", "l34", "l5", "serious1", "serious2")
                // ৭০% ছোট (২ অংশ), ৩০% মাঝারি (৩ অংশ — পরীক্ষা/সময় প্রসঙ্গসহ)
                val useMedium = supportsCtx && (cur % 10L) >= 7L && (bank.ctxNormal.isNotEmpty() || bank.ctxExam.isNotEmpty())

                if (!useMedium) {
                    val nShort = lSz * aSz
                    val uid = permuteIndex(cur, nShort, seed)
                    val li = (uid / aSz).toInt()
                    val ai = (uid % aSz).toInt()
                    return fill(joinParts(pool.lead[li], pool.act[ai]))
                } else {
                    val useExamCtx = ((cur * 37L + seed) % 100L + 100L) % 100L < examPct && bank.ctxExam.isNotEmpty()
                    val ctxList = if (useExamCtx) bank.ctxExam else bank.ctxNormal
                    val cSz = ctxList.size.toLong()
                    val nMed = lSz * cSz * aSz
                    val uid = permuteIndex(cur, nMed, seed + if (useExamCtx) 997L else 331L)
                    val li = (uid / (cSz * aSz)).toInt()
                    val rem = uid % (cSz * aSz)
                    val ci = (rem / aSz).toInt()
                    val ai = (rem % aSz).toInt()
                    return fill(joinParts(pool.lead[li], ctxList[ci], pool.act[ai]))
                }
            }
        }

        // নিরাপদ ফলব্যাক (যদি অ্যাসেট লোড না হয়)
        return fill("হেই {name}, {E}-এর আর {ED} বাকি—এখন একটু {S} পড়ে নেবে?")
    }
}
