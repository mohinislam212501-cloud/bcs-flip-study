package com.bcs.flipstudy

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import java.util.Calendar

object MascotContent {

    const val KIND_ASK = "ASK"
    const val KIND_RECHECK = "RECHECK"
    const val KIND_ANGRY = "ANGRY"
    const val KIND_IDLE = "IDLE"

    fun mascotResForLevel(level: Int): Int = when (level.coerceIn(1, 5)) {
        1 -> R.drawable.mascot_1
        2 -> R.drawable.mascot_2
        3 -> R.drawable.mascot_3
        4 -> R.drawable.mascot_4
        else -> R.drawable.mascot_5
    }

    fun resolveCharacter(ctx: Context): String {
        return when (DataStore.getSrMascotStyle(ctx)) {
            "dragon" -> "dragon"
            "ghost" -> "ghost"
            else -> {
                // অটো: নাইট মোড বা সন্ধ্যা ৬টা–সকাল ৬টা হলে রাতের ভূত, দিনে ড্রাগন
                val nightMode = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
                val themePref = DataStore.getThemeMode(ctx)
                val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                val isNight = when (themePref) {
                    "night" -> true
                    "day" -> false
                    else -> nightMode || hour >= 18 || hour < 6
                }
                if (isNight) "ghost" else "dragon"
            }
        }
    }

    fun accentColorFor(character: String, level: Int): Int {
        val lvl = level.coerceIn(1, 5)
        return if (character == "ghost") {
            when (lvl) {
                1 -> Color.parseColor("#7FE3FF")
                2 -> Color.parseColor("#A58BFF")
                3 -> Color.parseColor("#D060FF")
                4 -> Color.parseColor("#FF4A7A")
                else -> Color.parseColor("#FF3B1F")
            }
        } else {
            when (lvl) {
                1 -> Color.parseColor("#34D399")
                2 -> Color.parseColor("#FBBF24")
                3 -> Color.parseColor("#F97316")
                4 -> Color.parseColor("#EF4444")
                else -> Color.parseColor("#FF3B30")
            }
        }
    }

    fun titleFor(kind: String, level: Int): String = when (kind) {
        KIND_ASK -> "ফোনে কী করছো?"
        KIND_RECHECK -> "এখনো পড়ছো?"
        KIND_IDLE -> "পড়তে বসার সময় হয়েছে!"
        else -> titleForAngryLevel(level)
    }

    fun messageFor(kind: String, level: Int): String = when (kind) {
        KIND_ASK -> "বেশ কিছুক্ষণ ধরে ফোন চালাচ্ছো—পড়াশোনা করছো নাকি সময় নষ্ট হচ্ছে?"
        KIND_RECHECK -> "অনলাইন পড়া কি এখনো চলছে, নাকি অন্যদিকে চলে গেছো?"
        KIND_IDLE -> "অনেকক্ষণ বিরতি হয়ে গেল! চলো আজকের BCS লক্ষ্যের দিকে একটু এগিয়ে যাই।"
        else -> messageForAngryLevel(level)
    }

    fun titleForAngryLevel(level: Int): String = when (level.coerceIn(1, 5)) {
        1 -> "এই যে! পড়ায় ফিরবে না?"
        2 -> "বিরক্ত হচ্ছি কিন্তু!"
        3 -> "এবার সত্যিই রাগ উঠছে!"
        4 -> "ধৈর্যের সীমা ছাড়িয়ে যাচ্ছে!"
        else -> "চূড়ান্ত সতর্কতা!! এখনই ফোন রাখো!"
    }

    fun messageForAngryLevel(level: Int): String = when (level.coerceIn(1, 5)) {
        1 -> "অকারণে ফোন চালালে আজকের লক্ষ্য পিছিয়ে যাবে। চলো পড়ায় ফিরি!"
        2 -> "আবার স্ক্রিনে আটকে আছো? এবার ফোনটা উল্টে রেখে বই খোলো!"
        3 -> "BCS সিলেবাস কিন্তু কারও জন্য অপেক্ষা করছে না—এখনই মনোযোগ দাও!"
        4 -> "আর কত সময় নষ্ট করবে! এখনই ফোন রাখো, নাহলে আজকের টার্গেট শেষ!"
        else -> "আর এক সেকেন্ডও নয়! এখনই ফোন উল্টে পড়তে বসো!"
    }
}
