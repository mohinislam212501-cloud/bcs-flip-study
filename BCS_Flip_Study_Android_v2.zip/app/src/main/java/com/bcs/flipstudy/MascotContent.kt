package com.bcs.flipstudy

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import java.util.Calendar

object MascotContent {

    const val KIND_ASK = "ASK"
    const val KIND_RECHECK = "RECHECK"
    const val KIND_ANGRY = "ANGRY"
    const val KIND_STRICT = "STRICT"
    const val KIND_IDLE = "IDLE"
    const val KIND_AWAY_PRE = "AWAY_PRE"
    const val KIND_AWAY_END = "AWAY_END"

    fun mascotResFor(character: String, level: Int): Int {
        val lvl = level.coerceIn(1, 5)
        return if (character == "ghost") {
            when (lvl) {
                1 -> R.drawable.vec_mascot_ghost_1
                2 -> R.drawable.vec_mascot_ghost_2
                3 -> R.drawable.vec_mascot_ghost_3
                4 -> R.drawable.vec_mascot_ghost_4
                else -> R.drawable.vec_mascot_ghost_5
            }
        } else {
            when (lvl) {
                1 -> R.drawable.vec_mascot_dragon_1
                2 -> R.drawable.vec_mascot_dragon_2
                3 -> R.drawable.vec_mascot_dragon_3
                4 -> R.drawable.vec_mascot_dragon_4
                else -> R.drawable.vec_mascot_dragon_5
            }
        }
    }

    fun mascotResForLevel(level: Int): Int = mascotResFor("dragon", level)

    fun resolveCharacter(ctx: Context): String {
        return when (DataStore.getSrMascotStyle(ctx)) {
            "dragon" -> "dragon"
            "ghost" -> "ghost"
            else -> {
                val nightMode = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
                val themePref = DataStore.getThemeMode(ctx)
                val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                val isNight = when (themePref) {
                    "night" -> true
                    "day" -> false
                    else -> nightMode || hour >= 18 || hour < 6
                }
                if (isNight) "ghost" else "dragon"
            }
        }
    }

    fun accentColorFor(character: String, level: Int): Int {
        val lvl = level.coerceIn(1, 5)
        return if (character == "ghost") {
            when (lvl) {
                1 -> Color.parseColor("#7FE3FF")
                2 -> Color.parseColor("#A58BFF")
                3 -> Color.parseColor("#D060FF")
                4 -> Color.parseColor("#FF4A7A")
                else -> Color.parseColor("#FF3B1F")
            }
        } else {
            when (lvl) {
                1 -> Color.parseColor("#34D399")
                2 -> Color.parseColor("#FBBF24")
                3 -> Color.parseColor("#F97316")
                4 -> Color.parseColor("#EF4444")
                else -> Color.parseColor("#FF3B30")
            }
        }
    }

    fun formatDurationBn(minutes: Int): String {
        val m = minutes.coerceAtLeast(1)
        val h = m / 60
        val rem = m % 60
        return when {
            h > 0 && rem > 0 -> "${DataStore.toBnDigits(h)}ঘ ${DataStore.toBnDigits(rem)}মি"
            h > 0 -> "${DataStore.toBnDigits(h)} ঘণ্টা"
            else -> "${DataStore.toBnDigits(m)} মি."
        }
    }

    fun titleFor(kind: String, level: Int, elapsedMin: Int = 0): String = when (kind) {
        KIND_ASK -> "ফোনে কী করছো?"
        KIND_RECHECK -> "এখনো পড়ছো?"
        KIND_IDLE -> "পড়া থেকে দূরে আছো!"
        KIND_AWAY_PRE -> "পড়তে বসার সময় হয়ে এলো!"
        KIND_AWAY_END -> "বাইরে থাকার সময় শেষ!"
        KIND_STRICT -> if (elapsedMin > 0) "${formatDurationBn(elapsedMin)} ফোন চালানো হয়েছে!!" else "এখনই পড়তে বসো!!"
        else -> titleForAngryLevel(level)
    }

    fun messageFor(ctx: Context, kind: String, level: Int, elapsedMin: Int = 0, msgIndex: Int = 0): String {
        val dur = if (elapsedMin > 0) formatDurationBn(elapsedMin) else ""
        return when (kind) {
            KIND_ASK -> {
                if (dur.isNotEmpty()) "তুমি $dur ধরে ফোন চালাচ্ছো—পড়াশোনা করছো নাকি সময় নষ্ট হচ্ছে?"
                else "বেশ কিছুক্ষণ ধরে ফোন চালাচ্ছো—পড়াশোনা করছো নাকি সময় নষ্ট হচ্ছে?"
            }
            KIND_RECHECK -> "অনলাইন পড়া কি এখনো চলছে, নাকি অন্যদিকে চলে গেছো?"
            KIND_IDLE -> {
                if (dur.isNotEmpty()) "$dur ধরে ডিসপ্লে বন্ধ ও পড়া থেকে দূরে আছো! এখন কি পড়ছো নাকি বাইরে আছো?"
                else "অনেকক্ষণ ধরে পড়া থেকে দূরে আছো! এখন কি পড়ছো নাকি বাইরে আছো?"
            }
            KIND_AWAY_PRE -> {
                if (dur.isNotEmpty()) "আর মাত্র $dur পর তোমার পড়তে বসার সময়—প্রস্তুত হয়ে নাও!"
                else "আর কিছুক্ষণ পর তোমার পড়তে বসার সময়—প্রস্তুত হয়ে নাও!"
            }
            KIND_AWAY_END -> {
                if (dur.isNotEmpty()) "বাইরে থাকার $dur শেষ হয়ে গেছে! চলো এবার টেবিলে ফিরে পড়তে বসি।"
                else "বাইরে থাকার সময় শেষ! চলো এবার পড়তে বসি।"
            }
            KIND_STRICT -> strictMessage(ctx, elapsedMin, msgIndex)
            else -> angryMessage(ctx, level, elapsedMin, msgIndex)
        }
    }

    fun titleForAngryLevel(level: Int): String = when (level.coerceIn(1, 5)) {
        1 -> "এই যে! পড়ায় ফিরবে না?"
        2 -> "বিরক্ত হচ্ছি কিন্তু!"
        3 -> "এবার সত্যিই রাগ উঠছে!"
        4 -> "ধৈর্যের সীমা ছাড়িয়ে যাচ্ছে!"
        else -> "চূড়ান্ত সতর্কতা!! এখনই ফোন রাখো!"
    }

    private fun angryMessage(ctx: Context, level: Int, elapsedMin: Int, msgIndex: Int): String {
        val durPrefix = if (elapsedMin > 0) "তুমি ${formatDurationBn(elapsedMin)} ধরে ফোন চালাচ্ছো! " else ""
        return when (level.coerceIn(1, 5)) {
            1 -> "${durPrefix}অকারণে ফোন চালালে আজকের লক্ষ্য পিছিয়ে যাবে। চলো পড়ায় ফিরি!"
            2 -> "${durPrefix}আবার স্ক্রিনে আটকে আছো? এবার ফোনটা উল্টে রেখে বই খোলো!"
            3 -> "${durPrefix}BCS সিলেবাস কিন্তু কারও জন্য অপেক্ষা করছে না—এখনই মনোযোগ দাও!"
            4 -> "${durPrefix}আর কত সময় নষ্ট করবে! এখনই ফোন রাখো, নাহলে আজকের টার্গেট শেষ!"
            else -> strictMessage(ctx, elapsedMin, msgIndex)
        }
    }

    private fun strictMessage(ctx: Context, elapsedMin: Int, msgIndex: Int): String {
        val dur = if (elapsedMin > 0) formatDurationBn(elapsedMin) else "অনেকক্ষণ"
        val goalMin = DataStore.getDailyGoalHours(ctx) * 60
        val doneMin = DataStore.getToday(ctx).totalStudyMinutes()
        val remMin = (goalMin - doneMin).coerceAtLeast(0)
        val remText = if (remMin > 0) formatDurationBn(remMin) else "সামান্য"
        val examDays = DataStore.toBnDigits(DataStore.getDaysUntilExam(ctx))
        val examName = DataStore.getExamName(ctx)

        val variants = arrayOf(
            "টানা $dur ধরে ফোন চালাচ্ছো! আর এক সেকেন্ডও নয়—এখনই ফোন উল্টে পড়তে বসো!",
            "$dur চলে গেল ফোনে! আজকের লক্ষ্যের এখনো $remText বাকি—এখনই বই খোলো!",
            "$examName-এর আর মাত্র $examDays দিন বাকি, আর তুমি $dur ধরে স্ক্রিন দেখছো!",
            "আর কত স্ক্রল করবে? $dur নষ্ট হয়েছে—এবার ফোনটা রেখে ১টা অধ্যায় শেষ করো!",
            "প্রতি মিনিট মূল্যবান! $dur ফোন চালানো শেষ—এখনই টেবিলে ফিরে যাও!",
            "$dur অপচয় হচ্ছে! আজকের $remText পড়া শেষ না করে ফোন চালাবে না!",
            "তোমার প্রতিযোগীরা এখন পড়ছে, আর তুমি $dur ধরে ফোনে আছো—এখনই ওঠো!",
            "যথেষ্ট হয়েছে! $dur ফোনে কেটে গেছে—ফোন উল্টে রেখে ফোকাস শুরু করো!",
            "মনে রেখো, $examName আর $examDays দিন পর! $dur নষ্ট হলো—এবার পড়তে বসো!",
            "একবার ফোন রেখে দেখো—$dur নষ্ট হলেও এখনো $remText কভার করা সম্ভব!"
        )
        val idx = ((msgIndex % variants.size) + variants.size) % variants.size
        return variants[idx]
    }
}
