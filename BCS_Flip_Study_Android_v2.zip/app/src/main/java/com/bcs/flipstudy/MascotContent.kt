package com.bcs.flipstudy

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import java.util.Calendar

object MascotContent {

    const val KIND_ASK = "ASK"
    const val KIND_RECHECK = "RECHECK"
    const val KIND_ANGRY = "ANGRY"
    const val KIND_STRICT = "STRICT"
    const val KIND_IDLE = "IDLE"
    const val KIND_AWAY_PRE = "AWAY_PRE"
    const val KIND_AWAY_END = "AWAY_END"

    fun mascotResFor(character: String, level: Int): Int {
        val lvl = level.coerceIn(1, 5)
        return if (character == "ghost") {
            when (lvl) {
                1 -> R.drawable.vec_mascot_ghost_1
                2 -> R.drawable.vec_mascot_ghost_2
                3 -> R.drawable.vec_mascot_ghost_3
                4 -> R.drawable.vec_mascot_ghost_4
                else -> R.drawable.vec_mascot_ghost_5
            }
        } else {
            when (lvl) {
                1 -> R.drawable.vec_mascot_dragon_1
                2 -> R.drawable.vec_mascot_dragon_2
                3 -> R.drawable.vec_mascot_dragon_3
                4 -> R.drawable.vec_mascot_dragon_4
                else -> R.drawable.vec_mascot_dragon_5
            }
        }
    }

    fun mascotResForLevel(level: Int): Int = mascotResFor("dragon", level)

    fun resolveCharacter(ctx: Context): String {
        return when (DataStore.getSrMascotStyle(ctx)) {
            "dragon" -> "dragon"
            "ghost" -> "ghost"
            else -> {
                val nightMode = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
                val themePref = DataStore.getThemeMode(ctx)
                val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                val isNight = when (themePref) {
                    "night" -> true
                    "day" -> false
                    else -> nightMode || hour >= 18 || hour < 6
                }
                if (isNight) "ghost" else "dragon"
            }
        }
    }

    fun accentColorFor(character: String, level: Int): Int {
        val lvl = level.coerceIn(1, 5)
        return if (character == "ghost") {
            when (lvl) {
                1 -> Color.parseColor("#7FE3FF")
                2 -> Color.parseColor("#A58BFF")
                3 -> Color.parseColor("#D060FF")
                4 -> Color.parseColor("#FF4A7A")
                else -> Color.parseColor("#FF3B1F")
            }
        } else {
            when (lvl) {
                1 -> Color.parseColor("#34D399")
                2 -> Color.parseColor("#FBBF24")
                3 -> Color.parseColor("#F97316")
                4 -> Color.parseColor("#EF4444")
                else -> Color.parseColor("#FF3B30")
            }
        }
    }

    fun formatDurationBn(minutes: Int): String {
        val m = minutes.coerceAtLeast(1)
        val h = m / 60
        val rem = m % 60
        return when {
            h > 0 && rem > 0 -> "${DataStore.toBnDigits(h)}ঘ ${DataStore.toBnDigits(rem)}মি"
            h > 0 -> "${DataStore.toBnDigits(h)} ঘণ্টা"
            else -> "${DataStore.toBnDigits(m)} মি."
        }
    }

    fun titleFor(kind: String, level: Int, elapsedMin: Int = 0): String = when (kind) {
        KIND_ASK -> "ফোনে কী করছো?"
        KIND_RECHECK -> "এখনো পড়ছো?"
        KIND_IDLE -> "পড়া থেকে দূরে আছো!"
        KIND_AWAY_PRE -> "পড়তে বসার সময় হয়ে এলো!"
        KIND_AWAY_END -> "বাইরে থাকার সময় শেষ!"
        KIND_STRICT -> if (elapsedMin > 0) "${formatDurationBn(elapsedMin)} ফোন চালানো হয়েছে!!" else "এখনই পড়তে বসো!!"
        else -> titleForAngryLevel(level)
    }

    fun titleForAngryLevel(level: Int): String = when (level.coerceIn(1, 5)) {
        1 -> "এই যে! পড়ায় ফিরবে না?"
        2 -> "বিরক্ত হচ্ছি কিন্তু!"
        3 -> "এবার সত্যিই রাগ উঠছে!"
        4 -> "ধৈর্যের সীমা ছাড়িয়ে যাচ্ছে!"
        else -> "চূড়ান্ত সতর্কতা!! এখনই ফোন রাখো!"
    }

    // ------------------------------------------------------------------ 100+ বাক্যাংশের ৩৬৫-দিন কম্বিনেশন ইঞ্জিন

    private val WEATHER_BY_MONTH = arrayOf(
        "জানুয়ারির হাড়কাঁপানো শীতে",       // 0
        "ফাগুনের মিষ্টি বাতাসে",           // 1
        "বসন্তের ফুরফুরে হাওয়ায়",         // 2
        "বৈশাখী রোদ আর গরমে",             // 3
        "জ্যৈষ্ঠের তীব্র তাপদাহে",          // 4
        "আষাঢ়ের ঝুম বৃষ্টির দিনে",         // 5
        "শ্রাবণের মেঘলা আকাশে",            // 6
        "ভাদ্রের ভ্যাপসা গরমে",            // 7
        "শরতের নীল আকাশের নিচে",          // 8
        "অক্টোবরের স্নিগ্ধ বাতাসে",          // 9
        "হেমন্তের মিষ্টি হিমেল হাওয়ায়",      // 10
        "ডিসেম্বরের কুয়াশাচ্ছন্ন দিনে"       // 11
    )

    // টিয়ার ১: বন্ধুত্বপূর্ণ প্রথম প্রশ্ন (ASK) — ১৮টি বাক্যাংশ
    private val ASK_OPENERS = arrayOf(
        "{W} {D} ধরে ফোনে",
        "{E} আর {ED} দিন—{D} হলো স্ক্রিনে",
        "হ্যালো বন্ধু! {D} ধরে ফোন হাতে",
        "{S} পড়ার কথা, {D} ধরে স্ক্রিনে",
        "শুরুতেই ছোট্ট খোঁজ: {D} হলো ফোনে",
        "আজকের লক্ষ্যের {R} বাকি, {D} ফোনে",
        "{W} মন একটু নরম হতেই পারে—{D} হলো",
        "সময়ের এক ফোঁড়, অসময়ের দশ ফোঁড়—{D} গেছে",
        "ভালো থেকো—{D} ধরে স্ক্রিন খোলা"
    )
    private val ASK_ENDINGS = arrayOf(
        "পড়া চলছে তো?",
        "এখন কি {S} পড়ছো?",
        "পড়া নাকি একটু বিরতি?",
        "ফোনে কি আসলেই পড়া হচ্ছে?",
        "আম্মু-আব্বুর স্বপ্নটা মনে আছে তো?",
        "চলো {E}-র দিকে এক ধাপ এগোই?",
        "একটু বই নিয়ে বসবে নাকি?",
        "মনোযোগ কি পড়ার দিকে?",
        "এই সময়টা কাজে লাগাবে না?"
    )

    // টিয়ার ২: ধাপ ১ (হালকা উপদেশ ও প্রেরণা) — ২০টি বাক্যাংশ
    private val L1_CORES = arrayOf(
        "{D} ধরে ফোনে—আজকের {R} এখনো বাকি",
        "{W} আলসেমি ছেড়ে {S} ধরো",
        "আজকের কাজ কালকের জন্য রেখো না—{D} গেছে",
        "আম্মু-আব্বু আশা নিয়ে তোমার দিকে তাকিয়ে—{D} হলো",
        "{E} আর {ED} দিন পর, {D} ফোনে কাটলো",
        "ছোট ছোট চেষ্টাই বড় স্বপ্ন গড়ে—{D} গেছে",
        "তোমার স্বপ্ন তোমার হাতেই—{D} ধরে স্ক্রিনে",
        "একটা অধ্যায় শেষ করলে মনটা ভালো লাগবে",
        "কষ্টের ফল মিষ্টি হয়—{D} ফোনে গেছে",
        "রোজ একটু এগোলেই {E} জয় সহজ হবে"
    )
    private val L1_ACTIONS = arrayOf(
        "এবার বই খোলো!",
        "১৫ মিনিট পড়েই দেখো!",
        "চলো {S} শুরু করি!",
        "ফোনটা পাশে রাখো না!",
        "এখনই পড়ায় ফিরলে দিনটা জিতবে!",
        "নিজের জন্য একটু সময় দাও!",
        "ছোট্ট শুরুটাই আজ সেরা হবে!",
        "মন দিয়ে {S} ধরো!",
        "লক্ষ্য {R} পূরণে বসো!",
        "স্বপ্ন পূরণে এক কদম বাড়াও!"
    )

    // টিয়ার ৩: ধাপ ২ (নরম তাগিদ + উক্তি + পরিবার) — ২০টি বাক্যাংশ
    private val L2_CORES = arrayOf(
        "সময় ও স্রোত কারও জন্য থামে না—{D} গেছে",
        "{W} আরাম পরেও পাবে—{D} ফোনে নষ্ট",
        "স্বপ্ন সেটা নয় যা ঘুমিয়ে দেখো—{D} স্ক্রিনে",
        "পড়ছো না? অন্যজন পড়ে ঠিকই লক্ষ্যে পৌঁছাচ্ছে",
        "আম্মুর মুখের হাসিটা মনে করো—{D} চলে গেল",
        "আব্বুর কষ্টের ঘাম তোমার দিকে তাকিয়ে—{D} হলো",
        "{E} আর {ED} দিন—{D} স্ক্রল করে গেল",
        "লক্ষ্য {R} বাকি, অথচ {D} ফোনে কাটলো",
        "প্রতি মিনিট মূল্যবান—{D} ধরে স্ক্রিনে আছো",
        "এই {D}-এ একটা টপিক রিভিশন হয়ে যেত"
    )
    private val L2_ACTIONS = arrayOf(
        "এবার ফোনটা উল্টে রাখো!",
        "এখন না পড়লে পড়বে কখন?",
        "বইটা হাতে নাও!",
        "{S} নিয়ে বসে পড়ো!",
        "আর দেরি কোরো না!",
        "ফোন রেখে টেবিলে ফেরো!",
        "বন্ধুর মতো বলছি—এবার থামো!",
        "আজকের {R} জমতে দিও না!",
        "মনটাকে পড়ায় ফেরাও!",
        "লক্ষ্যের দিকে ফিরে তাকাও!"
    )

    // টিয়ার ৪: ধাপ ৩ ও ৪ (শাসন + ইমোশনাল সতর্কতা) — ২২টি বাক্যাংশ
    private val L34_CORES = arrayOf(
        "এবার শাসন! {D} ধরে ফোনে—{E} আর {ED} দিন",
        "নিজের হাতে নিজের স্বপ্ন নষ্ট করছো? {D} গেছে",
        "পড়ছো না? অন্যজন পড়ে ঠিকই {E}-তে জায়গা নিচ্ছে",
        "তোমার আম্মু-আব্বু আশা নিয়ে তাকিয়ে—{D} নষ্ট",
        "অতিরিক্ত বিলাসিতাই স্বপ্নভঙ্গের কারণ—{D} অপচয়",
        "{W} অজুহাত চলবে না—{D} গেছে, {R} বাকি",
        "পরিশ্রম সৌভাগ্যের প্রসূতি—{D} ধরে স্ক্রল করছো",
        "সময় নষ্ট করলে সময় তোমাকে নষ্ট করবে—{D} শেষ",
        "ধৈর্য শেষের দিকে! {D} ধরে ফোনে কী করছো?",
        "তুমি নিজের লক্ষ্য নিজেই ভাঙছো—{D} উড়ে গেল",
        "সিলেবাস কারও জন্য থামবে না—{D} পেরিয়েছে"
    )
    private val L34_ACTIONS = arrayOf(
        "এক্ষুনি স্ক্রিন বন্ধ করো!",
        "এখন না পড়লে পড়বে কখন?",
        "এই মুহূর্তে {S} বই খোলো!",
        "ফোন রাখো—আর অজুহাত নয়!",
        "টেবিলে না বসলে দিনটা বৃথা!",
        "লক্ষ্য {R} শেষ না করে উঠবে না!",
        "এখনই ফোন উল্টে রাখো!",
        "নিজের ভবিষ্যৎ বাঁচাতে বসো!",
        "ভিডিও-স্ক্রল বন্ধ করো!",
        "এক্ষুনি পড়তে বসো!",
        "আজই নিজেকে প্রমাণ করো!"
    )

    // টিয়ার ৫: ধাপ ৫ ও স্ট্রিক্ট মোড (চূড়ান্ত শাসন + গভীর ইমোশনাল) — ২০টি বাক্যাংশ
    private val L5_CORES = arrayOf(
        "তোমার পুরো ভবিষ্যৎ প্রজন্ম তোমার দিকে তাকিয়ে—{D} নষ্ট",
        "অতিরিক্ত বিলাসিতা একদিন কান্নার কারণ হবে—{D} ফোনে",
        "সময় নষ্ট, ভবিষ্যৎ নষ্ট—{D} চলে গেল স্ক্রিনে",
        "বিলাসিতা সাফল্যের প্রতিবন্ধকতা—{D} অপচয় করেছো",
        "নিজের হাতে স্বপ্ন নষ্ট করছো? {E} আর {ED} দিন",
        "পড়ছো না? প্রতিযোগীরা {D}-এ ২টা টপিক শেষ করেছে",
        "আম্মু-আব্বুর স্বপ্ন কাগজেই থাকবে—{D} ফোনে কাটলে",
        "কষ্ট না করলে কেষ্ট মেলে না—{D} ধরে ফোনে আছো",
        "শেষ সতর্কতা! {D} গেছে, আজকের {R} কে পূরণ করবে?",
        "আর এক সেকেন্ড নয়! {E}-র স্বপ্ন কি ফোনেই হারাবে?"
    )
    private val L5_ACTIONS = arrayOf(
        "এক্ষুনি ফোন উল্টে পড়তে বসো!",
        "এখন না পড়লে পড়বে কখন?!",
        "সব ছেড়ে এক্ষুনি {S} খোলো!",
        "আর ১ মিনিটও স্ক্রিনে নয়!",
        "ফোন রাখো—এখন লড়াইয়ের সময়!",
        "নিজের জন্য হলেও এখন ওঠো!",
        "লক্ষ্য {R} শেষ না করে থামবে না!",
        "অতিরিক্ত আরাম ছাড়ো, বই ধরো!",
        "এক্ষুনি ফোকাস সেশন শুরু করো!",
        "আজকের দিনটা বৃথা যেতে দিও না!"
    )

    // অন্যান্য: RECHECK, IDLE, AWAY — ১৮টি বাক্যাংশ
    private val RECHECK_MSGS = arrayOf(
        "{W} দারুণ ফোকাস—এখনো কি {S} পড়ছো?",
        "{E} আর {ED} দিন—অনলাইন পড়া ঠিকমতো চলছে তো?",
        "আজকের লক্ষ্যের {R} বাকি—মনোযোগ ধরে রেখেছো তো?",
        "ভালো চলছে! এখনো কি ক্লাস বা নোট দেখছো?",
        "আম্মু-আব্বুর স্বপ্ন পূরণে পড়া এখনো চলমান তো?",
        "অনেকক্ষণ হলো—স্ক্রলিংয়ে চলে যাওনি তো?"
    )
    private val IDLE_MSGS = arrayOf(
        "{W} {D} ধরে ফোন বন্ধ—বই নিয়ে বসেছো তো?",
        "{D} ধরে পড়া থেকে দূরে! {E} আর {ED} দিন বাকি",
        "লক্ষ্যের {R} বাকি—{D} বিরতি হলো, এখন পড়ছো নাকি বাইরে?",
        "ছোট ছোট চেষ্টাই {E} জিতবে—{D} পর খোঁজ নিলাম!",
        "তোমার স্বপ্ন অপেক্ষা করছে—{D} ধরে সেশন বন্ধ!",
        "অফলাইনে {S} পড়ছো, নাকি বাইরে আছো?"
    )
    private val AWAY_PRE_MSGS = arrayOf(
        "আর মাত্র {D} বাকি—{E}-র প্রস্তুতিতে ফেরার পালা!",
        "হাতে আর {D}—ধীরে ধীরে {S} নিয়ে টেবিলে বসো!",
        "আর {D} পরই পড়া শুরু—লক্ষ্যের {R} বাকি আছে!"
    )
    private val AWAY_END_MSGS = arrayOf(
        "বাইরে থাকার {D} শেষ! {E} আর {ED} দিন—এবার বসো!",
        "বিরতি শেষ ({D})—আজকের {R} পূরণ করতে টেবিলে এসো!",
        "সময় শেষ! {W} ফ্রেশ হয়ে এবার {S} শুরু করো!"
    )

    fun messageFor(ctx: Context, kind: String, level: Int, elapsedMin: Int = 0, msgIndex: Int = 0): String {
        val cal = Calendar.getInstance()
        val monthIdx = cal.get(Calendar.MONTH).coerceIn(0, 11)
        val dayOfYear = cal.get(Calendar.DAY_OF_YEAR)

        val weather = WEATHER_BY_MONTH[monthIdx]
        val dur = if (elapsedMin > 0) formatDurationBn(elapsedMin) else "কিছুক্ষণ"
        val examName = DataStore.getExamName(ctx)
        val examDays = DataStore.toBnDigits(DataStore.getDaysUntilExam(ctx))
        val subject = DataStore.getCurrentSubject(ctx)

        val goalMin = DataStore.getDailyGoalHours(ctx) * 60
        val doneMin = DataStore.getToday(ctx).totalStudyMinutes()
        val remMin = (goalMin - doneMin).coerceAtLeast(0)
        val remText = if (remMin > 0) formatDurationBn(remMin) else "সামান্য"

        fun fill(tpl: String): String = tpl
            .replace("{W}", weather)
            .replace("{D}", dur)
            .replace("{E}", examName)
            .replace("{ED}", examDays)
            .replace("{S}", subject)
            .replace("{R}", remText)

        // ৩৬৫ দিনে ৩৬৫ রকম কম্বিনেশন: dayOfYear + prime-stepped msgIndex
        val seedA = dayOfYear * 7 + msgIndex
        val seedB = dayOfYear * 13 + msgIndex * 3 + level

        val raw = when (kind) {
            KIND_ASK -> {
                val a = ASK_OPENERS[idx(seedA, ASK_OPENERS.size)]
                val b = ASK_ENDINGS[idx(seedB, ASK_ENDINGS.size)]
                "$a—$b"
            }
            KIND_RECHECK -> RECHECK_MSGS[idx(dayOfYear + msgIndex, RECHECK_MSGS.size)]
            KIND_IDLE -> IDLE_MSGS[idx(dayOfYear + msgIndex, IDLE_MSGS.size)]
            KIND_AWAY_PRE -> AWAY_PRE_MSGS[idx(dayOfYear + msgIndex, AWAY_PRE_MSGS.size)]
            KIND_AWAY_END -> AWAY_END_MSGS[idx(dayOfYear + msgIndex, AWAY_END_MSGS.size)]
            KIND_STRICT -> {
                val c = L5_CORES[idx(seedA, L5_CORES.size)]
                val a = L5_ACTIONS[idx(seedB, L5_ACTIONS.size)]
                "$c! $a"
            }
            else -> when (level.coerceIn(1, 5)) {
                1 -> "${L1_CORES[idx(seedA, L1_CORES.size)]}—${L1_ACTIONS[idx(seedB, L1_ACTIONS.size)]}"
                2 -> "${L2_CORES[idx(seedA, L2_CORES.size)]}—${L2_ACTIONS[idx(seedB, L2_ACTIONS.size)]}"
                3, 4 -> "${L34_CORES[idx(seedA, L34_CORES.size)]}—${L34_ACTIONS[idx(seedB, L34_ACTIONS.size)]}"
                else -> "${L5_CORES[idx(seedA, L5_CORES.size)]}! ${L5_ACTIONS[idx(seedB, L5_ACTIONS.size)]}"
            }
        }
        return fill(raw)
    }

    private fun idx(seed: Int, size: Int): Int = ((seed % size) + size) % size
}
