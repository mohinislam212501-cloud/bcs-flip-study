package com.bcs.flipstudy

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.core.content.FileProvider
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar
import android.net.Uri
import android.provider.Settings
import android.webkit.WebView
import android.widget.FrameLayout
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.widget.NestedScrollView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import java.util.Calendar
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var rootLayout: View

    private lateinit var tabTimer: View
    private lateinit var tabReport: View
    private lateinit var tabRoutine: View
    private lateinit var tabSettings: View

    private lateinit var navTimer: TextView
    private lateinit var navReport: TextView
    private lateinit var navRoutine: TextView
    private lateinit var navSettings: TextView

    // Timer UI
    private lateinit var btnTopTheme: ImageView
    private lateinit var statusPillBox: View
    private lateinit var tvStatusDot: TextView
    private lateinit var timerScrollView: NestedScrollView
    private lateinit var focusCardBox: View
    private lateinit var flipCardBox: View
    private lateinit var bottomNavBar: View
    private lateinit var cardStudyLive: View
    private lateinit var btnManualStudy: TextView
    private lateinit var btnManualWaste: TextView
    private lateinit var tvModeStatus: TextView
    private lateinit var btnTopAlarm: TextView
    private lateinit var examStripCard: View
    private lateinit var tvExamLabel: TextView
    private lateinit var tvStreakChip: TextView
    private lateinit var tvExamDaysPill: TextView
    private lateinit var focusRingView: FocusRingView
    private lateinit var tvRingCaption: TextView
    private lateinit var tvTimerClock: TextView
    private lateinit var tvSubjectChip: TextView
    private lateinit var tvGoalProgressText: TextView
    private lateinit var pbDailyGoal: ProgressBar
    private lateinit var btnPreset45: TextView
    private lateinit var btnPreset10: TextView
    private lateinit var btnPreset5: TextView
    private lateinit var btnPresetCustom: TextView
    private lateinit var tvFlipTitle: TextView
    private lateinit var tvFlipSub: TextView
    private lateinit var swFlipService: MaterialSwitch
    private lateinit var swOnlineStudy: MaterialSwitch
    private lateinit var cardWasteLive: View
    private lateinit var tvStudyLiveClock: TextView
    private lateinit var tvWasteLiveClock: TextView

    // Report UI
    private lateinit var tvReportPeriodSub: TextView
    private lateinit var btnPrevPeriod: ImageView
    private lateinit var btnNextPeriod: ImageView
    private lateinit var tvPeriodTitle: TextView
    private lateinit var btnRepDay: TextView
    private lateinit var btnRepWeek: TextView
    private lateinit var btnRepMonth: TextView
    private lateinit var btnRepYear: TextView
    private lateinit var btnReportMenu: ImageView
    private lateinit var viewUnsyncedDot: View
    private lateinit var tvReportStatusBanner: TextView
    private lateinit var tvStatStudy: TextView
    private lateinit var tvStatAvg: TextView
    private lateinit var tvStatWaste: TextView
    private lateinit var tvStatScore: TextView
    private lateinit var tvStatStreak: TextView
    private lateinit var tvStatBest: TextView
    private lateinit var tvReportChartTitle: TextView
    private lateinit var reportBarChart: WeeklyBarChartView
    private lateinit var reportChartLegend: LinearLayout
    private lateinit var dayDetailSummaryCard: LinearLayout
    private lateinit var pbDayGoal: ProgressBar
    private lateinit var tvDayGoalPct: TextView
    private lateinit var tvDayModesBreakdown: TextView
    private lateinit var tvDayTimesBreakdown: TextView
    private lateinit var subjectsContainer: LinearLayout
    private lateinit var wasteContainer: LinearLayout
    private lateinit var btnAllSubjects: TextView
    private lateinit var btnAllWaste: TextView
    private lateinit var btnOpenDashboard: View
    private lateinit var ivDashBtnIcon: ImageView
    private lateinit var tvDashBtnLabel: TextView
    private var lastReportData: UnifiedReportData? = null
    private var reportHydratedOnce = false

    // Routine UI
    private lateinit var tvRoutineHeader: TextView
    private lateinit var chkWordTarget: CheckBox
    private lateinit var routineContainer: LinearLayout

    // Settings UI
    private lateinit var btnGoalMinus: TextView
    private lateinit var btnGoalPlus: TextView
    private lateinit var tvGoalHoursVal: TextView
    private lateinit var tvGoalNotifSub: TextView
    private lateinit var swGoalNotif: MaterialSwitch
    private lateinit var rowEditExam: View
    private lateinit var tvExamSettingSub: TextView
    private lateinit var btnGrace0: TextView
    private lateinit var btnGrace3: TextView
    private lateinit var btnGrace5: TextView
    private lateinit var btnGrace10: TextView
    private lateinit var btnGraceCustom: TextView
    private lateinit var btnAlarmVib: TextView
    private lateinit var btnAlarmSound: TextView
    private lateinit var btnAlarmSilent: TextView
    private lateinit var btnThemeDay: TextView
    private lateinit var btnThemeNight: TextView
    private lateinit var btnThemeAuto: TextView
    private lateinit var btnColor1: TextView
    private lateinit var btnColor2: TextView
    private lateinit var btnColor3: TextView
    private lateinit var btnColor4: TextView
    private lateinit var btnSettingsDrawer: ImageView
    private lateinit var bannerMissingPerms: LinearLayout
    private lateinit var tvMissingPermsMsg: TextView
    private lateinit var btnFixMissingPerms: TextView
    private lateinit var syncLockedCard: LinearLayout
    private lateinit var tvSyncMaskedUrl: TextView
    private lateinit var tvSyncMaskedPass: TextView
    private lateinit var tvSyncLockedStamp: TextView
    private lateinit var btnUnlockSyncEditor: TextView
    private lateinit var syncEditorBox: LinearLayout
    private lateinit var etGasUrl: EditText
    private lateinit var etSyncKey: EditText
    private lateinit var etSyncKeyConfirm: EditText
    private lateinit var btnToggleSyncKeyVis1: ImageView
    private lateinit var btnToggleSyncKeyVis2: ImageView
    private lateinit var btnTestSync: TextView
    private lateinit var btnSaveSettings: TextView
    private lateinit var btnWeekStartSun: TextView
    private lateinit var btnWeekStartSat: TextView
    private lateinit var swDashCellAlways: MaterialSwitch
    private lateinit var btnExportJson: TextView
    private var syncEditorUnlocked = false
    private var syncKeyVis1 = false
    private var syncKeyVis2 = false

    // Smart Reminder Settings UI
    private lateinit var swSrEnabled: MaterialSwitch
    private lateinit var boxSrNotifWarn: View
    private lateinit var btnSrNotifPerm: TextView
    private lateinit var tvSrOverlaySub: TextView
    private lateinit var btnSrOverlayPerm: TextView
    private lateinit var btnSrMascotAuto: TextView
    private lateinit var btnSrMascotDragon: TextView
    private lateinit var btnSrMascotGhost: TextView
    private lateinit var btnSrPreviewPopup: TextView
    private lateinit var btnSrResetTimer: TextView
    private lateinit var btnSrAsk1: TextView
    private lateinit var btnSrAsk2: TextView
    private lateinit var btnSrAsk3: TextView
    private lateinit var btnSrAskCustom: TextView
    private lateinit var btnSrRep3: TextView
    private lateinit var btnSrRep5: TextView
    private lateinit var btnSrRep10: TextView
    private lateinit var btnSrRepCustom: TextView
    private lateinit var btnSrRecheck10: TextView
    private lateinit var btnSrRecheck15: TextView
    private lateinit var btnSrRecheck30: TextView
    private lateinit var btnSrRecheckCustom: TextView
    private lateinit var btnSrReset1: TextView
    private lateinit var btnSrReset3: TextView
    private lateinit var btnSrReset5: TextView
    private lateinit var btnSrResetCustom: TextView
    private lateinit var btnSrIdle30: TextView
    private lateinit var btnSrIdle45: TextView
    private lateinit var btnSrIdle60: TextView
    private lateinit var btnSrIdle0: TextView
    private lateinit var btnSrIdleCustom: TextView
    private lateinit var swSrQuiet: MaterialSwitch
    private lateinit var btnSrQuietStart: TextView
    private lateinit var btnSrQuietEnd: TextView
    private lateinit var btnSrFb10: TextView
    private lateinit var btnSrFb20: TextView
    private lateinit var btnSrFb30: TextView
    private lateinit var btnSrFbCustom: TextView
    private lateinit var btnSrEat20: TextView
    private lateinit var btnSrEat30: TextView
    private lateinit var btnSrEat45: TextView
    private lateinit var btnSrEatCustom: TextView
    private lateinit var btnSrStrict20: TextView
    private lateinit var btnSrStrict30: TextView
    private lateinit var btnSrStrict45: TextView
    private lateinit var btnSrStrict0: TextView
    private lateinit var btnSrStrictCustom: TextView
    private lateinit var btnSrCall5: TextView
    private lateinit var btnSrCall10: TextView
    private lateinit var btnSrCall15: TextView
    private lateinit var btnSrCall0: TextView
    private lateinit var btnSrCallCustom: TextView
    private var updatingSrSwitches = false
    private var srPreviewLevel = 1
    private var srResetPendingUntilMs = 0L

    private var currentTab = 0
    private var reportYearly = false
    private var updatingFlipSwitch = false
    private var reportYear = Calendar.getInstance().get(Calendar.YEAR)
    private var reportMonth = Calendar.getInstance().get(Calendar.MONTH) + 1

    private val bnMonths = arrayOf(
        "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
        "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
    )

    private val uiHandler = Handler(Looper.getMainLooper())
    private val uiTicker = object : Runnable {
        override fun run() {
            if (currentTab == 0) {
                refreshTimerUI()
                if (DataStore.loadRuntimeState(this@MainActivity).running) {
                    uiHandler.postDelayed(this, 1000L)
                }
            }
        }
    }

    private fun ensureTickerIfNeeded() {
        uiHandler.removeCallbacks(uiTicker)
        if (currentTab == 0 && DataStore.loadRuntimeState(this).running) {
            uiHandler.postDelayed(uiTicker, 1000L)
        }
    }

    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshTimerUI()
            ensureTickerIfNeeded()
        }
    }

    // ------------------------------------------------------------------ helpers

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun pal(): AppPalette = ThemePalette.get(DataStore.getColorPalette(this), isNightActive())

    private fun softOf(p: AppPalette): Int =
        ColorUtils.blendARGB(p.cardBg, p.accent, if (isNightActive()) 0.10f else 0.07f)

    private fun TextView.setTextIfChanged(value: String) {
        if (text.toString() != value) text = value
    }

    private fun View.onTap(block: () -> Unit) {
        setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            block()
        }
    }

    private fun sendServiceAction(action: String) {
        val i = Intent(this, FlipTrackerService::class.java).setAction(action)
        if (DataStore.loadRuntimeState(this).running) startService(i)
        else ContextCompat.startForegroundService(this, i)
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        applySavedThemeMode()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (savedInstanceState != null) {
            currentTab = savedInstanceState.getInt("tab", 0)
            reportYearly = savedInstanceState.getBoolean("rep_yearly", false)
            reportYear = savedInstanceState.getInt("rep_year", reportYear)
            reportMonth = savedInstanceState.getInt("rep_month", reportMonth)
        }

        requestNotificationPermissionIfNeeded()
        DailySyncWorker.scheduleDaily(this)
        if (DataStore.isDeviceUnlocked(this)) {
            SmartReminderManager.ensureMigratedAndStarted(this)
        }

        val absorbed = DataStore.absorbClosedTimeAsSleepOther(this)
        if (absorbed >= 60L) {
            Toast.makeText(
                this,
                "অ্যাপ বন্ধ থাকা ${DataStore.formatHoursMinBn(absorbed)} ঘুম ও অন্যান্য সময়ে যোগ হয়েছে",
                Toast.LENGTH_LONG
            ).show()
        }

        bindViews()
        setupListeners()
        refreshAllUI()
        showTab(currentTab, animate = false)
        if (currentTab == 2) renderRoutineTab()
        if (!DataStore.isDeviceUnlocked(this)) {
            showDeviceLockDialog()
        } else {
            checkMascotIntent(intent)
        }
    }

    private fun showDeviceLockDialog() {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(12), dp(22), dp(4))
        }
        val tvInfo = TextView(this).apply {
            text = "এই ডিভাইসে প্রথমবার চালু করতে পাসওয়ার্ড দাও (একবার দিলে আর চাইবে না)।"
            textSize = 13f
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_muted))
            setPadding(0, 0, 0, dp(10))
        }
        val etPass = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            hint = "পাসওয়ার্ড লিখো"
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        wrap.addView(tvInfo)
        wrap.addView(etPass)

        val dlg = MaterialAlertDialogBuilder(this)
            .setTitle("অ্যাপ আনলক করো")
            .setView(wrap)
            .setCancelable(false)
            .setPositiveButton("আনলক", null)
            .setNegativeButton("বন্ধ করো") { _, _ -> finish() }
            .create()

        dlg.setOnShowListener {
            dlg.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val entered = etPass.text.toString()
                if (DataStore.verifyAndUnlockDevice(this, entered)) {
                    dlg.dismiss()
                    SmartReminderManager.ensureMigratedAndStarted(this)
                    checkMascotIntent(intent)
                    Toast.makeText(this, "ডিভাইস ভেরিফাই সম্পন্ন! স্বাগতম।", Toast.LENGTH_SHORT).show()
                } else {
                    etPass.error = "পাসওয়ার্ড সঠিক নয়!"
                    Toast.makeText(this, "ভুল পাসওয়ার্ড!", Toast.LENGTH_SHORT).show()
                }
            }
        }
        dlg.show()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", currentTab)
        outState.putBoolean("rep_yearly", reportYearly)
        outState.putInt("rep_year", reportYear)
        outState.putInt("rep_month", reportMonth)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        checkMascotIntent(intent)
    }

    private fun checkMascotIntent(i: Intent?) {
        if (i == null) return
        val fallbackAction = i.getStringExtra(SmartReminderManager.EXTRA_START_STUDY_FALLBACK)
        if (!fallbackAction.isNullOrEmpty()) {
            i.removeExtra(SmartReminderManager.EXTRA_START_STUDY_FALLBACK)
            sendServiceAction(fallbackAction)
            refreshTimerUI()
        }
        if (i.getBooleanExtra(SmartReminderManager.EXTRA_SHOW_AWAY_PICKER, false)) {
            i.removeExtra(SmartReminderManager.EXTRA_SHOW_AWAY_PICKER)
            showAwayDurationDialog()
            return
        }
        val lvl = i.getIntExtra(SmartReminderManager.EXTRA_LEVEL, 0)
        if (lvl in 1..5) {
            val kind = i.getStringExtra(SmartReminderManager.EXTRA_KIND) ?: MascotContent.KIND_ANGRY
            val elapsed = i.getIntExtra(SmartReminderManager.EXTRA_ELAPSED_MIN, 0)
            i.removeExtra(SmartReminderManager.EXTRA_LEVEL)
            i.removeExtra(SmartReminderManager.EXTRA_KIND)
            i.removeExtra(SmartReminderManager.EXTRA_ELAPSED_MIN)
            showAnimatedMascotDialog(lvl, kind, elapsed)
        }
    }

    private fun showAwayDurationDialog() {
        val labels = arrayOf("৩০ মিনিট পর", "১ ঘণ্টা পর", "২ ঘণ্টা পর", "৩ ঘণ্টা পর", "কাস্টম সময় লিখো...")
        val mins = intArrayOf(30, 60, 120, 180, -1)
        MaterialAlertDialogBuilder(this)
            .setTitle("বাইরে আছো · কত সময় পর পড়তে বসবে?")
            .setItems(labels) { _, which ->
                val chosen = mins[which]
                if (chosen > 0) {
                    SmartReminderManager.onSetAwayMinutes(this, chosen)
                    val preMin = (chosen / 4).coerceAtLeast(1)
                    Toast.makeText(
                        this,
                        "${MascotContent.formatDurationBn(chosen)} সেট হয়েছে (${MascotContent.formatDurationBn(preMin)} আগে রিমাইন্ডার আসবে)",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    val input = EditText(this).apply {
                        inputType = InputType.TYPE_CLASS_NUMBER
                        hint = "মিনিট লিখো (যেমন: ৯০ বা ১৫০)"
                        setPadding(dp(20), dp(14), dp(20), dp(14))
                    }
                    val wrap = LinearLayout(this).apply {
                        setPadding(dp(20), dp(8), dp(20), 0)
                        addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                    }
                    MaterialAlertDialogBuilder(this)
                        .setTitle("কত মিনিট পর পড়তে বসবে?")
                        .setView(wrap)
                        .setPositiveButton("সেট করো") { _, _ ->
                            val m = input.text.toString().toIntOrNull()
                            if (m != null && m in 5..720) {
                                SmartReminderManager.onSetAwayMinutes(this, m)
                                Toast.makeText(this, "${MascotContent.formatDurationBn(m)} পর রিমাইন্ডার সেট হয়েছে", Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(this, "৫ থেকে ৭২০ মিনিটের মধ্যে সংখ্যা দাও", Toast.LENGTH_SHORT).show()
                            }
                        }
                        .setNegativeButton("বাতিল", null)
                        .show()
                }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun showAnimatedMascotDialog(level: Int, kind: String = MascotContent.KIND_ANGRY, elapsedMin: Int = 0) {
        val safeLvl = level.coerceIn(1, 5)
        val character = MascotContent.resolveCharacter(this)
        val accent = MascotContent.accentColorFor(character, safeLvl)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(18), dp(24), dp(8))
        }

        val mascotWrap = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(156), dp(156))
            background = ThemePalette.makeBg(this@MainActivity, Color.parseColor("#0B0F17"), accent, 20f, 2f)
            clipToOutline = true
        }

        val webView: WebView? = SmartReminderPopupOverlay.createMascotWebView(this, character, safeLvl)
        if (webView != null) {
            mascotWrap.addView(webView, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            ))
        } else {
            val iv = ImageView(this).apply {
                setImageResource(MascotContent.mascotResFor(character, safeLvl))
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            mascotWrap.addView(iv, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            ))
        }

        val tv = TextView(this).apply {
            text = MascotContent.messageFor(this@MainActivity, kind, safeLvl, elapsedMin, DataStore.getSrMsgIndex(this@MainActivity))
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, 0)
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_main))
        }
        box.addView(mascotWrap)
        box.addView(tv)

        val shakeAmp = when (safeLvl) {
            5 -> 22f
            4 -> 17f
            3 -> 12f
            else -> 0f
        }
        val anim = if (shakeAmp > 0f) {
            ObjectAnimator.ofFloat(mascotWrap, "translationX", -shakeAmp, shakeAmp, -shakeAmp * 0.7f, shakeAmp * 0.7f, -shakeAmp * 0.35f, shakeAmp * 0.35f, 0f).apply {
                duration = if (safeLvl >= 4) 380L else 560L
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.REVERSE
            }
        } else {
            ObjectAnimator.ofFloat(mascotWrap, "translationY", 0f, -14f, 0f).apply {
                duration = 720L
                repeatCount = ValueAnimator.INFINITE
            }
        }
        anim.start()

        fun cleanup() {
            anim.cancel()
            try {
                webView?.stopLoading()
                webView?.loadUrl("about:blank")
                webView?.destroy()
            } catch (_: Exception) {}
        }

        val builder = MaterialAlertDialogBuilder(this)
            .setTitle(MascotContent.titleFor(kind, safeLvl, elapsedMin))
            .setView(box)
            .setOnDismissListener { cleanup() }

        when (kind) {
            MascotContent.KIND_ASK, MascotContent.KIND_RECHECK -> {
                builder.setPositiveButton("পড়ছি") { _, _ ->
                    cleanup()
                    SmartReminderManager.onReadingYes(this)
                    refreshTimerUI()
                }
                builder.setNegativeButton("পড়ছি না") { _, _ ->
                    cleanup()
                    SmartReminderManager.onReadingNo(this)
                }
                builder.setNeutralButton("খাচ্ছি (${DataStore.toBnDigits(DataStore.getSrEatMin(this))} মি.)") { _, _ ->
                    cleanup()
                    SmartReminderManager.onEatingMode(this)
                }
            }
            MascotContent.KIND_IDLE, MascotContent.KIND_AWAY_END -> {
                builder.setPositiveButton("পড়ছি") { _, _ ->
                    cleanup()
                    SmartReminderManager.onStartStudyFromIdle(this)
                    refreshTimerUI()
                }
                builder.setNegativeButton("বাইরে আছি") { _, _ ->
                    cleanup()
                    showAwayDurationDialog()
                }
            }
            MascotContent.KIND_AWAY_PRE -> {
                builder.setPositiveButton("পড়া শুরু করি") { _, _ ->
                    cleanup()
                    SmartReminderManager.onStartStudyFromIdle(this)
                    refreshTimerUI()
                }
                builder.setNegativeButton("ঠিক আছে") { _, _ ->
                    cleanup()
                    SmartReminderManager.onSnoozeIdle(this)
                }
            }
            else -> {
                builder.setPositiveButton("ফোনে পড়ছি") { _, _ ->
                    cleanup()
                    SmartReminderManager.onReadingYes(this)
                    refreshTimerUI()
                }
                builder.setNegativeButton("ঠিক আছে, ফোন রাখছি") { _, _ ->
                    cleanup()
                    SmartReminderManager.dismissReminderUi(this)
                }
                builder.setNeutralButton("খাচ্ছি (${DataStore.toBnDigits(DataStore.getSrEatMin(this))} মি.)") { _, _ ->
                    cleanup()
                    SmartReminderManager.onEatingMode(this)
                }
            }
        }
        builder.show()
    }

    private fun applySavedThemeMode() {
        val mode = when (DataStore.getThemeMode(this)) {
            "day" -> AppCompatDelegate.MODE_NIGHT_NO
            "night" -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }
        AppCompatDelegate.setDefaultNightMode(mode)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED && !DataStore.wasNotifPermAsked(this)
            ) {
                DataStore.setNotifPermAsked(this)
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }
    }

    // ------------------------------------------------------------------ binding

    private fun bindViews() {
        rootLayout = findViewById(R.id.rootLayout)
        tabTimer = findViewById(R.id.tabTimer)
        tabReport = findViewById(R.id.tabReport)
        tabRoutine = findViewById(R.id.tabRoutine)
        tabSettings = findViewById(R.id.tabSettings)

        navTimer = findViewById(R.id.navTimer)
        navReport = findViewById(R.id.navReport)
        navRoutine = findViewById(R.id.navRoutine)
        navSettings = findViewById(R.id.navSettings)

        btnTopTheme = findViewById(R.id.btnTopTheme)
        statusPillBox = findViewById(R.id.statusPillBox)
        tvStatusDot = findViewById(R.id.tvStatusDot)
        timerScrollView = findViewById(R.id.timerScrollView)
        focusCardBox = findViewById(R.id.focusCardBox)
        flipCardBox = findViewById(R.id.flipCardBox)
        bottomNavBar = findViewById(R.id.bottomNavBar)
        cardStudyLive = findViewById(R.id.cardStudyLive)
        btnManualStudy = findViewById(R.id.btnManualStudy)
        btnManualWaste = findViewById(R.id.btnManualWaste)
        tvModeStatus = findViewById(R.id.tvModeStatus)
        btnTopAlarm = findViewById(R.id.btnTopAlarm)
        examStripCard = findViewById(R.id.examStripCard)
        tvExamLabel = findViewById(R.id.tvExamLabel)
        tvStreakChip = findViewById(R.id.tvStreakChip)
        tvExamDaysPill = findViewById(R.id.tvExamDaysPill)
        focusRingView = findViewById(R.id.focusRingView)
        tvRingCaption = findViewById(R.id.tvRingCaption)
        tvTimerClock = findViewById(R.id.tvTimerClock)
        tvSubjectChip = findViewById(R.id.tvSubjectChip)
        tvGoalProgressText = findViewById(R.id.tvGoalProgressText)
        pbDailyGoal = findViewById(R.id.pbDailyGoal)
        btnPreset45 = findViewById(R.id.btnPreset45)
        btnPreset10 = findViewById(R.id.btnPreset10)
        btnPreset5 = findViewById(R.id.btnPreset5)
        btnPresetCustom = findViewById(R.id.btnPresetCustom)
        tvFlipTitle = findViewById(R.id.tvFlipTitle)
        tvFlipSub = findViewById(R.id.tvFlipSub)
        swFlipService = findViewById(R.id.swFlipService)
        swOnlineStudy = findViewById(R.id.swOnlineStudy)
        cardWasteLive = findViewById(R.id.cardWasteLive)
        tvStudyLiveClock = findViewById(R.id.tvStudyLiveClock)
        tvWasteLiveClock = findViewById(R.id.tvWasteLiveClock)

        tvReportPeriodSub = findViewById(R.id.tvReportPeriodSub)
        btnPrevPeriod = findViewById(R.id.btnPrevPeriod)
        btnNextPeriod = findViewById(R.id.btnNextPeriod)
        tvPeriodTitle = findViewById(R.id.tvPeriodTitle)
        btnRepDay = findViewById(R.id.btnRepDay)
        btnRepWeek = findViewById(R.id.btnRepWeek)
        btnRepMonth = findViewById(R.id.btnRepMonth)
        btnRepYear = findViewById(R.id.btnRepYear)
        btnReportMenu = findViewById(R.id.btnReportMenu)
        viewUnsyncedDot = findViewById(R.id.viewUnsyncedDot)
        tvReportStatusBanner = findViewById(R.id.tvReportStatusBanner)
        tvStatStudy = findViewById(R.id.tvStatStudy)
        tvStatAvg = findViewById(R.id.tvStatAvg)
        tvStatWaste = findViewById(R.id.tvStatWaste)
        tvStatScore = findViewById(R.id.tvStatScore)
        tvStatStreak = findViewById(R.id.tvStatStreak)
        tvStatBest = findViewById(R.id.tvStatBest)
        tvReportChartTitle = findViewById(R.id.tvReportChartTitle)
        reportBarChart = findViewById(R.id.reportBarChart)
        reportChartLegend = findViewById(R.id.reportChartLegend)
        dayDetailSummaryCard = findViewById(R.id.dayDetailSummaryCard)
        pbDayGoal = findViewById(R.id.pbDayGoal)
        tvDayGoalPct = findViewById(R.id.tvDayGoalPct)
        tvDayModesBreakdown = findViewById(R.id.tvDayModesBreakdown)
        tvDayTimesBreakdown = findViewById(R.id.tvDayTimesBreakdown)
        subjectsContainer = findViewById(R.id.subjectsContainer)
        wasteContainer = findViewById(R.id.wasteContainer)
        btnAllSubjects = findViewById(R.id.btnAllSubjects)
        btnAllWaste = findViewById(R.id.btnAllWaste)
        btnOpenDashboard = findViewById(R.id.btnOpenDashboard)
        ivDashBtnIcon = findViewById(R.id.ivDashBtnIcon)
        tvDashBtnLabel = findViewById(R.id.tvDashBtnLabel)

        tvRoutineHeader = findViewById(R.id.tvRoutineHeader)
        chkWordTarget = findViewById(R.id.chkWordTarget)
        routineContainer = findViewById(R.id.routineContainer)

        btnGoalMinus = findViewById(R.id.btnGoalMinus)
        btnGoalPlus = findViewById(R.id.btnGoalPlus)
        tvGoalHoursVal = findViewById(R.id.tvGoalHoursVal)
        tvGoalNotifSub = findViewById(R.id.tvGoalNotifSub)
        swGoalNotif = findViewById(R.id.swGoalNotif)
        rowEditExam = findViewById(R.id.rowEditExam)
        tvExamSettingSub = findViewById(R.id.tvExamSettingSub)
        btnGrace0 = findViewById(R.id.btnGrace0)
        btnGrace3 = findViewById(R.id.btnGrace3)
        btnGrace5 = findViewById(R.id.btnGrace5)
        btnGrace10 = findViewById(R.id.btnGrace10)
        btnGraceCustom = findViewById(R.id.btnGraceCustom)
        btnAlarmVib = findViewById(R.id.btnAlarmVib)
        btnAlarmSound = findViewById(R.id.btnAlarmSound)
        btnAlarmSilent = findViewById(R.id.btnAlarmSilent)
        btnThemeDay = findViewById(R.id.btnThemeDay)
        btnThemeNight = findViewById(R.id.btnThemeNight)
        btnThemeAuto = findViewById(R.id.btnThemeAuto)
        btnColor1 = findViewById(R.id.btnColor1)
        btnColor2 = findViewById(R.id.btnColor2)
        btnColor3 = findViewById(R.id.btnColor3)
        btnColor4 = findViewById(R.id.btnColor4)
        btnSettingsDrawer = findViewById(R.id.btnSettingsDrawer)
        bannerMissingPerms = findViewById(R.id.bannerMissingPerms)
        tvMissingPermsMsg = findViewById(R.id.tvMissingPermsMsg)
        btnFixMissingPerms = findViewById(R.id.btnFixMissingPerms)
        syncLockedCard = findViewById(R.id.syncLockedCard)
        tvSyncMaskedUrl = findViewById(R.id.tvSyncMaskedUrl)
        tvSyncMaskedPass = findViewById(R.id.tvSyncMaskedPass)
        tvSyncLockedStamp = findViewById(R.id.tvSyncLockedStamp)
        btnUnlockSyncEditor = findViewById(R.id.btnUnlockSyncEditor)
        syncEditorBox = findViewById(R.id.syncEditorBox)
        etGasUrl = findViewById(R.id.etGasUrl)
        etSyncKey = findViewById(R.id.etSyncKey)
        etSyncKeyConfirm = findViewById(R.id.etSyncKeyConfirm)
        btnToggleSyncKeyVis1 = findViewById(R.id.btnToggleSyncKeyVis1)
        btnToggleSyncKeyVis2 = findViewById(R.id.btnToggleSyncKeyVis2)
        btnTestSync = findViewById(R.id.btnTestSync)
        btnSaveSettings = findViewById(R.id.btnSaveSettings)
        btnWeekStartSun = findViewById(R.id.btnWeekStartSun)
        btnWeekStartSat = findViewById(R.id.btnWeekStartSat)
        swDashCellAlways = findViewById(R.id.swDashCellAlways)
        btnExportJson = findViewById(R.id.btnExportJson)

        swSrEnabled = findViewById(R.id.swSrEnabled)
        boxSrNotifWarn = findViewById(R.id.boxSrNotifWarn)
        btnSrNotifPerm = findViewById(R.id.btnSrNotifPerm)
        tvSrOverlaySub = findViewById(R.id.tvSrOverlaySub)
        btnSrOverlayPerm = findViewById(R.id.btnSrOverlayPerm)
        btnSrMascotAuto = findViewById(R.id.btnSrMascotAuto)
        btnSrMascotDragon = findViewById(R.id.btnSrMascotDragon)
        btnSrMascotGhost = findViewById(R.id.btnSrMascotGhost)
        btnSrPreviewPopup = findViewById(R.id.btnSrPreviewPopup)
        btnSrResetTimer = findViewById(R.id.btnSrResetTimer)
        btnSrAsk1 = findViewById(R.id.btnSrAsk1)
        btnSrAsk2 = findViewById(R.id.btnSrAsk2)
        btnSrAsk3 = findViewById(R.id.btnSrAsk3)
        btnSrAskCustom = findViewById(R.id.btnSrAskCustom)
        btnSrRep3 = findViewById(R.id.btnSrRep3)
        btnSrRep5 = findViewById(R.id.btnSrRep5)
        btnSrRep10 = findViewById(R.id.btnSrRep10)
        btnSrRepCustom = findViewById(R.id.btnSrRepCustom)
        btnSrRecheck10 = findViewById(R.id.btnSrRecheck10)
        btnSrRecheck15 = findViewById(R.id.btnSrRecheck15)
        btnSrRecheck30 = findViewById(R.id.btnSrRecheck30)
        btnSrRecheckCustom = findViewById(R.id.btnSrRecheckCustom)
        btnSrReset1 = findViewById(R.id.btnSrReset1)
        btnSrReset3 = findViewById(R.id.btnSrReset3)
        btnSrReset5 = findViewById(R.id.btnSrReset5)
        btnSrResetCustom = findViewById(R.id.btnSrResetCustom)
        btnSrIdle30 = findViewById(R.id.btnSrIdle30)
        btnSrIdle45 = findViewById(R.id.btnSrIdle45)
        btnSrIdle60 = findViewById(R.id.btnSrIdle60)
        btnSrIdle0 = findViewById(R.id.btnSrIdle0)
        btnSrIdleCustom = findViewById(R.id.btnSrIdleCustom)
        swSrQuiet = findViewById(R.id.swSrQuiet)
        btnSrQuietStart = findViewById(R.id.btnSrQuietStart)
        btnSrQuietEnd = findViewById(R.id.btnSrQuietEnd)
        btnSrFb10 = findViewById(R.id.btnSrFb10)
        btnSrFb20 = findViewById(R.id.btnSrFb20)
        btnSrFb30 = findViewById(R.id.btnSrFb30)
        btnSrFbCustom = findViewById(R.id.btnSrFbCustom)
        btnSrEat20 = findViewById(R.id.btnSrEat20)
        btnSrEat30 = findViewById(R.id.btnSrEat30)
        btnSrEat45 = findViewById(R.id.btnSrEat45)
        btnSrEatCustom = findViewById(R.id.btnSrEatCustom)
        btnSrStrict20 = findViewById(R.id.btnSrStrict20)
        btnSrStrict30 = findViewById(R.id.btnSrStrict30)
        btnSrStrict45 = findViewById(R.id.btnSrStrict45)
        btnSrStrict0 = findViewById(R.id.btnSrStrict0)
        btnSrStrictCustom = findViewById(R.id.btnSrStrictCustom)
        btnSrCall5 = findViewById(R.id.btnSrCall5)
        btnSrCall10 = findViewById(R.id.btnSrCall10)
        btnSrCall15 = findViewById(R.id.btnSrCall15)
        btnSrCall0 = findViewById(R.id.btnSrCall0)
        btnSrCallCustom = findViewById(R.id.btnSrCallCustom)
    }

    private fun setupListeners() {
        navTimer.onTap { showTab(0); refreshTimerUI(); ensureTickerIfNeeded() }
        navReport.onTap { showTab(1); ensureTickerIfNeeded(); loadReportTab() }
        navRoutine.onTap { showTab(2); ensureTickerIfNeeded(); renderRoutineTab(scrollToToday = true) }
        navSettings.onTap { showTab(3); ensureTickerIfNeeded(); renderSettingsTab() }

        btnTopTheme.onTap {
            val next = if (isNightActive()) "day" else "night"
            DataStore.setThemeMode(this, next)
            applySavedThemeMode()
        }

        btnManualStudy.onTap {
            sendServiceAction(FlipTrackerService.ACTION_MANUAL_STUDY)
            uiHandler.postDelayed({ refreshTimerUI() }, 150L)
        }

        btnManualWaste.onTap {
            sendServiceAction(FlipTrackerService.ACTION_MANUAL_WASTE)
            uiHandler.postDelayed({ refreshTimerUI() }, 150L)
        }

        btnTopAlarm.onTap {
            val next = when (DataStore.getAlarmMode(this)) {
                "vibrate" -> "sound"
                "sound" -> "silent"
                else -> "vibrate"
            }
            DataStore.setAlarmMode(this, next)
            refreshAlarmUI()
            renderSettingsTab()
        }

        examStripCard.onTap { showExamDialog() }
        rowEditExam.onTap { showExamDialog() }

        tvSubjectChip.onTap { showSubjectDialog() }

        btnPreset45.onTap { selectPreset(45) }
        btnPreset10.onTap { selectPreset(10) }
        btnPreset5.onTap { selectPreset(5) }
        btnPresetCustom.onTap { showCustomTimerDialog() }

        swFlipService.setOnCheckedChangeListener { _, isChecked ->
            if (updatingFlipSwitch) return@setOnCheckedChangeListener
            val action = if (isChecked) FlipTrackerService.ACTION_START else FlipTrackerService.ACTION_STOP
            if (isChecked) sendServiceAction(action)
            else startService(Intent(this, FlipTrackerService::class.java).setAction(action))
            refreshTimerUI()
            uiHandler.postDelayed({ refreshTimerUI() }, 200L)
        }

        swOnlineStudy.setOnCheckedChangeListener { _, isChecked ->
            if (updatingFlipSwitch) return@setOnCheckedChangeListener
            DataStore.setOnlineStudy(this, isChecked)
            if (DataStore.loadRuntimeState(this).running) {
                startService(Intent(this, FlipTrackerService::class.java).setAction(FlipTrackerService.ACTION_ONLINE_CHANGED))
            }
            refreshTimerUI()
            uiHandler.postDelayed({ refreshTimerUI() }, 200L)
        }

        cardWasteLive.onTap { showWasteReasonDialog() }

        // Report Tab
        btnRepDay.onTap { DataStore.setReportPeriodType(this, ReportPeriodType.DAY); loadReportTab() }
        btnRepWeek.onTap { DataStore.setReportPeriodType(this, ReportPeriodType.WEEK); loadReportTab() }
        btnRepMonth.onTap { DataStore.setReportPeriodType(this, ReportPeriodType.MONTH); loadReportTab() }
        btnRepYear.onTap { DataStore.setReportPeriodType(this, ReportPeriodType.YEAR); loadReportTab() }
        btnPrevPeriod.onTap { shiftReportPeriod(-1) }
        btnNextPeriod.onTap { if (canGoNextReportPeriod()) shiftReportPeriod(1) }
        tvPeriodTitle.onTap { showReportDatePicker() }
        btnReportMenu.onTap { showReportMenuSheet() }
        btnAllSubjects.onTap { showAllBreakdownSheet(isWaste = false) }
        btnAllWaste.onTap { showAllBreakdownSheet(isWaste = true) }

        timerScrollView.setOnScrollChangeListener(NestedScrollView.OnScrollChangeListener { _, _, scrollY, _, _ ->
            val h = focusRingView.height.coerceAtLeast(dp(180)).toFloat()
            val progress = (scrollY / h).coerceIn(0f, 1f)
            focusCardBox.alpha = (1f - progress * 0.88f).coerceIn(0.12f, 1f)
            val s = 1f - progress * 0.05f
            focusCardBox.scaleX = s
            focusCardBox.scaleY = s
            focusCardBox.translationY = -scrollY * 0.08f
        })

        btnOpenDashboard.onTap {
            startActivity(Intent(this, DashboardActivity::class.java))
        }

        // Routine Tab
        chkWordTarget.setOnCheckedChangeListener { _, checked ->
            DataStore.updateToday(this) { rec ->
                rec.wordTarget = checked
                rec.synced = false
            }
            renderRoutineTab()
        }

        // Settings Tab
        btnGoalMinus.onTap {
            DataStore.setDailyGoalHours(this, DataStore.getDailyGoalHours(this) - 1)
            renderSettingsTab()
            refreshTimerUI()
        }
        btnGoalPlus.onTap {
            DataStore.setDailyGoalHours(this, DataStore.getDailyGoalHours(this) + 1)
            renderSettingsTab()
            refreshTimerUI()
        }
        swGoalNotif.setOnCheckedChangeListener { _, checked ->
            DataStore.setGoalNotifOn(this, checked)
        }

        btnGrace0.onTap { DataStore.setGraceSec(this, 0); renderSettingsTab(); refreshTimerUI() }
        btnGrace3.onTap { DataStore.setGraceSec(this, 3); renderSettingsTab(); refreshTimerUI() }
        btnGrace5.onTap { DataStore.setGraceSec(this, 5); renderSettingsTab(); refreshTimerUI() }
        btnGrace10.onTap { DataStore.setGraceSec(this, 10); renderSettingsTab(); refreshTimerUI() }
        btnGraceCustom.onTap {
            showCustomTimeDialog("ফ্লিপ গ্রেস টাইম (সেকেন্ড)", "সেকেন্ড লিখো (১–৬০)", 1, 60, DataStore.getGraceSec(this)) {
                DataStore.setGraceSec(this, it); renderSettingsTab(); refreshTimerUI()
            }
        }

        btnAlarmVib.onTap { DataStore.setAlarmMode(this, "vibrate"); refreshAlarmUI(); renderSettingsTab() }
        btnAlarmSound.onTap { DataStore.setAlarmMode(this, "sound"); refreshAlarmUI(); renderSettingsTab() }
        btnAlarmSilent.onTap { DataStore.setAlarmMode(this, "silent"); refreshAlarmUI(); renderSettingsTab() }

        btnThemeDay.onTap { DataStore.setThemeMode(this, "day"); applySavedThemeMode(); renderSettingsTab() }
        btnThemeNight.onTap { DataStore.setThemeMode(this, "night"); applySavedThemeMode(); renderSettingsTab() }
        btnThemeAuto.onTap { DataStore.setThemeMode(this, "auto"); applySavedThemeMode(); renderSettingsTab() }

        btnColor1.onTap { DataStore.setColorPalette(this, "sage"); applyColorPalette(); renderSettingsTab(); refreshTimerUI() }
        btnColor2.onTap { DataStore.setColorPalette(this, "ocean"); applyColorPalette(); renderSettingsTab(); refreshTimerUI() }
        btnColor3.onTap { DataStore.setColorPalette(this, "espresso"); applyColorPalette(); renderSettingsTab(); refreshTimerUI() }
        btnColor4.onTap { DataStore.setColorPalette(this, "nordic"); applyColorPalette(); renderSettingsTab(); refreshTimerUI() }

        btnSettingsDrawer.onTap { showSettingsQuickDrawer() }
        btnFixMissingPerms.onTap { fixMissingPermissionsFromBanner() }

        btnToggleSyncKeyVis1.onTap {
            syncKeyVis1 = !syncKeyVis1
            etSyncKey.inputType = if (syncKeyVis1)
                (InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)
            else
                (InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
            etSyncKey.setSelection(etSyncKey.text?.length ?: 0)
        }
        btnToggleSyncKeyVis2.onTap {
            syncKeyVis2 = !syncKeyVis2
            etSyncKeyConfirm.inputType = if (syncKeyVis2)
                (InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)
            else
                (InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
            etSyncKeyConfirm.setSelection(etSyncKeyConfirm.text?.length ?: 0)
        }

        btnUnlockSyncEditor.onTap { promptUnlockSyncEditor() }

        btnTestSync.onTap {
            val url = etGasUrl.text.toString().trim()
            val p1 = etSyncKey.text.toString().trim()
            val p2 = etSyncKeyConfirm.text.toString().trim()
            if (p1 != p2) {
                Snackbar.make(findViewById(android.R.id.content), "দুটি সিঙ্ক পাসওয়ার্ড মেলেনি!", Snackbar.LENGTH_LONG).show()
                return@onTap
            }
            btnTestSync.isEnabled = false
            btnTestSync.text = "টেস্ট হচ্ছে..."
            val appCtx = applicationContext
            thread {
                val (ok, msg) = DataStore.testSyncConnection(appCtx, url, p1)
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    btnTestSync.isEnabled = true
                    btnTestSync.text = "টেস্ট কানেকশন"
                    Snackbar.make(findViewById(android.R.id.content), msg, Snackbar.LENGTH_LONG).show()
                }
            }
        }

        btnSaveSettings.onTap {
            val url = etGasUrl.text.toString().trim()
            val p1 = etSyncKey.text.toString().trim()
            val p2 = etSyncKeyConfirm.text.toString().trim()
            if (p1 != p2) {
                Snackbar.make(findViewById(android.R.id.content), "দুটি সিঙ্ক পাসওয়ার্ড মেলেনি! আবার মিলিয়ে লিখো।", Snackbar.LENGTH_LONG).show()
                return@onTap
            }
            if (!DataStore.isSyncUrlValid(url)) {
                Snackbar.make(findViewById(android.R.id.content), "সঠিক Apps Script লিংক দাও (https://... এবং /exec দিয়ে শেষ)", Snackbar.LENGTH_LONG).show()
                return@onTap
            }
            btnSaveSettings.isEnabled = false
            btnSaveSettings.text = "যাচাই হচ্ছে..."
            val appCtx = applicationContext
            thread {
                val (ok, msg) = DataStore.testSyncConnection(appCtx, url, p1)
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    btnSaveSettings.isEnabled = true
                    btnSaveSettings.text = "যাচাই ও সেভ"
                    if (!ok) {
                        Snackbar.make(findViewById(android.R.id.content), "সেভ হয়নি: $msg", Snackbar.LENGTH_LONG).show()
                        return@runOnUiThread
                    }
                    val oldUrl = DataStore.getGasUrl(this)
                    if (oldUrl.isNotEmpty() && oldUrl != url) {
                        MaterialAlertDialogBuilder(this)
                            .setTitle("ড্রাইভ লিংক বদলেছে")
                            .setMessage("পুরোনো সব দিন কি নতুন ড্রাইভ শিটে আবার পাঠাবে, এবং পুরোনো ড্রাইভ ক্যাশ মুছে ফেলবে?")
                            .setPositiveButton("হ্যাঁ, সব পাঠাও") { _, _ ->
                                DataStore.resetSyncStateForNewUrl(this, resendAllDays = true, clearDriveCache = true)
                                completeSyncSettingsSave(url, p1)
                            }
                            .setNegativeButton("না, শুধু নতুনগুলো") { _, _ ->
                                DataStore.resetSyncStateForNewUrl(this, resendAllDays = false, clearDriveCache = true)
                                completeSyncSettingsSave(url, p1)
                            }
                            .show()
                    } else {
                        completeSyncSettingsSave(url, p1)
                    }
                }
            }
        }

        btnWeekStartSun.onTap { DataStore.setWeekStartDay(this, Calendar.SUNDAY); renderSettingsTab() }
        btnWeekStartSat.onTap { DataStore.setWeekStartDay(this, Calendar.SATURDAY); renderSettingsTab() }

        swDashCellAlways.setOnCheckedChangeListener { _, checked ->
            if (updatingSrSwitches) return@setOnCheckedChangeListener
            DataStore.setSrDashCellAlways(this, checked)
        }

        btnExportJson.onTap {
            shareExportedFile(DataStore.exportJsonToFile(this), "application/json", "JSON ব্যাকআপ শেয়ার / সেভ করো")
        }

        // Smart Reminder Settings
        swSrEnabled.setOnCheckedChangeListener { _, checked ->
            if (updatingSrSwitches) return@setOnCheckedChangeListener
            DataStore.setSrEnabled(this, checked)
            if (checked && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 102)
            }
            SmartReminderManager.onSettingsChanged(this)
            renderSettingsTab()
        }

        btnSrNotifPerm.onTap {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                    putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                }
                try { startActivity(i) } catch (_: Exception) {}
            }
        }

        btnSrOverlayPerm.onTap {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                try {
                    startActivity(i)
                } catch (_: Exception) {
                    Toast.makeText(this, "ফোনের সেটিংস থেকে Display over other apps চালু করো", Toast.LENGTH_LONG).show()
                }
            } else {
                val next = !DataStore.isSrPopupOverlayOn(this)
                DataStore.setSrPopupOverlayOn(this, next)
                renderSettingsTab()
            }
        }

        btnSrMascotAuto.onTap { DataStore.setSrMascotStyle(this, "auto"); renderSettingsTab() }
        btnSrMascotDragon.onTap { DataStore.setSrMascotStyle(this, "dragon"); renderSettingsTab() }
        btnSrMascotGhost.onTap { DataStore.setSrMascotStyle(this, "ghost"); renderSettingsTab() }

        btnSrResetTimer.onTap {
            val now = System.currentTimeMillis()
            if (now > srResetPendingUntilMs) {
                srResetPendingUntilMs = now + 3000L
                btnSrResetTimer.text = "নিশ্চিত করতে আরেকবার চাপো"
                uiHandler.postDelayed({
                    if (!isFinishing && !isDestroyed && System.currentTimeMillis() > srResetPendingUntilMs) {
                        btnSrResetTimer.text = "স্ক্রিনটাইম ও রিমাইন্ডার রিসেট করো"
                    }
                }, 3100L)
                return@onTap
            }
            srResetPendingUntilMs = 0L
            btnSrResetTimer.text = "স্ক্রিনটাইম ও রিমাইন্ডার রিসেট করো"
            SmartReminderManager.resetPhoneUseAndReminderNow(this)
            refreshTimerUI()
            Toast.makeText(this, "স্ক্রিনটাইম ও রিমাইন্ডার রিসেট হয়েছে—অ্যাপ থেকে বেরোলেই নতুন করে গুনবে!", Toast.LENGTH_LONG).show()
        }

        btnSrPreviewPopup.onTap {
            val lvl = srPreviewLevel
            srPreviewLevel = if (srPreviewLevel >= 5) 1 else srPreviewLevel + 1
            val kind = if (lvl == 1) MascotContent.KIND_ASK else MascotContent.KIND_ANGRY
            if (SmartReminderPopupOverlay.canDrawOverlay(this)) {
                SmartReminderPopupOverlay.show(this, kind, lvl, elapsedMin = lvl * 5, msgIndex = lvl, isPreview = true)
            } else {
                showAnimatedMascotDialog(lvl, kind, elapsedMin = lvl * 5)
                Toast.makeText(this, "অন্য অ্যাপের ওপর পপ-আপ পেতে ওভারলে অনুমতি দাও", Toast.LENGTH_LONG).show()
            }
        }

        fun updateSr(block: () -> Unit) {
            block()
            SmartReminderManager.onSettingsChanged(this)
            renderSettingsTab()
        }

        btnSrAsk1.onTap { updateSr { DataStore.setSrAskDelayMin(this, 1) } }
        btnSrAsk2.onTap { updateSr { DataStore.setSrAskDelayMin(this, 2) } }
        btnSrAsk3.onTap { updateSr { DataStore.setSrAskDelayMin(this, 3) } }
        btnSrAskCustom.onTap {
            showCustomTimeDialog("প্রথম প্রশ্ন আসার সময় (মিনিট)", "মিনিট লিখো (১–৬০)", 1, 60, DataStore.getSrAskDelayMin(this)) {
                updateSr { DataStore.setSrAskDelayMin(this, it) }
            }
        }

        btnSrRep3.onTap { updateSr { DataStore.setSrRepeatMin(this, 3) } }
        btnSrRep5.onTap { updateSr { DataStore.setSrRepeatMin(this, 5) } }
        btnSrRep10.onTap { updateSr { DataStore.setSrRepeatMin(this, 10) } }
        btnSrRepCustom.onTap {
            showCustomTimeDialog("রাগান্বিত পপ-আপ ব্যবধান (মিনিট)", "মিনিট লিখো (১–৬০)", 1, 60, DataStore.getSrRepeatMin(this)) {
                updateSr { DataStore.setSrRepeatMin(this, it) }
            }
        }

        btnSrRecheck10.onTap { updateSr { DataStore.setSrReadRecheckMin(this, 10) } }
        btnSrRecheck15.onTap { updateSr { DataStore.setSrReadRecheckMin(this, 15) } }
        btnSrRecheck30.onTap { updateSr { DataStore.setSrReadRecheckMin(this, 30) } }
        btnSrRecheckCustom.onTap {
            showCustomTimeDialog("'এখনো পড়ছো?' ব্যবধান (মিনিট)", "মিনিট লিখো (১–১২০)", 1, 120, DataStore.getSrReadRecheckMin(this)) {
                updateSr { DataStore.setSrReadRecheckMin(this, it) }
            }
        }

        btnSrReset1.onTap { updateSr { DataStore.setSrReadResetMin(this, 1) } }
        btnSrReset3.onTap { updateSr { DataStore.setSrReadResetMin(this, 3) } }
        btnSrReset5.onTap { updateSr { DataStore.setSrReadResetMin(this, 5) } }
        btnSrResetCustom.onTap {
            showCustomTimeDialog("ডিসপ্লে বন্ধ রিসেট সময় (মিনিট)", "মিনিট লিখো (১–৩০)", 1, 30, DataStore.getSrReadResetMin(this)) {
                updateSr { DataStore.setSrReadResetMin(this, it) }
            }
        }

        btnSrIdle30.onTap { updateSr { DataStore.setSrIdleMin(this, 30) } }
        btnSrIdle45.onTap { updateSr { DataStore.setSrIdleMin(this, 45) } }
        btnSrIdle60.onTap { updateSr { DataStore.setSrIdleMin(this, 60) } }
        btnSrIdle0.onTap { updateSr { DataStore.setSrIdleMin(this, 0) } }
        btnSrIdleCustom.onTap {
            showCustomTimeDialog("ডিসপ্লে বন্ধ (Idle) রিমাইন্ডার (মিনিট)", "মিনিট লিখো (৫–২৪০)", 5, 240, DataStore.getSrIdleMin(this).coerceAtLeast(10)) {
                updateSr { DataStore.setSrIdleMin(this, it) }
            }
        }

        btnSrFb10.onTap { updateSr { DataStore.setSrFallbackDelaySec(this, 10) } }
        btnSrFb20.onTap { updateSr { DataStore.setSrFallbackDelaySec(this, 20) } }
        btnSrFb30.onTap { updateSr { DataStore.setSrFallbackDelaySec(this, 30) } }
        btnSrFbCustom.onTap {
            showCustomTimeDialog("পপ-আপ ইগনোর ফলো-আপ (সেকেন্ড)", "সেকেন্ড লিখো (৫–১২০)", 5, 120, DataStore.getSrFallbackDelaySec(this)) {
                updateSr { DataStore.setSrFallbackDelaySec(this, it) }
            }
        }

        btnSrEat20.onTap { updateSr { DataStore.setSrEatMin(this, 20) } }
        btnSrEat30.onTap { updateSr { DataStore.setSrEatMin(this, 30) } }
        btnSrEat45.onTap { updateSr { DataStore.setSrEatMin(this, 45) } }
        btnSrEatCustom.onTap {
            showCustomTimeDialog("'খাচ্ছি' বিরতির সময় (মিনিট)", "মিনিট লিখো (১০–১৮০)", 10, 180, DataStore.getSrEatMin(this)) {
                updateSr { DataStore.setSrEatMin(this, it) }
            }
        }

        btnSrStrict20.onTap { updateSr { DataStore.setSrStrictAfterMin(this, 20) } }
        btnSrStrict30.onTap { updateSr { DataStore.setSrStrictAfterMin(this, 30) } }
        btnSrStrict45.onTap { updateSr { DataStore.setSrStrictAfterMin(this, 45) } }
        btnSrStrict0.onTap { updateSr { DataStore.setSrStrictAfterMin(this, 0) } }
        btnSrStrictCustom.onTap {
            showCustomTimeDialog("স্ট্রিক্ট মোড শুরু (মিনিট)", "মিনিট লিখো (৫–১৮০)", 5, 180, DataStore.getSrStrictAfterMin(this).coerceAtLeast(10)) {
                updateSr { DataStore.setSrStrictAfterMin(this, it) }
            }
        }

        btnSrCall5.onTap { updateSr { DataStore.setSrCallVibMin(this, 5) } }
        btnSrCall10.onTap { updateSr { DataStore.setSrCallVibMin(this, 10) } }
        btnSrCall15.onTap { updateSr { DataStore.setSrCallVibMin(this, 15) } }
        btnSrCall0.onTap { updateSr { DataStore.setSrCallVibMin(this, 0) } }
        btnSrCallCustom.onTap {
            showCustomTimeDialog("কলে থাকলে ৩বার ভাইব্রেট (মিনিট)", "মিনিট লিখো (১–৬০)", 1, 60, DataStore.getSrCallVibMin(this).coerceAtLeast(5)) {
                updateSr { DataStore.setSrCallVibMin(this, it) }
            }
        }

        swSrQuiet.setOnCheckedChangeListener { _, checked ->
            if (updatingSrSwitches) return@setOnCheckedChangeListener
            updateSr { DataStore.setSrQuietOn(this, checked) }
        }

        btnSrQuietStart.onTap {
            val cur = DataStore.getSrQuietStartMin(this)
            TimePickerDialog(this, { _, h, m ->
                updateSr { DataStore.setSrQuietStartMin(this, h * 60 + m) }
            }, cur / 60, cur % 60, true).show()
        }
        btnSrQuietEnd.onTap {
            val cur = DataStore.getSrQuietEndMin(this)
            TimePickerDialog(this, { _, h, m ->
                updateSr { DataStore.setSrQuietEndMin(this, h * 60 + m) }
            }, cur / 60, cur % 60, true).show()
        }
    }

    // ------------------------------------------------------------------ dialogs / actions

    private fun selectPreset(min: Int) {
        DataStore.setPresetMin(this, min)
        val rt = DataStore.loadRuntimeState(this)
        if (rt.running) {
            startService(Intent(this, FlipTrackerService::class.java).setAction(FlipTrackerService.ACTION_RESET_TIMER))
        } else {
            DataStore.saveRuntimeState(this, rt.copy(remainingSec = min * 60))
        }
        refreshPresetPills()
        refreshTimerUI()
    }

    private fun showCustomTimerDialog() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "মিনিট লিখো (যেমন: ২৫ বা ৬০)"
            setPadding(dp(20), dp(14), dp(20), dp(14))
        }
        val wrap = LinearLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("কাস্টম টাইমার সেট করো")
            .setView(wrap)
            .setPositiveButton("সেট করো") { _, _ ->
                val m = input.text.toString().toIntOrNull()
                if (m != null && m in 1..240) {
                    selectPreset(m)
                } else {
                    Toast.makeText(this, "১ থেকে ২৪০ মিনিটের মধ্যে সংখ্যা দাও", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun showCustomTimeDialog(title: String, hintText: String, minVal: Int, maxVal: Int, currentVal: Int, onSave: (Int) -> Unit) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = hintText
            if (currentVal in minVal..maxVal) setText(currentVal.toString())
            setPadding(dp(20), dp(14), dp(20), dp(14))
        }
        val wrap = LinearLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setView(wrap)
            .setPositiveButton("সেট করো") { _, _ ->
                val v = input.text.toString().toIntOrNull()
                if (v != null && v in minVal..maxVal) {
                    onSave(v)
                } else {
                    Toast.makeText(this, "${DataStore.toBnDigits(minVal)} থেকে ${DataStore.toBnDigits(maxVal)}-এর মধ্যে সংখ্যা দাও", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun showSubjectDialog() {
        val presets = arrayOf("বাংলা", "ইংরেজি", "গণিত", "সাধারণ জ্ঞান", "বিজ্ঞান", "নিজে লিখো...")
        MaterialAlertDialogBuilder(this)
            .setTitle("বিষয় নির্বাচন করো")
            .setItems(presets) { _, idx ->
                if (idx == presets.lastIndex) {
                    val input = EditText(this).apply {
                        setText(DataStore.getCurrentSubject(this@MainActivity))
                        setPadding(dp(20), dp(14), dp(20), dp(14))
                    }
                    val wrap = LinearLayout(this).apply {
                        setPadding(dp(20), dp(8), dp(20), 0)
                        addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                    }
                    MaterialAlertDialogBuilder(this)
                        .setTitle("বিষয়ের নাম লেখো")
                        .setView(wrap)
                        .setPositiveButton("সেভ") { _, _ ->
                            DataStore.setCurrentSubject(this, input.text.toString())
                            refreshTimerUI()
                        }
                        .setNegativeButton("বাতিল", null)
                        .show()
                } else {
                    DataStore.setCurrentSubject(this, presets[idx])
                    refreshTimerUI()
                }
            }
            .show()
    }

    private fun showExamDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val etName = EditText(this).apply {
            hint = "পরীক্ষার নাম (যেমন: BCS প্রিলি)"
            setText(DataStore.getExamName(this@MainActivity))
        }
        val etDate = EditText(this).apply {
            hint = "তারিখ (YYYY-MM-DD, যেমন: 2027-02-26)"
            setText(DataStore.getExamDateIso(this@MainActivity))
        }
        box.addView(etName)
        box.addView(etDate)
        MaterialAlertDialogBuilder(this)
            .setTitle("পরীক্ষা কাউন্টডাউন সেট করো")
            .setView(box)
            .setPositiveButton("সেভ") { _, _ ->
                DataStore.setExamName(this, etName.text.toString())
                val d = etDate.text.toString().trim()
                if (DataStore.isValidIsoDate(d)) {
                    DataStore.setExamDateIso(this, d)
                } else {
                    Toast.makeText(this, "তারিখ ঠিক নয়! YYYY-MM-DD ফরম্যাটে দাও (যেমন 2027-02-26)", Toast.LENGTH_LONG).show()
                }
                refreshTimerUI()
                renderSettingsTab()
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    /** কারণ ট্যাগ: যে অপচয় সময় এখনো ট্যাগ করা হয়নি তা থেকে সর্বোচ্চ ১৫ মিনিট বেছে নেওয়া কারণে সরানো হয়। মোট অপচয় আর বাড়ে না। */
    private fun showWasteReasonDialog() {
        val reasons = arrayOf("ফোন স্ক্রলিং", "আড্ডা/গল্প", "ক্লান্তি/অলসতা", "অন্যান্য কাজ")
        MaterialAlertDialogBuilder(this)
            .setTitle("অপচয়ের কারণ ট্যাগ করো (সর্বোচ্চ ১৫ মি.)")
            .setItems(reasons) { _, which ->
                val r = reasons[which]
                var moved = 0L
                DataStore.updateToday(this) { rec ->
                    val untagged = rec.wasteReasons["অপচয় সময়"] ?: 0L
                    moved = minOf(15 * 60L, untagged)
                    if (moved > 0L) {
                        rec.wasteReasons["অপচয় সময়"] = untagged - moved
                        if ((rec.wasteReasons["অপচয় সময়"] ?: 0L) <= 0L) rec.wasteReasons.remove("অপচয় সময়")
                        rec.wasteReasons[r] = (rec.wasteReasons[r] ?: 0L) + moved
                        rec.wasteReason = r
                        rec.synced = false
                    }
                }
                Toast.makeText(
                    this,
                    if (moved > 0L) "${DataStore.formatHoursMinBn(moved)} \"$r\" হিসেবে ট্যাগ হয়েছে" else "ট্যাগ করার মতো নতুন অপচয় সময় নেই",
                    Toast.LENGTH_SHORT
                ).show()
                refreshTimerUI()
            }
            .show()
    }

    // ------------------------------------------------------------------ tabs

    private fun showTab(idx: Int, animate: Boolean = true) {
        if (currentTab == 3 && idx != 3) syncEditorUnlocked = false
        currentTab = idx
        val tabs = listOf(tabTimer, tabReport, tabRoutine, tabSettings)
        tabs.forEachIndexed { i, v ->
            if (i == idx) {
                if (v.visibility != View.VISIBLE) {
                    v.visibility = View.VISIBLE
                    if (animate) {
                        v.alpha = 0f
                        v.translationY = dp(8).toFloat()
                        v.animate().alpha(1f).translationY(0f).setDuration(180L).start()
                    }
                }
            } else {
                v.animate().cancel()
                v.alpha = 1f
                v.translationY = 0f
                v.visibility = View.GONE
            }
        }
        styleNav()
    }

    private fun styleNav() {
        val p = pal()
        val idle = ContextCompat.getColor(this, R.color.nav_idle_text)
        val activeBg = ColorUtils.blendARGB(p.cardBg, p.accent, if (isNightActive()) 0.18f else 0.14f)
        listOf(navTimer, navReport, navRoutine, navSettings).forEachIndexed { i, tv ->
            val active = i == currentTab
            val c = if (active) p.accent else idle
            tv.setTextColor(c)
            tv.compoundDrawableTintList = ColorStateList.valueOf(c)
            tv.background = if (active) ThemePalette.makeBg(this, activeBg, 0, 16f, 0f) else null
        }
    }

    private fun refreshAllUI() {
        // শুধু UI সেট করছি: লিসেনার চালু হয়ে সার্ভিস রিস্টার্ট (টাইমার রিসেট) যেন না হয়
        updatingFlipSwitch = true
        swFlipService.isChecked = DataStore.isFlipEnabled(this)
        swOnlineStudy.isChecked = DataStore.isOnlineStudy(this)
        updatingFlipSwitch = false
        chkWordTarget.isChecked = DataStore.getToday(this).wordTarget
        applyColorPalette()
        refreshPresetPills()
        refreshAlarmUI()
        refreshTimerUI()
        renderSettingsTab()
    }

    private fun refreshAlarmUI() {
        btnTopAlarm.text = when (DataStore.getAlarmMode(this)) {
            "sound" -> "সাউন্ড"
            "silent" -> "নীরব"
            else -> "কম্পন"
        }
    }

    private fun refreshPresetPills() {
        val p = DataStore.getPresetMin(this)
        setPillActive(btnPreset45, p == 45)
        setPillActive(btnPreset10, p == 10)
        setPillActive(btnPreset5, p == 5)
        val isCustom = p != 45 && p != 10 && p != 5
        btnPresetCustom.text = if (isCustom) "${DataStore.toBnDigits(p)} মি." else "কাস্টম +"
        setPillActive(btnPresetCustom, isCustom)
    }

    private fun isNightActive(): Boolean {
        val uiMode = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return uiMode == Configuration.UI_MODE_NIGHT_YES
    }

    // ------------------------------------------------------------------ palette / styling

    private fun addRipple(v: View, color: Int) {
        v.foreground = RippleDrawable(ColorStateList.valueOf(ColorUtils.setAlphaComponent(color, 60)), null, null)
        v.clipToOutline = true
    }

    private fun styleByTag(v: View, p: AppPalette, soft: Int) {
        when (v.tag as? String) {
            "card" -> v.background = ThemePalette.makeBg(this, p.cardBg, p.cardBorder, 20f, 1f)
            "soft" -> { v.background = ThemePalette.makeBg(this, soft, p.cardBorder, 14f, 1f); addRipple(v, p.accent) }
            "track" -> v.background = ThemePalette.makeBg(this, soft, 0, 14f, 0f)
            "primary" -> {
                v.background = ThemePalette.makeBg(this, p.pillActiveBg, p.pillActiveBorder, 14f, 1.2f)
                if (v is TextView) v.setTextColor(p.pillActiveText)
                addRipple(v, p.pillActiveText)
            }
            "divider" -> v.setBackgroundColor(p.cardBorder)
            "input" -> v.background = ThemePalette.makeBg(this, soft, p.cardBorder, 14f, 1f)
            "muted_icon" -> if (v is ImageView) v.imageTintList = ColorStateList.valueOf(ContextCompat.getColor(this, R.color.text_muted))
        }
        if (v is ViewGroup) for (i in 0 until v.childCount) styleByTag(v.getChildAt(i), p, soft)
    }

    private fun tintDrawables(tv: TextView, color: Int) {
        tv.compoundDrawableTintList = ColorStateList.valueOf(color)
    }

    private fun applyColorPalette() {
        val pal = pal()
        val night = isNightActive()
        val soft = softOf(pal)
        val textMain = ContextCompat.getColor(this, R.color.text_main)
        val white = Color.WHITE

        styleByTag(rootLayout, pal, soft)

        // ডে মোডে চাঁদ, নাইট মোডে সূর্য
        btnTopTheme.setImageResource(if (night) R.drawable.ic_sun else R.drawable.ic_moon)
        btnTopTheme.imageTintList = ColorStateList.valueOf(textMain)
        btnPrevPeriod.imageTintList = ColorStateList.valueOf(textMain)
        btnNextPeriod.imageTintList = ColorStateList.valueOf(textMain)

        focusRingView.setRingColors(pal.ringStart, pal.ringEnd)
        focusRingView.setTrackColor(pal.cardBorder)
        statusPillBox.background = ThemePalette.makeBg(this, pal.statusBg, pal.statusBorder, 20f, 1.2f)
        tvModeStatus.setTextColor(pal.statusText)
        examStripCard.background = ThemePalette.makeBg(this, pal.cardBg, pal.cardBorder, 20f, 1f)
        focusCardBox.background = ThemePalette.makeBg(this, pal.cardBg, pal.cardBorder, 20f, 1f)
        flipCardBox.background = ThemePalette.makeBg(this, pal.cardBg, pal.cardBorder, 20f, 1f)
        bottomNavBar.background = ThemePalette.makeBg(this, pal.cardBg, pal.cardBorder, 24f, 1f)

        btnManualStudy.background = ThemePalette.makeBg(this, pal.studyBg, pal.studyBorder, 16f, 1.5f)
        btnManualStudy.setTextColor(pal.studyText)
        tintDrawables(btnManualStudy, pal.studyText)
        btnManualWaste.background = ThemePalette.makeBg(this, pal.wasteBg, pal.wasteBorder, 16f, 1.5f)
        btnManualWaste.setTextColor(pal.wasteText)
        tintDrawables(btnManualWaste, pal.wasteText)
        cardStudyLive.background = ThemePalette.makeBg(this, pal.studyBg, pal.studyBorder, 20f, 1.5f)
        cardWasteLive.background = ThemePalette.makeBg(this, pal.wasteBg, pal.wasteBorder, 20f, 1.5f)
        listOf(btnManualStudy, btnManualWaste, cardStudyLive, cardWasteLive, examStripCard).forEach {
            addRipple(it, white)
        }
        // লাইভ কার্ডের ভেতরের লেখা সবসময় পড়ার মতো উজ্জ্বল
        tvStudyLiveClock.setTextColor(pal.studyText)
        tvWasteLiveClock.setTextColor(pal.wasteText)

        tvSubjectChip.setTextColor(pal.accent)
        tintDrawables(tvSubjectChip, pal.accent)
        tintDrawables(tvExamLabel, pal.accent)
        tintDrawables(tvStreakChip, ContextCompat.getColor(this, R.color.amber_accent))
        tvExamDaysPill.background = ThemePalette.makeBg(this, ColorUtils.blendARGB(pal.cardBg, pal.accent, 0.16f), 0, 12f, 0f)
        tvExamDaysPill.setTextColor(pal.accent)
        btnToggleYearly.setTextColor(ContextCompat.getColor(this, R.color.pill_inactive_text))
        tvStatusDot.setTextColor(ContextCompat.getColor(this, R.color.status_dot))

        pbDailyGoal.progressTintList = ColorStateList.valueOf(pal.accent)
        pbDailyGoal.progressBackgroundTintList = ColorStateList.valueOf(pal.cardBorder)
        chkWordTarget.buttonTintList = ColorStateList.valueOf(pal.accent)

        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        val muted = ContextCompat.getColor(this, R.color.text_muted)
        val onThumb = if (night) Color.parseColor("#0B0F14") else Color.WHITE
        val trackOff = ColorUtils.blendARGB(pal.cardBg, muted, 0.22f)
        for (sw in listOf(swFlipService, swOnlineStudy, swGoalNotif, swSrEnabled, swSrQuiet, swDashCellAlways)) {
            sw.thumbTintList = ColorStateList(states, intArrayOf(onThumb, muted))
            sw.trackTintList = ColorStateList(states, intArrayOf(pal.accent, trackOff))
        }

        reportBarChart.setColors(
            pal.accent,
            ContextCompat.getColor(this, R.color.coral_waste),
            ContextCompat.getColor(this, R.color.indigo_sleep),
            pal.cardBorder,
            muted
        )
        ivDashBtnIcon.imageTintList = ColorStateList.valueOf(pal.pillActiveText)
        tvDashBtnLabel.setTextColor(pal.pillActiveText)
        btnReportMenu.imageTintList = ColorStateList.valueOf(textMain)
        updateReportPeriodPills()

        styleNav()
        refreshPresetPills()
    }

    private fun setPillActive(tv: TextView, active: Boolean) {
        val pal = pal()
        if (active) {
            tv.background = ThemePalette.makeBg(this, pal.pillActiveBg, pal.pillActiveBorder, 14f, 1.3f)
            tv.setTextColor(pal.pillActiveText)
        } else {
            tv.background = ThemePalette.makeBg(this, softOf(pal), pal.cardBorder, 14f, 1f)
            tv.setTextColor(ContextCompat.getColor(this, R.color.pill_inactive_text))
        }
        addRipple(tv, pal.accent)
    }

    private fun setSegmentActive(tv: TextView, active: Boolean) {
        val pal = pal()
        if (active) {
            tv.background = ThemePalette.makeBg(this, pal.pillActiveBg, pal.pillActiveBorder, 11f, 1f)
            tv.setTextColor(pal.pillActiveText)
        } else {
            tv.background = null
            tv.setTextColor(ContextCompat.getColor(this, R.color.pill_inactive_text))
        }
    }

    private fun setBtnIcon(tv: TextView, res: Int) {
        tv.setCompoundDrawablesRelativeWithIntrinsicBounds(res, 0, 0, 0)
    }

    private fun dot(color: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
        setSize(dp(12), dp(12))
    }

    // ------------------------------------------------------------------ timer tab

    private fun refreshTimerUI() {
        val rt = DataStore.loadRuntimeState(this)
        val now = System.currentTimeMillis()
        val elapsedSec = if (rt.running && rt.stateStartMs > 0L) ((now - rt.stateStartMs) / 1000L).coerceAtLeast(0L) else 0L

        val presetSec = (DataStore.getPresetMin(this) * 60).coerceAtLeast(60)
        val displaySec = if (rt.running && rt.mode == "STUDY") {
            (rt.remainingSec - elapsedSec.toInt()).coerceAtLeast(0)
        } else {
            rt.remainingSec
        }
        val clock = String.format(Locale.US, "%02d:%02d", displaySec / 60, displaySec % 60)
        tvTimerClock.setTextIfChanged(DataStore.toBnDigits(clock))
        focusRingView.setProgress(displaySec.toFloat() / presetSec.toFloat())

        tvSubjectChip.setTextIfChanged("বিষয়: ${DataStore.getCurrentSubject(this)}")
        tvExamLabel.setTextIfChanged(DataStore.getExamName(this))
        tvStreakChip.setTextIfChanged("${DataStore.toBnDigits(DataStore.getCurrentStreak(this))} দিন")
        tvExamDaysPill.setTextIfChanged("আর ${DataStore.toBnDigits(DataStore.getDaysUntilExam(this))} দিন")

        val grace = DataStore.getGraceSec(this)
        val flipOn = DataStore.isFlipEnabled(this)
        tvFlipTitle.text = if (flipOn) "ফ্লিপ মোড ON" else "ফ্লিপ মোড OFF"
        if (swFlipService.isChecked != flipOn) { updatingFlipSwitch = true; swFlipService.isChecked = flipOn; updatingFlipSwitch = false }
        val studyRunning = rt.running && rt.mode == "STUDY"
        val wasteRunning = rt.running && rt.mode == "WASTE"
        btnManualStudy.text = if (studyRunning) "পড়া পজ" else "পড়া শুরু"
        setBtnIcon(btnManualStudy, if (studyRunning) R.drawable.ic_pause else R.drawable.ic_play)
        btnManualWaste.text = if (wasteRunning) "অপচয় পজ" else "অপচয় শুরু"
        setBtnIcon(btnManualWaste, if (wasteRunning) R.drawable.ic_pause else R.drawable.ic_play)
        tvFlipSub.text = if (grace > 0) "${DataStore.toBnDigits(grace)} সে. গ্রেস টাইম • শুধু উল্টো থাকলেই পড়া" else "গ্রেস টাইম বন্ধ • শুধু উল্টো থাকলেই পড়া"

        tvModeStatus.text = when {
            !rt.running -> "বিরতি · ট্র্যাকিং বন্ধ"
            rt.mode == "STUDY" && DataStore.isOnlineStudy(this) -> "অনলাইন · পড়া চলছে"
            rt.mode == "STUDY" && !flipOn -> "ম্যানুয়াল · পড়া চলছে"
            rt.mode == "STUDY" -> "উল্টানো · পড়া চলছে"
            !flipOn -> "ম্যানুয়াল · অপচয় চলছে"
            else -> "স্ক্রিন খোলা · অপচয় চলছে"
        }
        tvStatusDot.setTextColor(
            when {
                studyRunning -> Color.parseColor("#34D399")
                wasteRunning -> Color.parseColor("#F87171")
                else -> Color.parseColor("#94A3B8")
            }
        )
        tvRingCaption.text = when {
            studyRunning -> "ফোকাস চলছে"
            wasteRunning -> "অপচয় চলছে · পড়ায় ফেরো"
            else -> "ফোকাস সেশন"
        }

        // রিয়েল-টাইম লাইভ কাউন্টার (আজকের অংশ মাঝরাত পেরোলেও ঠিক থাকে)
        val today = DataStore.getToday(this)
        val sinceMs = maxOf(rt.stateStartMs, DataStore.startOfTodayMs())
        val liveElapsed = if (rt.running && rt.stateStartMs > 0L) ((now - sinceMs) / 1000L).coerceAtLeast(0L) else 0L
        val liveStudySec = today.studySec + if (studyRunning) liveElapsed else 0L
        val liveWasteSec = today.wasteSec + if (wasteRunning) liveElapsed else 0L

        tvStudyLiveClock.text = DataStore.formatHmsBn(liveStudySec)
        tvWasteLiveClock.text = DataStore.formatHmsBn(liveWasteSec)

        val goalH = DataStore.getDailyGoalHours(this)
        val doneHours = liveStudySec / 3600.0
        val doneFmt = DataStore.toBnDigits(String.format(Locale.US, "%.1f", doneHours))
        tvGoalProgressText.text = "$doneFmt / ${DataStore.toBnDigits(goalH)} ঘণ্টা"
        val pct = ((liveStudySec * 100L) / (goalH * 3600L)).toInt().coerceIn(0, 100)
        pbDailyGoal.progress = pct
    }

    // ------------------------------------------------------------------ report tab

    private fun updateReportPeriodPills() {
        val type = DataStore.getReportPeriodType(this)
        setPillActive(btnRepDay, type == ReportPeriodType.DAY)
        setPillActive(btnRepWeek, type == ReportPeriodType.WEEK)
        setPillActive(btnRepMonth, type == ReportPeriodType.MONTH)
        setPillActive(btnRepYear, type == ReportPeriodType.YEAR)
    }

    private fun canGoNextReportPeriod(): Boolean {
        val type = DataStore.getReportPeriodType(this)
        val anchor = DataStore.getReportAnchorIso(this)
        val rep = DataStore.computeUnifiedReport(this, type, anchor)
        return rep.rangeEndIso < DataStore.todayIso()
    }

    private fun shiftReportPeriod(delta: Int) {
        val type = DataStore.getReportPeriodType(this)
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance().apply {
            time = try { fmt.parse(DataStore.getReportAnchorIso(this@MainActivity)) ?: Date() } catch (_: Exception) { Date() }
        }
        when (type) {
            ReportPeriodType.DAY -> cal.add(Calendar.DAY_OF_YEAR, delta)
            ReportPeriodType.WEEK -> cal.add(Calendar.DAY_OF_YEAR, delta * 7)
            ReportPeriodType.MONTH -> cal.add(Calendar.MONTH, delta)
            ReportPeriodType.YEAR -> cal.add(Calendar.YEAR, delta)
        }
        val today = DataStore.todayIso()
        var nextIso = fmt.format(cal.time)
        if (nextIso > today) nextIso = today
        DataStore.setReportAnchorIso(this, nextIso)
        loadReportTab()
    }

    private fun showReportDatePicker() {
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance().apply {
            time = try { fmt.parse(DataStore.getReportAnchorIso(this@MainActivity)) ?: Date() } catch (_: Exception) { Date() }
        }
        val dpDlg = DatePickerDialog(
            this,
            { _, y, m, d ->
                val picked = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)
                val today = DataStore.todayIso()
                DataStore.setReportAnchorIso(this, if (picked > today) today else picked)
                loadReportTab()
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        )
        dpDlg.datePicker.maxDate = System.currentTimeMillis()
        dpDlg.show()
    }

    private fun loadReportTab() {
        updateReportPeriodPills()
        val type = DataStore.getReportPeriodType(this)
        val anchor = DataStore.getReportAnchorIso(this)
        viewUnsyncedDot.visibility = if (DataStore.hasUnsyncedDays(this)) View.VISIBLE else View.GONE

        val needsHydration = !reportHydratedOnce &&
            DataStore.loadDriveCache(this).isEmpty() &&
            DataStore.getGasUrl(this).startsWith("http")

        if (needsHydration) {
            tvReportStatusBanner.text = "ড্রাইভ থেকে আনা হচ্ছে..."
            tvReportStatusBanner.visibility = View.VISIBLE
            val appCtx = applicationContext
            thread {
                DataStore.fetchAllDaysFromDrive(appCtx, 10000)
                reportHydratedOnce = true
                runOnUiThread {
                    if (!isFinishing && !isDestroyed) renderReportView(DataStore.getReportPeriodType(this), DataStore.getReportAnchorIso(this))
                }
            }
        }
        renderReportView(type, anchor, loadingDrive = needsHydration)
    }

    private fun renderReportView(type: ReportPeriodType, anchor: String, loadingDrive: Boolean = false) {
        val rep = DataStore.computeUnifiedReport(this, type, anchor)
        lastReportData = rep

        tvPeriodTitle.text = rep.periodLabelBn
        tvReportPeriodSub.text = rep.periodLabelBn
        val canNext = rep.rangeEndIso < DataStore.todayIso()
        btnNextPeriod.isEnabled = canNext
        btnNextPeriod.alpha = if (canNext) 1f else 0.35f
        viewUnsyncedDot.visibility = if (DataStore.hasUnsyncedDays(this)) View.VISIBLE else View.GONE

        if (loadingDrive) {
            tvReportStatusBanner.text = "ড্রাইভ থেকে আনা হচ্ছে..."
            tvReportStatusBanner.visibility = View.VISIBLE
        } else if (!rep.hasAnyDataInPeriod) {
            tvReportStatusBanner.text = "এই সময়কালে এখনো কোনো ডেটা নেই"
            tvReportStatusBanner.visibility = View.VISIBLE
        } else {
            tvReportStatusBanner.visibility = View.GONE
        }

        tvStatStudy.text = DataStore.formatHoursMinBn(rep.totalStudyMin * 60L)
        tvStatAvg.text = DataStore.formatHoursMinBn(rep.avgDailyStudyMin * 60L)
        tvStatWaste.text = DataStore.formatHoursMinBn(rep.totalWasteMin * 60L)

        val scoreSb = SpannableStringBuilder("${DataStore.toBnDigits(rep.goalCompletionPct)}%")
        val scoreSub = "
অপচয় অনুপাত ${DataStore.toBnDigits(rep.wasteRatioScore)}%"
        val sIdx = scoreSb.length
        scoreSb.append(scoreSub)
        scoreSb.setSpan(RelativeSizeSpan(0.62f), sIdx, scoreSb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        scoreSb.setSpan(ForegroundColorSpan(ContextCompat.getColor(this, R.color.text_muted)), sIdx, scoreSb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        tvStatScore.text = scoreSb

        val streakText = SpannableStringBuilder("${DataStore.toBnDigits(rep.currentStreak)} দিন")
        val sub = "
সর্বোচ্চ ${DataStore.toBnDigits(rep.longestStreak)} দিন"
        val start = streakText.length
        streakText.append(sub)
        streakText.setSpan(RelativeSizeSpan(0.62f), start, streakText.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        streakText.setSpan(ForegroundColorSpan(ContextCompat.getColor(this, R.color.text_muted)), start, streakText.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        tvStatStreak.text = streakText

        tvStatBest.text = if (rep.bestDayLabel == "—") "—" else "${rep.bestDayLabel}
(${DataStore.formatHoursMinBn(rep.bestDayMin * 60L)})"

        if (type == ReportPeriodType.DAY) {
            tvReportChartTitle.text = "দিনের লক্ষ্য ও সময়ভাগ"
            reportBarChart.visibility = View.GONE
            reportChartLegend.visibility = View.GONE
            dayDetailSummaryCard.visibility = View.VISIBLE
            val pct = rep.goalCompletionPct.coerceIn(0, 100)
            pbDayGoal.progress = pct
            tvDayGoalPct.text = "${DataStore.toBnDigits(rep.goalCompletionPct)}%"
            tvDayModesBreakdown.text = "ফ্লিপ: ${DataStore.formatHoursMinBn(rep.flipMin * 60L)} · ম্যানুয়াল: ${DataStore.formatHoursMinBn(rep.manualMin * 60L)} · অনলাইন: ${DataStore.formatHoursMinBn(rep.onlineMin * 60L)}"
            tvDayTimesBreakdown.text = "খাওয়া: ${DataStore.formatHoursMinBn(rep.totalEatMin * 60L)} · ঘুম ও অন্যান্য: ${DataStore.formatHoursMinBn(rep.totalSleepMin * 60L)}"
        } else {
            tvReportChartTitle.text = when (type) {
                ReportPeriodType.WEEK -> "সাপ্তাহিক তুলনা (৭ দিন)"
                ReportPeriodType.MONTH -> "দৈনিক তুলনা"
                else -> "মাসিক তুলনা (১২ মাস)"
            }
            dayDetailSummaryCard.visibility = View.GONE
            reportBarChart.visibility = View.VISIBLE
            reportChartLegend.visibility = View.VISIBLE
            reportBarChart.setBars(rep.bars)
        }

        fillBreakdown(subjectsContainer, rep.subjects, pal().accent, maxRows = 3)
        fillBreakdown(wasteContainer, rep.wasteReasons, ContextCompat.getColor(this, R.color.coral_waste), maxRows = 3)
    }

    private fun fillBreakdown(container: LinearLayout, data: Map<String, Long>, color: Int, maxRows: Int = Int.MAX_VALUE) {
        container.removeAllViews()
        val sortedAll = data.entries.filter { it.value > 0L }.sortedByDescending { it.value }
        val sorted = if (maxRows < sortedAll.size) sortedAll.take(maxRows) else sortedAll
        if (sorted.isEmpty()) {
            container.addView(TextView(this).apply {
                text = "কোনো তথ্য নেই"
                textSize = 12f
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_muted))
                setPadding(0, dp(8), 0, dp(2))
            })
            return
        }
        val maxVal = sortedAll.first().value.toFloat()
        val p = pal()
        for (e in sorted) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(8), 0, 0)
            }
            val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            head.addView(TextView(this).apply {
                text = e.key
                textSize = 11.5f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_main))
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            head.addView(TextView(this).apply {
                text = DataStore.formatHoursMinBn(e.value)
                textSize = 11.5f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_main))
            })
            row.addView(head)
            val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                this.max = 1000
                progress = ((e.value / maxVal) * 1000f).toInt().coerceIn(15, 1000)
                progressDrawable = ContextCompat.getDrawable(this@MainActivity, R.drawable.progress_goal)?.mutate()
                progressTintList = ColorStateList.valueOf(color)
                progressBackgroundTintList = ColorStateList.valueOf(p.cardBorder)
            }
            row.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(5)).apply { topMargin = dp(4) })
            container.addView(row)
        }
    }

    private fun showAllBreakdownSheet(isWaste: Boolean) {
        val rep = lastReportData ?: return
        val dlg = BottomSheetDialog(this)
        val p = pal()
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.cardBg)
            setPadding(dp(20), dp(18), dp(20), dp(24))
        }
        wrap.addView(TextView(this).apply {
            text = if (isWaste) "অপচয়ের সব কারণ · ${rep.periodLabelBn}" else "সব বিষয়ের পড়া · ${rep.periodLabelBn}"
            textSize = 16f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(textColorMain(p))
        })
        wrap.addView(TextView(this).apply {
            text = "খাওয়া: ${DataStore.formatHoursMinBn(rep.totalEatMin * 60L)} · ঘুম/অন্যান্য: ${DataStore.formatHoursMinBn(rep.totalSleepMin * 60L)}"
            textSize = 12f
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_muted))
            setPadding(0, dp(4), 0, dp(10))
        })
        val listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val color = if (isWaste) ContextCompat.getColor(this, R.color.coral_waste) else p.accent
        fillBreakdown(listBox, if (isWaste) rep.wasteReasons else rep.subjects, color)
        val scroll = ScrollView(this).apply { addView(listBox) }
        wrap.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        dlg.setContentView(wrap)
        dlg.show()
    }

    private fun showHeatmapBottomSheet() {
        val dlg = BottomSheetDialog(this)
        val p = pal()
        val muted = ContextCompat.getColor(this, R.color.text_muted)
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.cardBg)
            setPadding(dp(20), dp(18), dp(20), dp(24))
        }
        wrap.addView(TextView(this).apply {
            text = "শেষ ২৮ দিনের ফোকাস হিটম্যাপ"
            textSize = 16f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(textColorMain(p))
        })
        wrap.addView(TextView(this).apply {
            text = "রঙ যত গাঢ়, ওই দিন পড়াশোনা তত বেশি হয়েছে"
            textSize = 12f
            setTextColor(muted)
            setPadding(0, dp(4), 0, dp(12))
        })
        val hm = HeatmapView(this).apply {
            setPalette(ColorUtils.blendARGB(p.cardBg, muted, 0.18f), p.accent)
            setMinutes(DataStore.getLast28DaysMinutes(this@MainActivity))
        }
        wrap.addView(hm, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(170)))
        dlg.setContentView(wrap)
        dlg.show()
    }

    private fun showReportMenuSheet() {
        val dlg = BottomSheetDialog(this)
        val p = pal()
        val muted = ContextCompat.getColor(this, R.color.text_muted)
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.cardBg)
            setPadding(dp(18), dp(16), dp(18), dp(24))
        }
        wrap.addView(TextView(this).apply {
            text = "রিপোর্ট ও সিঙ্ক"
            textSize = 16f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(textColorMain(p))
        })
        wrap.addView(TextView(this).apply {
            val unsynced = if (DataStore.hasUnsyncedDays(this@MainActivity)) "অসিঙ্কড ডেটা আছে · " else ""
            text = "$unsynced${DataStore.getLastSyncText(this@MainActivity)}"
            textSize = 12f
            setTextColor(muted)
            setPadding(0, dp(2), 0, dp(12))
        })

        fun addMenuRow(title: String, subtitle: String, onClick: () -> Unit) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = ThemePalette.makeBg(this@MainActivity, softOf(p), p.cardBorder, 14f, 1f)
                setPadding(dp(14), dp(12), dp(14), dp(12))
                setOnClickListener { dlg.dismiss(); onClick() }
            }
            row.addView(TextView(this).apply {
                text = title
                textSize = 14f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setTextColor(textColorMain(p))
            })
            row.addView(TextView(this).apply {
                text = subtitle
                textSize = 11.5f
                setTextColor(muted)
            })
            wrap.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(8)
            })
        }

        addMenuRow("ড্রাইভে সিঙ্ক করো", "অসিঙ্কড দিনগুলো Google Sheet-এ পাঠাও") {
            val appCtx = applicationContext
            Snackbar.make(findViewById(android.R.id.content), "ড্রাইভে সিঙ্ক হচ্ছে...", Snackbar.LENGTH_SHORT).show()
            thread {
                val (ok, msg) = DataStore.syncToGoogleDrive(appCtx)
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    Snackbar.make(findViewById(android.R.id.content), msg, Snackbar.LENGTH_LONG).show()
                    if (ok) loadReportTab()
                }
            }
        }
        addMenuRow("২৮ দিনের ফোকাস হিটম্যাপ", "গত ৪ সপ্তাহের ধারাবাহিকতা বড় করে দেখো") {
            showHeatmapBottomSheet()
        }
        addMenuRow("CSV শেয়ার (এই সময়কাল)", "বর্তমান নির্বাচিত সময়কালের আসল .csv ফাইল") {
            val rep = lastReportData
            shareExportedFile(DataStore.exportCsvToFile(this, rep?.rangeStartIso, rep?.rangeEndIso, rep?.rangeStartIso ?: "period"), "text/csv", "CSV শেয়ার করো")
        }
        addMenuRow("CSV শেয়ার (সব ডেটা)", "সম্পূর্ণ ইতিহাসের UTF-8 .csv ফাইল") {
            shareExportedFile(DataStore.exportCsvToFile(this, null, null, "all_${DataStore.todayIso()}"), "text/csv", "সব ডেটা CSV শেয়ার করো")
        }
        dlg.setContentView(wrap)
        dlg.show()
    }

    private fun shareExportedFile(file: java.io.File, mime: String, chooserTitle: String) {
        try {
            val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", file)
            val share = Intent(Intent.ACTION_SEND).apply {
                type = mime
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(share, chooserTitle))
        } catch (e: Exception) {
            Snackbar.make(findViewById(android.R.id.content), "ফাইল শেয়ার ব্যর্থ: ${e.localizedMessage ?: "ত্রুটি"}", Snackbar.LENGTH_LONG).show()
        }
    }

    private fun textColorMain(p: ThemePalette.Palette): Int =
        if (p.isDark) Color.parseColor("#F1F5F9") else Color.parseColor("#0F172A")

    // ------------------------------------------------------------------ routine tab

    private fun renderRoutineTab(scrollToToday: Boolean = false) {
        routineContainer.removeAllViews()
        val days = DataStore.getCurrentMonthDays(this)
        val cal = Calendar.getInstance()
        tvRoutineHeader.text = "রুটিন · ${bnMonths[cal.get(Calendar.MONTH)]} ${DataStore.toBnDigits(cal.get(Calendar.YEAR))}"
        chkWordTarget.setOnCheckedChangeListener(null)
        chkWordTarget.isChecked = DataStore.getToday(this).wordTarget
        chkWordTarget.setOnCheckedChangeListener { _, checked ->
            DataStore.updateToday(this) { rec -> rec.wordTarget = checked; rec.synced = false }
            renderRoutineTab()
        }

        val p = pal()
        val today = DataStore.todayIso()
        val goalMin = DataStore.getDailyGoalHours(this) * 60
        val muted = ContextCompat.getColor(this, R.color.text_muted)
        val inflater = LayoutInflater.from(this)
        var todayRow: View? = null

        for (d in days) {
            val row = inflater.inflate(R.layout.item_routine_day, routineContainer, false)
            val isToday = d.date == today
            val isFuture = d.date > today
            row.background = ThemePalette.makeBg(this, p.cardBg, if (isToday) p.accent else p.cardBorder, 16f, if (isToday) 1.6f else 1f)
            if (isFuture) row.alpha = 0.5f

            val num = row.findViewById<TextView>(R.id.tvDayNum)
            num.text = DataStore.toBnDigits(d.date.takeLast(2))
            if (isToday) {
                num.background = ThemePalette.makeBg(this, p.accent, 0, 20f, 0f)
                num.setTextColor(if (isNightActive()) Color.parseColor("#0B0F14") else Color.WHITE)
            } else {
                num.background = ThemePalette.makeBg(this, softOf(p), 0, 20f, 0f)
            }

            val mins = d.totalStudyMinutes()
            row.findViewById<TextView>(R.id.tvDayStudy).text =
                if (mins > 0) DataStore.formatHoursMinBn(mins * 60L) else "—"
            row.findViewById<TextView>(R.id.tvDayCircles).text =
                if (d.c45 > 0) "${DataStore.toBnDigits(d.c45)}×৪৫মি" else ""
            row.findViewById<ProgressBar>(R.id.pbDay).apply {
                progress = (mins * 100 / goalMin).coerceIn(0, 100)
                progressTintList = ColorStateList.valueOf(p.accent)
                progressBackgroundTintList = ColorStateList.valueOf(p.cardBorder)
            }
            row.findViewById<TextView>(R.id.tvDayMeta).text =
                if (d.eatSec > 0L) "অপচয় ${DataStore.formatHoursMinBn(d.wasteSec)} · খাওয়া ${DataStore.formatHoursMinBn(d.eatSec)} · ঘুম ${DataStore.formatHoursMinBn(d.sleepOtherSec)}" else "অপচয় ${DataStore.formatHoursMinBn(d.wasteSec)} · ঘুম ${DataStore.formatHoursMinBn(d.sleepOtherSec)}"
            row.findViewById<ImageView>(R.id.ivWord).apply {
                imageTintList = ColorStateList.valueOf(if (d.wordTarget) p.accent else muted)
                alpha = if (d.wordTarget) 1f else 0.25f
            }
            routineContainer.addView(row)
            if (isToday) todayRow = row
        }

        if (scrollToToday && todayRow != null) {
            val target = todayRow
            (routineContainer.parent as? ScrollView)?.post {
                (routineContainer.parent as? ScrollView)?.scrollTo(0, (target.top - dp(8)).coerceAtLeast(0))
            }
        }
    }

    // ------------------------------------------------------------------ settings tab

    private fun renderSettingsTab() {
        val h = DataStore.getDailyGoalHours(this)
        tvGoalHoursVal.text = "${DataStore.toBnDigits(h)} ঘণ্টা"
        tvGoalNotifSub.text = "${DataStore.toBnDigits(h)} ঘণ্টা শেষ হলে জানাবে"
        if (swGoalNotif.isChecked != DataStore.isGoalNotifOn(this)) swGoalNotif.isChecked = DataStore.isGoalNotifOn(this)
        tvExamSettingSub.text = "${DataStore.getExamName(this)} · ${DataStore.toBnDigits(DataStore.getExamDateIso(this))}"

        val g = DataStore.getGraceSec(this)
        val gCustom = g !in listOf(0, 3, 5, 10)
        setSegmentActive(btnGrace0, g == 0)
        setSegmentActive(btnGrace3, g == 3)
        setSegmentActive(btnGrace5, g == 5)
        setSegmentActive(btnGrace10, g == 10)
        btnGraceCustom.text = if (gCustom) "${DataStore.toBnDigits(g)} সে." else "কাস্টম"
        setSegmentActive(btnGraceCustom, gCustom)

        val am = DataStore.getAlarmMode(this)
        setSegmentActive(btnAlarmVib, am == "vibrate")
        setSegmentActive(btnAlarmSound, am == "sound")
        setSegmentActive(btnAlarmSilent, am == "silent")

        val tm = DataStore.getThemeMode(this)
        setSegmentActive(btnThemeDay, tm == "day")
        setSegmentActive(btnThemeNight, tm == "night")
        setSegmentActive(btnThemeAuto, tm == "auto")

        val cp = DataStore.getColorPalette(this)
        val night = isNightActive()
        listOf(
            Triple(btnColor1, "sage", cp == "sage"),
            Triple(btnColor2, "ocean", cp == "ocean"),
            Triple(btnColor3, "espresso", cp == "espresso"),
            Triple(btnColor4, "nordic", cp == "nordic")
        ).forEach { (btn, id, active) ->
            setPillActive(btn, active)
            btn.setCompoundDrawablesRelativeWithIntrinsicBounds(dot(ThemePalette.get(id, night).accent), null, null, null)
        }

        btnSettingsDrawer.imageTintList = ColorStateList.valueOf(textColorMain(pal()))
        val savedUrl = DataStore.getGasUrl(this)
        val savedKey = DataStore.getSyncKey(this)
        if (savedUrl.isNotEmpty() && !syncEditorUnlocked) {
            syncLockedCard.visibility = View.VISIBLE
            syncEditorBox.visibility = View.GONE
            val shortUrl = if (savedUrl.length > 42) savedUrl.take(28) + "…" + savedUrl.takeLast(10) else savedUrl
            tvSyncMaskedUrl.text = "✓ সংযুক্ত · $shortUrl"
            tvSyncMaskedPass.text = if (savedKey.isNotEmpty()) "সিঙ্ক পাসওয়ার্ড: ••••••" else "সিঙ্ক পাসওয়ার্ড: সেট করা নেই"
            tvSyncLockedStamp.text = DataStore.getLastSyncText(this)
        } else {
            syncLockedCard.visibility = View.GONE
            syncEditorBox.visibility = View.VISIBLE
            if (!etGasUrl.hasFocus() && etGasUrl.text.toString() != savedUrl) etGasUrl.setText(savedUrl)
            if (!etSyncKey.hasFocus() && etSyncKey.text.toString() != savedKey) etSyncKey.setText(savedKey)
            if (!etSyncKeyConfirm.hasFocus() && etSyncKeyConfirm.text.toString() != savedKey) etSyncKeyConfirm.setText(savedKey)
        }

        val ws = DataStore.getWeekStartDay(this)
        setPillActive(btnWeekStartSun, ws == Calendar.SUNDAY)
        setPillActive(btnWeekStartSat, ws == Calendar.SATURDAY)

        // Smart Reminder UI state
        updatingSrSwitches = true
        val srOn = DataStore.isSrEnabled(this)
        if (swSrEnabled.isChecked != srOn) swSrEnabled.isChecked = srOn
        val qOn = DataStore.isSrQuietOn(this)
        if (swSrQuiet.isChecked != qOn) swSrQuiet.isChecked = qOn
        val cellOn = DataStore.isSrDashCellAlways(this)
        if (swDashCellAlways.isChecked != cellOn) swDashCellAlways.isChecked = cellOn
        updatingSrSwitches = false

        val notifBlocked = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        boxSrNotifWarn.visibility = if (srOn && notifBlocked) View.VISIBLE else View.GONE
        val overlayMissing = srOn && !SmartReminderPopupOverlay.canDrawOverlay(this)
        if (notifBlocked || overlayMissing) {
            bannerMissingPerms.visibility = View.VISIBLE
            tvMissingPermsMsg.text = when {
                notifBlocked && overlayMissing -> "নোটিফিকেশন ও পপআপ (Overlay) অনুমতি বন্ধ আছে"
                notifBlocked -> "নোটিফিকেশন অনুমতি বন্ধ থাকায় রিমাইন্ডার কাজ করবে না"
                else -> "অন্য অ্যাপের ওপর পপআপ অনুমতি বন্ধ আছে"
            }
        } else {
            bannerMissingPerms.visibility = View.GONE
        }

        val hasOverlay = SmartReminderPopupOverlay.canDrawOverlay(this)
        val overlayOn = DataStore.isSrPopupOverlayOn(this)
        if (!hasOverlay) {
            tvSrOverlaySub.text = "অন্য অ্যাপের ওপর ৬০fps লাইভ পপ-আপ দেখাতে অনুমতি দাও"
            btnSrOverlayPerm.text = "অনুমতি দাও"
        } else if (overlayOn) {
            tvSrOverlaySub.text = "লাইভ ৬০fps ফ্লোটিং পপ-আপ সক্রিয় আছে"
            btnSrOverlayPerm.text = "চালু ✓"
        } else {
            tvSrOverlaySub.text = "ওভারলে বন্ধ (শুধু হেডস-আপ নোটিফিকেশন আসবে)"
            btnSrOverlayPerm.text = "চালু করো"
        }

        val ms = DataStore.getSrMascotStyle(this)
        setSegmentActive(btnSrMascotAuto, ms == "auto")
        setSegmentActive(btnSrMascotDragon, ms == "dragon")
        setSegmentActive(btnSrMascotGhost, ms == "ghost")

        val ask = DataStore.getSrAskDelayMin(this)
        val askCust = ask !in listOf(1, 2, 3)
        setSegmentActive(btnSrAsk1, ask == 1)
        setSegmentActive(btnSrAsk2, ask == 2)
        setSegmentActive(btnSrAsk3, ask == 3)
        btnSrAskCustom.text = if (askCust) "${DataStore.toBnDigits(ask)} মি." else "কাস্টম"
        setSegmentActive(btnSrAskCustom, askCust)

        val rep = DataStore.getSrRepeatMin(this)
        val repCust = rep !in listOf(3, 5, 10)
        setSegmentActive(btnSrRep3, rep == 3)
        setSegmentActive(btnSrRep5, rep == 5)
        setSegmentActive(btnSrRep10, rep == 10)
        btnSrRepCustom.text = if (repCust) "${DataStore.toBnDigits(rep)} মি." else "কাস্টম"
        setSegmentActive(btnSrRepCustom, repCust)

        val rec = DataStore.getSrReadRecheckMin(this)
        val recCust = rec !in listOf(10, 15, 30)
        setSegmentActive(btnSrRecheck10, rec == 10)
        setSegmentActive(btnSrRecheck15, rec == 15)
        setSegmentActive(btnSrRecheck30, rec == 30)
        btnSrRecheckCustom.text = if (recCust) "${DataStore.toBnDigits(rec)} মি." else "কাস্টম"
        setSegmentActive(btnSrRecheckCustom, recCust)

        val rst = DataStore.getSrReadResetMin(this)
        val rstCust = rst !in listOf(1, 3, 5)
        setSegmentActive(btnSrReset1, rst == 1)
        setSegmentActive(btnSrReset3, rst == 3)
        setSegmentActive(btnSrReset5, rst == 5)
        btnSrResetCustom.text = if (rstCust) "${DataStore.toBnDigits(rst)} মি." else "কাস্টম"
        setSegmentActive(btnSrResetCustom, rstCust)

        val idle = DataStore.getSrIdleMin(this)
        val idleCust = idle !in listOf(0, 30, 45, 60)
        setSegmentActive(btnSrIdle30, idle == 30)
        setSegmentActive(btnSrIdle45, idle == 45)
        setSegmentActive(btnSrIdle60, idle == 60)
        setSegmentActive(btnSrIdle0, idle == 0)
        btnSrIdleCustom.text = if (idleCust) DataStore.toBnDigits(idle) else "কাস্টম"
        setSegmentActive(btnSrIdleCustom, idleCust)

        val fb = DataStore.getSrFallbackDelaySec(this)
        val fbCust = fb !in listOf(10, 20, 30)
        setSegmentActive(btnSrFb10, fb == 10)
        setSegmentActive(btnSrFb20, fb == 20)
        setSegmentActive(btnSrFb30, fb == 30)
        btnSrFbCustom.text = if (fbCust) "${DataStore.toBnDigits(fb)} সে." else "কাস্টম"
        setSegmentActive(btnSrFbCustom, fbCust)

        val eat = DataStore.getSrEatMin(this)
        val eatCust = eat !in listOf(20, 30, 45)
        setSegmentActive(btnSrEat20, eat == 20)
        setSegmentActive(btnSrEat30, eat == 30)
        setSegmentActive(btnSrEat45, eat == 45)
        btnSrEatCustom.text = if (eatCust) "${DataStore.toBnDigits(eat)} মি." else "কাস্টম"
        setSegmentActive(btnSrEatCustom, eatCust)

        val st = DataStore.getSrStrictAfterMin(this)
        val stCust = st !in listOf(0, 20, 30, 45)
        setSegmentActive(btnSrStrict20, st == 20)
        setSegmentActive(btnSrStrict30, st == 30)
        setSegmentActive(btnSrStrict45, st == 45)
        setSegmentActive(btnSrStrict0, st == 0)
        btnSrStrictCustom.text = if (stCust) DataStore.toBnDigits(st) else "কাস্টম"
        setSegmentActive(btnSrStrictCustom, stCust)

        val cv = DataStore.getSrCallVibMin(this)
        val cvCust = cv !in listOf(0, 5, 10, 15)
        setSegmentActive(btnSrCall5, cv == 5)
        setSegmentActive(btnSrCall10, cv == 10)
        setSegmentActive(btnSrCall15, cv == 15)
        setSegmentActive(btnSrCall0, cv == 0)
        btnSrCallCustom.text = if (cvCust) DataStore.toBnDigits(cv) else "কাস্টম"
        setSegmentActive(btnSrCallCustom, cvCust)

        btnSrQuietStart.text = "শুরু: ${DataStore.formatTimeMinBn(DataStore.getSrQuietStartMin(this))}"
        btnSrQuietEnd.text = "শেষ: ${DataStore.formatTimeMinBn(DataStore.getSrQuietEndMin(this))}"
        btnSrQuietStart.alpha = if (qOn) 1f else 0.45f
        btnSrQuietEnd.alpha = if (qOn) 1f else 0.45f
    }

    // ------------------------------------------------------------------ start / stop

    override fun onStart() {
        super.onStart()
        SmartReminderManager.onAppForeground(this, true)
        focusRingView.setGlowActive(true)
        val filter = IntentFilter(FlipTrackerService.BROADCAST_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(stateReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(stateReceiver, filter)
        }
        refreshTimerUI()
        ensureTickerIfNeeded()
        if (currentTab == 1) loadReportTab()
        if (currentTab == 3) renderSettingsTab()
    }

    override fun onStop() {
        super.onStop()
        SmartReminderManager.onAppForeground(this, false)
        focusRingView.setGlowActive(false)
        uiHandler.removeCallbacks(uiTicker)
        try { unregisterReceiver(stateReceiver) } catch (_: Exception) {}
        if (!DataStore.loadRuntimeState(this).running) {
            DataStore.markAppClosedNow(this)
        }
    }

    private fun completeSyncSettingsSave(url: String, key: String) {
        DataStore.setGasUrl(this, url)
        DataStore.setSyncKey(this, key)
        etGasUrl.clearFocus()
        etSyncKey.clearFocus()
        etSyncKeyConfirm.clearFocus()
        syncEditorUnlocked = false
        renderSettingsTab()
        Snackbar.make(findViewById(android.R.id.content), "সিঙ্ক সেটিংস যাচাই করে সেভ করা হয়েছে!", Snackbar.LENGTH_LONG).show()
    }

    private fun promptUnlockSyncEditor() {
        val currentKey = DataStore.getSyncKey(this)
        if (currentKey.isEmpty()) {
            MaterialAlertDialogBuilder(this)
                .setTitle("সিঙ্ক লিংক পরিবর্তন")
                .setMessage("সংযুক্ত Apps Script লিংক বা সিঙ্ক পাসওয়ার্ড পরিবর্তন করতে চান?")
                .setPositiveButton("হ্যাঁ") { _, _ ->
                    syncEditorUnlocked = true
                    renderSettingsTab()
                }
                .setNegativeButton("না", null)
                .show()
            return
        }

        val until = DataStore.getSyncLockUntilMs(this)
        val now = System.currentTimeMillis()
        if (until > now) {
            val sec = ((until - now) / 1000L).coerceAtLeast(1L)
            Snackbar.make(findViewById(android.R.id.content), "অনেকবার ভুল হয়েছে। ${DataStore.toBnDigits(sec)} সেকেন্ড পরে চেষ্টা করো।", Snackbar.LENGTH_LONG).show()
            return
        }

        val et = EditText(this).apply {
            hint = "বর্তমান সিঙ্ক পাসওয়ার্ড"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("সিঙ্ক সেটিংস আনলক")
            .setMessage("পরিবর্তন করতে বর্তমান সিঙ্ক পাসওয়ার্ড দাও।")
            .setView(et)
            .setPositiveButton("আনলক") { _, _ ->
                val entered = et.text.toString().trim()
                if (entered == currentKey) {
                    DataStore.resetSyncLockFailures(this)
                    syncEditorUnlocked = true
                    renderSettingsTab()
                } else {
                    val lockedUntil = DataStore.recordSyncLockFailure(this)
                    val msg = if (lockedUntil > System.currentTimeMillis()) "৫ বার ভুল হয়েছে, ৬০ সেকেন্ড অপেক্ষা করো।" else "ভুল সিঙ্ক পাসওয়ার্ড!"
                    Snackbar.make(findViewById(android.R.id.content), msg, Snackbar.LENGTH_LONG).show()
                }
            }
            .setNeutralButton("ভুলে গেছি (মূল পাসওয়ার্ড)") { _, _ ->
                promptMasterPasswordForSyncReset()
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun promptMasterPasswordForSyncReset() {
        val et = EditText(this).apply {
            hint = "অ্যাপ খোলার মূল পাসওয়ার্ড"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("মূল পাসওয়ার্ড দিয়ে রিসেট")
            .setMessage("অ্যাপ খোলার মূল পাসওয়ার্ড দিলে নতুন করে সিঙ্ক লিংক ও পাসওয়ার্ড সেট করতে পারবে। তোমার ফোনের লোকাল ডেটা মুছবে না।")
            .setView(et)
            .setPositiveButton("যাচাই করো") { _, _ ->
                if (DataStore.verifyAppMasterPassword(et.text.toString())) {
                    DataStore.resetSyncLockFailures(this)
                    syncEditorUnlocked = true
                    etSyncKey.setText("")
                    etSyncKeyConfirm.setText("")
                    renderSettingsTab()
                    Snackbar.make(findViewById(android.R.id.content), "মূল পাসওয়ার্ড মিলেছে! এখন নতুন সিঙ্ক পাসওয়ার্ড দুবার লিখে সেভ করো।", Snackbar.LENGTH_LONG).show()
                } else {
                    Snackbar.make(findViewById(android.R.id.content), "মূল পাসওয়ার্ড মেলেনি!", Snackbar.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun fixMissingPermissionsFromBanner() {
        val notifBlocked = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (notifBlocked) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 102)
        } else if (!SmartReminderPopupOverlay.canDrawOverlay(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
    }

    private fun showSettingsQuickDrawer() {
        val dlg = BottomSheetDialog(this)
        val p = pal()
        val muted = ContextCompat.getColor(this, R.color.text_muted)
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.cardBg)
            setPadding(dp(18), dp(16), dp(18), dp(24))
        }
        wrap.addView(TextView(this).apply {
            text = "সেটিংস বিভাগসমূহ · v9.0"
            textSize = 16f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(textColorMain(p))
            setPadding(0, 0, 0, dp(10))
        })
        val scroll = tabSettings as? ScrollView
        val srOn = DataStore.isSrEnabled(this)
        val syncOk = DataStore.getGasUrl(this).isNotEmpty()
        val items = listOf(
            Triple("লক্ষ্য ও পরীক্ষা", "দৈনিক ${DataStore.toBnDigits(DataStore.getDailyGoalHours(this))} ঘণ্টা · ${DataStore.getExamName(this)}", 0.0f),
            Triple("ফ্লিপ ও অ্যালার্ম", "গ্রেস ${DataStore.toBnDigits(DataStore.getGraceSec(this))} সে · ${DataStore.getAlarmMode(this)}", 0.16f),
            Triple("স্মার্ট রিমাইন্ডার", if (srOn) "চালু · মাসকট ও শান্ত সময়" else "বন্ধ", 0.34f),
            Triple("চেহারা ও রঙ", "থিম: ${DataStore.getThemeMode(this)} · ${DataStore.getColorPalette(this)}", 0.72f),
            Triple("ডেটা, সিঙ্ক ও এক্সপোর্ট", if (syncOk) "সংযুক্ত · ${DataStore.getLastSyncText(this)}" else "সংযুক্ত নয়", 1.0f)
        )
        for ((title, sub, frac) in items) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = ThemePalette.makeBg(this@MainActivity, softOf(p), p.cardBorder, 12f, 1f)
                setPadding(dp(14), dp(10), dp(14), dp(10))
                setOnClickListener {
                    dlg.dismiss()
                    scroll?.post {
                        val maxY = (scroll.getChildAt(0)?.height ?: 0) - scroll.height
                        scroll.smoothScrollTo(0, (maxY.coerceAtLeast(0) * frac).toInt())
                    }
                }
            }
            row.addView(TextView(this).apply {
                text = title
                textSize = 13.5f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setTextColor(textColorMain(p))
            })
            row.addView(TextView(this).apply {
                text = sub
                textSize = 11.5f
                setTextColor(muted)
            })
            wrap.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(7)
            })
        }
        dlg.setContentView(wrap)
        dlg.show()
    }
}
