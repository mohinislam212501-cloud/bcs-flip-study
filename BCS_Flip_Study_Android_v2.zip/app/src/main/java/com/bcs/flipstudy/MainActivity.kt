package com.bcs.flipstudy

import android.Manifest
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.core.content.FileProvider
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar
import android.net.Uri
import android.provider.Settings
import android.webkit.WebView
import android.widget.FrameLayout
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.activity.OnBackPressedCallback
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.animation.AccelerateInterpolator
import android.transition.AutoTransition
import android.transition.TransitionManager
import android.view.animation.DecelerateInterpolator
import android.widget.PopupWindow
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.widget.NestedScrollView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var rootLayout: View

    private lateinit var tabTimer: View
    private lateinit var tabReport: View
    private lateinit var tabRoutine: View
    private lateinit var tabSettings: View

    private lateinit var navTimer: TextView
    private lateinit var navReport: TextView
    private lateinit var navRoutine: TextView
    private lateinit var navSettings: TextView

    // Timer UI
    private lateinit var btnTopTheme: ImageView
    private lateinit var statusPillBox: View
    private lateinit var tvStatusDot: TextView
    private lateinit var focusCardBox: View
    private lateinit var flipCardBox: View
    private lateinit var bottomNavBar: View
    private lateinit var cardStudyLive: View
    private lateinit var btnManualStudy: TextView
    private lateinit var btnManualWaste: TextView
    private lateinit var tvModeStatus: TextView
    private lateinit var btnTopAlarm: TextView
    private lateinit var examStripCard: View
    private lateinit var tvExamLabel: TextView
    private lateinit var tvStreakChip: TextView
    private lateinit var tvExamDaysPill: TextView
    private lateinit var focusRingView: FocusRingView
    private lateinit var tvRingCaption: TextView
    private lateinit var tvTimerClock: TextView
    private lateinit var tvSubjectChip: TextView
    private lateinit var tvGoalProgressText: TextView
    private lateinit var pbDailyGoal: ProgressBar
    private lateinit var btnPreset45: TextView
    private lateinit var btnPreset10: TextView
    private lateinit var btnPreset5: TextView
    private lateinit var btnPresetCustom: TextView
    private lateinit var tvFlipTitle: TextView
    private lateinit var tvFlipSub: TextView
    private lateinit var swFlipService: MaterialSwitch
    private lateinit var swOnlineStudy: MaterialSwitch
    private lateinit var cardWasteLive: View
    private lateinit var tvStudyLiveClock: TextView
    private lateinit var tvWasteLiveClock: TextView
    private lateinit var bannerActiveBreak: LinearLayout
    private lateinit var tvActiveBreakInfo: TextView
    private lateinit var btnBannerEndBreak: TextView
    private lateinit var tvWasteUntaggedBadge: TextView
    private lateinit var tvWasteCardSub: TextView
    private lateinit var pbWasteBudget: ProgressBar
    private lateinit var btnManageWasteReasons: TextView
    private lateinit var btnWasteBudget: TextView
    private lateinit var cardProfileCorner: View
    private lateinit var tvProfileAvatar: TextView
    private lateinit var tvProfileName: TextView
    private lateinit var tvProfileAgeSub: TextView
    private lateinit var ivReminderHeroMascot: ImageView
    private lateinit var tvReminderHeroStatus: TextView
    private lateinit var swSrSeriousMode: MaterialSwitch
    private lateinit var boxSeriousControls: LinearLayout
    private lateinit var btnSrSeriousAfterMin: TextView
    private lateinit var btnSrSeriousMaxHr: TextView
    private lateinit var btnProfNickname: TextView
    private lateinit var btnProfDob: TextView
    private lateinit var btnProfGender: TextView
    private lateinit var btnProfStatus: TextView
    private lateinit var btnProfCadre: TextView
    private lateinit var btnProfTargetYear: TextView
    private lateinit var btnProfMaxAge: TextView

    // Report UI
    private lateinit var tvReportPeriodSub: TextView
    private lateinit var btnPrevPeriod: ImageView
    private lateinit var btnNextPeriod: ImageView
    private lateinit var tvPeriodTitle: TextView
    private lateinit var btnReportToday: TextView
    private lateinit var btnRepDay: TextView
    private lateinit var btnRepWeek: TextView
    private lateinit var btnRepMonth: TextView
    private lateinit var btnRepYear: TextView
    private lateinit var btnReportMenu: ImageView
    private lateinit var viewUnsyncedDot: View
    private lateinit var tvReportStatusBanner: TextView
    private lateinit var bannerBcsAlloc: TextView
    private lateinit var tvStatStudy: TextView
    private lateinit var tvStatAvg: TextView
    private lateinit var tvStatWaste: TextView
    private lateinit var tvStatScore: TextView
    private lateinit var tvStatStreak: TextView
    private lateinit var tvStatBest: TextView
    private lateinit var tvReportChartTitle: TextView
    private lateinit var reportBarChart: WeeklyBarChartView
    private lateinit var reportChartLegend: LinearLayout
    private lateinit var dayDetailSummaryCard: LinearLayout
    private lateinit var pbDayGoal: ProgressBar
    private lateinit var tvDayGoalPct: TextView
    private lateinit var tvDayModesBreakdown: TextView
    private lateinit var tvDayTimesBreakdown: TextView
    private lateinit var reportDay24Bar: Day24BarView
    private lateinit var btnSrGapPhoneMin: TextView
    private lateinit var swGapAppSheet: MaterialSwitch
    private lateinit var swGapPhonePopup: MaterialSwitch
    private lateinit var swGapNightNotif: MaterialSwitch
    private lateinit var swGapAutoSleep: MaterialSwitch
    private lateinit var cardBreakdown: View
    private lateinit var tvSubjectsTotal: TextView
    private lateinit var tvOtherTotal: TextView
    private lateinit var scrollSubjectsCol: View
    private lateinit var scrollOtherCol: View
    private lateinit var subjectsContainer: LinearLayout
    private lateinit var otherContainer: LinearLayout
    private lateinit var btnOpenDashboard: View
    private lateinit var ivDashBtnIcon: ImageView
    private lateinit var tvDashBtnLabel: TextView
    private var lastReportData: UnifiedReportData? = null
    private var reportHydratedOnce = false

    // Routine UI
    private lateinit var tvRoutineHeader: TextView
    private lateinit var chkWordTarget: CheckBox
    private lateinit var routineContainer: LinearLayout

    // Settings UI
    private lateinit var btnGoalMinus: TextView
    private lateinit var btnGoalPlus: TextView
    private lateinit var tvGoalHoursVal: TextView
    private lateinit var tvGoalNotifSub: TextView
    private lateinit var swGoalNotif: MaterialSwitch
    private lateinit var rowEditExam: View
    private lateinit var tvExamSettingSub: TextView
    private lateinit var btnGrace0: TextView
    private lateinit var btnGrace3: TextView
    private lateinit var btnGrace5: TextView
    private lateinit var btnGrace10: TextView
    private lateinit var btnGraceCustom: TextView
    private lateinit var btnAlarmVib: TextView
    private lateinit var btnAlarmSound: TextView
    private lateinit var btnAlarmSilent: TextView
    private lateinit var btnThemeDay: TextView
    private lateinit var btnThemeNight: TextView
    private lateinit var btnThemeAuto: TextView
    private lateinit var btnColor1: TextView
    private lateinit var btnColor2: TextView
    private lateinit var btnColor3: TextView
    private lateinit var btnColor4: TextView
    private lateinit var btnColor5: TextView
    private lateinit var btnColor6: TextView
    private lateinit var btnSettingsDrawer: ImageView
    private lateinit var pillSmartReminder: TextView
    private lateinit var tvSettingsSub: TextView
    private lateinit var viewSettingsAlertDot: View
    private lateinit var cardSettingsBattery: LinearLayout
    private lateinit var tvSettingsBattery: TextView
    private lateinit var rowDayBoundarySetting: LinearLayout
    private lateinit var tvDayBoundarySub: TextView
    private lateinit var swHapticGlobal: MaterialSwitch
    private lateinit var btnHapticIntensity: TextView
    private lateinit var swHapticFlip: MaterialSwitch
    private lateinit var swHapticGoal: MaterialSwitch
    private var activeAnchoredMenu: PopupWindow? = null
    private lateinit var bannerMissingPerms: LinearLayout
    private lateinit var tvMissingPermsMsg: TextView
    private lateinit var btnFixMissingPerms: TextView
    private lateinit var syncLockedCard: LinearLayout
    private lateinit var tvSyncMaskedUrl: TextView
    private lateinit var tvSyncMaskedPass: TextView
    private lateinit var tvSyncLockedStamp: TextView
    private lateinit var btnUnlockSyncEditor: TextView
    private lateinit var syncEditorBox: LinearLayout
    private lateinit var etGasUrl: EditText
    private lateinit var etSyncKey: EditText
    private lateinit var etSyncKeyConfirm: EditText
    private lateinit var btnToggleSyncKeyVis1: ImageView
    private lateinit var btnToggleSyncKeyVis2: ImageView
    private lateinit var btnTestSync: TextView
    private lateinit var btnSaveSettings: TextView
    private lateinit var btnWeekStartSun: TextView
    private lateinit var btnWeekStartSat: TextView
    private lateinit var swDashCellAlways: MaterialSwitch
    private lateinit var btnExportJson: TextView
    private var syncEditorUnlocked = false
    companion object {
        @Volatile private var settingsUnlockedInSession = false
    }
    private var syncKeyVis1 = false
    private var syncKeyVis2 = false
    private var settingsPage = -1
    private val styledTabs = mutableSetOf<Int>()
    private val rippledIds = java.util.WeakHashMap<View, Int>()
    private var wasStudyRunning = false
    private lateinit var settingsMainPage: View
    private lateinit var settingsSubPages: List<View>
    private lateinit var rowMainSyncStatus: View
    private lateinit var tvMainSyncSummary: TextView
    private lateinit var tvAboutPermsStatus: TextView
    private lateinit var btnSrTestHour: TextView
    private lateinit var settingsDrawerOverlay: View
    private lateinit var settingsDrawerScrim: View
    private lateinit var settingsDrawerPanel: View
    private lateinit var drwSubFlip: TextView
    private lateinit var drwSubReminder: TextView
    private lateinit var drwSubMascot: TextView
    private lateinit var drwSubQuiet: TextView
    private lateinit var drwSubData: TextView

    // Smart Reminder Settings UI
    private lateinit var swSrEnabled: MaterialSwitch
    private lateinit var boxSrNotifWarn: View
    private lateinit var btnSrNotifPerm: TextView
    private lateinit var tvSrOverlaySub: TextView
    private lateinit var btnSrOverlayPerm: TextView
    private lateinit var btnSrMascotAuto: TextView
    private lateinit var btnSrMascotDragon: TextView
    private lateinit var btnSrMascotGhost: TextView
    private lateinit var btnSrPopupStyle: TextView
    private lateinit var btnSrPreviewPopup: TextView
    private lateinit var btnSrResetTimer: TextView
    private lateinit var btnSrAsk1: TextView
    private lateinit var btnSrAsk2: TextView
    private lateinit var btnSrAsk3: TextView
    private lateinit var btnSrAskCustom: TextView
    private lateinit var btnSrRep3: TextView
    private lateinit var btnSrRep5: TextView
    private lateinit var btnSrRep10: TextView
    private lateinit var btnSrRepCustom: TextView
    private lateinit var btnSrRecheck10: TextView
    private lateinit var btnSrRecheck15: TextView
    private lateinit var btnSrRecheck30: TextView
    private lateinit var btnSrRecheckCustom: TextView
    private lateinit var btnSrReset1: TextView
    private lateinit var btnSrReset3: TextView
    private lateinit var btnSrReset5: TextView
    private lateinit var btnSrResetCustom: TextView
    private lateinit var btnSrIdle30: TextView
    private lateinit var btnSrIdle45: TextView
    private lateinit var btnSrIdle60: TextView
    private lateinit var btnSrIdle0: TextView
    private lateinit var btnSrIdleCustom: TextView
    private lateinit var swSrQuiet: MaterialSwitch
    private lateinit var btnSrQuietStart: TextView
    private lateinit var btnSrQuietEnd: TextView
    private lateinit var btnSrFb10: TextView
    private lateinit var btnSrFb20: TextView
    private lateinit var btnSrFb30: TextView
    private lateinit var btnSrFbCustom: TextView
    private lateinit var btnSrEat20: TextView
    private lateinit var btnSrEat30: TextView
    private lateinit var btnSrEat45: TextView
    private lateinit var btnSrEatCustom: TextView
    private lateinit var btnSrStrict20: TextView
    private lateinit var btnSrStrict30: TextView
    private lateinit var btnSrStrict45: TextView
    private lateinit var btnSrStrict0: TextView
    private lateinit var btnSrStrictCustom: TextView
    private lateinit var btnSrCall5: TextView
    private lateinit var btnSrCall10: TextView
    private lateinit var btnSrCall15: TextView
    private lateinit var btnSrCall0: TextView
    private lateinit var btnSrCallCustom: TextView
    private var updatingSrSwitches = false
    private var srPreviewLevel = 1
    private var srResetPendingUntilMs = 0L

    private var currentTab = 0
    private var reportYearly = false
    private var updatingFlipSwitch = false
    private var reportYear = Calendar.getInstance().get(Calendar.YEAR)
    private var reportMonth = Calendar.getInstance().get(Calendar.MONTH) + 1

    private val bnMonths = arrayOf(
        "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
        "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
    )

    private val uiHandler = Handler(Looper.getMainLooper())
    private val uiTicker = object : Runnable {
        override fun run() {
            if (currentTab == 0) {
                refreshTimerUI()
                if (DataStore.loadRuntimeState(this@MainActivity).running) {
                    uiHandler.postDelayed(this, 1000L)
                }
            }
        }
    }

    private fun ensureTickerIfNeeded() {
        DataStore.sampleBatteryDrop(this)
        uiHandler.removeCallbacks(uiTicker)
        if (currentTab == 0 && DataStore.loadRuntimeState(this).running) {
            uiHandler.postDelayed(uiTicker, 1000L)
        }
    }

    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshTimerUI()
            ensureTickerIfNeeded()
        }
    }

    // ------------------------------------------------------------------ helpers

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun pal(): AppPalette = ThemePalette.get(DataStore.getColorPalette(this), isNightActive())

    private fun softOf(p: AppPalette): Int =
        ColorUtils.blendARGB(p.cardBg, p.accent, if (isNightActive()) 0.10f else 0.07f)

    private fun TextView.setTextIfChanged(value: String) {
        if (text.toString() != value) text = value
    }

    private fun View.onTap(block: () -> Unit) {
        setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            block()
        }
    }

    private fun View.onSettingsTap(block: () -> Unit) {
        onTap { requireSettingsAuth { block() } }
    }

    private fun guardSettingsSwitch(sw: android.widget.CompoundButton, checked: Boolean, retrigger: Boolean = false, apply: () -> Unit = {}) {
        if (!settingsUnlockedInSession) {
            updatingSrSwitches = true
            sw.isChecked = !checked
            updatingSrSwitches = false
            requireSettingsAuth {
                if (retrigger) {
                    sw.isChecked = checked
                } else {
                    updatingSrSwitches = true
                    sw.isChecked = checked
                    updatingSrSwitches = false
                    apply()
                }
            }
            return
        }
        apply()
    }

    private fun sendServiceAction(action: String) {
        val i = Intent(this, FlipTrackerService::class.java).setAction(action)
        if (DataStore.loadRuntimeState(this).running) startService(i)
        else ContextCompat.startForegroundService(this, i)
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        applySavedThemeMode()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (savedInstanceState != null) {
            currentTab = savedInstanceState.getInt("tab", 0)
            reportYearly = savedInstanceState.getBoolean("rep_yearly", false)
            reportYear = savedInstanceState.getInt("rep_year", reportYear)
            reportMonth = savedInstanceState.getInt("rep_month", reportMonth)
        }

        if (savedInstanceState == null) {
            requestNotificationPermissionIfNeeded()
            DataStore.ensureGapPhonePopupDefaultOffOnce(this)
            DataStore.ensureDailySubjectReset(this)
            BcsAllocReminderReceiver.schedule(this)
            DataStore.repairImpossibleWaste(this)
            DataStore.autoFinalizeExpiredUnassignedAndGaps(this)
            DailySyncWorker.scheduleDaily(this)
            SmartReminderManager.ensureMigratedAndStarted(this)
            val absorbed = DataStore.absorbClosedTimeAsSleepOther(this)
            if (absorbed >= 60L) {
                Toast.makeText(
                    this,
                    "অ্যাপ বন্ধ থাকা ${DataStore.formatHoursMinBn(absorbed)} ঘুম ও অন্যান্য সময়ে যোগ হয়েছে",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        bindViews()
        setupListeners()
        attachHelpTooltips()
        refreshAllUI()
        showTab(currentTab, animate = false)
        if (currentTab == 2) renderRoutineTab()
        checkMascotIntent(intent)
        refreshTimerUI()
        maybeShowBreakPrompt()
        maybeShowGapBottomSheet(force = false)
        if (!DataStore.isHelpHintShown(this)) {
            DataStore.setHelpHintShown(this)
            uiHandler.postDelayed({
                if (!isFinishing && !isDestroyed) {
                    Snackbar.make(findViewById(android.R.id.content), "টিপস: যেকোনো বোতাম ১.২ সেকেন্ড ধরে রাখলে ব্যাখ্যা দেখাবে", Snackbar.LENGTH_LONG).show()
                }
            }, 900L)
        }
    }

    private fun requireSettingsAuth(onUnlocked: () -> Unit) {
        if (settingsUnlockedInSession) {
            onUnlocked()
            return
        }
        val bm = BiometricManager.from(this)
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.BIOMETRIC_WEAK
        if (bm.canAuthenticate(authenticators) == BiometricManager.BIOMETRIC_SUCCESS) {
            val exec = ContextCompat.getMainExecutor(this)
            val prompt = BiometricPrompt(this, exec, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    settingsUnlockedInSession = true
                    HapticManager.lockUnlock(this@MainActivity)
                    onUnlocked()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    if (errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON) {
                        showSettingsPasswordDialog(onUnlocked)
                    }
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    HapticManager.lockReject(this@MainActivity)
                }
            })
            val info = BiometricPrompt.PromptInfo.Builder()
                .setTitle("সেটিংস আনলক করো")
                .setSubtitle("ফিঙ্গারপ্রিন্ট বা পাসওয়ার্ড দিয়ে সেটিংস খুলুন")
                .setNegativeButtonText("পাসওয়ার্ড ব্যবহার করো")
                .build()
            prompt.authenticate(info)
        } else {
            showSettingsPasswordDialog(onUnlocked)
        }
    }

    private fun showSettingsPasswordDialog(onUnlocked: () -> Unit) {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(12), dp(22), dp(4))
        }
        val tvInfo = TextView(this).apply {
            text = "সেটিংস পরিবর্তন বা রিসেট করতে পাসওয়ার্ড দাও।"
            textSize = 13f
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_muted))
            setPadding(0, 0, 0, dp(10))
        }
        val etPass = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            hint = "পাসওয়ার্ড লিখো"
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        wrap.addView(tvInfo)
        wrap.addView(etPass)

        val dlg = MaterialAlertDialogBuilder(this)
            .setTitle("সেটিংস আনলক করো")
            .setView(wrap)
            .setCancelable(true)
            .setPositiveButton("আনলক", null)
            .setNegativeButton("বাতিল", null)
            .create()

        dlg.setOnShowListener {
            dlg.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val lockUntil = DataStore.getAppLockUntilMs(this)
                val nowMs = System.currentTimeMillis()
                if (lockUntil > nowMs) {
                    val waitSec = ((lockUntil - nowMs + 999L) / 1000L).toInt().coerceAtLeast(1)
                    etPass.error = "অনেকবার ভুল হয়েছে! ${DataStore.toBnDigits(waitSec)} সে. পর চেষ্টা করো"
                    return@setOnClickListener
                }
                val entered = etPass.text.toString()
                if (DataStore.verifyAndUnlockDevice(this, entered)) {
                    settingsUnlockedInSession = true
                    dlg.dismiss()
                    HapticManager.lockUnlock(this)
                    onUnlocked()
                } else {
                    val nextLock = DataStore.getAppLockUntilMs(this)
                    etPass.error = if (nextLock > System.currentTimeMillis()) "৫ বার ভুল! ৬০ সেকেন্ড লক করা হয়েছে" else "পাসওয়ার্ড সঠিক নয়!"
                    HapticManager.lockReject(this)
                    Toast.makeText(this, "ভুল পাসওয়ার্ড!", Toast.LENGTH_SHORT).show()
                }
            }
        }
        dlg.show()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", currentTab)
        outState.putBoolean("rep_yearly", reportYearly)
        outState.putInt("rep_year", reportYear)
        outState.putInt("rep_month", reportMonth)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        checkMascotIntent(intent)
    }

    private fun checkMascotIntent(i: Intent?) {
        if (i == null) return
        val fallbackAction = i.getStringExtra(SmartReminderManager.EXTRA_START_STUDY_FALLBACK)
        if (!fallbackAction.isNullOrEmpty()) {
            i.removeExtra(SmartReminderManager.EXTRA_START_STUDY_FALLBACK)
            sendServiceAction(fallbackAction)
            refreshTimerUI()
        }
        if (i.getBooleanExtra(SmartReminderManager.EXTRA_SHOW_AWAY_PICKER, false)) {
            i.removeExtra(SmartReminderManager.EXTRA_SHOW_AWAY_PICKER)
            showAwayDurationDialog()
            return
        }
        val lvl = i.getIntExtra(SmartReminderManager.EXTRA_LEVEL, 0)
        if (lvl in 1..5) {
            val kind = i.getStringExtra(SmartReminderManager.EXTRA_KIND) ?: MascotContent.KIND_ANGRY
            val elapsed = i.getIntExtra(SmartReminderManager.EXTRA_ELAPSED_MIN, 0)
            i.removeExtra(SmartReminderManager.EXTRA_LEVEL)
            i.removeExtra(SmartReminderManager.EXTRA_KIND)
            i.removeExtra(SmartReminderManager.EXTRA_ELAPSED_MIN)
            showAnimatedMascotDialog(lvl, kind, elapsed)
        }
    }

    private fun showAwayDurationDialog() {
        val labels = arrayOf("৩০ মিনিট পর", "১ ঘণ্টা পর", "২ ঘণ্টা পর", "৩ ঘণ্টা পর", "কাস্টম সময় লিখো...")
        val mins = intArrayOf(30, 60, 120, 180, -1)
        MaterialAlertDialogBuilder(this)
            .setTitle("বাইরে আছো · কত সময় পর পড়তে বসবে?")
            .setItems(labels) { _, which ->
                val chosen = mins[which]
                if (chosen > 0) {
                    showAwayReasonDialog(chosen)
                } else {
                    val input = EditText(this).apply {
                        inputType = InputType.TYPE_CLASS_NUMBER
                        hint = "মিনিট লিখো (যেমন: ৯০ বা ১৫০)"
                        setPadding(dp(20), dp(14), dp(20), dp(14))
                    }
                    val wrap = LinearLayout(this).apply {
                        setPadding(dp(20), dp(8), dp(20), 0)
                        addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                    }
                    MaterialAlertDialogBuilder(this)
                        .setTitle("কত মিনিট পর পড়তে বসবে?")
                        .setView(wrap)
                        .setPositiveButton("পরবর্তী") { _, _ ->
                            val mVal = input.text.toString().toIntOrNull()
                            if (mVal != null && mVal in 5..720) {
                                showAwayReasonDialog(mVal)
                            } else {
                                Toast.makeText(this, "৫ থেকে ৭২০ মিনিটের মধ্যে সংখ্যা দাও", Toast.LENGTH_SHORT).show()
                            }
                        }
                        .setNegativeButton("বাতিল", null)
                        .show()
                }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun showAwayReasonDialog(chosenMin: Int) {
        val reasons = ReasonCatalog.DEFAULT_AWAY_REASONS.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("কেন বাইরে যাচ্ছো? (${MascotContent.formatDurationBn(chosenMin)})")
            .setItems(reasons) { _, idx ->
                val reason = reasons[idx]
                SmartReminderManager.onSetAwayMinutes(this, chosenMin, reason)
                refreshTimerUI()
                val preMin = (chosenMin / 4).coerceAtLeast(1)
                Snackbar.make(
                    findViewById(android.R.id.content),
                    "$reason · ${MascotContent.formatDurationBn(chosenMin)} সেট (${MascotContent.formatDurationBn(preMin)} আগে রিমাইন্ডার)",
                    Snackbar.LENGTH_LONG
                ).show()
            }
            .setNegativeButton("অন্যান্য") { _, _ ->
                SmartReminderManager.onSetAwayMinutes(this, chosenMin, "অন্যান্য")
                refreshTimerUI()
            }
            .show()
    }

    private fun showAnimatedMascotDialog(level: Int, kind: String = MascotContent.KIND_ANGRY, elapsedMin: Int = 0) {
        val safeLvl = level.coerceIn(1, 5)
        val character = MascotContent.resolveCharacter(this)
        val accent = MascotContent.accentColorFor(character, safeLvl)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(18), dp(24), dp(8))
        }

        val mascotWrap = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(156), dp(156))
            background = ThemePalette.makeBg(this@MainActivity, Color.parseColor("#0B0F17"), accent, 20f, 2f)
            clipToOutline = true
        }

        val webView: WebView? = SmartReminderPopupOverlay.createMascotWebView(this, character, safeLvl)
        if (webView != null) {
            mascotWrap.addView(webView, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            ))
        } else {
            val iv = ImageView(this).apply {
                setImageResource(MascotContent.mascotResFor(character, safeLvl))
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            mascotWrap.addView(iv, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            ))
        }

        val tv = TextView(this).apply {
            text = MascotContent.messageFor(this@MainActivity, kind, safeLvl, elapsedMin, DataStore.getSrMsgIndex(this@MainActivity))
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, 0)
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_main))
        }
        box.addView(mascotWrap)
        box.addView(tv)

        val shakeAmp = when (safeLvl) {
            5 -> 22f
            4 -> 17f
            3 -> 12f
            else -> 0f
        }
        val anim = if (shakeAmp > 0f) {
            ObjectAnimator.ofFloat(mascotWrap, "translationX", -shakeAmp, shakeAmp, -shakeAmp * 0.7f, shakeAmp * 0.7f, -shakeAmp * 0.35f, shakeAmp * 0.35f, 0f).apply {
                duration = if (safeLvl >= 4) 380L else 560L
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.REVERSE
            }
        } else {
            ObjectAnimator.ofFloat(mascotWrap, "translationY", 0f, -14f, 0f).apply {
                duration = 720L
                repeatCount = ValueAnimator.INFINITE
            }
        }
        anim.start()

        fun cleanup() {
            anim.cancel()
            try {
                webView?.stopLoading()
                webView?.loadUrl("about:blank")
                webView?.destroy()
            } catch (_: Exception) {}
        }

        val builder = MaterialAlertDialogBuilder(this)
            .setTitle(MascotContent.titleFor(kind, safeLvl, elapsedMin))
            .setView(box)
            .setOnDismissListener { cleanup() }

        when (kind) {
            MascotContent.KIND_ASK, MascotContent.KIND_RECHECK -> {
                builder.setPositiveButton("পড়ছি") { _, _ ->
                    cleanup()
                    SmartReminderManager.onReadingYes(this)
                    refreshTimerUI()
                }
                builder.setNegativeButton("পড়ছি না") { _, _ ->
                    cleanup()
                    SmartReminderManager.onReadingNo(this)
                }
                builder.setNeutralButton("খাচ্ছি (${DataStore.toBnDigits(DataStore.getSrEatMin(this))} মি.)") { _, _ ->
                    cleanup()
                    SmartReminderManager.onEatingMode(this)
                }
            }
            MascotContent.KIND_IDLE, MascotContent.KIND_AWAY_END -> {
                builder.setPositiveButton("পড়ছি") { _, _ ->
                    cleanup()
                    SmartReminderManager.onStartStudyFromIdle(this)
                    refreshTimerUI()
                }
                builder.setNegativeButton("বাইরে আছি") { _, _ ->
                    cleanup()
                    showAwayDurationDialog()
                }
            }
            MascotContent.KIND_AWAY_PRE -> {
                builder.setPositiveButton("পড়া শুরু করি") { _, _ ->
                    cleanup()
                    SmartReminderManager.onStartStudyFromIdle(this)
                    refreshTimerUI()
                }
                builder.setNegativeButton("ঠিক আছে") { _, _ ->
                    cleanup()
                    SmartReminderManager.onSnoozeIdle(this)
                }
            }
            else -> {
                builder.setPositiveButton("ফোনে পড়ছি") { _, _ ->
                    cleanup()
                    SmartReminderManager.onReadingYes(this)
                    refreshTimerUI()
                }
                builder.setNegativeButton("ঠিক আছে, ফোন রাখছি") { _, _ ->
                    cleanup()
                    SmartReminderManager.dismissReminderUi(this)
                }
                builder.setNeutralButton("খাচ্ছি (${DataStore.toBnDigits(DataStore.getSrEatMin(this))} মি.)") { _, _ ->
                    cleanup()
                    SmartReminderManager.onEatingMode(this)
                }
            }
        }
        builder.show()
    }

    private fun applySavedThemeMode() {
        val mode = when (DataStore.getThemeMode(this)) {
            "day" -> AppCompatDelegate.MODE_NIGHT_NO
            "night" -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }
        AppCompatDelegate.setDefaultNightMode(mode)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED && !DataStore.wasNotifPermAsked(this)
            ) {
                DataStore.setNotifPermAsked(this)
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }
    }

    // ------------------------------------------------------------------ binding

    private fun bindViews() {
        rootLayout = findViewById(R.id.rootLayout)
        tabTimer = findViewById(R.id.tabTimer)
        tabReport = findViewById(R.id.tabReport)
        tabRoutine = findViewById(R.id.tabRoutine)
        tabSettings = findViewById(R.id.tabSettings)

        navTimer = findViewById(R.id.navTimer)
        navReport = findViewById(R.id.navReport)
        navRoutine = findViewById(R.id.navRoutine)
        navSettings = findViewById(R.id.navSettings)

        btnTopTheme = findViewById(R.id.btnTopTheme)
        statusPillBox = findViewById(R.id.statusPillBox)
        tvStatusDot = findViewById(R.id.tvStatusDot)
        focusCardBox = findViewById(R.id.focusCardBox)
        flipCardBox = findViewById(R.id.flipCardBox)
        bottomNavBar = findViewById(R.id.bottomNavBar)
        cardStudyLive = findViewById(R.id.cardStudyLive)
        btnManualStudy = findViewById(R.id.btnManualStudy)
        btnManualWaste = findViewById(R.id.btnManualWaste)
        tvModeStatus = findViewById(R.id.tvModeStatus)
        btnTopAlarm = findViewById(R.id.btnTopAlarm)
        examStripCard = findViewById(R.id.examStripCard)
        tvExamLabel = findViewById(R.id.tvExamLabel)
        tvStreakChip = findViewById(R.id.tvStreakChip)
        tvExamDaysPill = findViewById(R.id.tvExamDaysPill)
        focusRingView = findViewById(R.id.focusRingView)
        tvRingCaption = findViewById(R.id.tvRingCaption)
        tvTimerClock = findViewById(R.id.tvTimerClock)
        tvSubjectChip = findViewById(R.id.tvSubjectChip)
        tvGoalProgressText = findViewById(R.id.tvGoalProgressText)
        pbDailyGoal = findViewById(R.id.pbDailyGoal)
        btnPreset45 = findViewById(R.id.btnPreset45)
        btnPreset10 = findViewById(R.id.btnPreset10)
        btnPreset5 = findViewById(R.id.btnPreset5)
        btnPresetCustom = findViewById(R.id.btnPresetCustom)
        tvFlipTitle = findViewById(R.id.tvFlipTitle)
        tvFlipSub = findViewById(R.id.tvFlipSub)
        swFlipService = findViewById(R.id.swFlipService)
        swOnlineStudy = findViewById(R.id.swOnlineStudy)
        cardWasteLive = findViewById(R.id.cardWasteLive)
        tvStudyLiveClock = findViewById(R.id.tvStudyLiveClock)
        tvWasteLiveClock = findViewById(R.id.tvWasteLiveClock)
        bannerActiveBreak = findViewById(R.id.bannerActiveBreak)
        tvActiveBreakInfo = findViewById(R.id.tvActiveBreakInfo)
        btnBannerEndBreak = findViewById(R.id.btnBannerEndBreak)
        tvWasteUntaggedBadge = findViewById(R.id.tvWasteUntaggedBadge)
        tvWasteCardSub = findViewById(R.id.tvWasteCardSub)
        pbWasteBudget = findViewById(R.id.pbWasteBudget)
        btnManageWasteReasons = findViewById(R.id.btnManageWasteReasons)
        btnWasteBudget = findViewById(R.id.btnWasteBudget)
        cardProfileCorner = findViewById(R.id.cardProfileCorner)
        tvProfileAvatar = findViewById(R.id.tvProfileAvatar)
        tvProfileName = findViewById(R.id.tvProfileName)
        tvProfileAgeSub = findViewById(R.id.tvProfileAgeSub)
        ivReminderHeroMascot = findViewById(R.id.ivReminderHeroMascot)
        tvReminderHeroStatus = findViewById(R.id.tvReminderHeroStatus)
        swSrSeriousMode = findViewById(R.id.swSrSeriousMode)
        boxSeriousControls = findViewById(R.id.boxSeriousControls)
        btnSrSeriousAfterMin = findViewById(R.id.btnSrSeriousAfterMin)
        btnSrSeriousMaxHr = findViewById(R.id.btnSrSeriousMaxHr)
        btnProfNickname = findViewById(R.id.btnProfNickname)
        btnProfDob = findViewById(R.id.btnProfDob)
        btnProfGender = findViewById(R.id.btnProfGender)
        btnProfStatus = findViewById(R.id.btnProfStatus)
        btnProfCadre = findViewById(R.id.btnProfCadre)
        btnProfTargetYear = findViewById(R.id.btnProfTargetYear)
        btnProfMaxAge = findViewById(R.id.btnProfMaxAge)

        tvReportPeriodSub = findViewById(R.id.tvReportPeriodSub)
        btnPrevPeriod = findViewById(R.id.btnPrevPeriod)
        btnNextPeriod = findViewById(R.id.btnNextPeriod)
        tvPeriodTitle = findViewById(R.id.tvPeriodTitle)
        btnReportToday = findViewById(R.id.btnReportToday)
        btnRepDay = findViewById(R.id.btnRepDay)
        btnRepWeek = findViewById(R.id.btnRepWeek)
        btnRepMonth = findViewById(R.id.btnRepMonth)
        btnRepYear = findViewById(R.id.btnRepYear)
        btnReportMenu = findViewById(R.id.btnReportMenu)
        viewUnsyncedDot = findViewById(R.id.viewUnsyncedDot)
        tvReportStatusBanner = findViewById(R.id.tvReportStatusBanner)
        bannerBcsAlloc = findViewById(R.id.bannerBcsAlloc)
        tvStatStudy = findViewById(R.id.tvStatStudy)
        tvStatAvg = findViewById(R.id.tvStatAvg)
        tvStatWaste = findViewById(R.id.tvStatWaste)
        tvStatScore = findViewById(R.id.tvStatScore)
        tvStatStreak = findViewById(R.id.tvStatStreak)
        tvStatBest = findViewById(R.id.tvStatBest)
        tvReportChartTitle = findViewById(R.id.tvReportChartTitle)
        reportBarChart = findViewById(R.id.reportBarChart)
        reportChartLegend = findViewById(R.id.reportChartLegend)
        dayDetailSummaryCard = findViewById(R.id.dayDetailSummaryCard)
        pbDayGoal = findViewById(R.id.pbDayGoal)
        tvDayGoalPct = findViewById(R.id.tvDayGoalPct)
        tvDayModesBreakdown = findViewById(R.id.tvDayModesBreakdown)
        tvDayTimesBreakdown = findViewById(R.id.tvDayTimesBreakdown)
        reportDay24Bar = findViewById(R.id.reportDay24Bar)
        btnSrGapPhoneMin = findViewById(R.id.btnSrGapPhoneMin)
        swGapAppSheet = findViewById(R.id.swGapAppSheet)
        swGapPhonePopup = findViewById(R.id.swGapPhonePopup)
        swGapNightNotif = findViewById(R.id.swGapNightNotif)
        swGapAutoSleep = findViewById(R.id.swGapAutoSleep)
        cardBreakdown = findViewById(R.id.cardBreakdown)
        tvSubjectsTotal = findViewById(R.id.tvSubjectsTotal)
        tvOtherTotal = findViewById(R.id.tvOtherTotal)
        scrollSubjectsCol = findViewById(R.id.scrollSubjectsCol)
        scrollOtherCol = findViewById(R.id.scrollOtherCol)
        subjectsContainer = findViewById(R.id.subjectsContainer)
        otherContainer = findViewById(R.id.otherContainer)
        btnOpenDashboard = findViewById(R.id.btnOpenDashboard)
        ivDashBtnIcon = findViewById(R.id.ivDashBtnIcon)
        tvDashBtnLabel = findViewById(R.id.tvDashBtnLabel)

        tvRoutineHeader = findViewById(R.id.tvRoutineHeader)
        chkWordTarget = findViewById(R.id.chkWordTarget)
        routineContainer = findViewById(R.id.routineContainer)

        btnGoalMinus = findViewById(R.id.btnGoalMinus)
        btnGoalPlus = findViewById(R.id.btnGoalPlus)
        tvGoalHoursVal = findViewById(R.id.tvGoalHoursVal)
        tvGoalNotifSub = findViewById(R.id.tvGoalNotifSub)
        swGoalNotif = findViewById(R.id.swGoalNotif)
        rowEditExam = findViewById(R.id.rowEditExam)
        tvExamSettingSub = findViewById(R.id.tvExamSettingSub)
        btnGrace0 = findViewById(R.id.btnGrace0)
        btnGrace3 = findViewById(R.id.btnGrace3)
        btnGrace5 = findViewById(R.id.btnGrace5)
        btnGrace10 = findViewById(R.id.btnGrace10)
        btnGraceCustom = findViewById(R.id.btnGraceCustom)
        btnAlarmVib = findViewById(R.id.btnAlarmVib)
        btnAlarmSound = findViewById(R.id.btnAlarmSound)
        btnAlarmSilent = findViewById(R.id.btnAlarmSilent)
        btnThemeDay = findViewById(R.id.btnThemeDay)
        btnThemeNight = findViewById(R.id.btnThemeNight)
        btnThemeAuto = findViewById(R.id.btnThemeAuto)
        btnColor1 = findViewById(R.id.btnColor1)
        btnColor2 = findViewById(R.id.btnColor2)
        btnColor3 = findViewById(R.id.btnColor3)
        btnColor4 = findViewById(R.id.btnColor4)
        btnColor5 = findViewById(R.id.btnColor5)
        btnColor6 = findViewById(R.id.btnColor6)
        btnSettingsDrawer = findViewById(R.id.btnSettingsDrawer)
        pillSmartReminder = findViewById(R.id.pillSmartReminder)
        tvSettingsSub = findViewById(R.id.tvSettingsSub)
        viewSettingsAlertDot = findViewById(R.id.viewSettingsAlertDot)
        cardSettingsBattery = findViewById(R.id.cardSettingsBattery)
        tvSettingsBattery = findViewById(R.id.tvSettingsBattery)
        rowDayBoundarySetting = findViewById(R.id.rowDayBoundarySetting)
        tvDayBoundarySub = findViewById(R.id.tvDayBoundarySub)
        swHapticGlobal = findViewById(R.id.swHapticGlobal)
        btnHapticIntensity = findViewById(R.id.btnHapticIntensity)
        swHapticFlip = findViewById(R.id.swHapticFlip)
        swHapticGoal = findViewById(R.id.swHapticGoal)
        bannerMissingPerms = findViewById(R.id.bannerMissingPerms)
        tvMissingPermsMsg = findViewById(R.id.tvMissingPermsMsg)
        btnFixMissingPerms = findViewById(R.id.btnFixMissingPerms)
        syncLockedCard = findViewById(R.id.syncLockedCard)
        tvSyncMaskedUrl = findViewById(R.id.tvSyncMaskedUrl)
        tvSyncMaskedPass = findViewById(R.id.tvSyncMaskedPass)
        tvSyncLockedStamp = findViewById(R.id.tvSyncLockedStamp)
        btnUnlockSyncEditor = findViewById(R.id.btnUnlockSyncEditor)
        syncEditorBox = findViewById(R.id.syncEditorBox)
        etGasUrl = findViewById(R.id.etGasUrl)
        etSyncKey = findViewById(R.id.etSyncKey)
        etSyncKeyConfirm = findViewById(R.id.etSyncKeyConfirm)
        btnToggleSyncKeyVis1 = findViewById(R.id.btnToggleSyncKeyVis1)
        btnToggleSyncKeyVis2 = findViewById(R.id.btnToggleSyncKeyVis2)
        btnTestSync = findViewById(R.id.btnTestSync)
        btnSaveSettings = findViewById(R.id.btnSaveSettings)
        btnWeekStartSun = findViewById(R.id.btnWeekStartSun)
        btnWeekStartSat = findViewById(R.id.btnWeekStartSat)
        swDashCellAlways = findViewById(R.id.swDashCellAlways)
        btnExportJson = findViewById(R.id.btnExportJson)
        settingsMainPage = findViewById(R.id.settingsMainPage)
        settingsSubPages = listOf(
            findViewById(R.id.settingsPageFlip),
            findViewById(R.id.settingsPageReminder),
            findViewById(R.id.settingsPageMascot),
            findViewById(R.id.settingsPageQuiet),
            findViewById(R.id.settingsPageData),
            findViewById(R.id.settingsPageAbout),
            findViewById(R.id.settingsPageProfile),
            findViewById(R.id.settingsPageGap)
        )
        rowMainSyncStatus = findViewById(R.id.rowMainSyncStatus)
        tvMainSyncSummary = findViewById(R.id.tvMainSyncSummary)
        tvAboutPermsStatus = findViewById(R.id.tvAboutPermsStatus)
        btnSrTestHour = findViewById(R.id.btnSrTestHour)
        settingsDrawerOverlay = findViewById(R.id.settingsDrawerOverlay)
        settingsDrawerScrim = findViewById(R.id.settingsDrawerScrim)
        settingsDrawerPanel = findViewById(R.id.settingsDrawerPanel)
        drwSubFlip = findViewById(R.id.drwSubFlip)
        drwSubReminder = findViewById(R.id.drwSubReminder)
        drwSubMascot = findViewById(R.id.drwSubMascot)
        drwSubQuiet = findViewById(R.id.drwSubQuiet)
        drwSubData = findViewById(R.id.drwSubData)

        swSrEnabled = findViewById(R.id.swSrEnabled)
        boxSrNotifWarn = findViewById(R.id.boxSrNotifWarn)
        btnSrNotifPerm = findViewById(R.id.btnSrNotifPerm)
        tvSrOverlaySub = findViewById(R.id.tvSrOverlaySub)
        btnSrOverlayPerm = findViewById(R.id.btnSrOverlayPerm)
        btnSrMascotAuto = findViewById(R.id.btnSrMascotAuto)
        btnSrMascotDragon = findViewById(R.id.btnSrMascotDragon)
        btnSrMascotGhost = findViewById(R.id.btnSrMascotGhost)
        btnSrPopupStyle = findViewById(R.id.btnSrPopupStyle)
        btnSrPreviewPopup = findViewById(R.id.btnSrPreviewPopup)
        btnSrResetTimer = findViewById(R.id.btnSrResetTimer)
        btnSrAsk1 = findViewById(R.id.btnSrAsk1)
        btnSrAsk2 = findViewById(R.id.btnSrAsk2)
        btnSrAsk3 = findViewById(R.id.btnSrAsk3)
        btnSrAskCustom = findViewById(R.id.btnSrAskCustom)
        btnSrRep3 = findViewById(R.id.btnSrRep3)
        btnSrRep5 = findViewById(R.id.btnSrRep5)
        btnSrRep10 = findViewById(R.id.btnSrRep10)
        btnSrRepCustom = findViewById(R.id.btnSrRepCustom)
        btnSrRecheck10 = findViewById(R.id.btnSrRecheck10)
        btnSrRecheck15 = findViewById(R.id.btnSrRecheck15)
        btnSrRecheck30 = findViewById(R.id.btnSrRecheck30)
        btnSrRecheckCustom = findViewById(R.id.btnSrRecheckCustom)
        btnSrReset1 = findViewById(R.id.btnSrReset1)
        btnSrReset3 = findViewById(R.id.btnSrReset3)
        btnSrReset5 = findViewById(R.id.btnSrReset5)
        btnSrResetCustom = findViewById(R.id.btnSrResetCustom)
        btnSrIdle30 = findViewById(R.id.btnSrIdle30)
        btnSrIdle45 = findViewById(R.id.btnSrIdle45)
        btnSrIdle60 = findViewById(R.id.btnSrIdle60)
        btnSrIdle0 = findViewById(R.id.btnSrIdle0)
        btnSrIdleCustom = findViewById(R.id.btnSrIdleCustom)
        swSrQuiet = findViewById(R.id.swSrQuiet)
        btnSrQuietStart = findViewById(R.id.btnSrQuietStart)
        btnSrQuietEnd = findViewById(R.id.btnSrQuietEnd)
        btnSrFb10 = findViewById(R.id.btnSrFb10)
        btnSrFb20 = findViewById(R.id.btnSrFb20)
        btnSrFb30 = findViewById(R.id.btnSrFb30)
        btnSrFbCustom = findViewById(R.id.btnSrFbCustom)
        btnSrEat20 = findViewById(R.id.btnSrEat20)
        btnSrEat30 = findViewById(R.id.btnSrEat30)
        btnSrEat45 = findViewById(R.id.btnSrEat45)
        btnSrEatCustom = findViewById(R.id.btnSrEatCustom)
        btnSrStrict20 = findViewById(R.id.btnSrStrict20)
        btnSrStrict30 = findViewById(R.id.btnSrStrict30)
        btnSrStrict45 = findViewById(R.id.btnSrStrict45)
        btnSrStrict0 = findViewById(R.id.btnSrStrict0)
        btnSrStrictCustom = findViewById(R.id.btnSrStrictCustom)
        btnSrCall5 = findViewById(R.id.btnSrCall5)
        btnSrCall10 = findViewById(R.id.btnSrCall10)
        btnSrCall15 = findViewById(R.id.btnSrCall15)
        btnSrCall0 = findViewById(R.id.btnSrCall0)
        btnSrCallCustom = findViewById(R.id.btnSrCallCustom)
    }

    private fun setupListeners() {
        navTimer.onTap { showTab(0); refreshTimerUI(); ensureTickerIfNeeded() }
        navReport.onTap {
            DataStore.setReportPeriodType(this, ReportPeriodType.DAY)
            DataStore.setReportAnchorIso(this, DataStore.todayIso())
            showTab(1); ensureTickerIfNeeded(); loadReportTab()
        }
        navRoutine.onTap { showTab(2); ensureTickerIfNeeded(); renderRoutineTab(scrollToToday = true) }
        navSettings.onTap { showTab(3); ensureTickerIfNeeded(); renderSettingsTab() }

        btnTopTheme.onTap {
            val next = if (isNightActive()) "day" else "night"
            DataStore.setThemeMode(this, next)
            applySavedThemeMode()
            @Suppress("DEPRECATION")
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }

        btnManualStudy.onTap {
            sendServiceAction(FlipTrackerService.ACTION_MANUAL_STUDY)
            uiHandler.postDelayed({ refreshTimerUI() }, 150L)
        }

        btnManualWaste.onTap {
            val rt = DataStore.loadRuntimeState(this)
            if (rt.running && rt.mode == "WASTE") {
                sendServiceAction(FlipTrackerService.ACTION_MANUAL_WASTE)
                uiHandler.postDelayed({ refreshTimerUI() }, 150L)
            } else {
                val reasons = DataStore.getWasteReasonsList(this).toTypedArray()
                MaterialAlertDialogBuilder(this)
                    .setTitle("এখন কী করছো?")
                    .setItems(reasons) { _, which ->
                        DataStore.setSrLiveWasteReason(this, reasons[which])
                        sendServiceAction(FlipTrackerService.ACTION_MANUAL_WASTE)
                        uiHandler.postDelayed({ refreshTimerUI() }, 150L)
                    }
                    .setNegativeButton("অপচয় শুরু") { _, _ ->
                        DataStore.setSrLiveWasteReason(this, "অপচয় সময়")
                        sendServiceAction(FlipTrackerService.ACTION_MANUAL_WASTE)
                        uiHandler.postDelayed({ refreshTimerUI() }, 150L)
                    }
                    .show()
            }
        }

        btnTopAlarm.onTap {
            val next = when (DataStore.getAlarmMode(this)) {
                "vibrate" -> "sound"
                "sound" -> "silent"
                else -> "vibrate"
            }
            DataStore.setAlarmMode(this, next)
            refreshAlarmUI()
            renderSettingsTab()
        }

        examStripCard.onTap { showExamDialog() }
        rowEditExam.onTap { showExamDialog() }

        tvSubjectChip.onTap { showSubjectDialog() }

        btnPreset45.onTap { selectPreset(45) }
        btnPreset10.onTap { selectPreset(10) }
        btnPreset5.onTap { selectPreset(5) }
        btnPresetCustom.onTap { showCustomTimerDialog() }

        swFlipService.setOnCheckedChangeListener { _, isChecked ->
            if (updatingFlipSwitch) return@setOnCheckedChangeListener
            val action = if (isChecked) FlipTrackerService.ACTION_START else FlipTrackerService.ACTION_STOP
            if (isChecked) sendServiceAction(action)
            else startService(Intent(this, FlipTrackerService::class.java).setAction(action))
            refreshTimerUI()
            uiHandler.postDelayed({ refreshTimerUI() }, 200L)
        }

        swOnlineStudy.setOnCheckedChangeListener { _, isChecked ->
            if (updatingFlipSwitch) return@setOnCheckedChangeListener
            DataStore.setOnlineStudy(this, isChecked)
            if (DataStore.loadRuntimeState(this).running) {
                startService(Intent(this, FlipTrackerService::class.java).setAction(FlipTrackerService.ACTION_ONLINE_CHANGED))
            } else {
                SmartReminderManager.onStudyStateChanged(this)
            }
            refreshTimerUI()
            uiHandler.postDelayed({ refreshTimerUI() }, 200L)
        }

        cardWasteLive.onTap { showUnassignedClassifyDialog() }
        btnBannerEndBreak.onTap {
            val info = SmartReminderManager.getActiveBreakInfo(this)
            if (info?.type == SmartReminderManager.PHASE_EATING) SmartReminderManager.finishEatingNow(this)
            else if (info?.type == SmartReminderManager.PHASE_AWAY) SmartReminderManager.returnFromAway(this)
            refreshTimerUI()
        }

        // Report Tab
        btnRepDay.onTap { DataStore.setReportPeriodType(this, ReportPeriodType.DAY); loadReportTab() }
        btnRepWeek.onTap { DataStore.setReportPeriodType(this, ReportPeriodType.WEEK); loadReportTab() }
        btnRepMonth.onTap { DataStore.setReportPeriodType(this, ReportPeriodType.MONTH); loadReportTab() }
        btnRepYear.onTap { DataStore.setReportPeriodType(this, ReportPeriodType.YEAR); loadReportTab() }
        btnPrevPeriod.onTap { shiftReportPeriod(-1) }
        bannerBcsAlloc.onTap {
            val iso = lastReportData?.rangeStartIso ?: DataStore.todayIso()
            showBcsAllocateDialog(iso)
        }
        btnNextPeriod.onTap { if (canGoNextReportPeriod()) shiftReportPeriod(1) }
        tvPeriodTitle.onTap { showReportDatePicker() }
        btnReportToday.onTap {
            DataStore.setReportAnchorIso(this, DataStore.todayIso())
            loadReportTab()
        }
        reportBarChart.onBarClick = { barIdx ->
            val rep = lastReportData
            if (rep != null && (rep.type == ReportPeriodType.WEEK || rep.type == ReportPeriodType.MONTH)) {
                val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                val c = Calendar.getInstance().apply {
                    time = try { fmt.parse(rep.rangeStartIso) ?: Date() } catch (_: Exception) { Date() }
                    add(Calendar.DAY_OF_YEAR, barIdx)
                }
                val iso = fmt.format(c.time)
                if (iso <= DataStore.todayIso()) {
                    DataStore.setReportPeriodType(this, ReportPeriodType.DAY)
                    DataStore.setReportAnchorIso(this, iso)
                    loadReportTab()
                }
            }
        }
        btnReportMenu.onTap { showReportMenuSheet() }
        tabReport.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> fitBreakdownCard() }
        val innerScrollTouch = View.OnTouchListener { v, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN || ev.actionMasked == MotionEvent.ACTION_MOVE) {
                if (v.canScrollVertically(1) || v.canScrollVertically(-1)) {
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                }
            }
            false
        }
        scrollSubjectsCol.setOnTouchListener(innerScrollTouch)
        scrollOtherCol.setOnTouchListener(innerScrollTouch)



        btnOpenDashboard.onTap {
            startActivity(Intent(this, DashboardActivity::class.java))
        }

        // Routine Tab
        chkWordTarget.setOnCheckedChangeListener { _, checked ->
            DataStore.updateToday(this) { rec ->
                rec.wordTarget = checked
                rec.synced = false
            }
            renderRoutineTab()
        }

        // Settings Tab
        btnGoalMinus.onSettingsTap {
            DataStore.setDailyGoalHours(this, DataStore.getDailyGoalHours(this) - 1)
            renderSettingsTab()
            refreshTimerUI()
        }
        btnGoalPlus.onSettingsTap {
            DataStore.setDailyGoalHours(this, DataStore.getDailyGoalHours(this) + 1)
            renderSettingsTab()
            refreshTimerUI()
        }
        swGoalNotif.setOnCheckedChangeListener { _, checked ->
            if (updatingSrSwitches) return@setOnCheckedChangeListener
            guardSettingsSwitch(swGoalNotif, checked) { DataStore.setGoalNotifOn(this, checked) }
        }

        btnGrace0.onSettingsTap { DataStore.setGraceSec(this, 0); renderSettingsTab(); refreshTimerUI() }
        btnGrace3.onSettingsTap { DataStore.setGraceSec(this, 3); renderSettingsTab(); refreshTimerUI() }
        btnGrace5.onSettingsTap { DataStore.setGraceSec(this, 5); renderSettingsTab(); refreshTimerUI() }
        btnGrace10.onSettingsTap { DataStore.setGraceSec(this, 10); renderSettingsTab(); refreshTimerUI() }
        swHapticGlobal.setOnCheckedChangeListener { _, on ->
            if (updatingSrSwitches) return@setOnCheckedChangeListener
            guardSettingsSwitch(swHapticGlobal, on) { DataStore.setHapticGlobalOn(this, on); renderSettingsTab() }
        }
        swHapticFlip.setOnCheckedChangeListener { _, on ->
            if (updatingSrSwitches) return@setOnCheckedChangeListener
            guardSettingsSwitch(swHapticFlip, on) { DataStore.setHapticFlipOn(this, on) }
        }
        swHapticGoal.setOnCheckedChangeListener { _, on ->
            if (updatingSrSwitches) return@setOnCheckedChangeListener
            guardSettingsSwitch(swHapticGoal, on) { DataStore.setHapticGoalOn(this, on) }
        }
        btnHapticIntensity.onSettingsTap {
            val opts = arrayOf("খুব হালকা (প্রস্তাবিত)", "হালকা", "স্বাভাবিক", "বন্ধ")
            val vals = intArrayOf(1, 2, 3, 0)
            MaterialAlertDialogBuilder(this)
                .setTitle("হ্যাপটিক তীব্রতা")
                .setItems(opts) { _, w ->
                    DataStore.setHapticIntensity(this, vals[w])
                    renderSettingsTab()
                    HapticManager.timerStart(this)
                }
                .show()
        }
        btnGraceCustom.onSettingsTap {
            showCustomTimeDialog("ফ্লিপ গ্রেস টাইম (সেকেন্ড)", "সেকেন্ড লিখো (১–৬০)", 1, 60, DataStore.getGraceSec(this)) {
                DataStore.setGraceSec(this, it); renderSettingsTab(); refreshTimerUI()
            }
        }

        btnAlarmVib.onSettingsTap { DataStore.setAlarmMode(this, "vibrate"); refreshAlarmUI(); renderSettingsTab() }
        btnAlarmSound.onSettingsTap { DataStore.setAlarmMode(this, "sound"); refreshAlarmUI(); renderSettingsTab() }
        btnAlarmSilent.onSettingsTap { DataStore.setAlarmMode(this, "silent"); refreshAlarmUI(); renderSettingsTab() }

        btnThemeDay.onSettingsTap { DataStore.setThemeMode(this, "day"); applySavedThemeMode(); renderSettingsTab() }
        btnThemeNight.onSettingsTap { DataStore.setThemeMode(this, "night"); applySavedThemeMode(); renderSettingsTab() }
        btnThemeAuto.onSettingsTap { DataStore.setThemeMode(this, "auto"); applySavedThemeMode(); renderSettingsTab() }

        btnColor1.onSettingsTap { DataStore.setColorPalette(this, "sage"); applyColorPalette(); refreshTimerUI(); renderSettingsTab(); updateColorSwatchesOnly() }
        btnColor2.onSettingsTap { DataStore.setColorPalette(this, "ocean"); applyColorPalette(); refreshTimerUI(); renderSettingsTab(); updateColorSwatchesOnly() }
        btnColor3.onSettingsTap { DataStore.setColorPalette(this, "espresso"); applyColorPalette(); refreshTimerUI(); renderSettingsTab(); updateColorSwatchesOnly() }
        btnColor4.onSettingsTap { DataStore.setColorPalette(this, "nordic"); applyColorPalette(); refreshTimerUI(); renderSettingsTab(); updateColorSwatchesOnly() }
        btnColor5.onSettingsTap { DataStore.setColorPalette(this, "lavender"); applyColorPalette(); refreshTimerUI(); renderSettingsTab(); updateColorSwatchesOnly() }
        btnColor6.onSettingsTap { DataStore.setColorPalette(this, "forest"); applyColorPalette(); refreshTimerUI(); renderSettingsTab(); updateColorSwatchesOnly() }

        btnSettingsDrawer.onTap { openSettingsDrawer() }
        rowDayBoundarySetting.onSettingsTap {
            val curMin = DataStore.getDayStartMin(this)
            TimePickerDialog(this, { _, h, m ->
                val newMin = h * 60 + m
                DataStore.setDayStartMin(this, newMin)
                renderSettingsTab()
                refreshTimerUI()
                val lastOpenIso = DataStore.getLastOpenIso(this)
        if (lastOpenIso != DataStore.todayIso()) {
            DataStore.ensureDailySubjectReset(this)
            DataStore.setReportPeriodType(this, ReportPeriodType.DAY)
            DataStore.setReportAnchorIso(this, DataStore.todayIso())
            DataStore.setLastOpenIso(this, DataStore.todayIso())
        }
        if (currentTab == 1) loadReportTab()
                Snackbar.make(findViewById(android.R.id.content), "দিন বদলের সময়: ${DataStore.formatTime12hBn(newMin)}", Snackbar.LENGTH_SHORT).show()
            }, curMin / 60, curMin % 60, false).show()
        }
        cardSettingsBattery.onTap {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                Toast.makeText(this, "ফোনের Settings > Apps থেকে ব্যাটারি তথ্য দেখো", Toast.LENGTH_SHORT).show()
            }
        }
        pillSmartReminder.onSettingsTap {
            val notifBlocked = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            val overlayMissing = DataStore.isSrEnabled(this) && !SmartReminderPopupOverlay.canDrawOverlay(this)
            if (notifBlocked || overlayMissing) {
                fixMissingPermissionsFromBanner()
                return@onSettingsTap
            }
            val nextOn = !DataStore.isSrEnabled(this)
            setSmartReminderEnabled(nextOn, askPerm = true)
            Snackbar.make(
                findViewById(android.R.id.content),
                if (nextOn) "স্মার্ট রিমাইন্ডার চালু হলো" else "স্মার্ট রিমাইন্ডার বন্ধ হলো",
                Snackbar.LENGTH_LONG
            ).setAction("পূর্বাবস্থা") {
                setSmartReminderEnabled(!nextOn, askPerm = false)
            }.show()
        }
        settingsDrawerScrim.onTap { closeSettingsDrawer() }
        rowMainSyncStatus.onTap { openSettingsPage(4) }
        findViewById<View>(R.id.btnBackFlip).onTap { closeSettingsPage() }
        findViewById<View>(R.id.btnBackReminder).onTap { closeSettingsPage() }
        findViewById<View>(R.id.btnBackMascot).onTap { closeSettingsPage() }
        findViewById<View>(R.id.btnBackQuiet).onTap { closeSettingsPage() }
        findViewById<View>(R.id.btnBackData).onTap { closeSettingsPage() }
        findViewById<View>(R.id.btnBackAbout).onTap { closeSettingsPage() }
        findViewById<View>(R.id.btnBackProfile).onTap { closeSettingsPage() }
        findViewById<View>(R.id.btnBackGap).onTap { closeSettingsPage() }
        swGapAppSheet.setOnCheckedChangeListener { _, on -> if (!updatingSrSwitches) guardSettingsSwitch(swGapAppSheet, on) { DataStore.setGapAppSheetOn(this, on) } }
        swGapPhonePopup.setOnCheckedChangeListener { _, on -> if (!updatingSrSwitches) guardSettingsSwitch(swGapPhonePopup, on) { DataStore.setGapPhonePopupOn(this, on) } }
        swGapNightNotif.setOnCheckedChangeListener { _, on -> if (!updatingSrSwitches) guardSettingsSwitch(swGapNightNotif, on) { DataStore.setGapNightNotifOn(this, on) } }
        swGapAutoSleep.setOnCheckedChangeListener { _, on -> if (!updatingSrSwitches) guardSettingsSwitch(swGapAutoSleep, on) { DataStore.setGapAutoSleepOn(this, on) } }
        cardProfileCorner.onTap { openSettingsPage(6) }
        btnProfNickname.onSettingsTap { editProfileText("ডাকনাম", DataStore.getProfNickname(this)) { DataStore.setProfNickname(this, it); renderProfileUi() } }
        btnProfDob.onSettingsTap { pickProfileDob() }
        btnProfGender.onSettingsTap { pickProfileChoice("লিঙ্গ", arrayOf("পুরুষ", "নারী", "উল্লেখ নয়")) { DataStore.setProfGender(this, it); renderProfileUi() } }
        btnProfStatus.onSettingsTap { pickProfileChoice("বর্তমান অবস্থা", arrayOf("ছাত্র", "চাকরিজীবী", "প্রস্তুতি নিচ্ছি")) { DataStore.setProfStatus(this, it); renderProfileUi() } }
        btnProfCadre.onSettingsTap { editProfileText("লক্ষ্য পদ / ক্যাডার", DataStore.getProfCadre(this)) { DataStore.setProfCadre(this, it); renderProfileUi() } }
        btnProfTargetYear.onSettingsTap { editProfileText("টার্গেট সাল", DataStore.getProfTargetYear(this)) { DataStore.setProfTargetYear(this, it); renderProfileUi() } }
        btnProfMaxAge.onSettingsTap { pickProfileMaxAge() }

        swSrSeriousMode.setOnCheckedChangeListener { _, checked ->
            if (updatingSrSwitches) return@setOnCheckedChangeListener
            if (!settingsUnlockedInSession) { guardSettingsSwitch(swSrSeriousMode, checked, retrigger = true); return@setOnCheckedChangeListener }
            if (checked) {
                updatingSrSwitches = true
                swSrSeriousMode.isChecked = false
                updatingSrSwitches = false
                MaterialAlertDialogBuilder(this)
                    .setTitle("সিরিয়াস মোড চালু করবে?")
                    .setMessage("দিনে ২+ বার চরম পর্যায়ে ফোন চালালে কড়া শ্লেষ ও জেনারেল স্ল্যাং ব্যবহার করবে। নোটিফিকেশন থেকে যেকোনো সময় বন্ধ করা যাবে।")
                    .setPositiveButton("চালু করো") { _, _ ->
                        DataStore.setSrSeriousMode(this, true)
                        renderSettingsTab()
                    }
                    .setNegativeButton("বাতিল", null)
                    .show()
            } else {
                DataStore.setSrSeriousMode(this, false)
                renderSettingsTab()
            }
        }
        findViewById<View>(R.id.drwItemFlip).onTap { closeSettingsDrawer(); openSettingsPage(0) }
        findViewById<View>(R.id.drwItemReminder).onTap { closeSettingsDrawer(); openSettingsPage(1) }
        findViewById<View>(R.id.drwItemMascot).onTap { closeSettingsDrawer(); openSettingsPage(2) }
        findViewById<View>(R.id.drwItemQuiet).onTap { closeSettingsDrawer(); openSettingsPage(3) }
        findViewById<View>(R.id.drwItemData).onTap { closeSettingsDrawer(); openSettingsPage(4) }
        findViewById<View>(R.id.drwItemAbout).onTap { closeSettingsDrawer(); openSettingsPage(5) }
        btnSrTestHour.onTap { showTestHourDialog() }
        reportDay24Bar.onUnknownTap = { maybeShowGapBottomSheet(force = true) }
        btnSrSeriousAfterMin.onSettingsTap {
            val opts = arrayOf("১৫ মিনিট পর", "৩০ মিনিট পর (ডিফল্ট)", "৪৫ মিনিট পর", "৬০ মিনিট পর", "বন্ধ (শুধু লেভেল ৪–৫)", "কাস্টম মিনিট...")
            val vals = intArrayOf(15, 30, 45, 60, 0, -1)
            MaterialAlertDialogBuilder(this)
                .setTitle("কত মিনিট ফোন চালালে সব সিরিয়াস মেসেজ?")
                .setItems(opts) { _, w ->
                    val v = vals[w]
                    if (v >= 0) {
                        DataStore.setSrSeriousAfterMin(this, v)
                        renderSettingsTab()
                    } else {
                        val et = EditText(this).apply {
                            inputType = InputType.TYPE_CLASS_NUMBER
                            hint = "যেমন: ২০ (০ = বন্ধ)"
                            setText(DataStore.getSrSeriousAfterMin(this@MainActivity).toString())
                        }
                        MaterialAlertDialogBuilder(this)
                            .setTitle("ফোন সময়ের সীমা (মিনিট)")
                            .setView(et)
                            .setPositiveButton("সেভ") { _, _ ->
                                val parsed = et.text.toString().trim().toIntOrNull()?.coerceIn(0, 360) ?: 30
                                DataStore.setSrSeriousAfterMin(this, parsed)
                                renderSettingsTab()
                            }
                            .setNegativeButton("বাতিল", null)
                            .show()
                    }
                }
                .show()
        }
        btnSrSeriousMaxHr.onSettingsTap {
            val opts = arrayOf("ঘণ্টায় সর্বোচ্চ ২ বার", "ঘণ্টায় সর্বোচ্চ ৪ বার (ডিফল্ট)", "ঘণ্টায় সর্বোচ্চ ৬ বার", "ঘণ্টায় সর্বোচ্চ ১০ বার", "সীমাহীন (কোনো সীমা নেই)", "কাস্টম সংখ্যা...")
            val vals = intArrayOf(2, 4, 6, 10, 0, -1)
            MaterialAlertDialogBuilder(this)
                .setTitle("ঘণ্টায় সর্বোচ্চ কতবার সিরিয়াস মেসেজ?")
                .setItems(opts) { _, w ->
                    val v = vals[w]
                    if (v >= 0) {
                        DataStore.setSrSeriousMaxPerHour(this, v)
                        renderSettingsTab()
                    } else {
                        val et = EditText(this).apply {
                            inputType = InputType.TYPE_CLASS_NUMBER
                            hint = "যেমন: ৫ (০ = সীমাহীন)"
                            setText(DataStore.getSrSeriousMaxPerHour(this@MainActivity).toString())
                        }
                        MaterialAlertDialogBuilder(this)
                            .setTitle("ঘণ্টায় সর্বোচ্চ সংখ্যা")
                            .setView(et)
                            .setPositiveButton("সেভ") { _, _ ->
                                val parsed = et.text.toString().trim().toIntOrNull()?.coerceIn(0, 30) ?: 4
                                DataStore.setSrSeriousMaxPerHour(this, parsed)
                                renderSettingsTab()
                            }
                            .setNegativeButton("বাতিল", null)
                            .show()
                    }
                }
                .show()
        }
        btnSrGapPhoneMin.onSettingsTap {
            val opts = arrayOf("৩ মিনিট পর", "৫ মিনিট পর (ডিফল্ট)", "১০ মিনিট পর")
            val vals = intArrayOf(3, 5, 10)
            MaterialAlertDialogBuilder(this)
                .setTitle("অজানা গ্যাপ পপআপ (ফোন বসার সীমা)")
                .setItems(opts) { _, w ->
                    DataStore.setGapPhoneMin(this, vals[w])
                    renderSettingsTab()
                }
                .show()
        }
        btnManageWasteReasons.onSettingsTap { showManageWasteReasonsDialog() }
        btnWasteBudget.onSettingsTap { showWasteBudgetDialog() }

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 != null && (e2.x - e1.x) > dp(45)) { closeSettingsDrawer(); return true }
                return false
            }
        })
        settingsDrawerPanel.setOnTouchListener { _, ev -> gd.onTouchEvent(ev); true }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    activeAnchoredMenu?.isShowing == true -> activeAnchoredMenu?.dismiss()
                    settingsDrawerOverlay.visibility == View.VISIBLE -> closeSettingsDrawer()
                    currentTab == 3 && settingsPage >= 0 -> closeSettingsPage()
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                        isEnabled = true
                    }
                }
            }
        })
        btnFixMissingPerms.onTap { fixMissingPermissionsFromBanner() }

        btnToggleSyncKeyVis1.onTap {
            syncKeyVis1 = !syncKeyVis1
            etSyncKey.inputType = if (syncKeyVis1)
                (InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)
            else
                (InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
            etSyncKey.setSelection(etSyncKey.text?.length ?: 0)
        }
        btnToggleSyncKeyVis2.onTap {
            syncKeyVis2 = !syncKeyVis2
            etSyncKeyConfirm.inputType = if (syncKeyVis2)
                (InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)
            else
                (InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
            etSyncKeyConfirm.setSelection(etSyncKeyConfirm.text?.length ?: 0)
        }

        btnUnlockSyncEditor.onSettingsTap { promptUnlockSyncEditor() }

        btnTestSync.onTap {
            val url = etGasUrl.text.toString().trim()
            val p1 = etSyncKey.text.toString().trim()
            val p2 = etSyncKeyConfirm.text.toString().trim()
            if (p1 != p2) {
                Snackbar.make(findViewById(android.R.id.content), "দুটি সিঙ্ক পাসওয়ার্ড মেলেনি!", Snackbar.LENGTH_LONG).show()
                return@onTap
            }
            btnTestSync.isEnabled = false
            btnTestSync.text = "টেস্ট হচ্ছে..."
            val appCtx = applicationContext
            thread {
                val (ok, msg) = DataStore.testSyncConnection(appCtx, url, p1)
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    btnTestSync.isEnabled = true
                    btnTestSync.text = "টেস্ট কানেকশন"
                    Snackbar.make(findViewById(android.R.id.content), msg, Snackbar.LENGTH_LONG).show()
                }
            }
        }

        btnSaveSettings.onSettingsTap {
            val url = etGasUrl.text.toString().trim()
            val p1 = etSyncKey.text.toString().trim()
            val p2 = etSyncKeyConfirm.text.toString().trim()
            if (p1 != p2) {
                Snackbar.make(findViewById(android.R.id.content), "দুটি সিঙ্ক পাসওয়ার্ড মেলেনি! আবার মিলিয়ে লিখো।", Snackbar.LENGTH_LONG).show()
                return@onSettingsTap
            }
            if (!DataStore.isSyncUrlValid(url)) {
                Snackbar.make(findViewById(android.R.id.content), "সঠিক Apps Script লিংক দাও (https://... এবং /exec দিয়ে শেষ)", Snackbar.LENGTH_LONG).show()
                return@onSettingsTap
            }
            btnSaveSettings.isEnabled = false
            btnSaveSettings.text = "যাচাই হচ্ছে..."
            val appCtx = applicationContext
            thread {
                val (ok, msg) = DataStore.testSyncConnection(appCtx, url, p1)
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    btnSaveSettings.isEnabled = true
                    btnSaveSettings.text = "যাচাই ও সেভ"
                    if (!ok) {
                        Snackbar.make(findViewById(android.R.id.content), "সেভ হয়নি: $msg", Snackbar.LENGTH_LONG).show()
                        return@runOnUiThread
                    }
                    val oldUrl = DataStore.getGasUrl(this)
                    if (oldUrl.isNotEmpty() && oldUrl != url) {
                        MaterialAlertDialogBuilder(this)
                            .setTitle("ড্রাইভ লিংক বদলেছে")
                            .setMessage("পুরোনো সব দিন কি নতুন ড্রাইভ শিটে আবার পাঠাবে, এবং পুরোনো ড্রাইভ ক্যাশ মুছে ফেলবে?")
                            .setPositiveButton("হ্যাঁ, সব পাঠাও") { _, _ ->
                                DataStore.resetSyncStateForNewUrl(this, resendAllDays = true, clearDriveCache = true)
                                completeSyncSettingsSave(url, p1)
                            }
                            .setNegativeButton("না, শুধু নতুনগুলো") { _, _ ->
                                DataStore.resetSyncStateForNewUrl(this, resendAllDays = false, clearDriveCache = true)
                                completeSyncSettingsSave(url, p1)
                            }
                            .show()
                    } else {
                        completeSyncSettingsSave(url, p1)
                    }
                }
            }
        }

        btnWeekStartSun.onSettingsTap { DataStore.setWeekStartDay(this, Calendar.SUNDAY); renderSettingsTab() }
        btnWeekStartSat.onSettingsTap { DataStore.setWeekStartDay(this, Calendar.SATURDAY); renderSettingsTab() }

        swDashCellAlways.setOnCheckedChangeListener { _, checked ->
            if (updatingSrSwitches) return@setOnCheckedChangeListener
            guardSettingsSwitch(swDashCellAlways, checked) { DataStore.setSrDashCellAlways(this, checked) }
        }

        btnExportJson.onTap {
            shareExportedFile(DataStore.exportJsonToFile(this), "application/json", "JSON ব্যাকআপ শেয়ার / সেভ করো")
        }

        // Smart Reminder Settings
        swSrEnabled.setOnCheckedChangeListener { _, checked ->
            if (updatingSrSwitches) return@setOnCheckedChangeListener
            if (!settingsUnlockedInSession) { guardSettingsSwitch(swSrEnabled, checked, retrigger = true); return@setOnCheckedChangeListener }
            setSmartReminderEnabled(checked, askPerm = true)
        }

        btnSrNotifPerm.onTap {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                    putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                }
                try { startActivity(i) } catch (_: Exception) {}
            }
        }

        btnSrOverlayPerm.onTap {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                try {
                    startActivity(i)
                } catch (_: Exception) {
                    Toast.makeText(this, "ফোনের সেটিংস থেকে Display over other apps চালু করো", Toast.LENGTH_LONG).show()
                }
            } else {
                val next = !DataStore.isSrPopupOverlayOn(this)
                DataStore.setSrPopupOverlayOn(this, next)
                renderSettingsTab()
            }
        }

        btnSrMascotAuto.onSettingsTap { DataStore.setSrMascotStyle(this, "auto"); renderSettingsTab() }
        btnSrMascotDragon.onSettingsTap { DataStore.setSrMascotStyle(this, "dragon"); renderSettingsTab() }
        btnSrMascotGhost.onSettingsTap { DataStore.setSrMascotStyle(this, "ghost"); renderSettingsTab() }

        btnSrResetTimer.onSettingsTap {
            val now = System.currentTimeMillis()
            if (now > srResetPendingUntilMs) {
                srResetPendingUntilMs = now + 3000L
                btnSrResetTimer.text = "নিশ্চিত করতে আরেকবার চাপো"
                uiHandler.postDelayed({
                    if (!isFinishing && !isDestroyed && System.currentTimeMillis() > srResetPendingUntilMs) {
                        btnSrResetTimer.text = "স্ক্রিনটাইম ও রিমাইন্ডার রিসেট করো"
                    }
                }, 3100L)
                return@onSettingsTap
            }
            srResetPendingUntilMs = 0L
            btnSrResetTimer.text = "স্ক্রিনটাইম ও রিমাইন্ডার রিসেট করো"
            SmartReminderManager.resetPhoneUseAndReminderNow(this)
            refreshTimerUI()
            Toast.makeText(this, "স্ক্রিনটাইম ও রিমাইন্ডার রিসেট হয়েছে—অ্যাপ থেকে বেরোলেই নতুন করে গুনবে!", Toast.LENGTH_LONG).show()
        }

        btnSrPopupStyle.onSettingsTap {
            val keys = arrayOf("default", "compact", "standard", "focus")
            val labels = arrayOf(
                "বর্তমান (ডিফল্ট)",
                "Compact (ছোট পিল)",
                "Standard (মাঝারি কার্ড)",
                "Focus (বড় স্পষ্ট কার্ড)"
            )
            val curIdx = keys.indexOf(DataStore.getSrPopupStyle(this)).coerceAtLeast(0)
            MaterialAlertDialogBuilder(this)
                .setTitle("পপ-আপ মোড বাছাই করো")
                .setSingleChoiceItems(labels, curIdx) { dlg, which ->
                    DataStore.setSrPopupStyle(this, keys[which])
                    renderSettingsTab()
                    dlg.dismiss()
                }
                .setNegativeButton("বাতিল", null)
                .show()
        }
        btnSrPreviewPopup.onTap {
            val lvl = srPreviewLevel
            srPreviewLevel = if (srPreviewLevel >= 5) 1 else srPreviewLevel + 1
            val kind = if (lvl == 1) MascotContent.KIND_ASK else MascotContent.KIND_ANGRY
            if (SmartReminderPopupOverlay.canDrawOverlay(this)) {
                SmartReminderPopupOverlay.show(this, kind, lvl, elapsedMin = lvl * 5, msgIndex = lvl, isPreview = true)
            } else {
                showAnimatedMascotDialog(lvl, kind, elapsedMin = lvl * 5)
                Toast.makeText(this, "অন্য অ্যাপের ওপর পপ-আপ পেতে ওভারলে অনুমতি দাও", Toast.LENGTH_LONG).show()
            }
        }

        fun updateSr(block: () -> Unit) {
            block()
            SmartReminderManager.onSettingsChanged(this)
            renderSettingsTab()
        }

        btnSrAsk1.onSettingsTap { updateSr { DataStore.setSrAskDelayMin(this, 1) } }
        btnSrAsk2.onSettingsTap { updateSr { DataStore.setSrAskDelayMin(this, 2) } }
        btnSrAsk3.onSettingsTap { updateSr { DataStore.setSrAskDelayMin(this, 3) } }
        btnSrAskCustom.onSettingsTap {
            showCustomTimeDialog("প্রথম প্রশ্ন আসার সময় (মিনিট)", "মিনিট লিখো (১–৬০)", 1, 60, DataStore.getSrAskDelayMin(this)) {
                updateSr { DataStore.setSrAskDelayMin(this, it) }
            }
        }

        btnSrRep3.onSettingsTap { updateSr { DataStore.setSrRepeatMin(this, 3) } }
        btnSrRep5.onSettingsTap { updateSr { DataStore.setSrRepeatMin(this, 5) } }
        btnSrRep10.onSettingsTap { updateSr { DataStore.setSrRepeatMin(this, 10) } }
        btnSrRepCustom.onSettingsTap {
            showCustomTimeDialog("রাগান্বিত পপ-আপ ব্যবধান (মিনিট)", "মিনিট লিখো (১–৬০)", 1, 60, DataStore.getSrRepeatMin(this)) {
                updateSr { DataStore.setSrRepeatMin(this, it) }
            }
        }

        btnSrRecheck10.onSettingsTap { updateSr { DataStore.setSrReadRecheckMin(this, 10) } }
        btnSrRecheck15.onSettingsTap { updateSr { DataStore.setSrReadRecheckMin(this, 15) } }
        btnSrRecheck30.onSettingsTap { updateSr { DataStore.setSrReadRecheckMin(this, 30) } }
        btnSrRecheckCustom.onSettingsTap {
            showCustomTimeDialog("'এখনো পড়ছো?' ব্যবধান (মিনিট)", "মিনিট লিখো (১–১২০)", 1, 120, DataStore.getSrReadRecheckMin(this)) {
                updateSr { DataStore.setSrReadRecheckMin(this, it) }
            }
        }

        btnSrReset1.onSettingsTap { updateSr { DataStore.setSrReadResetMin(this, 1) } }
        btnSrReset3.onSettingsTap { updateSr { DataStore.setSrReadResetMin(this, 3) } }
        btnSrReset5.onSettingsTap { updateSr { DataStore.setSrReadResetMin(this, 5) } }
        btnSrResetCustom.onSettingsTap {
            showCustomTimeDialog("ডিসপ্লে বন্ধ রিসেট সময় (মিনিট)", "মিনিট লিখো (১–১২০)", 1, 120, DataStore.getSrReadResetMin(this)) {
                updateSr { DataStore.setSrReadResetMin(this, it) }
            }
        }

        btnSrIdle30.onSettingsTap { updateSr { DataStore.setSrIdleMin(this, 30) } }
        btnSrIdle45.onSettingsTap { updateSr { DataStore.setSrIdleMin(this, 45) } }
        btnSrIdle60.onSettingsTap { updateSr { DataStore.setSrIdleMin(this, 60) } }
        btnSrIdle0.onSettingsTap { updateSr { DataStore.setSrIdleMin(this, 0) } }
        btnSrIdleCustom.onSettingsTap {
            showCustomTimeDialog("ডিসপ্লে বন্ধ (Idle) রিমাইন্ডার (মিনিট)", "মিনিট লিখো (৫–২৪০)", 5, 240, DataStore.getSrIdleMin(this).coerceAtLeast(10)) {
                updateSr { DataStore.setSrIdleMin(this, it) }
            }
        }

        btnSrFb10.onSettingsTap { updateSr { DataStore.setSrFallbackDelaySec(this, 10) } }
        btnSrFb20.onSettingsTap { updateSr { DataStore.setSrFallbackDelaySec(this, 20) } }
        btnSrFb30.onSettingsTap { updateSr { DataStore.setSrFallbackDelaySec(this, 30) } }
        btnSrFbCustom.onSettingsTap {
            showCustomTimeDialog("পপ-আপ ইগনোর ফলো-আপ (সেকেন্ড)", "সেকেন্ড লিখো (৫–১২০)", 5, 120, DataStore.getSrFallbackDelaySec(this)) {
                updateSr { DataStore.setSrFallbackDelaySec(this, it) }
            }
        }

        btnSrEat20.onSettingsTap { updateSr { DataStore.setSrEatMin(this, 20) } }
        btnSrEat30.onSettingsTap { updateSr { DataStore.setSrEatMin(this, 30) } }
        btnSrEat45.onSettingsTap { updateSr { DataStore.setSrEatMin(this, 45) } }
        btnSrEatCustom.onSettingsTap {
            showCustomTimeDialog("'খাচ্ছি' বিরতির সময় (মিনিট)", "মিনিট লিখো (১০–১৮০)", 10, 180, DataStore.getSrEatMin(this)) {
                updateSr { DataStore.setSrEatMin(this, it) }
            }
        }

        btnSrStrict20.onSettingsTap { updateSr { DataStore.setSrStrictAfterMin(this, 20) } }
        btnSrStrict30.onSettingsTap { updateSr { DataStore.setSrStrictAfterMin(this, 30) } }
        btnSrStrict45.onSettingsTap { updateSr { DataStore.setSrStrictAfterMin(this, 45) } }
        btnSrStrict0.onSettingsTap { updateSr { DataStore.setSrStrictAfterMin(this, 0) } }
        btnSrStrictCustom.onSettingsTap {
            showCustomTimeDialog("স্ট্রিক্ট মোড শুরু (মিনিট)", "মিনিট লিখো (৫–১৮০)", 5, 180, DataStore.getSrStrictAfterMin(this).coerceAtLeast(10)) {
                updateSr { DataStore.setSrStrictAfterMin(this, it) }
            }
        }

        btnSrCall5.onSettingsTap { updateSr { DataStore.setSrCallVibMin(this, 5) } }
        btnSrCall10.onSettingsTap { updateSr { DataStore.setSrCallVibMin(this, 10) } }
        btnSrCall15.onSettingsTap { updateSr { DataStore.setSrCallVibMin(this, 15) } }
        btnSrCall0.onSettingsTap { updateSr { DataStore.setSrCallVibMin(this, 0) } }
        btnSrCallCustom.onSettingsTap {
            showCustomTimeDialog("কলে থাকলে ৩বার ভাইব্রেট (মিনিট)", "মিনিট লিখো (১–৬০)", 1, 60, DataStore.getSrCallVibMin(this).coerceAtLeast(5)) {
                updateSr { DataStore.setSrCallVibMin(this, it) }
            }
        }

        swSrQuiet.setOnCheckedChangeListener { _, checked ->
            if (updatingSrSwitches) return@setOnCheckedChangeListener
            if (!settingsUnlockedInSession) { guardSettingsSwitch(swSrQuiet, checked, retrigger = true); return@setOnCheckedChangeListener }
            updateSr { DataStore.setSrQuietOn(this, checked) }
        }

        btnSrQuietStart.onSettingsTap {
            val cur = DataStore.getSrQuietStartMin(this)
            TimePickerDialog(this, { _, h, m ->
                updateSr { DataStore.setSrQuietStartMin(this, h * 60 + m) }
            }, cur / 60, cur % 60, true).show()
        }
        btnSrQuietEnd.onSettingsTap {
            val cur = DataStore.getSrQuietEndMin(this)
            TimePickerDialog(this, { _, h, m ->
                updateSr { DataStore.setSrQuietEndMin(this, h * 60 + m) }
            }, cur / 60, cur % 60, true).show()
        }
    }

    // ------------------------------------------------------------------ dialogs / actions

    private fun selectPreset(min: Int) {
        DataStore.setPresetMin(this, min)
        val rt = DataStore.loadRuntimeState(this)
        if (rt.running) {
            startService(Intent(this, FlipTrackerService::class.java).setAction(FlipTrackerService.ACTION_RESET_TIMER))
        } else {
            DataStore.saveRuntimeState(this, rt.copy(remainingSec = min * 60))
        }
        refreshPresetPills()
        refreshTimerUI()
    }

    private fun showCustomTimerDialog() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "মিনিট লিখো (যেমন: ২৫ বা ৬০)"
            setPadding(dp(20), dp(14), dp(20), dp(14))
        }
        val wrap = LinearLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("কাস্টম টাইমার সেট করো")
            .setView(wrap)
            .setPositiveButton("সেট করো") { _, _ ->
                val m = input.text.toString().toIntOrNull()
                if (m != null && m in 1..240) {
                    selectPreset(m)
                } else {
                    Toast.makeText(this, "১ থেকে ২৪০ মিনিটের মধ্যে সংখ্যা দাও", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun showCustomTimeDialog(title: String, hintText: String, minVal: Int, maxVal: Int, currentVal: Int, onSave: (Int) -> Unit) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = hintText
            if (currentVal in minVal..maxVal) setText(currentVal.toString())
            setPadding(dp(20), dp(14), dp(20), dp(14))
        }
        val wrap = LinearLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setView(wrap)
            .setPositiveButton("সেট করো") { _, _ ->
                val v = input.text.toString().toIntOrNull()
                if (v != null && v in minVal..maxVal) {
                    onSave(v)
                } else {
                    Toast.makeText(this, "${DataStore.toBnDigits(minVal)} থেকে ${DataStore.toBnDigits(maxVal)}-এর মধ্যে সংখ্যা দাও", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun showSubjectDialog() {
        val presets = (DataStore.getSubjectList() + "নিজে লিখো...").toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("বিষয় নির্বাচন করো")
            .setItems(presets) { _, idx ->
                if (idx == presets.lastIndex) {
                    val input = EditText(this).apply {
                        setText(DataStore.getCurrentSubject(this@MainActivity))
                        setPadding(dp(20), dp(14), dp(20), dp(14))
                    }
                    val wrap = LinearLayout(this).apply {
                        setPadding(dp(20), dp(8), dp(20), 0)
                        addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                    }
                    MaterialAlertDialogBuilder(this)
                        .setTitle("বিষয়ের নাম লেখো")
                        .setView(wrap)
                        .setPositiveButton("সেভ") { _, _ ->
                            DataStore.setCurrentSubject(this, input.text.toString())
                            refreshTimerUI()
                        }
                        .setNegativeButton("বাতিল", null)
                        .show()
                } else {
                    DataStore.setCurrentSubject(this, presets[idx])
                    refreshTimerUI()
                }
            }
            .show()
    }

    private fun showExamDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val etName = EditText(this).apply {
            hint = "পরীক্ষার নাম (যেমন: BCS প্রিলি)"
            setText(DataStore.getExamName(this@MainActivity))
        }
        val etDate = EditText(this).apply {
            hint = "তারিখ (YYYY-MM-DD, যেমন: 2027-02-26)"
            setText(DataStore.getExamDateIso(this@MainActivity))
        }
        var pickedTimeMin = DataStore.getExamTimeMin(this)
        val btnExamTime = TextView(this).apply {
            text = "পরীক্ষার সময়: ${DataStore.formatTime12hBn(pickedTimeMin)} (বদলাতে ট্যাপ করো)"
            textSize = 13f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(pal().accent)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = ThemePalette.makeBg(this@MainActivity, softOf(pal()), pal().cardBorder, 12f, 1f)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) }
            setOnClickListener {
                TimePickerDialog(this@MainActivity, { _, h, m ->
                    pickedTimeMin = h * 60 + m
                    text = "পরীক্ষার সময়: ${DataStore.formatTime12hBn(pickedTimeMin)} (বদলাতে ট্যাপ করো)"
                }, pickedTimeMin / 60, pickedTimeMin % 60, false).show()
            }
        }
        box.addView(etName)
        box.addView(etDate)
        box.addView(btnExamTime)
        MaterialAlertDialogBuilder(this)
            .setTitle("পরীক্ষা কাউন্টডাউন সেট করো")
            .setView(box)
            .setPositiveButton("সেভ") { _, _ ->
                DataStore.setExamName(this, etName.text.toString())
                DataStore.setExamTimeMin(this, pickedTimeMin)
                val d = etDate.text.toString().trim()
                if (DataStore.isValidIsoDate(d)) {
                    DataStore.setExamDateIso(this, d)
                } else {
                    Toast.makeText(this, "তারিখ ঠিক নয়! YYYY-MM-DD ফরম্যাটে দাও (যেমন 2027-02-26)", Toast.LENGTH_LONG).show()
                }
                refreshTimerUI()
                renderSettingsTab()
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    /** কারণ ট্যাগ: যে অপচয় সময় এখনো ট্যাগ করা হয়নি তা থেকে সর্বোচ্চ ১৫ মিনিট বেছে নেওয়া কারণে সরানো হয়। মোট অপচয় আর বাড়ে না। */
    private fun showWasteReasonDialog(splitMaxSec: Long = Long.MAX_VALUE) {
        showUnassignedClassifyDialog()
    }

    private fun showManageWasteReasonsDialog() {
        val current = DataStore.getWasteReasonsList(this).toMutableList()
        val items = current.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("অপচয়ের কারণ (${DataStore.toBnDigits(current.size)}/৮)")
            .setItems(items) { _, which ->
                if (current.size > 1) {
                    MaterialAlertDialogBuilder(this)
                        .setTitle("'${current[which]}' মুছে ফেলবে?")
                        .setPositiveButton("মুছো") { _, _ ->
                            current.removeAt(which)
                            DataStore.saveWasteReasonsList(this, current)
                            Snackbar.make(findViewById(android.R.id.content), "কারণ মুছে ফেলা হয়েছে", Snackbar.LENGTH_SHORT).show()
                        }
                        .setNegativeButton("না", null)
                        .show()
                }
            }
            .setPositiveButton("নতুন যোগ করো") { _, _ ->
                if (current.size >= 8) {
                    Snackbar.make(findViewById(android.R.id.content), "সর্বোচ্চ ৮টি কারণ রাখা যায়", Snackbar.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val et = EditText(this).apply { hint = "কারণের নাম লিখো"; setPadding(dp(16), dp(12), dp(16), dp(12)) }
                MaterialAlertDialogBuilder(this)
                    .setTitle("নতুন অপচয়ের কারণ")
                    .setView(et)
                    .setPositiveButton("যোগ করো") { _, _ ->
                        val txt = et.text.toString().trim()
                        if (txt.isNotEmpty()) {
                            current.add(txt)
                            DataStore.saveWasteReasonsList(this, current)
                            Snackbar.make(findViewById(android.R.id.content), "'$txt' যোগ হয়েছে", Snackbar.LENGTH_SHORT).show()
                        }
                    }
                    .setNegativeButton("বাতিল", null)
                    .show()
            }
            .setNeutralButton("ডিফল্ট") { _, _ ->
                DataStore.saveWasteReasonsList(this, ReasonCatalog.DEFAULT_WASTE_REASONS)
                Snackbar.make(findViewById(android.R.id.content), "ডিফল্ট তালিকা ফিরেছে", Snackbar.LENGTH_SHORT).show()
            }
            .setNegativeButton("বন্ধ", null)
            .show()
    }


    private fun showUnassignedClassifyDialog() {
        val target = DataStore.getLatestReclassifiableUnassigned(this)
        val pendGap = DataStore.getUnansweredGaps(this).firstOrNull()
        if (target == null) {
            if (pendGap != null) {
                maybeShowGapBottomSheet(force = true)
            } else {
                Snackbar.make(findViewById(android.R.id.content), "কোনো অনির্ধারিত সময় বাকি নেই!", Snackbar.LENGTH_SHORT).show()
            }
            return
        }
        val (targetIso, unSec) = target
        val dayPrefix = if (targetIso == DataStore.todayIso()) "আজকের" else "${DataStore.formatFullDateBn(targetIso)}-এর"
        val p = pal()
        val muted = ContextCompat.getColor(this, R.color.text_muted)
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(10))
        }
        wrap.addView(TextView(this).apply {
            text = "$dayPrefix অনির্ধারিত সময়: ${DataStore.formatHoursMinBn(unSec)}"
            textSize = 14f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(p.accent)
        })
        wrap.addView(TextView(this).apply {
            text = "এই সময়টা আসলে কী করছিলে? নিচের যেকোনো ক্যাটাগরিতে সরিয়ে নাও:"
            textSize = 12f
            setTextColor(muted)
            setPadding(0, dp(4), 0, dp(10))
        })
        val etNote = EditText(this).apply {
            hint = "ঐচ্ছিক কারণ বা বিষয়ের নাম"
            background = ThemePalette.makeBg(this@MainActivity, softOf(p), p.cardBorder, 12f, 1f)
            setTextColor(textColorMain(p))
            setHintTextColor(muted)
            textSize = 13f
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        wrap.addView(etNote, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) })

        val dlg = MaterialAlertDialogBuilder(this)
            .setTitle("অনির্ধারিত সময় নির্ধারণ করো")
            .setView(wrap)
            .setNegativeButton("বন্ধ", null)
            .create()

        val cats = listOf(
            Triple("অপচয়", "WASTE", CategoryColors.WASTE_INT),
            Triple("বাইরে", "AWAY", CategoryColors.AWAY_INT),
            Triple("দৈনন্দিন কাজ", "OTHER", CategoryColors.OTHER_INT),
            Triple("খাওয়া", "EAT", CategoryColors.EAT_INT),
            Triple("ঘুম", "SLEEP", CategoryColors.SLEEP_INT),
            Triple("পড়েছি", "STUDY", p.accent)
        )
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        cats.forEachIndexed { i, (label, code, col) ->
            val chip = TextView(this).apply {
                text = label
                textSize = 12.5f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(textColorMain(p))
                background = ThemePalette.makeBg(this@MainActivity, ColorUtils.setAlphaComponent(col, 32), col, 12f, 1f)
                setPadding(dp(8), dp(11), dp(8), dp(11))
                setOnClickListener {
                    val moved = DataStore.reclassifyUnassignedForDay(this@MainActivity, targetIso, code, etNote.text.toString())
                    dlg.dismiss()
                    refreshTimerUI()
                    if (currentTab == 1) loadReportTab()
                    Snackbar.make(findViewById(android.R.id.content), "${DataStore.formatHoursMinBn(moved)} '$label' হিসেবে সরানো হয়েছে!", Snackbar.LENGTH_SHORT).show()
                }
            }
            val targetRow = if (i < 3) row1 else row2
            targetRow.addView(chip, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (targetRow.childCount > 0) marginStart = dp(8)
            })
        }
        wrap.addView(row1)
        wrap.addView(row2, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        dlg.show()
    }

    private fun showWasteBudgetDialog() {
        val opts = arrayOf("বন্ধ", "১ ঘণ্টা", "২ ঘণ্টা", "৩ ঘণ্টা", "৪ ঘণ্টা", "৫ ঘণ্টা")
        val vals = intArrayOf(0, 1, 2, 3, 4, 5)
        MaterialAlertDialogBuilder(this)
            .setTitle("দৈনিক অপচয় বাজেট")
            .setItems(opts) { _, which ->
                DataStore.setWasteBudgetHours(this, vals[which])
                renderSettingsTab()
                refreshTimerUI()
            }
            .show()
    }

    private fun showWasteReasonDialog() {
        val reasons = arrayOf("ফোন স্ক্রলিং", "আড্ডা/গল্প", "ক্লান্তি/অলসতা", "অন্যান্য কাজ")
        MaterialAlertDialogBuilder(this)
            .setTitle("অপচয়ের কারণ ট্যাগ করো (সর্বোচ্চ ১৫ মি.)")
            .setItems(reasons) { _, which ->
                val r = reasons[which]
                var moved = 0L
                DataStore.updateToday(this) { rec ->
                    val untagged = rec.wasteReasons["অপচয় সময়"] ?: 0L
                    moved = minOf(15 * 60L, untagged)
                    if (moved > 0L) {
                        rec.wasteReasons["অপচয় সময়"] = untagged - moved
                        if ((rec.wasteReasons["অপচয় সময়"] ?: 0L) <= 0L) rec.wasteReasons.remove("অপচয় সময়")
                        rec.wasteReasons[r] = (rec.wasteReasons[r] ?: 0L) + moved
                        rec.wasteReason = r
                        rec.synced = false
                    }
                }
                Toast.makeText(
                    this,
                    if (moved > 0L) "${DataStore.formatHoursMinBn(moved)} \"$r\" হিসেবে ট্যাগ হয়েছে" else "ট্যাগ করার মতো নতুন অপচয় সময় নেই",
                    Toast.LENGTH_SHORT
                ).show()
                refreshTimerUI()
            }
            .show()
    }

    // ------------------------------------------------------------------ tabs

    private fun showTab(idx: Int, animate: Boolean = true) {
        if (currentTab == 3 && idx != 3) {
            syncEditorUnlocked = false
        }
        currentTab = idx
        val tabs = listOf(tabTimer, tabReport, tabRoutine, tabSettings)
        tabs.forEachIndexed { i, v ->
            if (i == idx) {
                if (v.visibility != View.VISIBLE) {
                    v.visibility = View.VISIBLE
                    if (animate) {
                        v.alpha = 0f
                        v.translationY = dp(6).toFloat()
                        v.animate().withLayer().alpha(1f).translationY(0f).setDuration(150L).setInterpolator(DecelerateInterpolator()).start()
                    }
                }
            } else {
                v.animate().cancel()
                v.alpha = 1f
                v.translationY = 0f
                v.visibility = View.GONE
            }
        }
        if (idx !in styledTabs) {
            val p = pal()
            val v = tabs.getOrNull(idx)
            if (v != null) styleByTag(v, p, softOf(p))
            styledTabs.add(idx)
        }
        styleNav()
    }

    private fun styleNav() {
        val p = pal()
        val idle = ContextCompat.getColor(this, R.color.nav_idle_text)
        val activeBg = ColorUtils.blendARGB(p.cardBg, p.accent, if (isNightActive()) 0.18f else 0.14f)
        listOf(navTimer, navReport, navRoutine, navSettings).forEachIndexed { i, tv ->
            val active = i == currentTab
            val c = if (active) p.accent else idle
            tv.setTextColor(c)
            tv.compoundDrawableTintList = ColorStateList.valueOf(c)
            tv.background = if (active) ThemePalette.makeBg(this, activeBg, 0, 16f, 0f) else null
        }
    }

    private fun refreshAllUI() {
        // শুধু UI সেট করছি: লিসেনার চালু হয়ে সার্ভিস রিস্টার্ট (টাইমার রিসেট) যেন না হয়
        updatingFlipSwitch = true
        swFlipService.isChecked = DataStore.isFlipEnabled(this)
        swOnlineStudy.isChecked = DataStore.isOnlineStudy(this)
        updatingFlipSwitch = false
        chkWordTarget.isChecked = DataStore.getToday(this).wordTarget
        applyColorPalette()
        refreshPresetPills()
        refreshAlarmUI()
        refreshTimerUI()
        renderSettingsTab()
    }

    private fun refreshAlarmUI() {
        btnTopAlarm.text = when (DataStore.getAlarmMode(this)) {
            "sound" -> "সাউন্ড"
            "silent" -> "নীরব"
            else -> "কম্পন"
        }
    }

    private fun refreshPresetPills() {
        val p = DataStore.getPresetMin(this)
        setPillActive(btnPreset45, p == 45)
        setPillActive(btnPreset10, p == 10)
        setPillActive(btnPreset5, p == 5)
        val isCustom = p != 45 && p != 10 && p != 5
        btnPresetCustom.text = if (isCustom) "${DataStore.toBnDigits(p)} মি." else "কাস্টম +"
        setPillActive(btnPresetCustom, isCustom)
    }

    private fun isNightActive(): Boolean {
        val uiMode = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return uiMode == Configuration.UI_MODE_NIGHT_YES
    }

    // ------------------------------------------------------------------ palette / styling

    private fun addRipple(v: View, color: Int) {
        if (rippledIds[v] == color) return
        rippledIds[v] = color
        v.foreground = RippleDrawable(ColorStateList.valueOf(ColorUtils.setAlphaComponent(color, 60)), null, null)
        v.clipToOutline = true
    }

    private fun styleByTag(v: View, p: AppPalette, soft: Int) {
        when (v.tag as? String) {
            "card" -> v.background = ThemePalette.makeBg(this, p.cardBg, p.cardBorder, 20f, 1f)
            "soft" -> { v.background = ThemePalette.makeBg(this, soft, p.cardBorder, 14f, 1f); if (v is TextView) v.setTextColor(ContextCompat.getColor(this, R.color.text_main)); addRipple(v, p.accent) }
            "track" -> v.background = ThemePalette.makeBg(this, soft, 0, 14f, 0f)
            "primary" -> {
                v.background = ThemePalette.makeBg(this, p.pillActiveBg, p.pillActiveBorder, 14f, 1.2f)
                if (v is TextView) v.setTextColor(p.pillActiveText)
                addRipple(v, p.pillActiveText)
            }
            "divider" -> v.setBackgroundColor(p.cardBorder)
            "input" -> v.background = ThemePalette.makeBg(this, soft, p.cardBorder, 14f, 1f)
            "muted_icon" -> if (v is ImageView) v.imageTintList = ColorStateList.valueOf(ContextCompat.getColor(this, R.color.text_muted))
        }
        if (v is ViewGroup) for (i in 0 until v.childCount) styleByTag(v.getChildAt(i), p, soft)
    }

    private fun tintDrawables(tv: TextView, color: Int) {
        tv.compoundDrawableTintList = ColorStateList.valueOf(color)
    }

    private fun applyColorPalette() {
        val pal = pal()
        val night = isNightActive()
        val soft = softOf(pal)
        val textMain = ContextCompat.getColor(this, R.color.text_main)
        val white = Color.WHITE

        styledTabs.clear()
        val activeTabView = listOf(tabTimer, tabReport, tabRoutine, tabSettings).getOrNull(currentTab) ?: rootLayout
        styleByTag(activeTabView, pal, soft)
        styledTabs.add(currentTab)
        bannerBcsAlloc.background = ThemePalette.makeBg(this, ColorUtils.blendARGB(pal.cardBg, pal.accent, if (night) 0.22f else 0.14f), ColorUtils.setAlphaComponent(pal.accent, 110), 12f, 1f)
        bannerBcsAlloc.setTextColor(pal.accent)
        val backTint = ColorStateList.valueOf(textMain)
        listOf(R.id.btnBackFlip, R.id.btnBackReminder, R.id.btnBackMascot, R.id.btnBackQuiet, R.id.btnBackData, R.id.btnBackAbout, R.id.btnBackProfile, R.id.btnBackGap).forEach { id ->
            findViewById<ImageView>(id).imageTintList = backTint
        }

        // ডে মোডে চাঁদ, নাইট মোডে সূর্য
        btnTopTheme.setImageResource(if (night) R.drawable.ic_sun else R.drawable.ic_moon)
        btnTopTheme.imageTintList = ColorStateList.valueOf(textMain)
        btnPrevPeriod.imageTintList = ColorStateList.valueOf(textMain)
        btnNextPeriod.imageTintList = ColorStateList.valueOf(textMain)

        focusRingView.setRingColors(pal.ringStart, pal.ringEnd)
        focusRingView.setTrackColor(pal.cardBorder)
        statusPillBox.background = ThemePalette.makeBg(this, pal.statusBg, pal.statusBorder, 14f, 1.2f)
        tvModeStatus.setTextColor(pal.statusText)
        examStripCard.background = ThemePalette.makeBg(this, pal.cardBg, pal.cardBorder, 20f, 1f)
        focusCardBox.background = ThemePalette.makeBg(this, pal.cardBg, pal.cardBorder, 20f, 1f)
        flipCardBox.background = ThemePalette.makeBg(this, pal.cardBg, pal.cardBorder, 20f, 1f)
        bottomNavBar.background = ThemePalette.makeBg(this, pal.cardBg, pal.cardBorder, 24f, 1f)

        btnManualStudy.background = ThemePalette.makeBg(this, pal.studyBg, pal.studyBorder, 16f, 1.5f)
        btnManualStudy.setTextColor(pal.studyText)
        tintDrawables(btnManualStudy, pal.studyText)
        btnManualWaste.background = ThemePalette.makeBg(this, pal.wasteBg, pal.wasteBorder, 16f, 1.5f)
        btnManualWaste.setTextColor(pal.wasteText)
        tintDrawables(btnManualWaste, pal.wasteText)
        cardStudyLive.background = ThemePalette.makeBg(this, pal.studyBg, pal.studyBorder, 20f, 1.5f)
        cardWasteLive.background = ThemePalette.makeBg(this, pal.wasteBg, pal.wasteBorder, 20f, 1.5f)
        listOf(btnManualStudy, btnManualWaste, cardStudyLive, cardWasteLive, examStripCard).forEach {
            addRipple(it, white)
        }
        // লাইভ কার্ডের ভেতরের লেখা সবসময় পড়ার মতো উজ্জ্বল
        tvStudyLiveClock.setTextColor(pal.studyText)
        tvWasteLiveClock.setTextColor(pal.wasteText)

        tvSubjectChip.setTextColor(pal.accent)
        tvSubjectChip.alpha = 1f
        tintDrawables(tvSubjectChip, pal.accent)
        tintDrawables(tvExamLabel, pal.accent)
        tintDrawables(tvStreakChip, ContextCompat.getColor(this, R.color.amber_accent))
        tvExamDaysPill.background = ThemePalette.makeBg(this, ColorUtils.blendARGB(pal.cardBg, pal.accent, 0.16f), 0, 12f, 0f)
        tvExamDaysPill.setTextColor(pal.accent)
        tvStatusDot.setTextColor(pal.statusText)

        pbDailyGoal.progressTintList = ColorStateList.valueOf(pal.accent)
        pbDailyGoal.progressBackgroundTintList = ColorStateList.valueOf(pal.cardBorder)
        chkWordTarget.buttonTintList = ColorStateList.valueOf(pal.accent)

        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        val muted = ContextCompat.getColor(this, R.color.text_muted)
        val onThumb = if (night) Color.parseColor("#0B0F14") else Color.WHITE
        val trackOff = ColorUtils.blendARGB(pal.cardBg, muted, 0.22f)
        for (sw in listOf(swFlipService, swOnlineStudy, swGoalNotif, swSrEnabled, swSrQuiet, swDashCellAlways, swSrSeriousMode, swGapAppSheet, swGapPhonePopup, swGapNightNotif, swGapAutoSleep, swHapticGlobal, swHapticFlip, swHapticGoal)) {
            sw.thumbTintList = ColorStateList(states, intArrayOf(onThumb, muted))
            sw.trackTintList = ColorStateList(states, intArrayOf(pal.accent, trackOff))
        }

        reportBarChart.setColors(
            pal.accent,
            ContextCompat.getColor(this, R.color.coral_waste),
            ContextCompat.getColor(this, R.color.indigo_sleep),
            pal.cardBorder,
            muted
        )
        ivDashBtnIcon.imageTintList = ColorStateList.valueOf(pal.pillActiveText)
        tvDashBtnLabel.setTextColor(pal.pillActiveText)
        btnReportMenu.imageTintList = ColorStateList.valueOf(textMain)
        updateReportPeriodPills()

        styleNav()
        refreshPresetPills()
    }

    private fun setPillActive(tv: TextView, active: Boolean) {
        val pal = pal()
        if (active) {
            tv.background = ThemePalette.makeBg(this, pal.pillActiveBg, pal.pillActiveBorder, 14f, 1.3f)
            tv.setTextColor(pal.pillActiveText)
        } else {
            tv.background = ThemePalette.makeBg(this, softOf(pal), pal.cardBorder, 14f, 1f)
            tv.setTextColor(ContextCompat.getColor(this, R.color.pill_inactive_text))
        }
        addRipple(tv, pal.accent)
    }

    private fun setSegmentActive(tv: TextView, active: Boolean) {
        val pal = pal()
        if (active) {
            tv.background = ThemePalette.makeBg(this, pal.pillActiveBg, pal.pillActiveBorder, 11f, 1f)
            tv.setTextColor(pal.pillActiveText)
        } else {
            tv.background = null
            tv.setTextColor(ContextCompat.getColor(this, R.color.pill_inactive_text))
        }
    }

    private fun setBtnIcon(tv: TextView, res: Int) {
        tv.setCompoundDrawablesRelativeWithIntrinsicBounds(res, 0, 0, 0)
    }

    private fun dot(color: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
        setSize(dp(12), dp(12))
    }

    // ------------------------------------------------------------------ timer tab

    private fun refreshTimerUI() {
        val rt = DataStore.loadRuntimeState(this)
        val now = System.currentTimeMillis()
        val elapsedSec = if (rt.running && rt.stateStartMs > 0L) ((now - rt.stateStartMs) / 1000L).coerceAtLeast(0L) else 0L

        val presetSec = (DataStore.getPresetMin(this) * 60).coerceAtLeast(60)
        val displaySec = if (rt.running && rt.mode == "STUDY") {
            (rt.remainingSec - elapsedSec.toInt()).coerceAtLeast(0)
        } else {
            rt.remainingSec
        }
        val clock = String.format(Locale.US, "%02d:%02d", displaySec / 60, displaySec % 60)
        tvTimerClock.setTextIfChanged(DataStore.toBnDigits(clock))
        val palNow = pal()
        val studyActive = rt.running && rt.mode == "STUDY"
        val wasteActive = rt.running && rt.mode == "WASTE"
        if (studyActive) {
            val remFrac = (displaySec.toFloat() / presetSec.toFloat()).coerceIn(0f, 1f)
            val amberCol = Color.parseColor("#F59E0B")
            val orangeCol = Color.parseColor("#F97316")
            val redCol = Color.parseColor("#EF4444")
            val ringCol = when {
                displaySec <= 60 || remFrac <= 0.10f -> ColorUtils.blendARGB(redCol, orangeCol, (remFrac / 0.10f).coerceIn(0f, 1f))
                remFrac <= 0.25f -> ColorUtils.blendARGB(orangeCol, amberCol, ((remFrac - 0.10f) / 0.15f).coerceIn(0f, 1f))
                remFrac <= 0.50f -> ColorUtils.blendARGB(amberCol, palNow.accent, ((remFrac - 0.25f) / 0.25f).coerceIn(0f, 1f))
                else -> palNow.accent
            }
            focusRingView.setRingColors(ringCol, ringCol)
            val lastMin = displaySec <= 60
            focusRingView.setLastMinutePulse(lastMin)
            tvTimerClock.setTextColor(if (lastMin) redCol else textColorMain(palNow))
        } else if (wasteActive) {
            val wCol = Color.parseColor("#EF4444")
            focusRingView.setRingColors(wCol, wCol)
            focusRingView.setLastMinutePulse(false)
            tvTimerClock.setTextColor(textColorMain(palNow))
        } else {
            if (wasStudyRunning && rt.remainingSec <= 1) focusRingView.triggerSessionBurst()
            focusRingView.setRingColors(palNow.ringStart, palNow.ringEnd)
            focusRingView.setLastMinutePulse(false)
            tvTimerClock.setTextColor(textColorMain(palNow))
        }
        wasStudyRunning = studyActive
        focusRingView.setProgress(displaySec.toFloat() / presetSec.toFloat(), smoothTick = rt.running)
        focusRingView.setGlowActive(rt.running)

        tvSubjectChip.setTextIfChanged("বিষয়: ${DataStore.getCurrentSubject(this)}")
        tvExamLabel.setTextIfChanged(DataStore.getExamName(this))
        tvStreakChip.setTextIfChanged("${DataStore.toBnDigits(DataStore.getCurrentStreak(this))} দিন")
        tvExamDaysPill.setTextIfChanged("আর ${DataStore.formatExamCountdownBn(this)}")

        val grace = DataStore.getGraceSec(this)
        val flipOn = DataStore.isFlipEnabled(this)
        tvFlipTitle.text = if (flipOn) "ফ্লিপ মোড ON" else "ফ্লিপ মোড OFF"
        if (swFlipService.isChecked != flipOn) { updatingFlipSwitch = true; swFlipService.isChecked = flipOn; updatingFlipSwitch = false }
        val onl = DataStore.isOnlineStudy(this)
        if (swOnlineStudy.isChecked != onl) { updatingFlipSwitch = true; swOnlineStudy.isChecked = onl; updatingFlipSwitch = false }
        val studyRunning = rt.running && rt.mode == "STUDY"
        val wasteRunning = rt.running && rt.mode == "WASTE"
        btnManualStudy.text = if (studyRunning) "পড়া পজ" else "পড়া শুরু"
        setBtnIcon(btnManualStudy, if (studyRunning) R.drawable.ic_pause else R.drawable.ic_play)
        btnManualWaste.text = if (wasteRunning) "অপচয় পজ" else "অপচয় শুরু"
        setBtnIcon(btnManualWaste, if (wasteRunning) R.drawable.ic_pause else R.drawable.ic_play)
        tvFlipSub.text = if (grace > 0) "${DataStore.toBnDigits(grace)} সে. গ্রেস টাইম • শুধু উল্টো থাকলেই পড়া" else "গ্রেস টাইম বন্ধ • শুধু উল্টো থাকলেই পড়া"

        tvModeStatus.text = when {
            !rt.running -> "বিরতি · ট্র্যাকিং বন্ধ"
            rt.mode == "STUDY" && DataStore.isOnlineStudy(this) -> if (flipOn) "অনলাইন · ফ্লিপ বিরতিতে" else "অনলাইন · পড়া চলছে"
            rt.mode == "STUDY" && !flipOn -> "ম্যানুয়াল · পড়া চলছে"
            rt.mode == "STUDY" -> "উল্টানো · পড়া চলছে"
            !flipOn -> "ম্যানুয়াল · অপচয় চলছে"
            else -> "স্ক্রিন খোলা · অপচয় চলছে"
        }
        tvStatusDot.setTextColor(
            when {
                studyRunning -> Color.parseColor("#34D399")
                wasteRunning -> Color.parseColor("#F87171")
                else -> Color.parseColor("#94A3B8")
            }
        )
        tvRingCaption.text = when {
            studyRunning -> "ফোকাস চলছে"
            wasteRunning -> "অপচয় চলছে · পড়ায় ফেরো"
            else -> "ফোকাস সেশন"
        }

        // রিয়েল-টাইম লাইভ কাউন্টার (আজকের অংশ মাঝরাত পেরোলেও ঠিক থাকে)
        val today = DataStore.getToday(this)
        val sinceMs = maxOf(rt.stateStartMs, DataStore.startOfTodayMs())
        val liveElapsed = if (rt.running && rt.stateStartMs > 0L) ((now - sinceMs) / 1000L).coerceAtLeast(0L) else 0L
        val liveStudySec = today.studySec + if (studyRunning) liveElapsed else 0L
        val pendingTodayGapSec = DataStore.pendingUnassignedGapSecForDay(this, DataStore.todayIso())
        val liveOutsideSec = (DataStore.outsideSec(today) + pendingTodayGapSec + if (wasteRunning) liveElapsed else 0L)
            .coerceAtMost((DataStore.maxTrackableSecForDay(this, DataStore.todayIso()) - today.studySec).coerceAtLeast(0L))

        tvStudyLiveClock.text = DataStore.formatHmsBn(liveStudySec)
        tvWasteLiveClock.text = DataStore.formatHmsBn(liveOutsideSec)

        val goalH = DataStore.getDailyGoalHours(this)
        val doneHours = liveStudySec / 3600.0
        val doneFmt = DataStore.toBnDigits(String.format(Locale.US, "%.1f", doneHours))
        tvGoalProgressText.text = "$doneFmt / ${DataStore.toBnDigits(goalH)} ঘণ্টা"
        val pct = ((liveStudySec * 100L) / (goalH * 3600L)).toInt().coerceIn(0, 100)
        pbDailyGoal.progress = pct

        val brk = SmartReminderManager.getActiveBreakInfo(this)
        if (brk != null) {
            val remMin = ((brk.remainingMs + 59_999L) / 60_000L).toInt().coerceAtLeast(1)
            bannerActiveBreak.visibility = View.VISIBLE
            if (brk.type == SmartReminderManager.PHASE_EATING) {
                tvActiveBreakInfo.text = "🍽 খাওয়া চলছে · ${MascotContent.formatDurationBn(remMin)}"
                btnBannerEndBreak.text = "শেষ"
            } else {
                tvActiveBreakInfo.text = "🚶 বাইরে (${brk.reason}) · ${MascotContent.formatDurationBn(remMin)}"
                btnBannerEndBreak.text = "ফিরেছি"
            }
        } else {
            bannerActiveBreak.visibility = View.GONE
        }

        val nonSleepOutsideSec = (liveOutsideSec - today.sleepOtherSec).coerceAtLeast(0L)
        tvWasteUntaggedBadge.visibility = View.GONE
        tvWasteCardSub.text = "ঘুম বাদে ${DataStore.formatHoursMinBn(nonSleepOutsideSec)}"
        tvWasteCardSub.setTextColor(pal().wasteText)

        val livePureWasteSec = today.wasteSec + today.awaySec + if (wasteRunning) liveElapsed else 0L
        val budgetH = DataStore.getWasteBudgetHours(this)
        if (budgetH > 0) {
            pbWasteBudget.visibility = View.VISIBLE
            val bPct = ((livePureWasteSec * 100L) / (budgetH * 3600L)).toInt().coerceIn(0, 100)
            pbWasteBudget.progress = bPct
            val barCol = when {
                livePureWasteSec > budgetH * 3600L -> CategoryColors.WASTE_INT
                bPct >= 80 -> CategoryColors.EAT_INT
                else -> pal().accent
            }
            pbWasteBudget.progressTintList = ColorStateList.valueOf(barCol)
        } else {
            pbWasteBudget.visibility = View.GONE
        }
    }

    // ------------------------------------------------------------------ report tab

    private fun updateReportPeriodPills() {
        val type = DataStore.getReportPeriodType(this)
        setPillActive(btnRepDay, type == ReportPeriodType.DAY)
        setPillActive(btnRepWeek, type == ReportPeriodType.WEEK)
        setPillActive(btnRepMonth, type == ReportPeriodType.MONTH)
        setPillActive(btnRepYear, type == ReportPeriodType.YEAR)
    }

    private fun canGoNextReportPeriod(): Boolean {
        val type = DataStore.getReportPeriodType(this)
        val anchor = DataStore.getReportAnchorIso(this)
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance().apply {
            time = try { fmt.parse(anchor) ?: Date() } catch (_: Exception) { Date() }
        }
        val endIso = when (type) {
            ReportPeriodType.DAY -> fmt.format(cal.time)
            ReportPeriodType.WEEK -> {
                val ws = DataStore.getWeekStartDay(this)
                while (cal.get(Calendar.DAY_OF_WEEK) != ws) cal.add(Calendar.DAY_OF_YEAR, -1)
                cal.add(Calendar.DAY_OF_YEAR, 6)
                fmt.format(cal.time)
            }
            ReportPeriodType.MONTH -> {
                cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH))
                fmt.format(cal.time)
            }
            ReportPeriodType.YEAR -> "${cal.get(Calendar.YEAR)}-12-31"
        }
        return endIso < DataStore.todayIso()
    }

    private fun shiftReportPeriod(delta: Int) {
        val type = DataStore.getReportPeriodType(this)
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance().apply {
            time = try { fmt.parse(DataStore.getReportAnchorIso(this@MainActivity)) ?: Date() } catch (_: Exception) { Date() }
        }
        when (type) {
            ReportPeriodType.DAY -> cal.add(Calendar.DAY_OF_YEAR, delta)
            ReportPeriodType.WEEK -> cal.add(Calendar.DAY_OF_YEAR, delta * 7)
            ReportPeriodType.MONTH -> cal.add(Calendar.MONTH, delta)
            ReportPeriodType.YEAR -> cal.add(Calendar.YEAR, delta)
        }
        val today = DataStore.todayIso()
        var nextIso = fmt.format(cal.time)
        if (nextIso > today) nextIso = today
        DataStore.setReportAnchorIso(this, nextIso)
        loadReportTab()
    }

    private fun showReportDatePicker() {
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance().apply {
            time = try { fmt.parse(DataStore.getReportAnchorIso(this@MainActivity)) ?: Date() } catch (_: Exception) { Date() }
        }
        val dpDlg = DatePickerDialog(
            this,
            R.style.AppDatePicker,
            { _, y, m, d ->
                val picked = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)
                val today = DataStore.todayIso()
                DataStore.setReportAnchorIso(this, if (picked > today) today else picked)
                loadReportTab()
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        )
        dpDlg.datePicker.maxDate = System.currentTimeMillis()
        dpDlg.show()
    }

    private fun loadReportTab() {
        updateReportPeriodPills()
        val type = DataStore.getReportPeriodType(this)
        val anchor = DataStore.getReportAnchorIso(this)
        viewUnsyncedDot.visibility = if (DataStore.hasUnsyncedDays(this)) View.VISIBLE else View.GONE

        val needsHydration = !reportHydratedOnce &&
            DataStore.loadDriveCache(this).isEmpty() &&
            DataStore.getGasUrl(this).startsWith("http")

        if (needsHydration) {
            tvReportStatusBanner.text = "ড্রাইভ থেকে আনা হচ্ছে..."
            tvReportStatusBanner.visibility = View.VISIBLE
            val appCtx = applicationContext
            thread {
                DataStore.fetchAllDaysFromDrive(appCtx, 10000)
                reportHydratedOnce = true
                runOnUiThread {
                    if (!isFinishing && !isDestroyed) renderReportView(DataStore.getReportPeriodType(this), DataStore.getReportAnchorIso(this))
                }
            }
        }
        renderReportView(type, anchor, loadingDrive = needsHydration)
    }

    private fun renderReportView(type: ReportPeriodType, anchor: String, loadingDrive: Boolean = false) {
        val rep = DataStore.computeUnifiedReport(this, type, anchor)
        lastReportData = rep

        tvPeriodTitle.text = rep.periodLabelBn
        tvReportPeriodSub.text = rep.periodLabelBn
        val canNext = rep.rangeEndIso < DataStore.todayIso()
        btnNextPeriod.isEnabled = canNext
        btnNextPeriod.alpha = if (canNext) 1f else 0.35f
        viewUnsyncedDot.visibility = if (DataStore.hasUnsyncedDays(this)) View.VISIBLE else View.GONE

        if (loadingDrive) {
            tvReportStatusBanner.text = "ড্রাইভ থেকে আনা হচ্ছে..."
            tvReportStatusBanner.visibility = View.VISIBLE
        } else if (!rep.hasAnyDataInPeriod) {
            tvReportStatusBanner.text = "এই সময়কালে এখনো কোনো ডেটা নেই"
            tvReportStatusBanner.visibility = View.VISIBLE
        } else {
            tvReportStatusBanner.visibility = View.GONE
        }
        val bcsSecInDay = if (type == ReportPeriodType.DAY) (rep.subjects["BCS প্রস্তুতি"] ?: 0L) else 0L
        if (bcsSecInDay > 0L) {
            bannerBcsAlloc.text = "● BCS প্রস্তুতিতে ${DataStore.formatHoursMinBn(bcsSecInDay)} জমা · বিষয় ভাগ করুন ▸"
            bannerBcsAlloc.visibility = View.VISIBLE
            val isActivelyStudying = DataStore.loadRuntimeState(this).let { it.running && it.mode == "STUDY" }
            if (currentTab == 1 && !isActivelyStudying && rep.rangeStartIso == DataStore.todayIso() &&
                bcsSecInDay >= 20L * 60L && DataStore.canPromptBcsAlloc(this)
            ) {
                DataStore.markBcsAllocPrompted(this)
                uiHandler.post { if (!isFinishing && !isDestroyed) showBcsAllocateDialog(rep.rangeStartIso) }
            }
        } else {
            bannerBcsAlloc.visibility = View.GONE
        }

        tvStatStudy.text = DataStore.formatHoursMinBn(rep.totalStudyMin * 60L)
        tvStatAvg.text = DataStore.formatHoursMinBn(rep.avgDailyStudyMin * 60L)
        tvStatWaste.text = DataStore.formatHoursMinBn(rep.totalWasteMin * 60L)

        val scoreSb = SpannableStringBuilder("${DataStore.toBnDigits(rep.goalCompletionPct)}%")
        val scoreSub = "\nঅপচয় অনুপাত ${DataStore.toBnDigits(rep.wasteRatioScore)}%"
        val sIdx = scoreSb.length
        scoreSb.append(scoreSub)
        scoreSb.setSpan(RelativeSizeSpan(0.62f), sIdx, scoreSb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        scoreSb.setSpan(ForegroundColorSpan(ContextCompat.getColor(this, R.color.text_muted)), sIdx, scoreSb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        tvStatScore.text = scoreSb

        val streakText = SpannableStringBuilder("${DataStore.toBnDigits(rep.currentStreak)} দিন")
        val sub = "\nসর্বোচ্চ ${DataStore.toBnDigits(rep.longestStreak)} দিন"
        val start = streakText.length
        streakText.append(sub)
        streakText.setSpan(RelativeSizeSpan(0.62f), start, streakText.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        streakText.setSpan(ForegroundColorSpan(ContextCompat.getColor(this, R.color.text_muted)), start, streakText.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        tvStatStreak.text = streakText

        tvStatBest.text = if (rep.bestDayLabel == "—") "—" else "${rep.bestDayLabel}\n(${DataStore.formatHoursMinBn(rep.bestDayMin * 60L)})"

        if (type == ReportPeriodType.DAY) {
            tvReportChartTitle.text = "দিনের লক্ষ্য ও সময়ভাগ"
            reportBarChart.visibility = View.GONE
            reportChartLegend.visibility = View.GONE
            dayDetailSummaryCard.visibility = View.VISIBLE
            val pct = rep.goalCompletionPct.coerceIn(0, 100)
            pbDayGoal.progress = pct
            tvDayGoalPct.text = "${DataStore.toBnDigits(rep.goalCompletionPct)}%"
            tvDayModesBreakdown.text = "ফ্লিপ: ${DataStore.formatHoursMinBn(rep.flipMin * 60L)} · ম্যানুয়াল: ${DataStore.formatHoursMinBn(rep.manualMin * 60L)} · অনলাইন: ${DataStore.formatHoursMinBn(rep.onlineMin * 60L)}"
            val accMin = rep.totalStudyMin + rep.totalWasteMin + rep.totalEatMin + rep.totalAwayMin + rep.totalSleepMin + rep.totalOtherMin + rep.totalUnassignedMin
            val capMin = (DataStore.maxTrackableSecForDay(this, anchor) / 60L).toInt().coerceAtLeast(1)
            val accPct = (accMin * 100) / capMin
            val accBadge = when {
                accMin > capMin + 5 -> " · ⚠ হিসাব বেশি (${DataStore.formatHoursMinBn((accMin - capMin) * 60L)})"
                accPct >= 99 -> " · ✓ মিলেছে"
                else -> " · বাকি ${DataStore.formatHoursMinBn((capMin - accMin).coerceAtLeast(0) * 60L)}"
            }
            tvDayTimesBreakdown.text = "অপচয়: ${DataStore.formatHoursMinBn((rep.totalWasteMin + rep.totalAwayMin) * 60L)} · খাওয়া: ${DataStore.formatHoursMinBn(rep.totalEatMin * 60L)} · ঘুম: ${DataStore.formatHoursMinBn(rep.totalSleepMin * 60L)} · দৈনন্দিন: ${DataStore.formatHoursMinBn(rep.totalOtherMin * 60L)} · অনির্ধারিত: ${DataStore.formatHoursMinBn(rep.totalUnassignedMin * 60L)}$accBadge"
            reportDay24Bar.setData(rep.totalStudyMin, rep.totalWasteMin, rep.totalEatMin, rep.totalAwayMin, rep.totalSleepMin, rep.totalOtherMin, pal().accent, pal().cardBorder, rep.totalUnassignedMin)
        } else {
            tvReportChartTitle.text = when (type) {
                ReportPeriodType.WEEK -> "সাপ্তাহিক তুলনা (৭ দিন)"
                ReportPeriodType.MONTH -> "দৈনিক তুলনা"
                else -> "মাসিক তুলনা (১২ মাস)"
            }
            dayDetailSummaryCard.visibility = View.GONE
            reportBarChart.visibility = View.VISIBLE
            reportChartLegend.visibility = View.VISIBLE
            reportBarChart.setBars(rep.bars)
        }

        renderBreakdownCard(rep)
    }

    private data class OtherGroup(
        val code: String,
        val label: String,
        val color: Int,
        val totalSec: Long,
        val children: Map<String, Long>
    )

    private val expandedGroups = mutableSetOf<String>()

    private fun renderBreakdownCard(rep: UnifiedReportData) {
        val p = pal()
        tvSubjectsTotal.text = "মোট ${DataStore.formatHoursMinBn(rep.subjects.values.sum())}"
        subjectsContainer.removeAllViews()
        val baseSubs = DataStore.getSubjectList()
        val bcsSec = rep.subjects["BCS প্রস্তুতি"] ?: 0L
        val showBcsRow = bcsSec > 0L || (DataStore.getReportPeriodType(this) == ReportPeriodType.DAY && rep.rangeStartIso == DataStore.todayIso() && DataStore.getCurrentSubject(this) == "BCS প্রস্তুতি")
        val extraSubs = rep.subjects.keys.filter { it !in baseSubs && it != "BCS প্রস্তুতি" && (rep.subjects[it] ?: 0L) > 0L }
        val allSubNames = baseSubs + (if (showBcsRow) listOf("BCS প্রস্তুতি") else emptyList()) + extraSubs
        val maxSub = allSubNames.maxOfOrNull { rep.subjects[it] ?: 0L }?.toFloat()?.coerceAtLeast(1f) ?: 1f
        for (name in baseSubs) {
            val sec = rep.subjects[name] ?: 0L
            subjectsContainer.addView(
                itemRow(name, sec, maxSub, p.accent) {
                    showItemDetailSheet("SUBJECT", name, p.accent)
                }
            )
        }
        if (showBcsRow) {
            subjectsContainer.addView(
                itemRow("BCS প্রস্তুতি", bcsSec, maxSub, p.accent) {
                    showItemDetailSheet("SUBJECT", "BCS প্রস্তুতি", p.accent)
                }
            )
        }
        if (extraSubs.isNotEmpty()) {
            subjectsContainer.addView(View(this).apply {
                setBackgroundColor(p.cardBorder)
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)).apply {
                    topMargin = dp(6); bottomMargin = dp(2)
                }
            })
            for (name in extraSubs) {
                val sec = rep.subjects[name] ?: 0L
                subjectsContainer.addView(
                    itemRow(name, sec, maxSub, p.accent) {
                        showItemDetailSheet("SUBJECT", name, p.accent)
                    }
                )
            }
        }

        val wasteMergedKids = linkedMapOf<String, Long>()
        for ((k, v) in rep.wasteReasons.entries.filter { it.value > 0L && it.key != "অপচয় সময়" && it.key != "অপচয় সময়" }.sortedByDescending { it.value }) {
            wasteMergedKids[k] = v
        }
        val awaySec = rep.totalAwayMin * 60L
        wasteMergedKids["বাইরে যাওয়া"] = awaySec
        val wasteTotalSec = rep.totalWasteMin * 60L + awaySec
        val groups = listOf(
            OtherGroup("WASTE", "অপচয়", CategoryColors.WASTE_INT, wasteTotalSec, wasteMergedKids),
            OtherGroup("OTHER", "দৈনন্দিন কাজ", CategoryColors.OTHER_INT, rep.totalOtherMin * 60L, emptyMap()),
            OtherGroup("SLEEP", "ঘুম", CategoryColors.SLEEP_INT, rep.totalSleepMin * 60L, emptyMap()),
            OtherGroup("EAT", "খাওয়া", CategoryColors.EAT_INT, rep.totalEatMin * 60L, emptyMap()),
            OtherGroup("UNASSIGNED", "অনির্ধারিত", CategoryColors.UNASSIGNED_INT, rep.totalUnassignedMin * 60L, emptyMap())
        )

        tvOtherTotal.text = "মোট ${DataStore.formatHoursMinBn(groups.sumOf { it.totalSec })}"
        renderOtherGroups(groups)
        fitBreakdownCard()
    }

    private fun renderOtherGroups(groups: List<OtherGroup>) {
        otherContainer.removeAllViews()
        if (groups.isEmpty()) {
            otherContainer.addView(emptyText())
            return
        }
        val maxVal = groups.maxOfOrNull { it.totalSec }?.toFloat()?.coerceAtLeast(1f) ?: 1f
        for (g in groups) {
            val kids = g.children.entries.filter { it.value > 0L || it.key == "বাইরে যাওয়া" }.sortedByDescending { it.value }
            val kidsSum = kids.sumOf { it.value }
            val kidsBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                visibility = if (g.code in expandedGroups) View.VISIBLE else View.GONE
            }
            for (k in kids) {
                val isAwayKid = k.key == "বাইরে যাওয়া"
                val kidColor = if (isAwayKid) CategoryColors.AWAY_INT else ColorUtils.setAlphaComponent(g.color, 190)
                val kidKind = if (isAwayKid) "AWAY" else "WASTE_REASON"
                kidsBox.addView(
                    itemRow(k.key, k.value, g.totalSec.toFloat().coerceAtLeast(1f), kidColor, indentDp = 12) {
                        showItemDetailSheet(kidKind, k.key, if (isAwayKid) CategoryColors.AWAY_INT else g.color)
                    }
                )
            }
            if (kids.isNotEmpty() && g.totalSec - kidsSum >= 60L) {
                kidsBox.addView(
                    itemRow("অন্যান্য অপচয়", g.totalSec - kidsSum, g.totalSec.toFloat(), ColorUtils.setAlphaComponent(g.color, 110), indentDp = 12) {
                        showItemDetailSheet(g.code, g.label, g.color)
                    }
                )
            }
            if (kids.isNotEmpty()) {
                kidsBox.addView(TextView(this).apply {
                    text = "পুরো বিস্তারিত ›"
                    textSize = 11f
                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                    setTextColor(g.color)
                    setPadding(dp(12), dp(8), 0, dp(6))
                    setOnClickListener { showItemDetailSheet(g.code, g.label, g.color) }
                })
            }

            fun label(open: Boolean) = if (kids.isEmpty()) g.label else g.label + if (open) " ▴" else " ▾"
            var nameTv: TextView? = null
            val header = itemRow(label(g.code in expandedGroups), g.totalSec, maxVal, g.color, bold = true, onNameView = { nameTv = it }) {
                if (kids.isEmpty()) {
                    showItemDetailSheet(g.code, g.label, g.color)
                } else {
                    val open = kidsBox.visibility != View.VISIBLE
                    TransitionManager.beginDelayedTransition(otherContainer, AutoTransition().setDuration(160))
                    kidsBox.visibility = if (open) View.VISIBLE else View.GONE
                    if (open) expandedGroups.add(g.code) else expandedGroups.remove(g.code)
                    nameTv?.text = label(open)
                }
            }
            otherContainer.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(header)
                addView(kidsBox)
            })
        }
    }

    private fun emptyText(): TextView = TextView(this).apply {
        text = "কোনো তথ্য নেই"
        textSize = 12f
        setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_muted))
        setPadding(0, dp(8), 0, dp(2))
    }

    private fun itemRow(
        name: String,
        valueSec: Long,
        maxVal: Float,
        color: Int,
        indentDp: Int = 0,
        bold: Boolean = false,
        onNameView: ((TextView) -> Unit)? = null,
        onClick: () -> Unit
    ): View {
        val p = pal()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(indentDp), dp(8), 0, dp(4))
            isClickable = true
            foreground = RippleDrawable(ColorStateList.valueOf(ColorUtils.setAlphaComponent(color, 50)), null, null)
            setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                onClick()
            }
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val nameTv = TextView(this).apply {
            text = name
            textSize = 11.5f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(textColorMain(p))
        }
        onNameView?.invoke(nameTv)
        head.addView(nameTv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(TextView(this).apply {
            text = DataStore.formatHoursMinBn(valueSec)
            textSize = 11.5f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(textColorMain(p))
            setPadding(dp(6), 0, 0, 0)
        })
        row.addView(head)
        row.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            this.max = 1000
            progress = if (valueSec <= 0L) 0 else ((valueSec / maxVal.coerceAtLeast(1f)) * 1000f).toInt().coerceIn(15, 1000)
            progressDrawable = ContextCompat.getDrawable(this@MainActivity, R.drawable.progress_goal)?.mutate()
            progressTintList = ColorStateList.valueOf(color)
            progressBackgroundTintList = ColorStateList.valueOf(p.cardBorder)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(5)).apply { topMargin = dp(4) })
        return row
    }

    private fun fitBreakdownCard() {
        // cardBreakdown এখন layout_weight=1 দিয়ে স্ক্রিনের বাকি অংশ স্বয়ংক্রিয়ভাবে পূরণ করে
    }

    private fun showBcsAllocateDialog(iso: String) {
        val dayRec = DataStore.loadAllDays(this)[iso] ?: return
        val bcsSec = dayRec.subjects["BCS প্রস্তুতি"] ?: 0L
        if (bcsSec <= 0L) return
        val durText = DataStore.formatHoursMinBn(bcsSec)
        val base = DataStore.getSubjectList()
        val choices = (base + "অন্যান্য (শুধু আজকের জন্য)").toTypedArray()
        val checked = BooleanArray(choices.size)

        MaterialAlertDialogBuilder(this)
            .setTitle("আজ কোন কোন বিষয় পড়েছো? ($durText)")
            .setMultiChoiceItems(choices, checked) { _, which, isChecked ->
                checked[which] = isChecked
            }
            .setPositiveButton("পরবর্তী") { _, _ ->
                val selectedBase = base.filterIndexed { i, _ -> checked[i] }
                val wantCustom = checked[base.size]
                if (selectedBase.isEmpty() && !wantCustom) {
                    Toast.makeText(this, "অন্তত একটি বিষয় বাছাই করো", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (wantCustom) {
                    val et = EditText(this).apply {
                        hint = "বিষয়ের নাম লিখো (যেমন: একাডেমিক)"
                        filters = arrayOf(android.text.InputFilter.LengthFilter(28))
                        setPadding(dp(16), dp(12), dp(16), dp(12))
                    }
                    MaterialAlertDialogBuilder(this)
                        .setTitle("একদিনের কাস্টম বিষয়")
                        .setView(et)
                        .setPositiveButton("ঠিক আছে") { _, _ ->
                            val custom = et.text.toString().trim()
                            val finalList = if (custom.isNotEmpty() && custom != "BCS প্রস্তুতি") selectedBase + custom else selectedBase
                            proceedWithSelectedBcsSubjects(iso, bcsSec, finalList)
                        }
                        .setNegativeButton("বাতিল", null)
                        .show()
                } else {
                    proceedWithSelectedBcsSubjects(iso, bcsSec, selectedBase)
                }
            }
            .setNeutralButton("পরে বলবো") { _, _ ->
            }
            .setOnCancelListener {
            }
            .show()
    }

    private fun proceedWithSelectedBcsSubjects(iso: String, bcsSec: Long, selectedSubjects: List<String>) {
        if (selectedSubjects.isEmpty()) return
        if (selectedSubjects.size == 1) {
            val target = selectedSubjects[0]
            val moved = DataStore.allocateBcsSubjectForDay(this, iso, mapOf(target to bcsSec))
            if (moved > 0L) {
                Toast.makeText(this, "${DataStore.formatHoursMinBn(moved)} → $target-এ যোগ হয়েছে", Toast.LENGTH_SHORT).show()
                renderReportView(DataStore.getReportPeriodType(this), iso)
            }
        } else {
            showTimelineSplitForBcs(iso, bcsSec, selectedSubjects)
        }
    }

    private fun showTimelineSplitForBcs(iso: String, bcsSec: Long, selectedSubjects: List<String>) {
        val blocks = DataStore.getMergedStudyBlocksForDay(this, iso)
        val subjects = selectedSubjects.ifEmpty { DataStore.getSubjectList() }
        val allOpts = (listOf("BCS প্রস্তুতি (রেখে দাও)") + subjects).toTypedArray()
        val p = pal()

        val scroll = android.widget.ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(8))
        }
        scroll.addView(container)

        if (blocks.isNotEmpty()) {
            container.addView(TextView(this).apply {
                text = "১৫ মিনিটের কম বিরতির সেশনগুলো এক ব্লকে জোড়া হয়েছে। প্রতিটি ব্লকের পাশে বিষয় বাছো:"
                textSize = 12.5f
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_muted))
                setPadding(0, 0, 0, dp(8))
            })
            val fmt = SimpleDateFormat("hh:mm a", Locale.US)
            val chosen = MutableList(blocks.size) { 0 }
            blocks.forEachIndexed { idx, blk ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(6), 0, dp(6))
                }
                val tvTime = TextView(this).apply {
                    val lbl = "${DataStore.toBnDigits(fmt.format(Date(blk.startMs)))} – ${DataStore.toBnDigits(fmt.format(Date(blk.endMs)))}"
                    text = "$lbl\nপড়া: ${DataStore.formatHoursMinBn(blk.actualStudySec)}"
                    textSize = 12f
                    setTextColor(textColorMain(p))
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                }
                val btnPick = TextView(this).apply {
                    text = "বিষয় বাছো ▾"
                    textSize = 12f
                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                    setTextColor(p.accent)
                    background = ThemePalette.makeBg(this@MainActivity, softOf(p), p.cardBorder, 10f, 1f)
                    setPadding(dp(10), dp(7), dp(10), dp(7))
                }
                btnPick.setOnClickListener {
                    MaterialAlertDialogBuilder(this)
                        .setTitle("এই ব্লকের বিষয়")
                        .setSingleChoiceItems(allOpts, chosen[idx]) { d, w ->
                            chosen[idx] = w
                            btnPick.text = if (w == 0) "রেখে দাও ▾" else "${subjects[w - 1]} ▾"
                            d.dismiss()
                        }
                        .show()
                }
                row.addView(tvTime)
                row.addView(btnPick)
                container.addView(row)
            }

            MaterialAlertDialogBuilder(this)
                .setTitle("টাইমলাইন অনুযায়ী ভাগ (${DataStore.formatHoursMinBn(bcsSec)})")
                .setView(scroll)
                .setPositiveButton("সেভ করো") { _, _ ->
                    val alloc = linkedMapOf<String, Long>()
                    val usedIds = mutableSetOf<Long>()
                    blocks.forEachIndexed { idx, blk ->
                        val pick = chosen[idx]
                        if (pick > 0) {
                            val subName = subjects[pick - 1]
                            alloc[subName] = (alloc[subName] ?: 0L) + blk.actualStudySec
                            usedIds.addAll(blk.sessionIds)
                        }
                    }
                    val moved = DataStore.allocateBcsSubjectForDay(this, iso, alloc, usedIds)
                    if (moved > 0L) {
                        Toast.makeText(this, "${DataStore.formatHoursMinBn(moved)} বিষয়গুলোতে ভাগ করা হয়েছে", Toast.LENGTH_SHORT).show()
                        renderReportView(DataStore.getReportPeriodType(this), iso)
                    }
                }
                .setNeutralButton("মিনিট লিখে ভাগ") { _, _ -> showManualMinuteSplitForBcs(iso, bcsSec) }
                .setNegativeButton("বাতিল", null)
                .show()
        } else {
            showManualMinuteSplitForBcs(iso, bcsSec)
        }
    }

    private fun showManualMinuteSplitForBcs(iso: String, bcsSec: Long) {
        val totalMin = (bcsSec / 60L).toInt().coerceAtLeast(1)
        val subjects = DataStore.getSubjectList()
        val p = pal()
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(8))
        }
        wrap.addView(TextView(this).apply {
            text = "মোট ${DataStore.formatHoursMinBn(bcsSec)} (${DataStore.toBnDigits(totalMin)} মি.) — প্রতি বিষয়ে মিনিট লিখো:"
            textSize = 12.5f
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_muted))
            setPadding(0, 0, 0, dp(8))
        })
        val inputs = mutableListOf<Pair<String, EditText>>()
        for (sub in subjects) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(4), 0, dp(4))
            }
            val tv = TextView(this).apply {
                text = sub
                textSize = 13f
                setTextColor(textColorMain(p))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            val et = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER
                hint = "০ মি."
                filters = arrayOf(android.text.InputFilter.LengthFilter(4))
                layoutParams = LinearLayout.LayoutParams(dp(90), ViewGroup.LayoutParams.WRAP_CONTENT)
            }
            row.addView(tv)
            row.addView(et)
            wrap.addView(row)
            inputs.add(sub to et)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("মিনিট অনুযায়ী বিষয় ভাগ")
            .setView(wrap)
            .setPositiveButton("সেভ করো") { _, _ ->
                val alloc = linkedMapOf<String, Long>()
                for ((sub, et) in inputs) {
                    val m = et.text.toString().trim().toIntOrNull() ?: 0
                    if (m > 0) alloc[sub] = m * 60L
                }
                val moved = DataStore.allocateBcsSubjectForDay(this, iso, alloc)
                if (moved > 0L) {
                    Toast.makeText(this, "${DataStore.formatHoursMinBn(moved)} বিষয়গুলোতে ভাগ করা হয়েছে", Toast.LENGTH_SHORT).show()
                    renderReportView(DataStore.getReportPeriodType(this), iso)
                }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun showItemDetailSheet(kind: String, title: String, color: Int) {
        val rep = lastReportData ?: return
        val type = DataStore.getReportPeriodType(this)
        val daily = DataStore.getItemDailyBreakdown(this, kind, title, rep.rangeStartIso, rep.rangeEndIso)
        val totalSec = daily.sumOf { it.second }
        val p = pal()
        val muted = ContextCompat.getColor(this, R.color.text_muted)

        val dlg = BottomSheetDialog(this)
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = ThemePalette.makeBg(this@MainActivity, p.cardBg, p.cardBorder, 20f, 1f)
            setPadding(dp(20), dp(18), dp(20), dp(24))
        }

        val kindLabel = when (kind) {
            "SUBJECT" -> "পড়ার বিষয়"
            "WASTE", "WASTE_REASON" -> "অপচয়"
            "EAT" -> "খাওয়া"
            "AWAY", "AWAY_REASON" -> "বাইরে"
            "SLEEP" -> "ঘুম"
            "UNASSIGNED" -> "অনির্ধারিত"
            else -> "দৈনন্দিন কাজ"
        }

        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        titleCol.addView(TextView(this).apply {
            text = title
            textSize = 17f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(textColorMain(p))
        })
        titleCol.addView(TextView(this).apply {
            text = "$kindLabel · ${rep.periodLabelBn}"
            textSize = 12f
            setTextColor(muted)
        })
        val totalBadge = TextView(this).apply {
            text = DataStore.formatHoursMinBn(totalSec)
            textSize = 13f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(color)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = ThemePalette.makeBg(this@MainActivity, ColorUtils.setAlphaComponent(color, 28), ColorUtils.setAlphaComponent(color, 95), 14f, 1f)
        }
        headerRow.addView(titleCol)
        headerRow.addView(totalBadge)
        wrap.addView(headerRow)

        val listBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(12), 0, 0)
        }
        if (type == ReportPeriodType.DAY) {
            listBox.addView(TextView(this).apply {
                text = "এই দিনে মোট সময়: ${DataStore.formatHoursMinBn(totalSec)}"
                textSize = 13.5f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setTextColor(textColorMain(p))
            })
            listBox.addView(TextView(this).apply {
                text = "সাপ্তাহিক, মাসিক বা বার্ষিক মোডে গেলে এখানে দিনভিত্তিক তালিকা দেখাবে।"
                textSize = 12f
                setTextColor(muted)
                setPadding(0, dp(6), 0, 0)
            })
            if (kind == "SUBJECT" && title == "BCS প্রস্তুতি" && totalSec > 0L) {
                listBox.addView(TextView(this).apply {
                    text = "বিষয় ভাগ / স্থানান্তর করো"
                    textSize = 13.5f
                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                    setTextColor(p.pillActiveText)
                    background = ThemePalette.makeBg(this@MainActivity, p.pillActiveBg, p.pillActiveBorder, 12f, 1f)
                    setPadding(dp(14), dp(10), dp(14), dp(10))
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        topMargin = dp(12)
                    }
                    setOnClickListener {
                        dlg.dismiss()
                        showBcsAllocateDialog(rep.rangeStartIso)
                    }
                })
            }
        } else if (daily.isEmpty()) {
            listBox.addView(emptyText())
        } else {
            val maxSec = daily.maxOf { it.second }.toFloat().coerceAtLeast(1f)
            for ((iso, sec) in daily) {
                val dateLabel = DataStore.formatFullDateBn(iso)
                listBox.addView(itemRow(dateLabel, sec, maxSec, color) {
                    dlg.dismiss()
                    DataStore.setReportPeriodType(this@MainActivity, ReportPeriodType.DAY)
                    DataStore.setReportAnchorIso(this@MainActivity, iso)
                    renderReportView(ReportPeriodType.DAY, iso)
                })
            }
        }
        val scroll = ScrollView(this).apply { addView(listBox) }
        wrap.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        dlg.setContentView(wrap)
        dlg.show()
    }

    private fun showHeatmapBottomSheet() {
        val dlg = BottomSheetDialog(this)
        val p = pal()
        val muted = ContextCompat.getColor(this, R.color.text_muted)
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = ThemePalette.makeBg(this@MainActivity, p.cardBg, p.cardBorder, 20f, 1f)
            setPadding(dp(20), dp(18), dp(20), dp(24))
        }
        wrap.addView(TextView(this).apply {
            text = "শেষ ২৮ দিনের ফোকাস হিটম্যাপ"
            textSize = 16f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(textColorMain(p))
        })
        wrap.addView(TextView(this).apply {
            text = "যেকোনো ঘরে ট্যাপ করলে ওই দিনের রিপোর্ট খুলবে"
            textSize = 12f
            setTextColor(muted)
            setPadding(0, dp(4), 0, dp(12))
        })
        val hm = HeatmapView(this).apply {
            setPalette(ColorUtils.blendARGB(p.cardBg, muted, 0.18f), p.accent)
            setMinutes(DataStore.getLast28DaysMinutes(this@MainActivity))
            onCellClick = { cellIdx ->
                val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -(27 - cellIdx)) }
                val iso = fmt.format(cal.time)
                dlg.dismiss()
                DataStore.setReportPeriodType(this@MainActivity, ReportPeriodType.DAY)
                DataStore.setReportAnchorIso(this@MainActivity, iso)
                loadReportTab()
            }
        }
        wrap.addView(hm, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(170)))
        dlg.setContentView(wrap)
        dlg.show()
    }

    private data class AnchoredMenuItem(
        val group: String?,
        val iconRes: Int,
        val iconColor: Int,
        val title: String,
        val subtitle: String,
        val badgeText: String? = null,
        val badgeDot: Boolean = false,
        val onClick: () -> Unit
    )

    private fun showAnchoredMenu(anchor: View, items: List<AnchoredMenuItem>) {
        activeAnchoredMenu?.dismiss()
        val p = pal()
        val muted = ContextCompat.getColor(this, R.color.text_muted)
        val textMain = textColorMain(p)
        val widthPx = dp(276)
        val loc = IntArray(2)
        anchor.getLocationOnScreen(loc)
        val anchorBottom = loc[1] + anchor.height
        val availBelow = resources.displayMetrics.heightPixels - anchorBottom - dp(96)
        val maxHeightPx = availBelow.coerceAtLeast(dp(260))

        val listCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, dp(6))
        }
        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = true
            addView(listCol)
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = ThemePalette.makeBg(this@MainActivity, p.cardBg, p.cardBorder, 16f, 1.2f)
            elevation = dp(12).toFloat()
            addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        val popup = PopupWindow(card, widthPx, ViewGroup.LayoutParams.WRAP_CONTENT, true).apply {
            isOutsideTouchable = true
            elevation = dp(12).toFloat()
            setOnDismissListener { if (activeAnchoredMenu === this) activeAnchoredMenu = null }
        }
        activeAnchoredMenu = popup

        var lastGroup: String? = null
        items.forEachIndexed { idx, item ->
            if (!item.group.isNullOrEmpty() && item.group != lastGroup) {
                lastGroup = item.group
                listCol.addView(TextView(this).apply {
                    text = item.group
                    textSize = 10.5f
                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                    setTextColor(muted)
                    setPadding(dp(14), if (idx == 0) dp(2) else dp(6), dp(14), dp(2))
                })
            } else if (idx > 0) {
                listCol.addView(View(this).apply { setBackgroundColor(p.cardBorder) },
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)).apply {
                        marginStart = dp(14); marginEnd = dp(14)
                    })
            }

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(6), dp(12), dp(6))
                addRipple(this, p.accent)
                setOnClickListener {
                    popup.dismiss()
                    item.onClick()
                }
            }
            val iconTile = FrameLayout(this).apply {
                background = ThemePalette.makeBg(this@MainActivity, ColorUtils.setAlphaComponent(item.iconColor, 34), 0, 11f, 0f)
            }
            iconTile.addView(ImageView(this).apply {
                setImageResource(item.iconRes)
                imageTintList = ColorStateList.valueOf(item.iconColor)
            }, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
            row.addView(iconTile, LinearLayout.LayoutParams(dp(34), dp(34)).apply { marginEnd = dp(10) })

            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(TextView(this).apply {
                text = item.title
                textSize = 13.5f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setTextColor(textMain)
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            })
            col.addView(TextView(this).apply {
                text = item.subtitle
                textSize = 11f
                setTextColor(muted)
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            })
            row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            if (!item.badgeText.isNullOrEmpty()) {
                row.addView(TextView(this).apply {
                    text = item.badgeText
                    textSize = 11f
                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                    setTextColor(p.pillActiveText)
                    background = ThemePalette.makeBg(this@MainActivity, p.accent, 0, 10f, 0f)
                    setPadding(dp(7), dp(2), dp(7), dp(2))
                }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(6) })
            } else if (item.badgeDot) {
                row.addView(View(this).apply {
                    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(CategoryColors.EAT_INT) }
                }, LinearLayout.LayoutParams(dp(8), dp(8)).apply { marginEnd = dp(8) })
            }

            row.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_chevron_right)
                imageTintList = ColorStateList.valueOf(muted)
            }, LinearLayout.LayoutParams(dp(16), dp(16)))
            listCol.addView(row)
        }

        card.measure(
            View.MeasureSpec.makeMeasureSpec(widthPx, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(maxHeightPx, View.MeasureSpec.AT_MOST)
        )
        if (card.measuredHeight >= maxHeightPx) {
            scroll.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, maxHeightPx)
        }

        card.pivotX = widthPx.toFloat()
        card.pivotY = 0f
        card.scaleX = 0.85f
        card.scaleY = 0.85f
        card.alpha = 0f
        popup.showAsDropDown(anchor, -(widthPx - anchor.width), dp(4))
        card.animate()
            .scaleX(1f).scaleY(1f).alpha(1f)
            .setDuration(200L)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }

    private fun showReportMenuSheet() {
        val p = pal()
        val unsyncedCount = DataStore.loadAllDays(this).values.count { !it.synced }
        val badge = if (unsyncedCount > 0) DataStore.toBnDigits(unsyncedCount) else null
        showAnchoredMenu(btnReportMenu, listOf(
            AnchoredMenuItem("দেখা ও বিশ্লেষণ", R.drawable.ic_calendar, p.accent, "তারিখ বেছে নাও", "যেকোনো দিন সরাসরি দেখো") {
                showReportDatePicker()
            },
            AnchoredMenuItem("দেখা ও বিশ্লেষণ", R.drawable.ic_chart, CategoryColors.AWAY_INT, "২৮ দিনের হিটম্যাপ", "ট্যাপ করে নির্দিষ্ট দিনে যাও") {
                showHeatmapBottomSheet()
            },
            AnchoredMenuItem("ডেটা ও ব্যাকআপ", R.drawable.ic_check, p.accent, "ড্রাইভে সিঙ্ক", DataStore.getLastSyncText(this), badgeText = badge, badgeDot = unsyncedCount > 0) {
                val appCtx = applicationContext
                Snackbar.make(findViewById(android.R.id.content), "ড্রাইভে সিঙ্ক হচ্ছে...", Snackbar.LENGTH_SHORT).show()
                thread {
                    val (ok, msg) = DataStore.syncToGoogleDrive(appCtx)
                    runOnUiThread {
                        if (isFinishing || isDestroyed) return@runOnUiThread
                        Snackbar.make(findViewById(android.R.id.content), msg, Snackbar.LENGTH_LONG).show()
                        if (ok) loadReportTab()
                    }
                }
            },
            AnchoredMenuItem("ডেটা ও ব্যাকআপ", R.drawable.ic_edit, CategoryColors.EAT_INT, "CSV শেয়ার", "এই সময়কাল বা সব ডেটা (.csv)") {
                val rep = lastReportData
                MaterialAlertDialogBuilder(this)
                    .setTitle("কোন ডেটা CSV বানাবে?")
                    .setItems(arrayOf("এই সময়কাল (${rep?.periodLabelBn ?: ""})", "সব ডেটা (সম্পূর্ণ ইতিহাস)")) { _, which ->
                        if (which == 0) {
                            shareExportedFile(DataStore.exportCsvToFile(this, rep?.rangeStartIso, rep?.rangeEndIso, rep?.rangeStartIso ?: "period"), "text/csv", "CSV শেয়ার করো")
                        } else {
                            shareExportedFile(DataStore.exportCsvToFile(this, null, null, "all_${DataStore.todayIso()}"), "text/csv", "সব ডেটা CSV শেয়ার করো")
                        }
                    }
                    .show()
            }
        ))
    }

    private fun shareExportedFile(file: java.io.File, mime: String, chooserTitle: String) {
        try {
            val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", file)
            val share = Intent(Intent.ACTION_SEND).apply {
                type = mime
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(share, chooserTitle))
        } catch (e: Exception) {
            Snackbar.make(findViewById(android.R.id.content), "ফাইল শেয়ার ব্যর্থ: ${e.localizedMessage ?: "ত্রুটি"}", Snackbar.LENGTH_LONG).show()
        }
    }

    private fun textColorMain(p: AppPalette): Int =
        ContextCompat.getColor(this, R.color.text_main)

    // ------------------------------------------------------------------ routine tab

    private fun renderRoutineTab(scrollToToday: Boolean = false) {
        routineContainer.removeAllViews()
        val days = DataStore.getCurrentMonthDays(this)
        val cal = Calendar.getInstance()
        tvRoutineHeader.text = "রুটিন · ${bnMonths[cal.get(Calendar.MONTH)]} ${DataStore.toBnDigits(cal.get(Calendar.YEAR))}"
        chkWordTarget.setOnCheckedChangeListener(null)
        chkWordTarget.isChecked = DataStore.getToday(this).wordTarget
        chkWordTarget.setOnCheckedChangeListener { _, checked ->
            DataStore.updateToday(this) { rec -> rec.wordTarget = checked; rec.synced = false }
            renderRoutineTab()
        }

        val p = pal()
        val today = DataStore.todayIso()
        val goalMin = DataStore.getDailyGoalHours(this) * 60
        val muted = ContextCompat.getColor(this, R.color.text_muted)
        val inflater = LayoutInflater.from(this)
        var todayRow: View? = null

        for (d in days) {
            val row = inflater.inflate(R.layout.item_routine_day, routineContainer, false)
            val isToday = d.date == today
            val isFuture = d.date > today
            row.background = ThemePalette.makeBg(this, p.cardBg, if (isToday) p.accent else p.cardBorder, 16f, if (isToday) 1.6f else 1f)
            if (isFuture) row.alpha = 0.5f

            val num = row.findViewById<TextView>(R.id.tvDayNum)
            num.text = DataStore.toBnDigits(d.date.takeLast(2))
            if (isToday) {
                num.background = ThemePalette.makeBg(this, p.accent, 0, 20f, 0f)
                num.setTextColor(if (isNightActive()) Color.parseColor("#0B0F14") else Color.WHITE)
            } else {
                num.background = ThemePalette.makeBg(this, softOf(p), 0, 20f, 0f)
            }

            val mins = d.totalStudyMinutes()
            row.findViewById<TextView>(R.id.tvDayStudy).text =
                if (mins > 0) DataStore.formatHoursMinBn(mins * 60L) else "—"
            row.findViewById<TextView>(R.id.tvDayCircles).text =
                if (d.c45 > 0) "${DataStore.toBnDigits(d.c45)}×৪৫মি" else ""
            row.findViewById<ProgressBar>(R.id.pbDay).apply {
                progress = (mins * 100 / goalMin).coerceIn(0, 100)
                progressTintList = ColorStateList.valueOf(p.accent)
                progressBackgroundTintList = ColorStateList.valueOf(p.cardBorder)
            }
            row.findViewById<TextView>(R.id.tvDayMeta).text =
                if (d.eatSec > 0L) "অপচয় ${DataStore.formatHoursMinBn(d.wasteSec)} · খাওয়া ${DataStore.formatHoursMinBn(d.eatSec)} · ঘুম ${DataStore.formatHoursMinBn(d.sleepOtherSec)}" else "অপচয় ${DataStore.formatHoursMinBn(d.wasteSec)} · ঘুম ${DataStore.formatHoursMinBn(d.sleepOtherSec)}"
            row.findViewById<ImageView>(R.id.ivWord).apply {
                imageTintList = ColorStateList.valueOf(if (d.wordTarget) p.accent else muted)
                alpha = if (d.wordTarget) 1f else 0.25f
            }
            routineContainer.addView(row)
            if (isToday) todayRow = row
        }

        if (scrollToToday && todayRow != null) {
            val target = todayRow
            (routineContainer.parent as? ScrollView)?.post {
                (routineContainer.parent as? ScrollView)?.scrollTo(0, (target.top - dp(8)).coerceAtLeast(0))
            }
        }
    }

    // ------------------------------------------------------------------ settings tab

    private fun renderSettingsTab() {
        val h = DataStore.getDailyGoalHours(this)
        tvGoalHoursVal.text = "${DataStore.toBnDigits(h)} ঘণ্টা"
        tvGoalNotifSub.text = "${DataStore.toBnDigits(h)} ঘণ্টা শেষ হলে জানাবে"
        if (swGoalNotif.isChecked != DataStore.isGoalNotifOn(this)) {
            updatingSrSwitches = true
            swGoalNotif.isChecked = DataStore.isGoalNotifOn(this)
            updatingSrSwitches = false
        }
        val exIso = DataStore.getExamDateIso(this)
        val exParts = exIso.split("-")
        val exBnDate = if (exParts.size == 3) {
            val y = DataStore.toBnDigits(exParts[0])
            val mo = bnMonths[(exParts[1].toIntOrNull() ?: 1).coerceIn(1, 12) - 1]
            val d = DataStore.toBnDigits(exParts[2].toIntOrNull() ?: 1)
            "$d $mo $y"
        } else DataStore.toBnDigits(exIso)
        val dbMin = DataStore.getDayStartMin(this)
        tvDayBoundarySub.text = if (dbMin == 0) "রাত ১২:০০ (ডিফল্ট · ট্যাপ করে বদলাও)" else "${DataStore.formatTime12hBn(dbMin)} থেকে নতুন দিন"
        tvExamSettingSub.text = "${DataStore.getExamName(this)} · $exBnDate (${DataStore.formatTime12hBn(DataStore.getExamTimeMin(this))}) · আর ${DataStore.formatExamCountdownBn(this)}"

        val g = DataStore.getGraceSec(this)
        val gCustom = g !in listOf(0, 3, 5, 10)
        setSegmentActive(btnGrace0, g == 0)
        setSegmentActive(btnGrace3, g == 3)
        setSegmentActive(btnGrace5, g == 5)
        setSegmentActive(btnGrace10, g == 10)
        btnGraceCustom.text = if (gCustom) "${DataStore.toBnDigits(g)} সে." else "কাস্টম"
        setSegmentActive(btnGraceCustom, gCustom)

        val am = DataStore.getAlarmMode(this)
        setSegmentActive(btnAlarmVib, am == "vibrate")
        setSegmentActive(btnAlarmSound, am == "sound")
        setSegmentActive(btnAlarmSilent, am == "silent")

        val tm = DataStore.getThemeMode(this)
        setSegmentActive(btnThemeDay, tm == "day")
        setSegmentActive(btnThemeNight, tm == "night")
        setSegmentActive(btnThemeAuto, tm == "auto")

        fun twoToneSwatch(primary: Int, secondary: Int, active: Boolean): android.graphics.drawable.Drawable {
            val outer = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(primary)
                setStroke(dp(2), if (active) Color.WHITE else ColorUtils.setAlphaComponent(secondary, 220))
                setSize(dp(14), dp(14))
            }
            val inner = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(secondary)
                setSize(dp(6), dp(6))
            }
            return android.graphics.drawable.LayerDrawable(arrayOf(outer, inner)).apply {
                setLayerInset(1, dp(4), dp(4), dp(4), dp(4))
            }
        }
        val cp = DataStore.getColorPalette(this)
        val night = isNightActive()
        val secColors = mapOf(
            "sage" to Color.parseColor("#F59E0B"),
            "ocean" to Color.parseColor("#2DD4BF"),
            "espresso" to Color.parseColor("#92400E"),
            "nordic" to Color.parseColor("#6366F1"),
            "lavender" to Color.parseColor("#7C3AED"),
            "forest" to Color.parseColor("#1B4332")
        )
        listOf(
            Triple(btnColor1, "sage" to "সেজ ও অ্যাম্বার", cp == "sage"),
            Triple(btnColor2, "ocean" to "ওশান ও টিল", cp == "ocean"),
            Triple(btnColor3, "espresso" to "এসপ্রেসো ও টিল", cp == "espresso"),
            Triple(btnColor4, "nordic" to "নর্ডিক ও স্লেট", cp == "nordic"),
            Triple(btnColor5, "lavender" to "ল্যাভেন্ডার ড্রিম", cp == "lavender"),
            Triple(btnColor6, "forest" to "ফরেস্ট গোল্ড", cp == "forest")
        ).forEach { (btn, idLabel, active) ->
            val (id, lbl) = idLabel
            setPillActive(btn, active)
            btn.text = lbl
            btn.setCompoundDrawablesRelativeWithIntrinsicBounds(
                twoToneSwatch(ThemePalette.get(id, night).accent, secColors[id] ?: Color.WHITE, active),
                null, null, null
            )
        }

        btnSrPopupStyle.text = "পপ-আপ মোড: " + when (DataStore.getSrPopupStyle(this)) {
            "compact" -> "Compact (ছোট পিল)"
            "standard" -> "Standard (মাঝারি)"
            "focus" -> "Focus (বড় স্পষ্ট)"
            else -> "বর্তমান (ডিফল্ট)"
        }
        btnSettingsDrawer.imageTintList = ColorStateList.valueOf(textColorMain(pal()))
        val savedUrl = DataStore.getGasUrl(this)
        val savedKey = DataStore.getSyncKey(this)
        if (savedUrl.isNotEmpty() && !syncEditorUnlocked) {
            syncLockedCard.visibility = View.VISIBLE
            syncEditorBox.visibility = View.GONE
            val shortUrl = if (savedUrl.length > 42) savedUrl.take(28) + "…" + savedUrl.takeLast(10) else savedUrl
            tvSyncMaskedUrl.text = "✓ সংযুক্ত · $shortUrl"
            tvSyncMaskedPass.text = if (savedKey.isNotEmpty()) "সিঙ্ক পাসওয়ার্ড: ••••••" else "সিঙ্ক পাসওয়ার্ড: সেট করা নেই"
            tvSyncLockedStamp.text = DataStore.getLastSyncText(this)
        } else {
            syncLockedCard.visibility = View.GONE
            syncEditorBox.visibility = View.VISIBLE
            if (!etGasUrl.hasFocus() && etGasUrl.text.toString() != savedUrl) etGasUrl.setText(savedUrl)
            if (!etSyncKey.hasFocus() && etSyncKey.text.toString() != savedKey) etSyncKey.setText(savedKey)
            if (!etSyncKeyConfirm.hasFocus() && etSyncKeyConfirm.text.toString() != savedKey) etSyncKeyConfirm.setText(savedKey)
        }

        val ws = DataStore.getWeekStartDay(this)
        setPillActive(btnWeekStartSun, ws == Calendar.SUNDAY)
        setPillActive(btnWeekStartSat, ws == Calendar.SATURDAY)

        // Smart Reminder UI state
        updatingSrSwitches = true
        val srOn = DataStore.isSrEnabled(this)
        if (swSrEnabled.isChecked != srOn) swSrEnabled.isChecked = srOn
        val serOn = DataStore.isSrSeriousMode(this)
        if (swSrSeriousMode.isChecked != serOn) swSrSeriousMode.isChecked = serOn
        boxSeriousControls.visibility = if (serOn) View.VISIBLE else View.GONE
        val serAfter = DataStore.getSrSeriousAfterMin(this)
        btnSrSeriousAfterMin.text = if (serAfter > 0) "সব সিরিয়াস শুরু: ফোনে ${DataStore.toBnDigits(serAfter)} মি. পর" else "সব সিরিয়াস শুরু: শুধু রাগ লেভেল ৪–৫"
        val serMaxHr = DataStore.getSrSeriousMaxPerHour(this)
        btnSrSeriousMaxHr.text = if (serMaxHr > 0) "ঘণ্টায় সর্বোচ্চ সিরিয়াস মেসেজ: ${DataStore.toBnDigits(serMaxHr)} বার" else "ঘণ্টায় সর্বোচ্চ সিরিয়াস মেসেজ: সীমাহীন"
        swGapAppSheet.isChecked = DataStore.isGapAppSheetOn(this)
        swGapPhonePopup.isChecked = DataStore.isGapPhonePopupOn(this)
        swGapNightNotif.isChecked = DataStore.isGapNightNotifOn(this)
        swGapAutoSleep.isChecked = DataStore.isGapAutoSleepOn(this)
        swHapticGlobal.isChecked = DataStore.isHapticGlobalOn(this)
        swHapticFlip.isChecked = DataStore.isHapticFlipOn(this)
        swHapticGoal.isChecked = DataStore.isHapticGoalOn(this)
        val hInt = DataStore.getHapticIntensity(this)
        btnHapticIntensity.text = when (hInt) {
            1 -> "তীব্রতা: খুব হালকা"
            2 -> "তীব্রতা: হালকা"
            3 -> "তীব্রতা: স্বাভাবিক"
            else -> "তীব্রতা: বন্ধ"
        }
        val srLvl = DataStore.getSrLevel(this)
        val chHero = MascotContent.resolveCharacter(this)
        ivReminderHeroMascot.setImageResource(MascotContent.mascotResFor(chHero, srLvl.coerceAtLeast(1)))
        tvReminderHeroStatus.text = "অবস্থা: ${if (srOn) "চালু" else "বন্ধ"} · আজকের রাগ লেভেল ${DataStore.toBnDigits(srLvl)} · সিরিয়াস ট্রিগার ${DataStore.toBnDigits(DataStore.getSrSeriousDailyCount(this))} বার"
        renderProfileUi()
        val qOn = DataStore.isSrQuietOn(this)
        if (swSrQuiet.isChecked != qOn) swSrQuiet.isChecked = qOn
        val cellOn = DataStore.isSrDashCellAlways(this)
        if (swDashCellAlways.isChecked != cellOn) swDashCellAlways.isChecked = cellOn
        updatingSrSwitches = false

        val notifBlocked = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        boxSrNotifWarn.visibility = if (srOn && notifBlocked) View.VISIBLE else View.GONE
        btnSrGapPhoneMin.text = "অজানা গ্যাপ পপআপ: ফোনে ${DataStore.toBnDigits(DataStore.getGapPhoneMin(this))} মি. পর"
        val wbH = DataStore.getWasteBudgetHours(this)
        btnWasteBudget.text = if (wbH > 0) "দৈনিক অপচয় বাজেট: ${DataStore.toBnDigits(wbH)} ঘণ্টা" else "দৈনিক অপচয় বাজেট: বন্ধ"
        DataStore.sampleBatteryDrop(this)
        tvSettingsBattery.text = "🔋 আজ সেশনে ব্যাটারি (আনুমানিক): ~${DataStore.toBnDigits(DataStore.getTodayBatteryDropPct(this))}%"
        tvMainSyncSummary.text = if (savedUrl.isNotEmpty()) "সংযুক্ত · ${DataStore.getLastSyncText(this)}" else "সেট করা নেই (ট্যাপ করে যুক্ত করো)"
        val ovOk = SmartReminderPopupOverlay.canDrawOverlay(this)
        tvAboutPermsStatus.text = "নোটিফিকেশন: ${if (notifBlocked) "বন্ধ" else "চালু"} · ওভারলে পপ-আপ: ${if (ovOk) "চালু" else "বন্ধ"}" 
        val overlayMissing = srOn && !SmartReminderPopupOverlay.canDrawOverlay(this)
        val pNow = pal()
        when {
            notifBlocked || overlayMissing -> {
                pillSmartReminder.text = "⚠ অনুমতি"
                pillSmartReminder.setTextColor(Color.WHITE)
                pillSmartReminder.background = ThemePalette.makeBg(this, Color.parseColor("#D97706"), Color.TRANSPARENT, 20f, 0f)
                tvSettingsSub.text = "অনুমতি ঠিক করা দরকার"
                viewSettingsAlertDot.visibility = View.VISIBLE
            }
            srOn -> {
                pillSmartReminder.text = "● চালু"
                pillSmartReminder.setTextColor(Color.WHITE)
                pillSmartReminder.background = ThemePalette.makeBg(this, Color.parseColor("#16A34A"), Color.TRANSPARENT, 20f, 0f)
                tvSettingsSub.text = "স্মার্ট রিমাইন্ডার চালু · ${MascotContent.formatDurationBn(DataStore.getSrAskDelayMin(this))} পর"
                viewSettingsAlertDot.visibility = View.GONE
            }
            else -> {
                pillSmartReminder.text = "○ বন্ধ"
                pillSmartReminder.setTextColor(ContextCompat.getColor(this, R.color.text_muted))
                pillSmartReminder.background = ThemePalette.makeBg(this, softOf(pNow), pNow.cardBorder, 20f, 1f)
                tvSettingsSub.text = "স্মার্ট রিমাইন্ডার বন্ধ"
                viewSettingsAlertDot.visibility = View.GONE
            }
        }
        if (notifBlocked || overlayMissing) {
            bannerMissingPerms.visibility = View.VISIBLE
            tvMissingPermsMsg.text = when {
                notifBlocked && overlayMissing -> "নোটিফিকেশন ও পপআপ (Overlay) অনুমতি বন্ধ আছে"
                notifBlocked -> "নোটিফিকেশন অনুমতি বন্ধ থাকায় রিমাইন্ডার কাজ করবে না"
                else -> "অন্য অ্যাপের ওপর পপআপ অনুমতি বন্ধ আছে"
            }
        } else {
            bannerMissingPerms.visibility = View.GONE
        }

        val hasOverlay = SmartReminderPopupOverlay.canDrawOverlay(this)
        val overlayOn = DataStore.isSrPopupOverlayOn(this)
        if (!hasOverlay) {
            tvSrOverlaySub.text = "অন্য অ্যাপের ওপর ৬০fps লাইভ পপ-আপ দেখাতে অনুমতি দাও"
            btnSrOverlayPerm.text = "অনুমতি দাও"
        } else if (overlayOn) {
            tvSrOverlaySub.text = "লাইভ ৬০fps ফ্লোটিং পপ-আপ সক্রিয় আছে"
            btnSrOverlayPerm.text = "চালু ✓"
        } else {
            tvSrOverlaySub.text = "ওভারলে বন্ধ (শুধু হেডস-আপ নোটিফিকেশন আসবে)"
            btnSrOverlayPerm.text = "চালু করো"
        }

        val ms = DataStore.getSrMascotStyle(this)
        setSegmentActive(btnSrMascotAuto, ms == "auto")
        setSegmentActive(btnSrMascotDragon, ms == "dragon")
        setSegmentActive(btnSrMascotGhost, ms == "ghost")

        val ask = DataStore.getSrAskDelayMin(this)
        val askCust = ask !in listOf(1, 2, 3)
        setSegmentActive(btnSrAsk1, ask == 1)
        setSegmentActive(btnSrAsk2, ask == 2)
        setSegmentActive(btnSrAsk3, ask == 3)
        btnSrAskCustom.text = if (askCust) "${DataStore.toBnDigits(ask)} মি." else "কাস্টম"
        setSegmentActive(btnSrAskCustom, askCust)

        val rep = DataStore.getSrRepeatMin(this)
        val repCust = rep !in listOf(3, 5, 10)
        setSegmentActive(btnSrRep3, rep == 3)
        setSegmentActive(btnSrRep5, rep == 5)
        setSegmentActive(btnSrRep10, rep == 10)
        btnSrRepCustom.text = if (repCust) "${DataStore.toBnDigits(rep)} মি." else "কাস্টম"
        setSegmentActive(btnSrRepCustom, repCust)

        val rec = DataStore.getSrReadRecheckMin(this)
        val recCust = rec !in listOf(10, 15, 30)
        setSegmentActive(btnSrRecheck10, rec == 10)
        setSegmentActive(btnSrRecheck15, rec == 15)
        setSegmentActive(btnSrRecheck30, rec == 30)
        btnSrRecheckCustom.text = if (recCust) "${DataStore.toBnDigits(rec)} মি." else "কাস্টম"
        setSegmentActive(btnSrRecheckCustom, recCust)

        val rst = DataStore.getSrReadResetMin(this)
        val rstCust = rst !in listOf(1, 3, 5)
        setSegmentActive(btnSrReset1, rst == 1)
        setSegmentActive(btnSrReset3, rst == 3)
        setSegmentActive(btnSrReset5, rst == 5)
        btnSrResetCustom.text = if (rstCust) "${DataStore.toBnDigits(rst)} মি." else "কাস্টম"
        setSegmentActive(btnSrResetCustom, rstCust)

        val idle = DataStore.getSrIdleMin(this)
        val idleCust = idle !in listOf(0, 30, 45, 60)
        setSegmentActive(btnSrIdle30, idle == 30)
        setSegmentActive(btnSrIdle45, idle == 45)
        setSegmentActive(btnSrIdle60, idle == 60)
        setSegmentActive(btnSrIdle0, idle == 0)
        btnSrIdleCustom.text = if (idleCust) DataStore.toBnDigits(idle) else "কাস্টম"
        setSegmentActive(btnSrIdleCustom, idleCust)

        val fb = DataStore.getSrFallbackDelaySec(this)
        val fbCust = fb !in listOf(10, 20, 30)
        setSegmentActive(btnSrFb10, fb == 10)
        setSegmentActive(btnSrFb20, fb == 20)
        setSegmentActive(btnSrFb30, fb == 30)
        btnSrFbCustom.text = if (fbCust) "${DataStore.toBnDigits(fb)} সে." else "কাস্টম"
        setSegmentActive(btnSrFbCustom, fbCust)

        val eat = DataStore.getSrEatMin(this)
        val eatCust = eat !in listOf(20, 30, 45)
        setSegmentActive(btnSrEat20, eat == 20)
        setSegmentActive(btnSrEat30, eat == 30)
        setSegmentActive(btnSrEat45, eat == 45)
        btnSrEatCustom.text = if (eatCust) "${DataStore.toBnDigits(eat)} মি." else "কাস্টম"
        setSegmentActive(btnSrEatCustom, eatCust)

        val st = DataStore.getSrStrictAfterMin(this)
        val stCust = st !in listOf(0, 20, 30, 45)
        setSegmentActive(btnSrStrict20, st == 20)
        setSegmentActive(btnSrStrict30, st == 30)
        setSegmentActive(btnSrStrict45, st == 45)
        setSegmentActive(btnSrStrict0, st == 0)
        btnSrStrictCustom.text = if (stCust) DataStore.toBnDigits(st) else "কাস্টম"
        setSegmentActive(btnSrStrictCustom, stCust)

        val cv = DataStore.getSrCallVibMin(this)
        val cvCust = cv !in listOf(0, 5, 10, 15)
        setSegmentActive(btnSrCall5, cv == 5)
        setSegmentActive(btnSrCall10, cv == 10)
        setSegmentActive(btnSrCall15, cv == 15)
        setSegmentActive(btnSrCall0, cv == 0)
        btnSrCallCustom.text = if (cvCust) DataStore.toBnDigits(cv) else "কাস্টম"
        setSegmentActive(btnSrCallCustom, cvCust)

        btnSrQuietStart.text = "শুরু: ${DataStore.formatTimeMinBn(DataStore.getSrQuietStartMin(this))}"
        btnSrQuietEnd.text = "শেষ: ${DataStore.formatTimeMinBn(DataStore.getSrQuietEndMin(this))}"
        btnSrQuietStart.alpha = if (qOn) 1f else 0.45f
        btnSrQuietEnd.alpha = if (qOn) 1f else 0.45f
    }

    // ------------------------------------------------------------------ start / stop

    override fun onStart() {
        super.onStart()
        SmartReminderManager.onAppForeground(this, true)
        focusRingView.setGlowActive(true)
        val filter = IntentFilter(FlipTrackerService.BROADCAST_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(stateReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(stateReceiver, filter)
        }
        refreshTimerUI()
        maybeShowBreakPrompt()
        ensureTickerIfNeeded()
        if (currentTab == 1) loadReportTab()
        if (currentTab == 3) renderSettingsTab()
    }

    override fun onStop() {
        super.onStop()
        SmartReminderManager.onAppForeground(this, false)
        focusRingView.setGlowActive(false)
        uiHandler.removeCallbacks(uiTicker)
        try { unregisterReceiver(stateReceiver) } catch (_: Exception) {}
        if (!DataStore.loadRuntimeState(this).running) {
            DataStore.markAppClosedNow(this)
        }
    }

    private fun completeSyncSettingsSave(url: String, key: String) {
        DataStore.setGasUrl(this, url)
        DataStore.setSyncKey(this, key)
        etGasUrl.clearFocus()
        etSyncKey.clearFocus()
        etSyncKeyConfirm.clearFocus()
        syncEditorUnlocked = false
        renderSettingsTab()
        Snackbar.make(findViewById(android.R.id.content), "সিঙ্ক সেটিংস যাচাই করে সেভ করা হয়েছে!", Snackbar.LENGTH_LONG).show()
    }

    private fun promptUnlockSyncEditor() {
        val currentKey = DataStore.getSyncKey(this)
        if (currentKey.isEmpty()) {
            MaterialAlertDialogBuilder(this)
                .setTitle("সিঙ্ক লিংক পরিবর্তন")
                .setMessage("সংযুক্ত Apps Script লিংক বা সিঙ্ক পাসওয়ার্ড পরিবর্তন করতে চান?")
                .setPositiveButton("হ্যাঁ") { _, _ ->
                    syncEditorUnlocked = true
                    renderSettingsTab()
                }
                .setNegativeButton("না", null)
                .show()
            return
        }

        val until = DataStore.getSyncLockUntilMs(this)
        val now = System.currentTimeMillis()
        if (until > now) {
            val sec = ((until - now) / 1000L).coerceAtLeast(1L)
            Snackbar.make(findViewById(android.R.id.content), "অনেকবার ভুল হয়েছে। ${DataStore.toBnDigits(sec)} সেকেন্ড পরে চেষ্টা করো।", Snackbar.LENGTH_LONG).show()
            return
        }

        val et = EditText(this).apply {
            hint = "বর্তমান সিঙ্ক পাসওয়ার্ড"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("সিঙ্ক সেটিংস আনলক")
            .setMessage("পরিবর্তন করতে বর্তমান সিঙ্ক পাসওয়ার্ড দাও।")
            .setView(et)
            .setPositiveButton("আনলক") { _, _ ->
                val entered = et.text.toString().trim()
                if (entered == currentKey) {
                    DataStore.resetSyncLockFailures(this)
                    syncEditorUnlocked = true
                    renderSettingsTab()
                } else {
                    val lockedUntil = DataStore.recordSyncLockFailure(this)
                    val msg = if (lockedUntil > System.currentTimeMillis()) "৫ বার ভুল হয়েছে, ৬০ সেকেন্ড অপেক্ষা করো।" else "ভুল সিঙ্ক পাসওয়ার্ড!"
                    Snackbar.make(findViewById(android.R.id.content), msg, Snackbar.LENGTH_LONG).show()
                }
            }
            .setNeutralButton("ভুলে গেছি (মূল পাসওয়ার্ড)") { _, _ ->
                promptMasterPasswordForSyncReset()
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun promptMasterPasswordForSyncReset() {
        val et = EditText(this).apply {
            hint = "অ্যাপ খোলার মূল পাসওয়ার্ড"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("মূল পাসওয়ার্ড দিয়ে রিসেট")
            .setMessage("অ্যাপ খোলার মূল পাসওয়ার্ড দিলে নতুন করে সিঙ্ক লিংক ও পাসওয়ার্ড সেট করতে পারবে। তোমার ফোনের লোকাল ডেটা মুছবে না।")
            .setView(et)
            .setPositiveButton("যাচাই করো") { _, _ ->
                if (DataStore.verifyAppMasterPassword(et.text.toString())) {
                    DataStore.resetSyncLockFailures(this)
                    syncEditorUnlocked = true
                    etSyncKey.setText("")
                    etSyncKeyConfirm.setText("")
                    renderSettingsTab()
                    Snackbar.make(findViewById(android.R.id.content), "মূল পাসওয়ার্ড মিলেছে! এখন নতুন সিঙ্ক পাসওয়ার্ড দুবার লিখে সেভ করো।", Snackbar.LENGTH_LONG).show()
                } else {
                    Snackbar.make(findViewById(android.R.id.content), "মূল পাসওয়ার্ড মেলেনি!", Snackbar.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun fixMissingPermissionsFromBanner() {
        val notifBlocked = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (notifBlocked) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 102)
        } else if (!SmartReminderPopupOverlay.canDrawOverlay(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
    }

    private fun setSmartReminderEnabled(checked: Boolean, askPerm: Boolean) {
        DataStore.setSrEnabled(this, checked)
        if (askPerm && checked && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 102)
        }
        SmartReminderManager.onSettingsChanged(this)
        renderSettingsTab()
    }

    private fun openSettingsDrawer() {
        val p = pal()
        val grace = DataStore.getGraceSec(this)
        val srOn = DataStore.isSrEnabled(this)
        val mascotBn = when (DataStore.getSrMascotStyle(this)) {
            "dragon" -> "ড্রাগন"
            "ghost" -> "রাতের ভূত"
            else -> "অটো (ঘড়ি অনুযায়ী)"
        }
        val quietBn = if (DataStore.isSrQuietOn(this)) {
            "${DataStore.formatTimeMinBn(DataStore.getSrQuietStartMin(this))}–${DataStore.formatTimeMinBn(DataStore.getSrQuietEndMin(this))}"
        } else "বন্ধ"
        val syncOk = DataStore.getGasUrl(this).isNotEmpty()
        val unsynced = DataStore.hasUnsyncedDays(this)
        val notifBlocked = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        val permMissing = notifBlocked || (srOn && !SmartReminderPopupOverlay.canDrawOverlay(this))

        val profName = DataStore.getProfNickname(this).ifEmpty { "সেট করা নেই" }
        showAnchoredMenu(btnSettingsDrawer, listOf(
            AnchoredMenuItem("প্রোফাইল", R.drawable.ic_edit, p.accent, "আমার প্রোফাইল", "$profName · ${DataStore.getProfCadre(this)}") {
                openSettingsPage(6)
            },
            AnchoredMenuItem("রিমাইন্ডার", R.drawable.ic_calendar, CategoryColors.EAT_INT, "স্মার্ট রিমাইন্ডার (সময়সূচি)", if (srOn) "চালু · ${DataStore.toBnDigits(DataStore.getSrAskDelayMin(this))} মি. পর" else "বন্ধ", badgeDot = permMissing) {
                openSettingsPage(1)
            },
            AnchoredMenuItem("রিমাইন্ডার", R.drawable.ic_flame, CategoryColors.WASTE_INT, "মাসকট ও পপআপ", mascotBn) {
                openSettingsPage(2)
            },
            AnchoredMenuItem("রিমাইন্ডার", R.drawable.ic_moon, CategoryColors.SLEEP_INT, "শান্ত সময় ও কল", "$quietBn · কল ভাইব ${DataStore.toBnDigits(DataStore.getSrCallVibMin(this))} মি.") {
                openSettingsPage(3)
            },
            AnchoredMenuItem("পড়া", R.drawable.ic_timer, p.accent, "ফ্লিপ ও গ্রেস টাইম", "গ্রেস ${DataStore.toBnDigits(grace)} সেকেন্ড") {
                openSettingsPage(0)
            },
            AnchoredMenuItem("পড়া", R.drawable.ic_bookmark, p.accent, "লক্ষ্য ও পরীক্ষা (বিস্তারিত)", "${DataStore.getExamName(this)} · আর ${DataStore.formatExamCountdownBn(this)}") {
                showExamDialog()
            },
            AnchoredMenuItem("রিমাইন্ডার", R.drawable.ic_timer, CategoryColors.AWAY_INT, "সময়ের হিসাব ও গ্যাপ", "গ্যাপ শিট, পপআপ ও রাতের নোটিফিকেশন") {
                openSettingsPage(7)
            },
            AnchoredMenuItem("ডেটা", R.drawable.ic_chart, CategoryColors.AWAY_INT, "ডেটা, সিঙ্ক ও এক্সপোর্ট", if (syncOk) DataStore.getLastSyncText(this) else "সংযুক্ত নয়", badgeDot = unsynced) {
                openSettingsPage(4)
            },
            AnchoredMenuItem("ডেটা", R.drawable.ic_check, p.accent, "ব্যাটারি ও অনুমতি", if (permMissing) "অনুমতি দরকার" else "সব অনুমতি চালু", badgeDot = permMissing) {
                openSettingsPage(5)
            },
            AnchoredMenuItem("অন্যান্য", R.drawable.ic_settings, ContextCompat.getColor(this, R.color.text_muted), "অ্যাপ সম্পর্কে ও সাহায্য", "ভার্সন ৯.৪ · লং-প্রেস টিপস") {
                openSettingsPage(5)
            }
        ))
    }

    private fun closeSettingsDrawer() {
        settingsDrawerPanel.animate()
            .translationX(dp(290).toFloat())
            .setDuration(200L)
            .setInterpolator(AccelerateInterpolator())
            .withEndAction { settingsDrawerOverlay.visibility = View.GONE }
            .start()
        settingsDrawerScrim.animate().alpha(0f).setDuration(200L).start()
    }

    private fun openSettingsPage(n: Int) {
        if (n == 6 && !settingsUnlockedInSession) {
            requireSettingsAuth { openSettingsPage(6) }
            return
        }
        if (n !in settingsSubPages.indices) return
        settingsPage = n
        settingsMainPage.visibility = View.GONE
        settingsSubPages.forEachIndexed { i, v ->
            if (i == n) {
                v.visibility = View.VISIBLE
                v.translationX = resources.displayMetrics.widthPixels * 0.35f
                v.alpha = 0f
                v.animate().withLayer().translationX(0f).alpha(1f).setDuration(190L).setInterpolator(DecelerateInterpolator()).start()
            } else {
                v.visibility = View.GONE
            }
        }
        renderSettingsTab()
    }

    private fun closeSettingsPage() {
        val cur = settingsSubPages.getOrNull(settingsPage)
        settingsPage = -1
        settingsMainPage.visibility = View.VISIBLE
        if (cur != null) {
            cur.animate()
                .translationX(resources.displayMetrics.widthPixels * 0.35f)
                .alpha(0f)
                .setDuration(200L)
                .withEndAction { cur.visibility = View.GONE; cur.translationX = 0f; cur.alpha = 1f }
                .start()
        }
        renderSettingsTab()
    }

    private fun showTestHourDialog() {
        val hours = (0..23).map { h -> "${DataStore.toBnDigits(String.format(Locale.US, "%02d:00", h))}" }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("ঘণ্টা নকল করে ম্যাসেজ টেস্ট")
            .setItems(hours) { _, which ->
                MascotContent.debugMockHour = which
                val ch = MascotContent.resolveCharacter(this, which)
                val msg = MascotContent.messageFor(this, MascotContent.KIND_ASK, 1, 10, 0)
                val chBn = if (ch == "ghost") "রাতের ভূত" else "ড্রাগন"
                MaterialAlertDialogBuilder(this)
                    .setTitle("${hours[which]} · $chBn")
                    .setMessage(msg)
                    .setPositiveButton("প্রিভিউ দেখাও") { _, _ ->
                        SmartReminderPopupOverlay.show(this, MascotContent.KIND_ASK, 1, 10, 0)
                    }
                    .setNegativeButton("রিসেট (আসল সময়)") { _, _ ->
                        MascotContent.debugMockHour = -1
                    }
                    .show()
            }
            .setNeutralButton("আসল সময় চালু") { _, _ ->
                MascotContent.debugMockHour = -1
            }
            .show()
    }

    private fun maybeShowBreakPrompt() {
        SmartReminderManager.checkExpiredBreaks(this)
        val brk = SmartReminderManager.getActiveBreakInfo(this) ?: return
        val now = System.currentTimeMillis()
        if (now - DataStore.getLastBreakPromptMs(this) < 4 * 60_000L) return
        DataStore.setLastBreakPromptMs(this, now)

        val remMin = ((brk.remainingMs + 59_999L) / 60_000L).toInt().coerceAtLeast(1)
        val totalMin = brk.totalMin.coerceAtLeast(remMin).coerceAtLeast(1)
        val elapsedFrac = (1f - (brk.remainingMs.toFloat() / (totalMin * 60_000f))).coerceIn(0.06f, 1f)
        val isEat = brk.type == SmartReminderManager.PHASE_EATING
        val p = pal()
        val accent = if (isEat) Color.parseColor("#D97706") else Color.parseColor("#0D9488")
        val textMain = ContextCompat.getColor(this, R.color.text_main)
        val textMuted = ContextCompat.getColor(this, R.color.text_muted)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(18))
            background = ThemePalette.makeBg(this@MainActivity, p.cardBg, p.cardBorder, 24f, 1f)
        }

        // Top row: icon badge + title + remaining pill
        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val iconBadge = TextView(this).apply {
            text = if (isEat) "🍽️" else "🚶"
            textSize = 20f
            gravity = Gravity.CENTER
            background = ThemePalette.makeBg(this@MainActivity, ColorUtils.setAlphaComponent(accent, 34), ColorUtils.setAlphaComponent(accent, 85), 14f, 1f)
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(12) }
        }
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        titleCol.addView(TextView(this).apply {
            text = if (isEat) "খাওয়া চলছে" else "বাইরে আছো"
            setTextColor(textMain)
            textSize = 17f
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        titleCol.addView(TextView(this).apply {
            text = if (isEat) "বিরতি ট্র্যাকিং চালু আছে" else brk.reason
            setTextColor(textMuted)
            textSize = 12f
        })
        val remPill = TextView(this).apply {
            text = "আর ${MascotContent.formatDurationBn(remMin)}"
            setTextColor(accent)
            textSize = 11.5f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(dp(10), dp(5), dp(10), dp(5))
            background = ThemePalette.makeBg(this@MainActivity, ColorUtils.setAlphaComponent(accent, 28), ColorUtils.setAlphaComponent(accent, 90), 14f, 1f)
        }
        topRow.addView(iconBadge)
        topRow.addView(titleCol)
        topRow.addView(remPill)
        card.addView(topRow)

        // Description
        card.addView(TextView(this).apply {
            text = if (isEat) {
                "খাওয়া শেষ হয়ে থাকলে এখনই পড়া শুরু করো, অথবা শুধু বিরতি শেষ করে রাখো।"
            } else {
                "বাসায় ফিরে এসে থাকলে ‘ফিরে এসেছি’ চাপো, অথবা সময় বদলে নিতে পারো।"
            }
            setTextColor(textMuted)
            textSize = 13f
            setLineSpacing(dp(3).toFloat(), 1f)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(14)
            }
        })

        // Progress bar + meta caption
        val progBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = ThemePalette.makeBg(this@MainActivity, softOf(p), p.cardBorder, 14f, 1f)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(12)
            }
        }
        val track = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = ThemePalette.makeBg(this@MainActivity, ColorUtils.setAlphaComponent(accent, 36), Color.TRANSPARENT, 4f, 0f)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(6))
        }
        val fill = View(this).apply {
            background = ThemePalette.makeBg(this@MainActivity, accent, Color.TRANSPARENT, 4f, 0f)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, elapsedFrac)
        }
        val remSpace = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, (1f - elapsedFrac).coerceAtLeast(0.001f))
        }
        track.addView(fill)
        track.addView(remSpace)
        progBox.addView(track)
        progBox.addView(TextView(this).apply {
            text = "মোট ${MascotContent.formatDurationBn(totalMin)} · বাকি ${MascotContent.formatDurationBn(remMin)}"
            setTextColor(textMuted)
            textSize = 11f
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(6)
            }
        })
        card.addView(progBox)

        val dialog = MaterialAlertDialogBuilder(this)
            .setView(card)
            .create()

        // Primary full-width CTA
        val btnPrimary = TextView(this).apply {
            text = if (isEat) "▶  খাওয়া শেষ · এখনই পড়া শুরু" else "✓  ফিরে এসেছি"
            setTextColor(p.pillActiveText)
            textSize = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            background = ThemePalette.makeBg(this@MainActivity, p.pillActiveBg, Color.TRANSPARENT, 14f, 0f)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(46)).apply {
                topMargin = dp(16)
            }
            setOnClickListener {
                dialog.dismiss()
                if (isEat) {
                    SmartReminderManager.finishEatingNow(this@MainActivity)
                    SmartReminderManager.onStartStudyFromIdle(this@MainActivity)
                    refreshTimerUI()
                } else {
                    SmartReminderManager.returnFromAway(this@MainActivity)
                    refreshTimerUI()
                    Snackbar.make(findViewById(android.R.id.content), "বাইরের সময় সেভ হয়েছে!", Snackbar.LENGTH_SHORT).show()
                }
            }
        }
        card.addView(btnPrimary)

        // Secondary 2-button row
        val secRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(8)
            }
        }
        val btnSec1 = TextView(this).apply {
            text = if (isEat) "✓ শুধু খাওয়া শেষ" else "⏱ সময় বদলাও"
            setTextColor(textMain)
            textSize = 12.5f
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            background = ThemePalette.makeBg(this@MainActivity, softOf(p), p.cardBorder, 12f, 1f)
            layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(6) }
            setOnClickListener {
                dialog.dismiss()
                if (isEat) {
                    SmartReminderManager.finishEatingNow(this@MainActivity)
                    refreshTimerUI()
                    Snackbar.make(findViewById(android.R.id.content), "খাওয়ার সময় সেভ হয়েছে!", Snackbar.LENGTH_SHORT).show()
                } else {
                    showAwayDurationDialog()
                }
            }
        }
        val btnSec2 = TextView(this).apply {
            text = if (isEat) "এখনো খাচ্ছি" else "এখনো বাইরে"
            setTextColor(textMuted)
            textSize = 12.5f
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            background = ThemePalette.makeBg(this@MainActivity, softOf(p), p.cardBorder, 12f, 1f)
            layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(6) }
            setOnClickListener { dialog.dismiss() }
        }
        secRow.addView(btnSec1)
        secRow.addView(btnSec2)
        card.addView(secRow)

        dialog.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        dialog.show()
    }

    private fun View.attachHoldHelp(helpKey: Int = this.id, holdMs: Long = 1200L) {
        var downX = 0f
        var downY = 0f
        var fired = false
        val slop = ViewConfiguration.get(context).scaledTouchSlop
        val h = Handler(Looper.getMainLooper())
        val trigger = Runnable {
            fired = true
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            showHelpDialog(helpKey)
        }
        setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    fired = false
                    downX = ev.x
                    downY = ev.y
                    h.postDelayed(trigger, holdMs)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (kotlin.math.abs(ev.x - downX) > slop || kotlin.math.abs(ev.y - downY) > slop) {
                        h.removeCallbacks(trigger)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    h.removeCallbacks(trigger)
                }
            }
            false
        }
        setOnLongClickListener {
            if (fired) {
                fired = false
                true
            } else {
                showHelpDialog(helpKey)
                true
            }
        }
        ViewCompat.replaceAccessibilityAction(
            this,
            AccessibilityNodeInfoCompat.AccessibilityActionCompat.ACTION_LONG_CLICK,
            "ব্যাখ্যা দেখাও"
        ) { _, _ ->
            showHelpDialog(helpKey)
            true
        }
    }

    private fun showHelpDialog(helpKey: Int) {
        val item = HelpContent.forKey(this, helpKey) ?: return
        MaterialAlertDialogBuilder(this)
            .setTitle(item.title)
            .setMessage("${item.what}\n\n💡 টিপস: ${item.tip}")
            .setPositiveButton("বুঝেছি", null)
            .show()
    }

    private fun attachHelpTooltips() {
        listOf(
            btnManualStudy, btnManualWaste, btnPreset45, btnPreset10, btnPreset5, btnPresetCustom,
            swFlipService, swOnlineStudy, cardStudyLive, cardWasteLive, tvSubjectChip, examStripCard,
            btnOpenDashboard, btnReportMenu, btnRepDay, btnRepWeek, btnRepMonth, btnRepYear,
            tvPeriodTitle, btnReportToday, pillSmartReminder, swSrEnabled, btnUnlockSyncEditor
        ).forEach { v -> v.attachHoldHelp(v.id) }
    }

    private fun updateColorSwatchesOnly() {
        fun twoToneSwatch(primary: Int, secondary: Int, active: Boolean): android.graphics.drawable.Drawable {
            val outer = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(primary)
                setStroke(dp(2), if (active) Color.WHITE else ColorUtils.setAlphaComponent(secondary, 220))
                setSize(dp(14), dp(14))
            }
            val inner = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(secondary)
                setSize(dp(6), dp(6))
            }
            return android.graphics.drawable.LayerDrawable(arrayOf(outer, inner)).apply {
                setLayerInset(1, dp(4), dp(4), dp(4), dp(4))
            }
        }
        val cp = DataStore.getColorPalette(this)
        val night = isNightActive()
        val secColors = mapOf(
            "sage" to Color.parseColor("#F59E0B"),
            "ocean" to Color.parseColor("#2DD4BF"),
            "espresso" to Color.parseColor("#92400E"),
            "nordic" to Color.parseColor("#6366F1"),
            "lavender" to Color.parseColor("#7C3AED"),
            "forest" to Color.parseColor("#1B4332")
        )
        listOf(
            Triple(btnColor1, "sage" to "সেজ ও অ্যাম্বার", cp == "sage"),
            Triple(btnColor2, "ocean" to "ওশান ও টিল", cp == "ocean"),
            Triple(btnColor3, "espresso" to "এসপ্রেসো ও টিল", cp == "espresso"),
            Triple(btnColor4, "nordic" to "নর্ডিক ও স্লেট", cp == "nordic"),
            Triple(btnColor5, "lavender" to "ল্যাভেন্ডার ড্রিম", cp == "lavender"),
            Triple(btnColor6, "forest" to "ফরেস্ট গোল্ড", cp == "forest")
        ).forEach { (btn, idLabel, active) ->
            val (id, lbl) = idLabel
            setPillActive(btn, active)
            btn.text = lbl
            btn.setCompoundDrawablesRelativeWithIntrinsicBounds(
                twoToneSwatch(ThemePalette.get(id, night).accent, secColors[id] ?: Color.WHITE, active),
                null, null, null
            )
        }
    }

    private fun renderProfileUi() {
        val nick = DataStore.getProfNickname(this)
        val ageInfo = DataStore.computeProfileAgeAndRemaining(this)
        tvProfileAvatar.text = if (nick.isNotEmpty()) nick.take(1) else "প্র"
        tvProfileName.text = if (nick.isNotEmpty()) nick else "প্রোফাইল সেট করো"
        tvProfileAgeSub.text = if (ageInfo != null) {
            "বয়স ${DataStore.toBnDigits(ageInfo.first)} · চাকরির বয়স বাকি ${ageInfo.second}"
        } else {
            "${DataStore.getProfCadre(this)} · জন্মতারিখ যোগ করো"
        }
        btnProfNickname.text = "ডাকনাম: ${nick.ifEmpty { "সেট করো" }}"
        val dob = DataStore.getProfDobIso(this)
        btnProfDob.text = "জন্মতারিখ: ${if (dob.isNotEmpty()) DataStore.toBnDigits(dob) else "সেট করো"}"
        btnProfGender.text = "লিঙ্গ (ঐচ্ছিক): ${DataStore.getProfGender(this).ifEmpty { "উল্লেখ নয়" }}"
        btnProfStatus.text = "বর্তমান অবস্থা: ${DataStore.getProfStatus(this)}"
        btnProfCadre.text = "লক্ষ্য পদ/ক্যাডার: ${DataStore.getProfCadre(this)}"
        btnProfTargetYear.text = "টার্গেট সাল: ${DataStore.getProfTargetYear(this)}"
        btnProfMaxAge.text = "আবেদনের সর্বোচ্চ বয়স: ${DataStore.toBnDigits(DataStore.getProfMaxAge(this))} বছর"
    }

    private fun editProfileText(title: String, current: String, onSave: (String) -> Unit) {
        val isYear = title.contains("সাল")
        val maxLen = if (isYear) 4 else if (title.contains("ডাকনাম")) 25 else 40
        val et = EditText(this).apply {
            setText(current)
            if (isYear) inputType = InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(android.text.InputFilter.LengthFilter(maxLen))
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        val dlg = MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setView(et)
            .setPositiveButton("সেভ", null)
            .setNegativeButton("বাতিল", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val txt = et.text.toString().trim()
                if (txt.isEmpty()) {
                    et.error = "খালি রাখা যাবে না"
                    return@setOnClickListener
                }
                if (isYear) {
                    val y = txt.toIntOrNull()
                    if (y == null || y !in 2024..2045) {
                        et.error = "সঠিক সাল দাও (২০২৪–২০৪৫)"
                        return@setOnClickListener
                    }
                }
                onSave(txt)
                dlg.dismiss()
            }
        }
        dlg.show()
    }

    private fun pickProfileChoice(title: String, opts: Array<String>, onPick: (String) -> Unit) {
        MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setItems(opts) { _, w -> onPick(opts[w]) }
            .show()
    }

    private fun pickProfileDob() {
        val cal = Calendar.getInstance()
        val cur = DataStore.getProfDobIso(this)
        if (DataStore.isValidIsoDate(cur)) {
            try { cal.time = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(cur)!! } catch (_: Exception) {}
        } else {
            cal.set(1999, 0, 1)
        }
        val dlg = DatePickerDialog(
            this, R.style.AppDatePicker,
            { _, y, mo, d ->
                DataStore.setProfDobIso(this, String.format(Locale.US, "%04d-%02d-%02d", y, mo + 1, d))
                renderProfileUi()
            },
            cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)
        )
        dlg.datePicker.maxDate = System.currentTimeMillis()
        dlg.show()
    }

    private fun pickProfileMaxAge() {
        val ages = (28..35).toList()
        val labels = ages.map { "${DataStore.toBnDigits(it)} বছর" }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("আবেদনের সর্বোচ্চ বয়সসীমা")
            .setItems(labels) { _, w ->
                DataStore.setProfMaxAge(this, ages[w])
                renderProfileUi()
            }
            .show()
    }

    private fun maybeShowGapBottomSheet(force: Boolean = false) {
        if (!force && !DataStore.isGapAppSheetOn(this)) return
        val rt = DataStore.loadRuntimeState(this)
        if (!force && rt.running && rt.mode == "STUDY") return
        val gap = DataStore.getUnansweredGaps(this).firstOrNull() ?: run {
            if (force) Snackbar.make(findViewById(android.R.id.content), "এখন কোনো অজানা সময়ের গ্যাপ নেই!", Snackbar.LENGTH_SHORT).show()
            return
        }
        val todayIso = DataStore.todayIso()
        if (!force && DataStore.getLastGapSheetDate(this) == todayIso) return
        DataStore.setLastGapSheetDate(this, todayIso)

        val dlg = BottomSheetDialog(this)
        val p = pal()
        val muted = ContextCompat.getColor(this, R.color.text_muted)
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = ThemePalette.makeBg(this@MainActivity, p.cardBg, p.cardBorder, 20f, 1f)
            setPadding(dp(20), dp(16), dp(20), dp(22))
        }
        wrap.addView(TextView(this).apply {
            text = "সময়ের হিসাব মেলানো বাকি"
            textSize = 15.5f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(textColorMain(p))
        })
        wrap.addView(TextView(this).apply {
            text = "${DataStore.formatGapWindowBn(gap.startMs, gap.endMs)} — কী করছিলে?"
            textSize = 13.5f
            setTextColor(p.accent)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, dp(4), 0, dp(10))
        })

        val todayRec = DataStore.getToday(this)
        val bar = Day24BarView(this).apply {
            setData(
                todayRec.totalStudyMinutes(),
                (todayRec.wasteSec / 60L).toInt(),
                (todayRec.eatSec / 60L).toInt(),
                (todayRec.awaySec / 60L).toInt(),
                (todayRec.sleepOtherSec / 60L).toInt(),
                (todayRec.otherSec / 60L).toInt(),
                p.accent,
                p.cardBorder
            )
        }
        wrap.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(12)).apply { bottomMargin = dp(12) })

        val etNote = EditText(this).apply {
            hint = "ঐচ্ছিক নোট (যেমন: কোচিং বা বিষয়)"
            background = ThemePalette.makeBg(this@MainActivity, softOf(p), p.cardBorder, 12f, 1f)
            setTextColor(textColorMain(p))
            setHintTextColor(muted)
            textSize = 13f
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        wrap.addView(etNote, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) })

        val cats = listOf(
            Triple("পড়েছি", "STUDY", p.accent),
            Triple("বাইরে ছিলাম", "AWAY", CategoryColors.AWAY_INT),
            Triple("খেয়েছি", "EAT", CategoryColors.EAT_INT),
            Triple("ঘুম/বিশ্রাম", "SLEEP", CategoryColors.SLEEP_INT),
            Triple("দৈনন্দিন কাজ", "OTHER", CategoryColors.OTHER_INT),
            Triple("অপচয়", "WASTE", CategoryColors.WASTE_INT)
        )
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        cats.forEachIndexed { i, (label, code, col) ->
            val chip = TextView(this).apply {
                text = label
                textSize = 12.5f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(textColorMain(p))
                background = ThemePalette.makeBg(this@MainActivity, ColorUtils.setAlphaComponent(col, 32), col, 12f, 1f)
                setPadding(dp(8), dp(11), dp(8), dp(11))
                setOnClickListener {
                    it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    DataStore.classifyGap(this@MainActivity, gap.id, code, etNote.text.toString())
                    dlg.dismiss()
                    refreshTimerUI()
                    if (currentTab == 1) loadReportTab()
                    Snackbar.make(findViewById(android.R.id.content), "'$label' হিসেবে হিসাব যুক্ত হয়েছে!", Snackbar.LENGTH_SHORT).show()
                }
            }
            val targetRow = if (i < 3) row1 else row2
            targetRow.addView(chip, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (targetRow.childCount > 0) marginStart = dp(8)
            })
        }
        wrap.addView(row1)
        wrap.addView(row2, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })

        wrap.addView(TextView(this).apply {
            text = "পরে বলবো ▾"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(muted)
            setPadding(0, dp(14), 0, dp(4))
            setOnClickListener {
                val opts = arrayOf("আজ রাতে মনে করিও (রাত ৯:০০)", "কাল সকালে মনে করিও (সকাল ৮:০০)", "আর জিজ্ঞেস করো না (অনির্ধারিতে রাখো)")
                MaterialAlertDialogBuilder(this@MainActivity)
                    .setTitle("কখন মনে করাবো?")
                    .setItems(opts) { _, which ->
                        val cal = Calendar.getInstance()
                        when (which) {
                            0 -> {
                                cal.set(Calendar.HOUR_OF_DAY, 21); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
                                if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
                                DataStore.snoozeGap(this@MainActivity, gap.id, cal.timeInMillis)
                            }
                            1 -> {
                                cal.add(Calendar.DAY_OF_YEAR, 1)
                                cal.set(Calendar.HOUR_OF_DAY, 8); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
                                DataStore.snoozeGap(this@MainActivity, gap.id, cal.timeInMillis)
                            }
                            else -> DataStore.deferGap(this@MainActivity, gap.id)
                        }
                        dlg.dismiss()
                        refreshTimerUI()
                        if (currentTab == 1) loadReportTab()
                    }
                    .show()
            }
        })
        dlg.setContentView(wrap)
        dlg.show()
    }
}
