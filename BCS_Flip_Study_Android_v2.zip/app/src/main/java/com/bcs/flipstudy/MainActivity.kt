package com.bcs.flipstudy

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var tabTimer: View
    private lateinit var tabReport: View
    private lateinit var tabRoutine: View
    private lateinit var tabSettings: View

    private lateinit var navTimer: TextView
    private lateinit var navReport: TextView
    private lateinit var navRoutine: TextView
    private lateinit var navSettings: TextView

    // Timer UI
    private lateinit var btnTopTheme: TextView
    private lateinit var tvModeStatus: TextView
    private lateinit var btnTopAlarm: TextView
    private lateinit var examStripCard: View
    private lateinit var tvExamLabel: TextView
    private lateinit var tvStreakChip: TextView
    private lateinit var tvExamDaysPill: TextView
    private lateinit var focusRingView: FocusRingView
    private lateinit var tvTimerClock: TextView
    private lateinit var tvSubjectChip: TextView
    private lateinit var tvGoalProgressText: TextView
    private lateinit var pbDailyGoal: ProgressBar
    private lateinit var btnPreset45: TextView
    private lateinit var btnPreset10: TextView
    private lateinit var btnPreset5: TextView
    private lateinit var btnPresetCustom: TextView
    private lateinit var tvFlipTitle: TextView
    private lateinit var tvFlipSub: TextView
    private lateinit var swFlipService: Switch
    private lateinit var swOnlineStudy: Switch
    private lateinit var cardWasteLive: View
    private lateinit var tvStudyLiveClock: TextView
    private lateinit var tvWasteLiveClock: TextView

    // Report UI
    private lateinit var btnPrevPeriod: TextView
    private lateinit var btnNextPeriod: TextView
    private lateinit var tvPeriodTitle: TextView
    private lateinit var btnToggleYearly: TextView
    private lateinit var tvReportOfflineBadge: TextView
    private lateinit var tvReportSummary: TextView
    private lateinit var reportBarChart: WeeklyBarChartView
    private lateinit var heatmapView: HeatmapView
    private lateinit var tvReportBreakdown: TextView
    private lateinit var tvSyncStatus: TextView
    private lateinit var btnSyncNow: TextView
    private lateinit var btnExportCsv: TextView

    // Routine UI
    private lateinit var tvRoutineHeader: TextView
    private lateinit var chkWordTarget: CheckBox
    private lateinit var routineContainer: LinearLayout

    // Settings UI
    private lateinit var btnGoalMinus: TextView
    private lateinit var btnGoalPlus: TextView
    private lateinit var tvGoalHoursVal: TextView
    private lateinit var tvGoalNotifSub: TextView
    private lateinit var swGoalNotif: Switch
    private lateinit var rowEditExam: View
    private lateinit var tvExamSettingSub: TextView
    private lateinit var btnGrace0: TextView
    private lateinit var btnGrace3: TextView
    private lateinit var btnGrace5: TextView
    private lateinit var btnGrace10: TextView
    private lateinit var btnAlarmVib: TextView
    private lateinit var btnAlarmSound: TextView
    private lateinit var btnAlarmSilent: TextView
    private lateinit var btnThemeDay: TextView
    private lateinit var btnThemeNight: TextView
    private lateinit var btnThemeAuto: TextView
    private lateinit var etGasUrl: EditText
    private lateinit var etSyncKey: EditText
    private lateinit var btnSaveSettings: TextView

    private var reportYearly = false
    private var reportYear = Calendar.getInstance().get(Calendar.YEAR)
    private var reportMonth = Calendar.getInstance().get(Calendar.MONTH) + 1

    private val uiHandler = Handler(Looper.getMainLooper())
    private val uiTicker = object : Runnable {
        override fun run() {
            refreshTimerUI()
            uiHandler.postDelayed(this, 1000L)
        }
    }

    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshTimerUI()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        applySavedThemeMode()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        requestNotificationPermissionIfNeeded()
        DailySyncWorker.scheduleDaily(this)

        val absorbed = DataStore.absorbClosedTimeAsSleepOther(this)
        if (absorbed >= 60L) {
            Toast.makeText(
                this,
                "অ্যাপ বন্ধ থাকা ${DataStore.formatHoursMinBn(absorbed)} ঘুম ও অন্যান্য সময়ে যোগ হয়েছে",
                Toast.LENGTH_LONG
            ).show()
        }

        bindViews()
        setupListeners()
        showTab(0)
        refreshAllUI()
    }

    private fun applySavedThemeMode() {
        val mode = when (DataStore.getThemeMode(this)) {
            "day" -> AppCompatDelegate.MODE_NIGHT_NO
            "night" -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }
        AppCompatDelegate.setDefaultNightMode(mode)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }
    }

    private fun bindViews() {
        tabTimer = findViewById(R.id.tabTimer)
        tabReport = findViewById(R.id.tabReport)
        tabRoutine = findViewById(R.id.tabRoutine)
        tabSettings = findViewById(R.id.tabSettings)

        navTimer = findViewById(R.id.navTimer)
        navReport = findViewById(R.id.navReport)
        navRoutine = findViewById(R.id.navRoutine)
        navSettings = findViewById(R.id.navSettings)

        btnTopTheme = findViewById(R.id.btnTopTheme)
        tvModeStatus = findViewById(R.id.tvModeStatus)
        btnTopAlarm = findViewById(R.id.btnTopAlarm)
        examStripCard = findViewById(R.id.examStripCard)
        tvExamLabel = findViewById(R.id.tvExamLabel)
        tvStreakChip = findViewById(R.id.tvStreakChip)
        tvExamDaysPill = findViewById(R.id.tvExamDaysPill)
        focusRingView = findViewById(R.id.focusRingView)
        tvTimerClock = findViewById(R.id.tvTimerClock)
        tvSubjectChip = findViewById(R.id.tvSubjectChip)
        tvGoalProgressText = findViewById(R.id.tvGoalProgressText)
        pbDailyGoal = findViewById(R.id.pbDailyGoal)
        btnPreset45 = findViewById(R.id.btnPreset45)
        btnPreset10 = findViewById(R.id.btnPreset10)
        btnPreset5 = findViewById(R.id.btnPreset5)
        btnPresetCustom = findViewById(R.id.btnPresetCustom)
        tvFlipTitle = findViewById(R.id.tvFlipTitle)
        tvFlipSub = findViewById(R.id.tvFlipSub)
        swFlipService = findViewById(R.id.swFlipService)
        swOnlineStudy = findViewById(R.id.swOnlineStudy)
        cardWasteLive = findViewById(R.id.cardWasteLive)
        tvStudyLiveClock = findViewById(R.id.tvStudyLiveClock)
        tvWasteLiveClock = findViewById(R.id.tvWasteLiveClock)

        btnPrevPeriod = findViewById(R.id.btnPrevPeriod)
        btnNextPeriod = findViewById(R.id.btnNextPeriod)
        tvPeriodTitle = findViewById(R.id.tvPeriodTitle)
        btnToggleYearly = findViewById(R.id.btnToggleYearly)
        tvReportOfflineBadge = findViewById(R.id.tvReportOfflineBadge)
        tvReportSummary = findViewById(R.id.tvReportSummary)
        reportBarChart = findViewById(R.id.reportBarChart)
        heatmapView = findViewById(R.id.heatmapView)
        tvReportBreakdown = findViewById(R.id.tvReportBreakdown)
        tvSyncStatus = findViewById(R.id.tvSyncStatus)
        btnSyncNow = findViewById(R.id.btnSyncNow)
        btnExportCsv = findViewById(R.id.btnExportCsv)

        tvRoutineHeader = findViewById(R.id.tvRoutineHeader)
        chkWordTarget = findViewById(R.id.chkWordTarget)
        routineContainer = findViewById(R.id.routineContainer)

        btnGoalMinus = findViewById(R.id.btnGoalMinus)
        btnGoalPlus = findViewById(R.id.btnGoalPlus)
        tvGoalHoursVal = findViewById(R.id.tvGoalHoursVal)
        tvGoalNotifSub = findViewById(R.id.tvGoalNotifSub)
        swGoalNotif = findViewById(R.id.swGoalNotif)
        rowEditExam = findViewById(R.id.rowEditExam)
        tvExamSettingSub = findViewById(R.id.tvExamSettingSub)
        btnGrace0 = findViewById(R.id.btnGrace0)
        btnGrace3 = findViewById(R.id.btnGrace3)
        btnGrace5 = findViewById(R.id.btnGrace5)
        btnGrace10 = findViewById(R.id.btnGrace10)
        btnAlarmVib = findViewById(R.id.btnAlarmVib)
        btnAlarmSound = findViewById(R.id.btnAlarmSound)
        btnAlarmSilent = findViewById(R.id.btnAlarmSilent)
        btnThemeDay = findViewById(R.id.btnThemeDay)
        btnThemeNight = findViewById(R.id.btnThemeNight)
        btnThemeAuto = findViewById(R.id.btnThemeAuto)
        etGasUrl = findViewById(R.id.etGasUrl)
        etSyncKey = findViewById(R.id.etSyncKey)
        btnSaveSettings = findViewById(R.id.btnSaveSettings)
    }

    private fun setupListeners() {
        navTimer.setOnClickListener { showTab(0); refreshTimerUI() }
        navReport.setOnClickListener { showTab(1); loadReportTab() }
        navRoutine.setOnClickListener { showTab(2); renderRoutineTab() }
        navSettings.setOnClickListener { showTab(3); renderSettingsTab() }

        btnTopTheme.setOnClickListener {
            val next = when (DataStore.getThemeMode(this)) {
                "day" -> "night"
                "night" -> "auto"
                else -> "day"
            }
            DataStore.setThemeMode(this, next)
            applySavedThemeMode()
        }

        btnTopAlarm.setOnClickListener {
            val next = when (DataStore.getAlarmMode(this)) {
                "vibrate" -> "sound"
                "sound" -> "silent"
                else -> "vibrate"
            }
            DataStore.setAlarmMode(this, next)
            refreshAlarmUI()
        }

        examStripCard.setOnClickListener { showExamDialog() }
        rowEditExam.setOnClickListener { showExamDialog() }

        tvSubjectChip.setOnClickListener { showSubjectDialog() }

        btnPreset45.setOnClickListener { selectPreset(45) }
        btnPreset10.setOnClickListener { selectPreset(10) }
        btnPreset5.setOnClickListener { selectPreset(5) }
        btnPresetCustom.setOnClickListener { showCustomTimerDialog() }

        swFlipService.setOnCheckedChangeListener { _, isChecked ->
            val intent = Intent(this, FlipTrackerService::class.java).apply {
                action = if (isChecked) FlipTrackerService.ACTION_START else FlipTrackerService.ACTION_STOP
            }
            if (isChecked) ContextCompat.startForegroundService(this, intent) else startService(intent)
            refreshTimerUI()
        }

        swOnlineStudy.setOnCheckedChangeListener { _, isChecked ->
            DataStore.setOnlineStudy(this, isChecked)
            if (DataStore.loadRuntimeState(this).running) {
                startService(Intent(this, FlipTrackerService::class.java).setAction(FlipTrackerService.ACTION_ONLINE_CHANGED))
            }
            refreshTimerUI()
        }

        cardWasteLive.setOnClickListener {
            val reasons = arrayOf("ফোন স্ক্রলিং", "আড্ডা/গল্প", "ক্লান্তি/অলসতা", "অন্যান্য কাজ")
            AlertDialog.Builder(this)
                .setTitle("অপচয়ের কারণ ট্যাগ করো (+১৫ মি.)")
                .setItems(reasons) { _, which ->
                    val r = reasons[which]
                    DataStore.updateToday(this) { rec ->
                        rec.wasteSec += 15 * 60L
                        rec.wasteReason = r
                        rec.wasteReasons[r] = (rec.wasteReasons[r] ?: 0L) + 15 * 60L
                        rec.synced = false
                    }
                    Toast.makeText(this, "অপচয় লগ হয়েছে: $r", Toast.LENGTH_SHORT).show()
                    refreshTimerUI()
                }
                .show()
        }

        // Report Tab
        btnPrevPeriod.setOnClickListener {
            if (reportYearly) reportYear-- else {
                reportMonth--; if (reportMonth < 1) { reportMonth = 12; reportYear-- }
            }
            loadReportTab()
        }
        btnNextPeriod.setOnClickListener {
            if (reportYearly) reportYear++ else {
                reportMonth++; if (reportMonth > 12) { reportMonth = 1; reportYear++ }
            }
            loadReportTab()
        }
        btnToggleYearly.setOnClickListener {
            reportYearly = !reportYearly
            btnToggleYearly.text = if (reportYearly) "মাসিক" else "বার্ষিক"
            loadReportTab()
        }
        btnSyncNow.setOnClickListener {
            btnSyncNow.isEnabled = false
            btnSyncNow.text = "সিঙ্ক হচ্ছে..."
            thread {
                val (ok, msg) = DataStore.syncToGoogleDrive(this)
                runOnUiThread {
                    btnSyncNow.isEnabled = true
                    btnSyncNow.text = "ড্রাইভে সিঙ্ক করো"
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                    if (ok) loadReportTab()
                }
            }
        }
        btnExportCsv.setOnClickListener {
            val csv = DataStore.buildCsvExport(this)
            val share = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "BCS Flip Study Report CSV")
                putExtra(Intent.EXTRA_TEXT, csv)
            }
            startActivity(Intent.createChooser(share, "CSV শেয়ার / সেভ করো"))
        }

        // Routine Tab
        chkWordTarget.setOnCheckedChangeListener { _, checked ->
            DataStore.updateToday(this) { rec ->
                rec.wordTarget = checked
                rec.synced = false
            }
            renderRoutineTab()
        }

        // Settings Tab
        btnGoalMinus.setOnClickListener {
            DataStore.setDailyGoalHours(this, DataStore.getDailyGoalHours(this) - 1)
            renderSettingsTab()
            refreshTimerUI()
        }
        btnGoalPlus.setOnClickListener {
            DataStore.setDailyGoalHours(this, DataStore.getDailyGoalHours(this) + 1)
            renderSettingsTab()
            refreshTimerUI()
        }
        swGoalNotif.setOnCheckedChangeListener { _, checked ->
            DataStore.setGoalNotifOn(this, checked)
        }

        btnGrace0.setOnClickListener { DataStore.setGraceSec(this, 0); renderSettingsTab(); refreshTimerUI() }
        btnGrace3.setOnClickListener { DataStore.setGraceSec(this, 3); renderSettingsTab(); refreshTimerUI() }
        btnGrace5.setOnClickListener { DataStore.setGraceSec(this, 5); renderSettingsTab(); refreshTimerUI() }
        btnGrace10.setOnClickListener { DataStore.setGraceSec(this, 10); renderSettingsTab(); refreshTimerUI() }

        btnAlarmVib.setOnClickListener { DataStore.setAlarmMode(this, "vibrate"); refreshAlarmUI(); renderSettingsTab() }
        btnAlarmSound.setOnClickListener { DataStore.setAlarmMode(this, "sound"); refreshAlarmUI(); renderSettingsTab() }
        btnAlarmSilent.setOnClickListener { DataStore.setAlarmMode(this, "silent"); refreshAlarmUI(); renderSettingsTab() }

        btnThemeDay.setOnClickListener { DataStore.setThemeMode(this, "day"); applySavedThemeMode() }
        btnThemeNight.setOnClickListener { DataStore.setThemeMode(this, "night"); applySavedThemeMode() }
        btnThemeAuto.setOnClickListener { DataStore.setThemeMode(this, "auto"); applySavedThemeMode() }

        btnSaveSettings.setOnClickListener {
            DataStore.setGasUrl(this, etGasUrl.text.toString())
            DataStore.setSyncKey(this, etSyncKey.text.toString())
            Toast.makeText(this, "সিঙ্ক সেটিংস সেভ হয়েছে!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun selectPreset(min: Int) {
        DataStore.setPresetMin(this, min)
        val rt = DataStore.loadRuntimeState(this)
        if (rt.running) {
            startService(Intent(this, FlipTrackerService::class.java).setAction(FlipTrackerService.ACTION_RESET_TIMER))
        } else {
            DataStore.saveRuntimeState(this, rt.copy(remainingSec = min * 60))
        }
        refreshPresetPills()
        refreshTimerUI()
    }

    private fun showCustomTimerDialog() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "মিনিট লিখো (যেমন: ২৫ বা ৬০)"
            setPadding(48, 32, 48, 24)
        }
        AlertDialog.Builder(this)
            .setTitle("কাস্টম টাইমার সেট করো")
            .setView(input)
            .setPositiveButton("সেট করো") { _, _ ->
                val m = input.text.toString().toIntOrNull()
                if (m != null && m in 1..240) {
                    selectPreset(m)
                } else {
                    Toast.makeText(this, "১ থেকে ২৪০ মিনিটের মধ্যে সংখ্যা দাও", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun showSubjectDialog() {
        val presets = arrayOf("বাংলা", "ইংরেজি", "গণিত", "সাধারণ জ্ঞান", "বিজ্ঞান", "নিজে লিখো...")
        AlertDialog.Builder(this)
            .setTitle("বিষয় নির্বাচন করো")
            .setItems(presets) { _, idx ->
                if (idx == presets.lastIndex) {
                    val input = EditText(this).apply {
                        setText(DataStore.getCurrentSubject(this@MainActivity))
                        setPadding(48, 32, 48, 24)
                    }
                    AlertDialog.Builder(this)
                        .setTitle("বিষয়ের নাম লেখো")
                        .setView(input)
                        .setPositiveButton("সেভ") { _, _ ->
                            DataStore.setCurrentSubject(this, input.text.toString())
                            refreshTimerUI()
                        }
                        .setNegativeButton("বাতিল", null)
                        .show()
                } else {
                    DataStore.setCurrentSubject(this, presets[idx])
                    refreshTimerUI()
                }
            }
            .show()
    }

    private fun showExamDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 12)
        }
        val etName = EditText(this).apply {
            hint = "পরীক্ষার নাম (যেমন: BCS প্রিলি)"
            setText(DataStore.getExamName(this@MainActivity))
        }
        val etDate = EditText(this).apply {
            hint = "তারিখ (YYYY-MM-DD, যেমন: 2027-02-26)"
            setText(DataStore.getExamDateIso(this@MainActivity))
        }
        box.addView(etName)
        box.addView(etDate)
        AlertDialog.Builder(this)
            .setTitle("পরীক্ষা কাউন্টডাউন সেট করো")
            .setView(box)
            .setPositiveButton("সেভ") { _, _ ->
                DataStore.setExamName(this, etName.text.toString())
                DataStore.setExamDateIso(this, etDate.text.toString())
                refreshTimerUI()
                renderSettingsTab()
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun showTab(idx: Int) {
        tabTimer.visibility = if (idx == 0) View.VISIBLE else View.GONE
        tabReport.visibility = if (idx == 1) View.VISIBLE else View.GONE
        tabRoutine.visibility = if (idx == 2) View.VISIBLE else View.GONE
        tabSettings.visibility = if (idx == 3) View.VISIBLE else View.GONE

        val activeText = ContextCompat.getColor(this, R.color.nav_active_text)
        val idleText = ContextCompat.getColor(this, R.color.nav_idle_text)
        val navs = listOf(navTimer, navReport, navRoutine, navSettings)
        navs.forEachIndexed { i, tv ->
            tv.setTextColor(if (i == idx) activeText else idleText)
            tv.setBackgroundResource(if (i == idx) R.drawable.bg_nav_active else 0)
        }
    }

    private fun refreshAllUI() {
        swFlipService.isChecked = DataStore.loadRuntimeState(this).running
        swOnlineStudy.isChecked = DataStore.isOnlineStudy(this)
        chkWordTarget.isChecked = DataStore.getToday(this).wordTarget
        refreshPresetPills()
        refreshAlarmUI()
        refreshTimerUI()
        renderSettingsTab()
    }

    private fun refreshAlarmUI() {
        btnTopAlarm.text = when (DataStore.getAlarmMode(this)) {
            "sound" -> "সাউন্ড"
            "silent" -> "নীরব"
            else -> "কম্পন"
        }
    }

    private fun refreshPresetPills() {
        val p = DataStore.getPresetMin(this)
        setPillActive(btnPreset45, p == 45)
        setPillActive(btnPreset10, p == 10)
        setPillActive(btnPreset5, p == 5)
        val isCustom = p != 45 && p != 10 && p != 5
        btnPresetCustom.text = if (isCustom) "${DataStore.toBnDigits(p)} মি." else "কাস্টম +"
        setPillActive(btnPresetCustom, isCustom)
    }

    private fun setPillActive(tv: TextView, active: Boolean) {
        tv.setBackgroundResource(if (active) R.drawable.bg_pill_active else R.drawable.bg_pill_inactive)
        tv.setTextColor(ContextCompat.getColor(this, if (active) R.color.pill_active_text else R.color.pill_inactive_text))
    }

    private fun setSegmentActive(tv: TextView, active: Boolean) {
        tv.setBackgroundResource(if (active) R.drawable.bg_pill_active else 0)
        tv.setTextColor(ContextCompat.getColor(this, if (active) R.color.pill_active_text else R.color.pill_inactive_text))
    }

    private fun refreshTimerUI() {
        val rt = DataStore.loadRuntimeState(this)
        val now = System.currentTimeMillis()
        val elapsedSec = if (rt.running && rt.stateStartMs > 0L) ((now - rt.stateStartMs) / 1000L).coerceAtLeast(0L) else 0L

        val presetSec = (DataStore.getPresetMin(this) * 60).coerceAtLeast(60)
        val displaySec = if (rt.running && rt.mode == "STUDY") {
            (rt.remainingSec - elapsedSec.toInt()).coerceAtLeast(0)
        } else {
            rt.remainingSec
        }
        val clock = String.format(Locale.US, "%02d:%02d", displaySec / 60, displaySec % 60)
        tvTimerClock.text = DataStore.toBnDigits(clock)
        focusRingView.setProgress(displaySec.toFloat() / presetSec.toFloat())

        tvSubjectChip.text = "বিষয়: ${DataStore.getCurrentSubject(this)} ✎"
        tvExamLabel.text = "🔖 ${DataStore.getExamName(this)}"
        tvStreakChip.text = "🔥 ${DataStore.toBnDigits(DataStore.getCurrentStreak(this))} দিন"
        tvExamDaysPill.text = "আর ${DataStore.toBnDigits(DataStore.getDaysUntilExam(this))} দিন"

        val grace = DataStore.getGraceSec(this)
        tvFlipTitle.text = if (rt.running) "ফ্লিপ মোড ON" else "ফ্লিপ মোড OFF"
        tvFlipSub.text = if (grace > 0) "${DataStore.toBnDigits(grace)} সে. গ্রেস টাইম • শুধু উল্টো থাকলেই পড়া" else "গ্রেস টাইম বন্ধ • শুধু উল্টো থাকলেই পড়া"

        tvModeStatus.text = when {
            !rt.running -> "ট্র্যাকিং বন্ধ"
            rt.mode == "STUDY" && DataStore.isOnlineStudy(this) -> "অনলাইন · পড়া চলছে"
            rt.mode == "STUDY" -> "উল্টানো · পড়া চলছে"
            else -> "স্ক্রিন খোলা · অপচয় চলছে"
        }

        // রিয়েল-টাইম লাইভ সেকেন্ড-বাই-সেকেন্ড কাউন্টার (নিচের দুটো কার্ড)
        val today = DataStore.getToday(this)
        val liveStudySec = today.studySec + if (rt.running && rt.mode == "STUDY") elapsedSec else 0L
        val liveWasteSec = today.wasteSec + if (rt.running && rt.mode == "WASTE") elapsedSec else 0L

        tvStudyLiveClock.text = DataStore.formatHmsBn(liveStudySec)
        tvWasteLiveClock.text = DataStore.formatHmsBn(liveWasteSec)

        val goalH = DataStore.getDailyGoalHours(this)
        val doneHours = liveStudySec / 3600.0
        val doneFmt = DataStore.toBnDigits(String.format(Locale.US, "%.1f", doneHours))
        tvGoalProgressText.text = "$doneFmt / ${DataStore.toBnDigits(goalH)} ঘণ্টা"
        val pct = ((liveStudySec * 100L) / (goalH * 3600L)).toInt().coerceIn(0, 100)
        pbDailyGoal.progress = pct
    }

    private fun loadReportTab() {
        val period = if (reportYearly) String.format(Locale.US, "%04d", reportYear)
        else String.format(Locale.US, "%04d-%02d", reportYear, reportMonth)
        tvPeriodTitle.text = DataStore.toBnDigits(period)
        tvReportSummary.text = "রিপোর্ট লোড হচ্ছে..."
        tvSyncStatus.text = DataStore.getLastSyncText(this)
        heatmapView.setMinutes(DataStore.getLast28DaysMinutes(this))

        thread {
            val rep = DataStore.fetchOrComputeReport(this, period, reportYearly)
            runOnUiThread {
                tvReportOfflineBadge.visibility = if (rep.isOffline) View.VISIBLE else View.GONE
                tvReportSummary.text =
                    "মোট পড়া: ${DataStore.formatHoursMinBn(rep.totalStudyMin * 60L)} • দৈনিক গড়: ${DataStore.formatHoursMinBn(rep.avgDailyStudyMin * 60L)}\n" +
                    "অপচয়: ${DataStore.formatHoursMinBn(rep.totalWasteMin * 60L)} • ঘুম/অন্যান্য: ${DataStore.formatHoursMinBn(rep.totalSleepMin * 60L)}\n" +
                    "ফোকাস স্কোর: ${DataStore.toBnDigits(rep.productivityScore)}% • সেরা দিন: ${DataStore.toBnDigits(rep.bestDay)}\n" +
                    "স্ট্রিক: বর্তমান ${DataStore.toBnDigits(rep.currentStreak)} দিন • সর্বোচ্চ ${DataStore.toBnDigits(rep.longestStreak)} দিন"

                reportBarChart.setBars(rep.bars)

                val sb = StringBuilder()
                sb.append("বিষয় অনুযায়ী পড়া:\n")
                if (rep.subjects.isEmpty()) sb.append("• কোনো তথ্য নেই\n")
                else rep.subjects.entries.sortedByDescending { it.value }.forEach {
                    sb.append("• ${it.key}: ${DataStore.formatHoursMinBn(it.value)}\n")
                }
                sb.append("\nঅপচয়ের কারণ:\n")
                if (rep.wasteReasons.isEmpty()) sb.append("• কোনো তথ্য নেই")
                else rep.wasteReasons.entries.sortedByDescending { it.value }.forEach {
                    sb.append("• ${it.key}: ${DataStore.formatHoursMinBn(it.value)}\n")
                }
                tvReportBreakdown.text = sb.toString().trim()
            }
        }
    }

    private fun renderRoutineTab() {
        routineContainer.removeAllViews()
        val days = DataStore.getCurrentMonthDays(this)
        val monthTitle = SimpleDateFormat("MMMM yyyy", Locale.US).format(Date())
        tvRoutineHeader.text = "রুটিন · $monthTitle"

        for (d in days) {
            val row = TextView(this).apply {
                val dayNum = DataStore.toBnDigits(d.date.takeLast(2))
                val c45Dots = "●".repeat(d.c45.coerceAtMost(10)) + if (d.c45 == 0) "—" else ""
                val wt = if (d.wordTarget) "✅" else "○"
                text = "$dayNum | ৪৫মি: $c45Dots | পড়া: ${DataStore.formatHoursMinBn(d.totalStudyMinutes() * 60L)} | অপচয়: ${DataStore.formatHoursMinBn(d.wasteSec)} | ঘুম: ${DataStore.formatHoursMinBn(d.sleepOtherSec)} | ওয়ার্ড: $wt"
                textSize = 12f
                setPadding(20, 14, 20, 14)
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_main))
                setBackgroundResource(if (d.date == DataStore.todayIso()) R.drawable.bg_badge_mint else R.drawable.bg_card_rounded)
            }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = 8
            routineContainer.addView(row, lp)
        }
    }

    private fun renderSettingsTab() {
        val h = DataStore.getDailyGoalHours(this)
        tvGoalHoursVal.text = "${DataStore.toBnDigits(h)} ঘণ্টা"
        tvGoalNotifSub.text = "${DataStore.toBnDigits(h)} ঘণ্টা শেষ হলে জানাবে"
        swGoalNotif.isChecked = DataStore.isGoalNotifOn(this)
        tvExamSettingSub.text = "${DataStore.getExamName(this)} · ${DataStore.toBnDigits(DataStore.getExamDateIso(this))}"

        val g = DataStore.getGraceSec(this)
        setSegmentActive(btnGrace0, g == 0)
        setSegmentActive(btnGrace3, g == 3)
        setSegmentActive(btnGrace5, g == 5)
        setSegmentActive(btnGrace10, g == 10)

        val am = DataStore.getAlarmMode(this)
        setSegmentActive(btnAlarmVib, am == "vibrate")
        setSegmentActive(btnAlarmSound, am == "sound")
        setSegmentActive(btnAlarmSilent, am == "silent")

        val tm = DataStore.getThemeMode(this)
        setSegmentActive(btnThemeDay, tm == "day")
        setSegmentActive(btnThemeNight, tm == "night")
        setSegmentActive(btnThemeAuto, tm == "auto")

        etGasUrl.setText(DataStore.getGasUrl(this))
        etSyncKey.setText(DataStore.getSyncKey(this))
    }

    override fun onStart() {
        super.onStart()
        focusRingView.setGlowActive(true)
        val filter = IntentFilter(FlipTrackerService.BROADCAST_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(stateReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(stateReceiver, filter)
        }
        uiHandler.removeCallbacks(uiTicker)
        uiHandler.post(uiTicker)
    }

    override fun onStop() {
        super.onStop()
        focusRingView.setGlowActive(false)
        uiHandler.removeCallbacks(uiTicker)
        try { unregisterReceiver(stateReceiver) } catch (_: Exception) {}
        if (!DataStore.loadRuntimeState(this).running) {
            DataStore.markAppClosedNow(this)
        }
    }
}
