package com.bcs.flipstudy

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class DashboardActivity : AppCompatActivity() {

    private var webView: WebView? = null
    private var tvUpdated: TextView? = null
    private var pageReady = false
    private var pendingPayloadJson: String? = null

    @Volatile
    private var isLoading = false

    inner class DashBridge {
        @JavascriptInterface
        fun saveFilters(json: String) {
            try {
                getSharedPreferences("bcs_flip_study_prefs", Context.MODE_PRIVATE)
                    .edit()
                    .putString("dash_saved_filters", json)
                    .apply()
            } catch (_: Exception) {}
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val night = isNightActive()
        val pal = ThemePalette.get(DataStore.getColorPalette(this), night)
        val bgCol = if (night) Color.BLACK else Color.parseColor("#F4F6FA")
        val textCol = if (night) Color.parseColor("#F2F5F9") else Color.parseColor("#101828")
        val mutedCol = if (night) Color.parseColor("#94A3B8") else Color.parseColor("#667085")
        val dm = resources.displayMetrics
        fun dp(v: Int): Int = (v * dm.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bgCol)
        }

        // একটাই ফিক্সড হেডার: বামে ভেক্টর ব্যাক আইকন, মাঝে শিরোনাম + লাইভ অবস্থা, ডানে ভেক্টর রিফ্রেশ আইকন
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setBackgroundColor(pal.cardBg)
        }

        val btnBack = ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            imageTintList = ColorStateList.valueOf(pal.accent)
            contentDescription = "ফিরে যাও"
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener { finish() }
        }

        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val tvTitle = TextView(this).apply {
            text = "ইন্টারেক্টিভ ড্যাশবোর্ড"
            setTextColor(textCol)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvSub = TextView(this).apply {
            text = "লোড হচ্ছে..."
            setTextColor(mutedCol)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        }
        tvUpdated = tvSub
        titleCol.addView(tvTitle)
        titleCol.addView(tvSub)

        val btnRefresh = ImageView(this).apply {
            setImageResource(R.drawable.ic_refresh)
            imageTintList = ColorStateList.valueOf(pal.accent)
            contentDescription = "রিফ্রেশ করো"
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener {
                if (!isLoading) decideNetworkAndLoad()
            }
        }

        topBar.addView(btnBack, LinearLayout.LayoutParams(dp(48), dp(48)))
        topBar.addView(titleCol)
        topBar.addView(btnRefresh, LinearLayout.LayoutParams(dp(48), dp(48)))

        val wv = WebView(this).apply {
            setBackgroundColor(bgCol)
            settings.apply {
                javaScriptEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                domStorageEnabled = false
            }
            addJavascriptInterface(DashBridge(), "AndroidDash")
        }
        webView = wv

        root.addView(topBar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(wv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                pageReady = true
                pendingPayloadJson?.let { json ->
                    pushPayloadToWeb(json)
                    pendingPayloadJson = null
                }
            }
        }

        wv.loadUrl("https://appassets.androidplatform.net/assets/dashboard.html")
        decideNetworkAndLoad()
    }

    private fun isNightActive(): Boolean {
        val uiMode = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return uiMode == Configuration.UI_MODE_NIGHT_YES
    }

    private fun decideNetworkAndLoad() {
        val hasUrl = DataStore.getGasUrl(this).startsWith("http")
        if (!hasUrl) {
            loadData(fetchDrive = false, offlineFlag = true)
            return
        }

        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork
        val caps = cm.getNetworkCapabilities(net)
        val hasWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        val hasCell = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true

        when {
            hasWifi -> loadData(fetchDrive = true, offlineFlag = false)
            hasCell -> {
                if (DataStore.isSrDashCellAlways(this)) {
                    loadData(fetchDrive = true, offlineFlag = false)
                } else {
                    MaterialAlertDialogBuilder(this)
                        .setTitle("মোবাইল ডেটা চালু আছে")
                        .setMessage("ড্রাইভ থেকে লাইভ ডেটা এনে ড্যাশবোর্ড আপডেট করবে?")
                        .setPositiveButton("এবার নেব") { _, _ ->
                            loadData(fetchDrive = true, offlineFlag = false)
                        }
                        .setNeutralButton("সবসময় নেব") { _, _ ->
                            DataStore.setSrDashCellAlways(this, true)
                            loadData(fetchDrive = true, offlineFlag = false)
                        }
                        .setNegativeButton("লোকালই দেখাও") { _, _ ->
                            loadData(fetchDrive = false, offlineFlag = true)
                        }
                        .setCancelable(true)
                        .setOnCancelListener {
                            loadData(fetchDrive = false, offlineFlag = true)
                        }
                        .show()
                }
            }
            else -> loadData(fetchDrive = false, offlineFlag = true)
        }
    }

    private fun loadData(fetchDrive: Boolean, offlineFlag: Boolean) {
        if (isLoading) return
        isLoading = true
        runOnUiThread { tvUpdated?.text = "আপডেট হচ্ছে..." }
        val appCtx = applicationContext
        thread {
            var payload = ""
            var statusLabel = "অফলাইন ডেটা"
            try {
                val merged: Map<String, DayRecord>
                val isOffline: Boolean
                if (fetchDrive) {
                    val (ok, map) = DataStore.fetchAllDaysFromDrive(appCtx, timeoutMs = 10_000)
                    merged = map
                    isOffline = !ok
                } else {
                    merged = DataStore.getAllDaysMerged(appCtx)
                    isOffline = offlineFlag
                }
                payload = buildDashboardJson(merged, isOffline)
                val stamp = DataStore.toBnDigits(SimpleDateFormat("hh:mm", Locale.US).format(Date()))
                statusLabel = if (isOffline) "অফলাইন · $stamp" else "ড্রাইভ লাইভ · $stamp"
            } catch (_: Exception) {
                val fallback = try { DataStore.getAllDaysMerged(appCtx) } catch (_: Exception) { emptyMap() }
                payload = buildDashboardJson(fallback, true)
                statusLabel = "লোকাল ফলব্যাক"
            } finally {
                isLoading = false
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    tvUpdated?.text = statusLabel
                    if (payload.isNotEmpty()) {
                        if (pageReady) {
                            pushPayloadToWeb(payload)
                        } else {
                            pendingPayloadJson = payload
                        }
                    }
                }
            }
        }
    }

    private fun pushPayloadToWeb(jsonStr: String) {
        val escaped = JSONObject.quote(jsonStr)
        webView?.evaluateJavascript("window.setData(JSON.parse($escaped));", null)
    }

    private fun buildDashboardJson(daysMap: Map<String, DayRecord>, isOffline: Boolean): String {
        val night = isNightActive()
        val p = ThemePalette.get(DataStore.getColorPalette(this), night)

        fun hex(c: Int): String = String.format("#%06X", 0xFFFFFF and c)

        val themeObj = JSONObject().apply {
            put("bg", if (night) "#000000" else "#F4F6FA")
            put("card", hex(p.cardBg))
            put("border", hex(p.cardBorder))
            put("text", if (night) "#F1F5F9" else "#0F172A")
            put("muted", if (night) "#94A3B8" else "#64748B")
            put("accent", hex(p.accent))
            put("accentText", hex(p.pillActiveText))
            put("waste", CategoryColors.WASTE_HEX)
            put("eat", CategoryColors.EAT_HEX)
            put("away", CategoryColors.AWAY_HEX)
            put("sleep", CategoryColors.SLEEP_HEX)
            put("isDark", night)
        }

        val daysArr = JSONArray()
        for (d in daysMap.values.sortedBy { it.date }) {
            val totalStudySec = d.totalStudyMinutes() * 60L
            val fSec = if (d.flipSec + d.manualSec + d.onlineSec > 0L) d.flipSec
            else if (d.mode == "online") 0L else totalStudySec
            val oSec = if (d.flipSec + d.manualSec + d.onlineSec > 0L) d.onlineSec
            else if (d.mode == "online") totalStudySec else 0L
            daysArr.put(d.toJson().apply {
                put("studySec", totalStudySec)
                put("flipTotalSec", fSec)
                put("manualSec", d.manualSec)
                put("onlineSec", oSec)
            })
        }

        val savedFiltersRaw = getSharedPreferences("bcs_flip_study_prefs", Context.MODE_PRIVATE)
            .getString("dash_saved_filters", "") ?: ""
        val savedFiltersObj = try {
            if (savedFiltersRaw.isNotEmpty()) JSONObject(savedFiltersRaw) else null
        } catch (_: Exception) { null }

        return JSONObject().apply {
            put("theme", themeObj)
            put("goalMin", DataStore.getDailyGoalHours(this@DashboardActivity) * 60)
            put("todayIso", DataStore.todayIso())
            put("offline", isOffline)
            put("currentStreak", DataStore.getCurrentStreak(this@DashboardActivity))
            put("weekStartDay", DataStore.getWeekStartDay(this@DashboardActivity))
            put("examName", DataStore.getExamName(this@DashboardActivity))
            put("examDateIso", DataStore.getExamDateIso(this@DashboardActivity))
            put("daysUntilExam", DataStore.getDaysUntilExam(this@DashboardActivity))
            if (savedFiltersObj != null) put("savedFilters", savedFiltersObj)
            put("days", daysArr)
        }.toString()
    }
}
