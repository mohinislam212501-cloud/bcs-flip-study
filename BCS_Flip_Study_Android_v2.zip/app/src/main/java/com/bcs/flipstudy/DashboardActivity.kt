package com.bcs.flipstudy

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class DashboardActivity : AppCompatActivity() {

    private var webView: WebView? = null
    private var tvUpdated: TextView? = null
    private var pageReady = false
    private var pendingPayloadJson: String? = null

    @Volatile
    private var isLoading = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val night = isNightActive()
        val pal = ThemePalette.get(DataStore.getColorPalette(this), night)
        val bgCol = if (night) Color.BLACK else Color.parseColor("#F4F6FA")
        val textCol = if (night) Color.parseColor("#F2F5F9") else Color.parseColor("#101828")
        val mutedCol = if (night) Color.parseColor("#94A3B8") else Color.parseColor("#667085")
        val dm = resources.displayMetrics
        fun dp(v: Int): Int = (v * dm.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bgCol)
        }

        // Top bar: ← ফিরে যাও | ইন্টারেক্টিভ ড্যাশবোর্ড + সময় | ⟳ রিফ্রেশ
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(pal.cardBg)
        }

        val btnBack = TextView(this).apply {
            text = "← ফিরে যাও"
            setTextColor(pal.accent)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(8), dp(8), dp(10), dp(8))
            setOnClickListener { finish() }
        }

        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val tvTitle = TextView(this).apply {
            text = "ইন্টারেক্টিভ ড্যাশবোর্ড"
            setTextColor(textCol)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvSub = TextView(this).apply {
            text = "লোড হচ্ছে..."
            setTextColor(mutedCol)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        }
        tvUpdated = tvSub
        titleCol.addView(tvTitle)
        titleCol.addView(tvSub)

        val btnRefresh = TextView(this).apply {
            text = "⟳ রিফ্রেশ"
            setTextColor(pal.accent)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(10), dp(8), dp(8), dp(8))
            setOnClickListener {
                if (!isLoading) decideNetworkAndLoad()
            }
        }

        topBar.addView(btnBack)
        topBar.addView(titleCol)
        topBar.addView(btnRefresh)

        val wv = WebView(this).apply {
            setBackgroundColor(bgCol)
            settings.apply {
                javaScriptEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                domStorageEnabled = false
            }
        }
        webView = wv

        root.addView(topBar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(wv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                pageReady = true
                pendingPayloadJson?.let { json ->
                    pushPayloadToWeb(json)
                    pendingPayloadJson = null
                }
            }
        }

        wv.loadUrl("https://appassets.androidplatform.net/assets/dashboard.html")
        decideNetworkAndLoad()
    }

    private fun isNightActive(): Boolean {
        val uiMode = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return uiMode == Configuration.UI_MODE_NIGHT_YES
    }

    private fun decideNetworkAndLoad() {
        val hasUrl = DataStore.getGasUrl(this).startsWith("http")
        if (!hasUrl) {
            loadData(fetchDrive = false, offlineFlag = true)
            return
        }

        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork
        val caps = cm.getNetworkCapabilities(net)
        val hasWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        val hasCell = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true

        when {
            hasWifi -> loadData(fetchDrive = true, offlineFlag = false)
            hasCell -> {
                if (DataStore.isSrDashCellAlways(this)) {
                    loadData(fetchDrive = true, offlineFlag = false)
                } else {
                    MaterialAlertDialogBuilder(this)
                        .setTitle("মোবাইল ডেটা চালু আছে")
                        .setMessage("ড্রাইভ থেকে লাইভ ডেটা এনে ড্যাশবোর্ড আপডেট করবে?")
                        .setPositiveButton("এবার নেব") { _, _ ->
                            loadData(fetchDrive = true, offlineFlag = false)
                        }
                        .setNeutralButton("সবসময় নেব") { _, _ ->
                            DataStore.setSrDashCellAlways(this, true)
                            loadData(fetchDrive = true, offlineFlag = false)
                        }
                        .setNegativeButton("লোকালই দেখাও") { _, _ ->
                            loadData(fetchDrive = false, offlineFlag = true)
                        }
                        .setCancelable(true)
                        .setOnCancelListener {
                            loadData(fetchDrive = false, offlineFlag = true)
                        }
                        .show()
                }
            }
            else -> loadData(fetchDrive = false, offlineFlag = true)
        }
    }

    private fun loadData(fetchDrive: Boolean, offlineFlag: Boolean) {
        if (isLoading) return
        isLoading = true
        runOnUiThread { tvUpdated?.text = "আপডেট হচ্ছে..." }
        val appCtx = applicationContext
        thread {
            var payload = ""
            var statusLabel = "অফলাইন ডেটা"
            try {
                val merged: Map<String, DayRecord>
                val isOffline: Boolean
                if (fetchDrive) {
                    val (ok, map) = DataStore.fetchAllDaysFromDrive(appCtx, timeoutMs = 10_000)
                    merged = map
                    isOffline = !ok
                } else {
                    merged = DataStore.getAllDaysMerged(appCtx)
                    isOffline = offlineFlag
                }
                payload = buildDashboardJson(merged, isOffline)
                val stamp = DataStore.toBnDigits(SimpleDateFormat("hh:mm a", Locale.US).format(Date()))
                statusLabel = if (isOffline) "অফলাইন · $stamp" else "ড্রাইভ লাইভ · $stamp"
            } catch (_: Exception) {
                val fallback = try { DataStore.getAllDaysMerged(appCtx) } catch (_: Exception) { emptyMap() }
                payload = buildDashboardJson(fallback, true)
                statusLabel = "লোকাল ফলব্যাক"
            } finally {
                isLoading = false
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    tvUpdated?.text = statusLabel
                    if (payload.isNotEmpty()) {
                        if (pageReady) {
                            pushPayloadToWeb(payload)
                        } else {
                            pendingPayloadJson = payload
                        }
                    }
                }
            }
        }
    }

    private fun pushPayloadToWeb(jsonStr: String) {
        val escaped = JSONObject.quote(jsonStr)
        webView?.evaluateJavascript("window.setData(JSON.parse($escaped));", null)
    }

    private fun buildDashboardJson(daysMap: Map<String, DayRecord>, isOffline: Boolean): String {
        val night = isNightActive()
        val p = ThemePalette.get(DataStore.getColorPalette(this), night)

        fun hex(c: Int): String = String.format("#%06X", 0xFFFFFF and c)

        val themeObj = JSONObject().apply {
            put("bg", if (night) "#000000" else "#F4F6FA")
            put("card", hex(p.cardBg))
            put("border", hex(p.cardBorder))
            put("text", if (night) "#F2F5F9" else "#101828")
            put("muted", if (night) "#94A3B8" else "#667085")
            put("accent", hex(p.accent))
            put("study", hex(p.accent))
            put("waste", if (night) "#F87171" else "#D92D20")
            put("eat", "#F59E0B")
            put("sleep", if (night) "#818CF8" else "#4F46E5")
        }

        val arr = JSONArray()
        for (rec in daysMap.values.sortedBy { it.date }) {
            val accounted = rec.flipSec + rec.manualSec + rec.onlineSec
            val legacyFlip = (rec.studySec - accounted).coerceAtLeast(0L)
            arr.put(rec.toJson().apply {
                put("flipTotalSec", rec.flipSec + legacyFlip)
                put("totalStudyMin", rec.totalStudyMinutes())
            })
        }

        return JSONObject().apply {
            put("isOffline", isOffline)
            put("goalMin", DataStore.getDailyGoalHours(this@DashboardActivity) * 60)
            put("examName", DataStore.getExamName(this@DashboardActivity))
            put("examDays", DataStore.getDaysUntilExam(this@DashboardActivity))
            put("todayIso", DataStore.todayIso())
            put("theme", themeObj)
            put("days", arr)
        }.toString()
    }

    override fun onDestroy() {
        webView?.apply {
            stopLoading()
            loadUrl("about:blank")
            destroy()
        }
        webView = null
        super.onDestroy()
    }
}
