package com.bcs.flipstudy

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings

/**
 * কেন্দ্রীয় হালকা হ্যাপটিক ফিডব্যাক সিস্টেম।
 * সিস্টেম হ্যাপটিক সেটিং ও অ্যাপের গ্লোবাল/তীব্রতা/ফ্লিপ/গোল সেটিং মেনে চলে।
 */
object HapticManager {

    private fun getVibrator(ctx: Context): Vibrator? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun isSystemHapticEnabled(ctx: Context): Boolean {
        return try {
            Settings.System.getInt(ctx.contentResolver, Settings.System.HAPTIC_FEEDBACK_ENABLED, 1) != 0
        } catch (_: Exception) {
            true
        }
    }

    private fun canVibrate(ctx: Context): Boolean {
        if (!DataStore.isHapticGlobalOn(ctx)) return false
        if (DataStore.getHapticIntensity(ctx) <= 0) return false
        val vib = getVibrator(ctx) ?: return false
        return vib.hasVibrator()
    }

    private fun ampForIntensity(ctx: Context): Int = when (DataStore.getHapticIntensity(ctx)) {
        1 -> 90   // খুব হালকা
        2 -> 150  // হালকা
        3 -> 220  // স্বাভাবিক
        else -> 0
    }

    private fun durForIntensity(ctx: Context, baseMs: Long): Long = when (DataStore.getHapticIntensity(ctx)) {
        1 -> (baseMs * 0.7).toLong().coerceAtLeast(10L)
        2 -> baseMs
        3 -> (baseMs * 1.35).toLong().coerceAtLeast(14L)
        else -> 0L
    }

    private fun pulse(ctx: Context, baseMs: Long, useEffectTick: Boolean = true) {
        if (!canVibrate(ctx)) return
        val vib = getVibrator(ctx) ?: return
        try {
            val ms = durForIntensity(ctx, baseMs)
            val amp = ampForIntensity(ctx)
            if (ms <= 0L || amp <= 0) return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vib.vibrate(VibrationEffect.createOneShot(ms, amp))
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(ms)
            }
        } catch (_: Exception) {}
    }

    private fun pattern(ctx: Context, timings: LongArray, amps: IntArray) {
        if (!canVibrate(ctx)) return
        val vib = getVibrator(ctx) ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vib.vibrate(VibrationEffect.createWaveform(timings, amps, -1))
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(timings, -1)
            }
        } catch (_: Exception) {}
    }

    fun flipStudyOn(ctx: Context) {
        if (!DataStore.isHapticFlipOn(ctx)) return
        pulse(ctx, 60L, useEffectTick = false)
    }

    fun flipWasteOn(ctx: Context) {
        if (!DataStore.isHapticFlipOn(ctx)) return
        val a = ampForIntensity(ctx)
        if (a <= 0) return
        val d = durForIntensity(ctx, 50L)
        pattern(ctx, longArrayOf(0L, d, 55L, d), intArrayOf(0, a, 0, (a * 0.75f).toInt().coerceAtLeast(20)))
    }

    fun flipToggleConfirm(ctx: Context) {
        if (!DataStore.isHapticFlipOn(ctx)) return
        pulse(ctx, 20L, useEffectTick = false)
    }

    fun timerStart(ctx: Context) = pulse(ctx, 18L, useEffectTick = true)

    fun timerPause(ctx: Context) = pulse(ctx, 22L, useEffectTick = false)

    fun goalReached(ctx: Context) {
        if (!DataStore.isHapticGoalOn(ctx)) return
        val a = ampForIntensity(ctx)
        if (a <= 0) return
        val d = durForIntensity(ctx, 22L)
        pattern(ctx, longArrayOf(0L, d, 70L, d + 10L), intArrayOf(0, a, 0, a))
    }

    fun reminderAction(ctx: Context) = pulse(ctx, 16L, useEffectTick = true)

    fun routineDone(ctx: Context) = pulse(ctx, 16L, useEffectTick = true)

    fun syncSuccess(ctx: Context) = pulse(ctx, 18L, useEffectTick = true)

    fun syncFail(ctx: Context) {
        val a = ampForIntensity(ctx)
        if (a <= 0 || !canVibrate(ctx)) return
        pattern(ctx, longArrayOf(0L, 35L, 60L, 35L), intArrayOf(0, a, 0, a))
    }

    fun lockUnlock(ctx: Context) = pulse(ctx, 20L, useEffectTick = false)

    fun lockReject(ctx: Context) {
        val a = ampForIntensity(ctx)
        if (a <= 0 || !canVibrate(ctx)) return
        pattern(ctx, longArrayOf(0L, 40L, 50L, 40L), intArrayOf(0, a, 0, a))
    }
}
