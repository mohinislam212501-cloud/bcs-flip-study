package com.bcs.flipstudy

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

class Day24BarView @JvmOverloads constructor(
    ctx: Context,
    attrs: AttributeSet? = null
) : View(ctx, attrs) {

    private var studyMin: Int = 0
    private var wasteMin: Int = 0
    private var eatMin: Int = 0
    private var awayMin: Int = 0
    private var sleepMin: Int = 0
    private var otherMin: Int = 0
    private var unassignedMin: Int = 0
    private var accentColor: Int = Color.parseColor("#0EA98B")
    private var trackColor: Int = Color.parseColor("#334155")
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stripePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#64748B")
        strokeWidth = 2f * resources.displayMetrics.density
    }
    private val rect = RectF()
    var onUnknownTap: (() -> Unit)? = null

    fun setData(study: Int, waste: Int, eat: Int, away: Int, sleep: Int, other: Int = 0, accent: Int, track: Int, unassigned: Int = 0) {
        studyMin = study.coerceAtLeast(0)
        wasteMin = waste.coerceAtLeast(0)
        eatMin = eat.coerceAtLeast(0)
        awayMin = away.coerceAtLeast(0)
        sleepMin = sleep.coerceAtLeast(0)
        otherMin = other.coerceAtLeast(0)
        unassignedMin = unassigned.coerceAtLeast(0)
        accentColor = accent
        trackColor = track
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val r = h / 2f

        // Background track for unaccounted time
        paint.color = trackColor
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, r, r, paint)

        val sumMin = studyMin + wasteMin + eatMin + awayMin + sleepMin + otherMin + unassignedMin
        val totalCap = maxOf(1440f, sumMin.toFloat())
        val segs = listOf(
            studyMin to accentColor,
            wasteMin to CategoryColors.WASTE_INT,
            eatMin to CategoryColors.EAT_INT,
            awayMin to CategoryColors.AWAY_INT,
            sleepMin to CategoryColors.SLEEP_INT,
            otherMin to CategoryColors.OTHER_INT,
            unassignedMin to CategoryColors.UNASSIGNED_INT
        )
        var x = 0f
        for ((m, col) in segs) {
            if (m <= 0) continue
            val segW = (m / totalCap) * w
            val endX = minOf(w, x + segW)
            paint.color = col
            rect.set(x, 0f, endX, h)
            canvas.drawRect(rect, paint)
            x = endX
        }
        // Subtle diagonal stripes on unaccounted right portion
        if (x < w - 4f) {
            var sx = x + 6f
            val step = 10f * resources.displayMetrics.density
            while (sx < w) {
                canvas.drawLine(sx, 0f, sx - h * 0.6f, h, stripePaint)
                sx += step
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            onUnknownTap?.invoke()
            return true
        }
        return event.action == MotionEvent.ACTION_DOWN || super.onTouchEvent(event)
    }
}
