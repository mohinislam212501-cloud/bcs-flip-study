package com.bcs.flipstudy

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import androidx.core.content.ContextCompat

class FocusRingView @JvmOverloads constructor(
    ctx: Context,
    attrs: AttributeSet? = null
) : View(ctx, attrs) {

    private var progress: Float = 0.72f
    private var shownProgress: Float = 0.72f
    private var glowEnabled: Boolean = false
    private var lastMinutePulse: Boolean = false
    private var breathFactor: Float = 0.5f
    private var customStartColor: Int = 0
    private var customEndColor: Int = 0
    private var customTrackColor: Int = 0
    private val rect = RectF()
    private val gradMatrix = Matrix()
    private var shader: SweepGradient? = null
    private var progressAnimator: ValueAnimator? = null
    private var breathAnimator: ValueAnimator? = null

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    fun setProgress(value: Float, smoothTick: Boolean = false) {
        val clamped = value.coerceIn(0.02f, 1f)
        if (kotlin.math.abs(clamped - progress) <= 0.001f) return
        val big = kotlin.math.abs(clamped - progress) > 0.05f
        progress = clamped
        progressAnimator?.cancel()
        if ((big || smoothTick) && isShown && isAttachedToWindow) {
            progressAnimator = ValueAnimator.ofFloat(shownProgress, clamped).apply {
                duration = if (big) 450L else 950L
                interpolator = if (big) DecelerateInterpolator() else LinearInterpolator()
                addUpdateListener { shownProgress = it.animatedValue as Float; invalidate() }
                start()
            }
        } else {
            shownProgress = clamped
            invalidate()
        }
    }

    fun setGlowActive(active: Boolean) {
        if (glowEnabled != active) {
            glowEnabled = active
            if (active && isShown && isAttachedToWindow) startBreathing() else stopBreathing()
            invalidate()
        }
    }

    fun setLastMinutePulse(pulse: Boolean) {
        if (lastMinutePulse != pulse) {
            lastMinutePulse = pulse
            invalidate()
        }
    }

    fun triggerSessionBurst() {
        if (!isShown || !isAttachedToWindow) return
        animate().cancel()
        animate()
            .scaleX(1.045f).scaleY(1.045f)
            .setDuration(160L)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction {
                animate().scaleX(1f).scaleY(1f).setDuration(180L).start()
            }
            .start()
    }

    private fun startBreathing() {
        if (breathAnimator?.isRunning == true) return
        breathAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 3000L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            addUpdateListener {
                breathFactor = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun stopBreathing() {
        breathAnimator?.cancel()
        breathAnimator = null
    }

    fun setRingColors(startColor: Int, endColor: Int) {
        if (customStartColor == startColor && customEndColor == endColor) return
        customStartColor = startColor
        customEndColor = endColor
        shader = null
        invalidate()
    }

    fun setTrackColor(color: Int) {
        if (customTrackColor == color) return
        customTrackColor = color
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        shader = null
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility != VISIBLE) {
            progressAnimator?.cancel()
            stopBreathing()
        } else if (glowEnabled && isAttachedToWindow) {
            startBreathing()
        }
    }

    override fun onDetachedFromWindow() {
        progressAnimator?.cancel()
        stopBreathing()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val maxPx = 276f * resources.displayMetrics.density
        val size = minOf(width.toFloat() * 0.88f, height.toFloat(), maxPx)
        if (size <= 0f) return

        val strokeW = (size * 0.068f).coerceIn(11f, 13.5f * resources.displayMetrics.density)
        val pad = strokeW * 0.7f
        val left = (width - size) / 2f + pad
        val top = (height - size) / 2f + pad
        rect.set(left, top, left + size - pad * 2f, top + size - pad * 2f)

        trackPaint.strokeWidth = strokeW
        trackPaint.color = if (customTrackColor != 0) customTrackColor else ContextCompat.getColor(context, R.color.ring_track)
        canvas.drawOval(rect, trackPaint)

        val cStart = if (customStartColor != 0) customStartColor else ContextCompat.getColor(context, R.color.ring_start)
        val cEnd = if (customEndColor != 0) customEndColor else ContextCompat.getColor(context, R.color.ring_end)
        val sweepAngle = 360f * shownProgress

        if (shader == null) {
            shader = SweepGradient(rect.centerX(), rect.centerY(), intArrayOf(cStart, cEnd, cStart), floatArrayOf(0f, 0.5f, 1f))
            gradMatrix.setRotate(-90f, rect.centerX(), rect.centerY())
            shader?.setLocalMatrix(gradMatrix)
        }

        if (glowEnabled) {
            glowPaint.strokeWidth = strokeW * 1.85f
            glowPaint.color = cEnd
            glowPaint.alpha = (34 + (breathFactor * 36f).toInt()).coerceIn(24, 78)
            canvas.drawArc(rect, -90f, sweepAngle, false, glowPaint)
        }

        arcPaint.strokeWidth = strokeW
        arcPaint.shader = shader
        canvas.drawArc(rect, -90f, sweepAngle, false, arcPaint)

        val rad = Math.toRadians((-90f + sweepAngle).toDouble())
        val rx = rect.width() / 2f
        val ry = rect.height() / 2f
        val dotX = (rect.centerX() + rx * Math.cos(rad)).toFloat()
        val dotY = (rect.centerY() + ry * Math.sin(rad)).toFloat()
        val dotScale = if (lastMinutePulse) 0.42f + breathFactor * 0.14f else 0.42f
        dotPaint.color = Color.WHITE
        canvas.drawCircle(dotX, dotY, strokeW * dotScale, dotPaint)
    }
}
