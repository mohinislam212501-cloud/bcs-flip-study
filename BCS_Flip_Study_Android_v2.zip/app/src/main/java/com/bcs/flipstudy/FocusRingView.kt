package com.bcs.flipstudy

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.core.content.ContextCompat

class FocusRingView @JvmOverloads constructor(
    ctx: Context,
    attrs: AttributeSet? = null
) : View(ctx, attrs) {

    private var progress: Float = 0.72f
    private var shownProgress: Float = 0.72f
    private var glowEnabled: Boolean = true
    private var customStartColor: Int = 0
    private var customEndColor: Int = 0
    private var customTrackColor: Int = 0
    private val rect = RectF()
    private val gradMatrix = Matrix()
    private var shader: SweepGradient? = null
    private var animator: ValueAnimator? = null

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    /** ধীরে ধীরে মসৃণভাবে প্রোগ্রেস বদলায়; ছোট বদলে (প্রতি সেকেন্ডের টিকে) অ্যানিমেশন ছাড়াই আঁকে। */
    fun setProgress(value: Float) {
        val clamped = value.coerceIn(0.02f, 1f)
        if (kotlin.math.abs(clamped - progress) <= 0.002f) return
        val big = kotlin.math.abs(clamped - progress) > 0.05f
        progress = clamped
        animator?.cancel()
        if (big && isShown) {
            animator = ValueAnimator.ofFloat(shownProgress, clamped).apply {
                duration = 450L
                interpolator = DecelerateInterpolator()
                addUpdateListener { shownProgress = it.animatedValue as Float; invalidate() }
                start()
            }
        } else {
            shownProgress = clamped
            invalidate()
        }
    }

    fun setGlowActive(active: Boolean) {
        if (glowEnabled != active) {
            glowEnabled = active
            invalidate()
        }
    }

    fun setRingColors(startColor: Int, endColor: Int) {
        if (customStartColor == startColor && customEndColor == endColor) return
        customStartColor = startColor
        customEndColor = endColor
        shader = null
        invalidate()
    }

    fun setTrackColor(color: Int) {
        customTrackColor = color
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        shader = null
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val size = minOf(width, height).toFloat()
        if (size <= 0f) return

        val strokeW = (size * 0.07f).coerceIn(12f, 28f)
        val pad = strokeW * 1.5f
        val left = (width - size) / 2f + pad
        val top = (height - size) / 2f + pad
        rect.set(left, top, left + size - pad * 2f, top + size - pad * 2f)

        trackPaint.strokeWidth = strokeW
        trackPaint.color = if (customTrackColor != 0) customTrackColor else ContextCompat.getColor(context, R.color.ring_track)
        canvas.drawOval(rect, trackPaint)

        val cStart = if (customStartColor != 0) customStartColor else ContextCompat.getColor(context, R.color.ring_start)
        val cEnd = if (customEndColor != 0) customEndColor else ContextCompat.getColor(context, R.color.ring_end)
        val sweepAngle = 360f * shownProgress

        if (shader == null) {
            // গ্রেডিয়েন্ট ১২টার অবস্থান থেকে শুরু হবে (আর্ক -৯০° থেকে শুরু, তাই ঘুরিয়ে মেলানো)
            shader = SweepGradient(rect.centerX(), rect.centerY(), intArrayOf(cStart, cEnd, cStart), floatArrayOf(0f, 0.5f, 1f))
            gradMatrix.setRotate(-90f, rect.centerX(), rect.centerY())
            shader?.setLocalMatrix(gradMatrix)
            glowPaint.maskFilter = BlurMaskFilter(strokeW * 0.8f, BlurMaskFilter.Blur.NORMAL)
        }

        if (glowEnabled) {
            glowPaint.strokeWidth = strokeW * 1.1f
            glowPaint.color = cEnd
            glowPaint.alpha = 60
            canvas.drawArc(rect, -90f, sweepAngle, false, glowPaint)
        }

        arcPaint.strokeWidth = strokeW
        arcPaint.shader = shader
        canvas.drawArc(rect, -90f, sweepAngle, false, arcPaint)

        // আর্কের মাথায় ছোট সাদা বিন্দু
        val rad = Math.toRadians((-90f + sweepAngle).toDouble())
        val r = rect.width() / 2f
        val cx = rect.centerX() + (r * Math.cos(rad)).toFloat()
        val cy = rect.centerY() + (r * Math.sin(rad)).toFloat()
        dotPaint.color = 0xFFFFFFFF.toInt()
        canvas.drawCircle(cx, cy, strokeW * 0.22f, dotPaint)
    }
}
