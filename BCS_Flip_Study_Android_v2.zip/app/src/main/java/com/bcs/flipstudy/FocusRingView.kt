package com.bcs.flipstudy

import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat

class FocusRingView @JvmOverloads constructor(
    ctx: Context,
    attrs: AttributeSet? = null
) : View(ctx, attrs) {

    private var progress: Float = 0.72f
    private var glowEnabled: Boolean = true
    private val rect = RectF()

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun setProgress(value: Float) {
        val clamped = value.coerceIn(0.02f, 1f)
        if (kotlin.math.abs(clamped - progress) > 0.002f) {
            progress = clamped
            invalidate()
        }
    }

    fun setGlowActive(active: Boolean) {
        if (glowEnabled != active) {
            glowEnabled = active
            invalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val size = minOf(width, height).toFloat()
        if (size <= 0f) return

        val strokeW = (size * 0.078f).coerceIn(14f, 28f)
        val pad = strokeW * 1.45f
        val left = (width - size) / 2f + pad
        val top = (height - size) / 2f + pad
        rect.set(left, top, left + size - pad * 2f, top + size - pad * 2f)

        trackPaint.strokeWidth = strokeW
        trackPaint.color = ContextCompat.getColor(context, R.color.ring_track)
        canvas.drawOval(rect, trackPaint)

        val cStart = ContextCompat.getColor(context, R.color.ring_start)
        val cEnd = ContextCompat.getColor(context, R.color.ring_end)
        val sweepAngle = 360f * progress

        if (glowEnabled) {
            glowPaint.strokeWidth = strokeW * 1.25f
            glowPaint.color = cEnd
            glowPaint.alpha = 85
            glowPaint.maskFilter = BlurMaskFilter(strokeW * 0.85f, BlurMaskFilter.Blur.NORMAL)
            canvas.drawArc(rect, -90f, sweepAngle, false, glowPaint)
        }

        arcPaint.strokeWidth = strokeW
        arcPaint.shader = SweepGradient(rect.centerX(), rect.centerY(), intArrayOf(cStart, cEnd, cStart), null)
        canvas.drawArc(rect, -90f, sweepAngle, false, arcPaint)
    }
}
