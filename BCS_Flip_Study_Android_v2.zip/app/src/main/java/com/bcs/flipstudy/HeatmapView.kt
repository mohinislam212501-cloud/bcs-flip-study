package com.bcs.flipstudy

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

class HeatmapView @JvmOverloads constructor(
    ctx: Context,
    attrs: AttributeSet? = null
) : View(ctx, attrs) {

    private var minutesList: List<Int> = emptyList()
    private val cellPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun setMinutes(list: List<Int>) {
        minutesList = list
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (minutesList.isEmpty()) return

        val cols = 7
        val rows = ((minutesList.size + cols - 1) / cols).coerceAtLeast(1)
        val gap = 10f
        val cellW = ((width - gap * (cols + 1)) / cols).coerceAtLeast(16f)
        val cellH = ((height - gap * (rows + 1)) / rows).coerceAtLeast(16f)
        val size = minOf(cellW, cellH)
        val startX = (width - (size * cols + gap * (cols - 1))) / 2f
        val startY = (height - (size * rows + gap * (rows - 1))) / 2f

        minutesList.forEachIndexed { idx, mins ->
            val r = idx / cols
            val c = idx % cols
            val x = startX + c * (size + gap)
            val y = startY + r * (size + gap)

            cellPaint.color = when {
                mins <= 0 -> Color.parseColor("#2A3B38")
                mins < 45 -> Color.parseColor("#0F5E4E")
                mins < 120 -> Color.parseColor("#0EA98B")
                mins < 240 -> Color.parseColor("#24D19E")
                else -> Color.parseColor("#5EF2C8")
            }
            canvas.drawRoundRect(x, y, x + size, y + size, 8f, 8f, cellPaint)
        }
    }
}
