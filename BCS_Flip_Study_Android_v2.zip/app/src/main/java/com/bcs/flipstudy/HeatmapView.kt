package com.bcs.flipstudy

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import androidx.core.graphics.ColorUtils

class HeatmapView @JvmOverloads constructor(
    ctx: Context,
    attrs: AttributeSet? = null
) : View(ctx, attrs) {

    private var minutesList: List<Int> = emptyList()
    private val cellPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val density = resources.displayMetrics.density
    private var emptyColor = Color.parseColor("#EDF0F6")
    private var baseColor = Color.parseColor("#0EA98B")

    fun setPalette(empty: Int, accent: Int) {
        emptyColor = empty
        baseColor = accent
        invalidate()
    }

    fun setMinutes(list: List<Int>) {
        minutesList = list
        invalidate()
    }

    private fun levelColor(mins: Int): Int = when {
        mins <= 0 -> emptyColor
        mins < 45 -> ColorUtils.setAlphaComponent(baseColor, 70)
        mins < 120 -> ColorUtils.setAlphaComponent(baseColor, 130)
        mins < 240 -> ColorUtils.setAlphaComponent(baseColor, 195)
        else -> baseColor
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (minutesList.isEmpty()) return

        val cols = 7
        val rows = ((minutesList.size + cols - 1) / cols).coerceAtLeast(1)
        val gap = 6f * density
        val cellW = (width - gap * (cols - 1)) / cols
        val cellH = (height - gap * (rows - 1)) / rows
        val size = minOf(cellW, cellH).coerceAtLeast(8f)
        val startX = (width - (size * cols + gap * (cols - 1))) / 2f
        val startY = (height - (size * rows + gap * (rows - 1))) / 2f
        val radius = size * 0.28f

        minutesList.forEachIndexed { idx, mins ->
            val r = idx / cols
            val c = idx % cols
            val x = startX + c * (size + gap)
            val y = startY + r * (size + gap)
            cellPaint.color = levelColor(mins)
            rect.set(x, y, x + size, y + size)
            canvas.drawRoundRect(rect, radius, radius, cellPaint)
        }
    }
}
