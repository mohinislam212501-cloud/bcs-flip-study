package com.bcs.flipstudy

import android.annotation.SuppressLint
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class TimelineActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_DATE_ISO = "extra_date_iso"
        @Volatile
        var editedInLastSession: Boolean = false
    }

    private var webView: WebView? = null
    private var tvDateTitle: TextView? = null
    private var tvSyncSub: TextView? = null
    private var btnNextDay: ImageView? = null
    private var currentIso: String = ""
    private var pageReady = false

    inner class TimelineBridge {
        @JavascriptInterface
        fun saveDay(iso: String, segmentsJson: String) {
            val (ok, _) = DataStore.saveEditedTimelineForDay(this@TimelineActivity, iso, segmentsJson)
            if (ok) {
                editedInLastSession = true
                runOnUiThread {
                    tvSyncSub?.text = "ড্রাইভে সিঙ্ক হচ্ছে..."
                }
                thread {
                    val (syncOk, _) = DataStore.syncToGoogleDrive(this@TimelineActivity)
                    runOnUiThread {
                        tvSyncSub?.text = if (syncOk) "Drive সিঙ্কড" else "লোকাল সেভড · অসিঙ্কড"
                    }
                }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        currentIso = intent.getStringExtra(EXTRA_DATE_ISO)?.takeIf { it.isNotBlank() } ?: DataStore.todayIso()
        val night = isNightActive()
        val pal = ThemePalette.get(DataStore.getColorPalette(this), night)
        val bgCol = if (night) Color.parseColor("#0F172A") else Color.parseColor("#F4F6FA")
        val textCol = if (night) Color.parseColor("#F8FAFC") else Color.parseColor("#101828")
        val mutedCol = if (night) Color.parseColor("#B8C5D6") else Color.parseColor("#475467")
        val dm = resources.displayMetrics
        fun dp(v: Int): Int = (v * dm.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bgCol)
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(8), dp(8), dp(8))
            setBackgroundColor(pal.cardBg)
        }

        val btnBack = ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            imageTintList = ColorStateList.valueOf(pal.accent)
            contentDescription = "ফিরে যাও"
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener { finish() }
        }

        val btnPrev = ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            imageTintList = ColorStateList.valueOf(textCol)
            contentDescription = "আগের দিন"
            setPadding(dp(10), dp(10), dp(6), dp(10))
            setOnClickListener { shiftDay(-1) }
        }

        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val tvTitle = TextView(this).apply {
            text = formatDateBn(currentIso)
            setTextColor(textCol)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvSub = TextView(this).apply {
            text = "২৪ ঘণ্টা টাইমলাইন · Drive সিঙ্ক"
            setTextColor(mutedCol)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        }
        tvDateTitle = tvTitle
        tvSyncSub = tvSub
        titleCol.addView(tvTitle)
        titleCol.addView(tvSub)

        val btnNext = ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            rotation = 180f
            imageTintList = ColorStateList.valueOf(textCol)
            contentDescription = "পরের দিন"
            setPadding(dp(10), dp(10), dp(6), dp(10))
            setOnClickListener { shiftDay(1) }
        }
        btnNextDay = btnNext

        topBar.addView(btnBack, LinearLayout.LayoutParams(dp(42), dp(42)))
        topBar.addView(btnPrev, LinearLayout.LayoutParams(dp(38), dp(40)))
        topBar.addView(titleCol)
        topBar.addView(btnNext, LinearLayout.LayoutParams(dp(38), dp(40)))
        root.addView(topBar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        val accentHex = String.format("#%06X", 0xFFFFFF and pal.accent)
        val wv = WebView(this).apply {
            setBackgroundColor(bgCol)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = false
            settings.allowFileAccess = false
            addJavascriptInterface(TimelineBridge(), "AndroidTimeline")
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                    return assetLoader.shouldInterceptRequest(request.url)
                }

                override fun onPageFinished(view: WebView, url: String?) {
                    pageReady = true
                    view.evaluateJavascript("window.applyTheme(${if (night) "true" else "false"}, '$accentHex');", null)
                    pushCurrentDayToWeb()
                }
            }
            loadUrl("https://appassets.androidplatform.net/assets/day_timeline_v10.html")
        }
        webView = wv
        root.addView(wv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        updateNextBtnState()
    }

    private fun shiftDay(delta: Int) {
        val today = DataStore.todayIso()
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance().apply {
            time = try { fmt.parse(currentIso) ?: Date() } catch (_: Exception) { Date() }
            add(Calendar.DAY_OF_YEAR, delta)
        }
        val nextIso = fmt.format(cal.time)
        if (nextIso > today) return
        currentIso = nextIso
        tvDateTitle?.text = formatDateBn(currentIso)
        updateNextBtnState()
        if (pageReady) pushCurrentDayToWeb()
    }

    private fun updateNextBtnState() {
        val isToday = currentIso >= DataStore.todayIso()
        btnNextDay?.alpha = if (isToday) 0.28f else 1.0f
        btnNextDay?.isEnabled = !isToday
    }

    private fun pushCurrentDayToWeb() {
        val payload = DataStore.buildTimelinePayloadForDay(this, currentIso)
        val recSynced = try { JSONObject(payload).optBoolean("synced", false) } catch (_: Exception) { false }
        val editable = DataStore.isTimelineEditable(this, currentIso)
        tvSyncSub?.text = when {
            !editable -> "🔒 লকড (শুধু দেখার জন্য)"
            recSynced -> "Drive সিঙ্কড"
            else -> "এডিটযোগ্য · Drive সিঙ্ক প্রস্তুত"
        }
        val quoted = JSONObject.quote(payload)
        webView?.evaluateJavascript("window.hydrateDay($quoted);", null)
    }

    private fun formatDateBn(iso: String): String {
        if (iso == DataStore.todayIso()) return "আজ (${DataStore.toBnDigits(iso.takeLast(2))})"
        return try {
            val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val d = fmt.parse(iso) ?: return iso
            val out = SimpleDateFormat("dd MMM, EEE", Locale("bn", "BD")).format(d)
            DataStore.toBnDigits(out)
        } catch (_: Exception) {
            DataStore.toBnDigits(iso)
        }
    }

    private fun isNightActive(): Boolean {
        val mode = DataStore.getThemeMode(this)
        if (mode == "dark") return true
        if (mode == "light") return false
        val ui = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return ui == Configuration.UI_MODE_NIGHT_YES
    }

    override fun onPause() {
        webView?.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView?.onResume()
    }

    override fun onDestroy() {
        webView?.let { wv ->
            wv.stopLoading()
            wv.removeJavascriptInterface("AndroidTimeline")
            wv.destroy()
        }
        webView = null
        super.onDestroy()
    }
}
