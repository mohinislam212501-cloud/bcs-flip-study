package com.bcs.flipstudy

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        // প্রসেস ক্র্যাশ বা সোয়াইপ হয়ে বন্ধ হলে ফোরগ্রাউন্ড ফ্ল্যাগ যেন true আটকে না থাকে
        DataStore.setSrAppForeground(this, false)
    }
}
