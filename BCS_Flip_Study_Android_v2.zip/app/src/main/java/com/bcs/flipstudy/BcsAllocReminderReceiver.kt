package com.bcs.flipstudy

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import java.util.Calendar

class BcsAllocReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent?) {
        schedule(ctx) // পরের দিনের জন্য
        val today = DataStore.todayIso()
        if (DataStore.getBcsAllocNotifDay(ctx) == today) return
        val bcsSec = DataStore.loadAllDays(ctx)[today]?.subjects?.get("BCS প্রস্তুতি") ?: 0L
        if (bcsSec < 20L * 60L) return
        DataStore.setBcsAllocNotifDay(ctx, today)

        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val chId = "bcs_alloc_daily_reminder"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(chId, "পড়ার বিষয় ভাগ করার রিমাইন্ডার", NotificationManager.IMPORTANCE_DEFAULT)
            nm.createNotificationChannel(ch)
        }
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(ctx, chId)
            .setSmallIcon(R.drawable.ic_notif_mascot)
            .setContentTitle("আজকের পড়ার বিষয় ভাগ করা বাকি")
            .setContentText("BCS প্রস্তুতিতে ${DataStore.formatHoursMinBn(bcsSec)} জমা আছে। রিপোর্টে গিয়ে বিষয় এসাইন করো।")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(1004, n)
    }

    companion object {
        fun schedule(ctx: Context) {
            // দিন শেষ হওয়ার ৩ ঘণ্টা আগে (ডিফল্ট রাত ৯:০০, কাস্টম ডে-বাউন্ডারি মেনে চলে)
            val targetMinOfDay = (DataStore.getDayStartMin(ctx) - 180 + 1440) % 1440
            val c = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, targetMinOfDay / 60)
                set(Calendar.MINUTE, targetMinOfDay % 60)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            val pi = PendingIntent.getBroadcast(
                ctx, 5001, Intent(ctx, BcsAllocReminderReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            try {
                (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager)
                    .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.timeInMillis, pi)
            } catch (_: Exception) {}
        }
    }
}
