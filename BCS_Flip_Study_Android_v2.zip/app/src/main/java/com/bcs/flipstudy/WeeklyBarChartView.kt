package com.bcs.flipstudy

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

class WeeklyBarChartView @JvmOverloads constructor(
    ctx: Context,
    attrs: AttributeSet? = null
) : View(ctx, attrs) {

    private var bars: List<ChartBar> = emptyList()
    private val density = resources.displayMetrics.density
    private val rect = RectF()
    private val path = Path()

    private val studyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0F766E") }
    private val wastePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E11D48") }
    private val sleepPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#4F46E5") }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#667085")
        textAlign = Paint.Align.CENTER
    }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E4E8F0")
        strokeWidth = 1f * density
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(6f * density, 6f * density), 0f)
    }
    private val axisPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#667085")
        textAlign = Paint.Align.LEFT
    }

    fun setColors(study: Int, waste: Int, sleep: Int, grid: Int, label: Int) {
        studyPaint.color = study
        wastePaint.color = waste
        sleepPaint.color = sleep
        gridPaint.color = grid
        labelPaint.color = label
        axisPaint.color = label
        invalidate()
    }

    fun setBars(list: List<ChartBar>) {
        bars = list
        invalidate()
    }

    private fun topRounded(l: Float, t: Float, r: Float, b: Float, rad: Float, p: Paint, c: Canvas) {
        if (b - t < 1f) return
        val rr = minOf(rad, (r - l) / 2f, b - t)
        path.reset()
        path.moveTo(l, b)
        path.lineTo(l, t + rr)
        path.quadTo(l, t, l + rr, t)
        path.lineTo(r - rr, t)
        path.quadTo(r, t, r, t + rr)
        path.lineTo(r, b)
        path.close()
        c.drawPath(path, p)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val padTop = 8f * density
        val padBottom = 24f * density
        val padLeft = 30f * density
        val padRight = 4f * density
        val chartH = (height - padTop - padBottom).coerceAtLeast(40f)
        val chartW = (width - padLeft - padRight).coerceAtLeast(100f)

        val maxMin = if (bars.isEmpty()) 60f
        else bars.maxOf { maxOf(maxOf(it.studyMin, it.wasteMin), maxOf(it.sleepMin, 60)) }.toFloat()
        // ওপরের অক্ষ ঘণ্টায়: একটা সুন্দর রাউন্ড সংখ্যা
        val maxHours = Math.ceil(maxMin / 60.0).toInt().coerceAtLeast(1)
        val axisMax = maxHours * 60f

        axisPaint.textSize = 10f * density
        for (i in 0..2) {
            val y = padTop + chartH * i / 2f
            canvas.drawLine(padLeft, y, width - padRight, y, gridPaint)
            val hours = (maxHours * (2 - i) / 2f)
            val label = DataStore.toBnDigits(if (hours % 1f == 0f) hours.toInt().toString() else String.format(java.util.Locale.US, "%.1f", hours)) + "ঘ"
            canvas.drawText(label, 0f, y + 4f * density, axisPaint)
        }
        if (bars.isEmpty()) return

        val groupW = chartW / bars.size
        val barW = (groupW * 0.26f).coerceIn(2f * density, 14f * density)
        val labelStep = when {
            bars.size > 20 -> 5
            bars.size > 10 -> 2
            else -> 1
        }
        labelPaint.textSize = (if (bars.size > 12) 9f else 11f) * density
        val rad = (barW / 2f).coerceAtMost(4f * density)

        bars.forEachIndexed { idx, b ->
            val cx = padLeft + groupW * idx + groupW / 2f
            val baseY = padTop + chartH

            val sH = (b.studyMin / axisMax) * chartH
            val wH = (b.wasteMin / axisMax) * chartH
            val slH = (b.sleepMin / axisMax) * chartH

            topRounded(cx - barW * 1.5f, baseY - sH, cx - barW * 0.5f, baseY, rad, studyPaint, canvas)
            topRounded(cx - barW * 0.5f, baseY - wH, cx + barW * 0.5f, baseY, rad, wastePaint, canvas)
            topRounded(cx + barW * 0.5f, baseY - slH, cx + barW * 1.5f, baseY, rad, sleepPaint, canvas)

            if (idx % labelStep == 0 || idx == bars.size - 1) {
                canvas.drawText(b.label, cx, height - 6f * density, labelPaint)
            }
        }
    }
}
