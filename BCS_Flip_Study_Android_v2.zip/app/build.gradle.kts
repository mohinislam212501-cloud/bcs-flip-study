plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.bcs.flipstudy"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.bcs.flipstudy"
        minSdk = 26
        targetSdk = 34
        versionCode = 14
        versionName = "8.4"
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file("bcs_fixed.p12")
            storePassword = "bcsflip2026"
            keyAlias = "bcskey"
            keyPassword = "bcsflip2026"
            storeType = "PKCS12"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("debug")
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
}
